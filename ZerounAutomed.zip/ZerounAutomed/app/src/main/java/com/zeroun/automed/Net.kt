package com.zeroun.automed

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Net {
    fun post(base: String, path: String, body: JSONObject): JSONObject? = try {
        val c = URL(base + path).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 10000; c.readTimeout = 15000; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val txt = (if (c.responseCode < 400) c.inputStream else c.errorStream).bufferedReader().readText()
        JSONObject(txt)
    } catch (e: Exception) { null }
}
