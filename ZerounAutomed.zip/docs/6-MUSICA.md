# 🎵 Aba Música — "Mediação com música"

Botão **Música** na barra de baixo (entre *Salas* e *Controle*).

## O que tem na tela
| Parte | O que faz |
|---|---|
| 🔎 Barra de pesquisa | Digite o nome da música ou cole um link do YouTube (igual ao `!play` do `index.js`) |
| Resultados | Toque numa música para tocar. Ficam salvos: repetir a mesma busca **não vai ao YouTube** (botão *Atualizar* força uma busca nova) |
| 🔥 Mais ouvidas | As músicas que **o usuário** mais tocou (conta como ouvida quando o áudio realmente começa) |
| 🕘 Recentes | As últimas músicas **do usuário** (cada usuário só vê as suas) |
| ▶ Player (embaixo) | Play/pausa, anterior, próxima, barra de tempo e fechar. Continua tocando com a tela apagada (notificação com botões) |

## Como procura e toca (igual ao index.js)
| index.js (bot de call) | App (no celular) |
|---|---|
| `yt-dlp ytsearch1:<busca>` → título + link | `YT.buscar()` → busca no YouTube, devolve título, canal, duração e capa |
| `yt-dlp -f bestaudio` | `YT.resolver()` → pega o melhor áudio (m4a) |
| `cache` (busca → resultado) | `MusicaStore` → `files/musica.json` |
| `ffmpeg` → Discord | `MediaPlayer` toca no próprio celular |

## O que fica salvo no celular (`files/musica.json` + `files/capas/`)
- `faixas`: músicas em que o usuário clicou · `buscas`: resultado de cada pesquisa · `streams`: endereço do áudio (reaproveitado enquanto vale, ~6 h) · `usuarios`: plays e última vez de cada usuário.
- **Não usa a key nem o servidor.** Se a key acabar, tudo continua salvo; ao comprar outra, as músicas e buscas já estão lá (Sair/trocar de key não apaga nada).
- Entra no backup do Google (`allowBackup`), então reinstalar o app restaura.

## Se a música parar de tocar um dia
O YouTube muda de vez em quando (o mesmo acontece com o yt-dlp). A lista de "clientes" fica no topo de `Musica.kt` (`YT.clientes`): atualize as versões lá e lance o app de novo. A busca e o histórico não são afetados.

## Arquivos
`Musica.kt` (YouTube + JSON + capas + estado da busca) · `Tocador.kt` (player e serviço da notificação) · `MusicaUI.kt` (tela).

## Playlists e Favoritas (versão estilo Spotify)
- **Início / Buscar / Playlists** (botões no topo da aba). Cada música tem ❤ (guarda nas **Músicas Favoritas**) e ＋ (salvar em qualquer playlist ou criar uma nova na hora).
- A tela da playlist tem capa (mosaico 2x2), nome, ▶ tocar, 🔀 aleatório e ⋮ (renomear / excluir).
- Tocar na mini barra abre o **player grande** (capa, ❤, barra de tempo, anterior/próxima).
- Tudo fica em `files/musica.json` (chave `playlists`), junto com o resto da música.

## Por que a música demorava ~4 s (e o que mudou)
Antes: o app chamava `/musica/preparar` e depois `/musica/audio` (que ainda redirecionava para o CDN) → 2 idas ao servidor + redirecionamento.
Agora: `/musica/preparar` já devolve o endereço direto do CDN (`url`), o app toca direto de lá, o servidor pré-aquece as 3 primeiras músicas da busca, e o app pré-carrega a próxima música da fila.

## Sem internet (músicas baixadas)
- Música que está em **qualquer playlist (inclusive Favoritas)** é baixada sozinha para o celular (`files/audio/`). No topo da playlist, o botão ⬇ baixa todas; o ✓ verde na linha mostra as que já estão salvas.
- Música baixada toca **sem internet e sem servidor**. A lista, as playlists, as buscas já feitas e as capas também ficam salvas.
- Para baixar a primeira vez precisa de internet. Se o arquivo estragar, o app apaga e baixa de novo.

## Baixar tudo automático
Ao abrir o app (e a cada 5 min) ele baixa **todas as músicas que conhece** (tocadas, favoritas e de playlists) quando o celular está no **Wi-Fi**, e para se sobrar menos de ~1 GB de espaço. Quem falhou espera 1 h para tentar de novo. Roda enquanto o app está aberto.

## Visual ZEROUN (preto e branco)
A aba Música deixou o estilo Spotify e usa a identidade da Zeroun (avatar + banner do bot):
- Paleta só preto/branco/cinza, e **segue o tema claro/escuro do app** (antes era sempre escura). Destaque = preto no claro, branco no escuro (sem verde).
- Imagens em `res/drawable-nodpi/`: `zeroun_avatar.webp` (robô no cabeçalho, estados vazios e "carregando" piscando) e `zeroun_banner.webp` (topo do Início).
- Cabeçalho "ZEROUN / MÚSICA" com linha fina, abas em cantos quadrados, títulos de seção em caixa alta com barrinha, marca d'água "ZEROUN" ao fundo e selo GG/ZEROUN no fim do Início.
- Cantos mais arredondados nas capas, mini player com contorno, botão de tocar quadrado e player grande com "ZEROUN · TOCANDO".
- Música tocando: barrinha lateral + título em negrito (em vez de texto verde).
- Todas as cores ficam no objeto `Sp` do topo de `MusicaUI.kt`; a estrutura e a lógica não mudaram.
