plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.zeroun.automed"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.zeroun.automed"
        minSdk = 26
        targetSdk = 34
        // O GitHub (Actions) escolhe a versão sozinho: sempre 1 número acima da última Release.
        // Só mude "versaoBase" se quiser PULAR para uma versão maior (ex.: "4.0.0").
        val versaoBase = "3.6.0"
        val nomeDaVersao = (project.findProperty("versaoApp") as String?) ?: versaoBase
        versionName = nomeDaVersao
        versionCode = nomeDaVersao.split(".").let { it[0].toInt() * 10000 + it[1].toInt() * 100 + it[2].toInt() }
    }

    // Assinatura FIXA: qualquer computador gera um APK com a MESMA assinatura,
    // então o ID do celular não muda e a key não é desvinculada ao atualizar.
    signingConfigs {
        create("zeroun") {
            storeFile = file("zeroun.jks")
            storePassword = "zeroun2026"
            keyAlias = "zeroun"
            keyPassword = "zeroun2026"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("zeroun") }
        getByName("release") { signingConfig = signingConfigs.getByName("zeroun") }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
}

dependencies {
    val bom = platform("androidx.compose:compose-bom:2024.06.00")
    implementation(bom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.core:core-ktx:1.13.1")
}
