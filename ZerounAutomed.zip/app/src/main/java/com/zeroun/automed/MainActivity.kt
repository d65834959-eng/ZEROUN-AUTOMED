package com.zeroun.automed

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Cor {
    val Fundo = Color(0xFF0B0A14)
    val Fundo2 = Color(0xFF15102E)
    val Card = Color(0xFF1A1733)
    val Card2 = Color(0xFF231F45)
    val Roxo = Color(0xFF8B5CF6)
    val Ciano = Color(0xFF22D3EE)
    val Verde = Color(0xFF22C55E)
    val Rosa = Color(0xFFEC4899)
    val Laranja = Color(0xFFF59E0B)
    val Vermelho = Color(0xFFEF4444)
    val Azul = Color(0xFF3B82F6)
    val Texto = Color(0xFFEDEBFF)
    val Muted = Color(0xFF9A96C0)
}

enum class Tela(val emoji: String, val titulo: String) {
    HOME("🏠", "Início"),
    MENSAGENS("💬", "Mensagens"),
    SALAS("🎮", "Comandos de sala"),
    CONTA("👤", "Conta e servidores"),
    PIX("💸", "Pix lidos"),
    ATIVIDADE("📜", "Atividade"),
    CONEXAO("🔗", "Conexão"),
    FONTE("📩", "Fonte dos Pix"),
    APPS("📱", "Apps monitorados"),
    PERMISSAO("🔔", "Permissão")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Estado.init(applicationContext)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Cor.Roxo, secondary = Cor.Ciano,
                    background = Cor.Fundo, surface = Cor.Card,
                    onPrimary = Color.White, onBackground = Cor.Texto, onSurface = Cor.Texto
                )
            ) { App() }
        }
    }

    override fun onResume() {
        super.onResume()
        Estado.tick = Estado.tick + 1
        if (Prefs.conectado) { Estado.atualizar(); Painel.carregar() }
    }
}

// ───────────────────────── utilidades ─────────────────────────

fun brl(v: Double): String = String.format(Locale("pt", "BR"), "R$ %,.2f", v)
fun hora(ts: Long): String = SimpleDateFormat("dd/MM HH:mm", Locale("pt", "BR")).format(Date(ts))
fun permissaoOk(c: Context): Boolean =
    NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)

fun origemTxt(p: PixItem): String =
    if (p.origem == "gmail") "✉️ E-mail Gmail (bot)"
    else "🔔 Notificação · " + p.fonte.ifBlank { "app" }

// ───────────────────────── raiz ─────────────────────────

@Composable
fun App() {
    var tela by remember { mutableStateOf(Tela.HOME) }
    BackHandler(enabled = tela != Tela.HOME) { tela = Tela.HOME }
    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Cor.Fundo, Cor.Fundo2, Cor.Fundo)))
    ) {
        if (tela == Tela.HOME) Home { tela = it }
        else Secao(tela) { tela = Tela.HOME }
    }
}

// ───────────────────────── componentes ─────────────────────────

@Composable
fun Pill(texto: String, cor: Color) {
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(cor.copy(alpha = 0.18f))
            .border(1.dp, cor.copy(alpha = 0.5f), RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(cor))
        Spacer(Modifier.width(7.dp))
        Text(texto, color = cor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Cartao(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Column(
        modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Cor.Card)
            .border(1.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(20.dp))
            .padding(16.dp)
    ) { content() }
}

@Composable
fun Botao(texto: String, cor: Color = Cor.Roxo, modifier: Modifier = Modifier.fillMaxWidth(), onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier.height(52.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = cor, contentColor = Color.White)
    ) { Text(texto, fontWeight = FontWeight.Bold, fontSize = 15.sp) }
}

@Composable
fun BotaoCategoria(emoji: String, titulo: String, sub: String, cor: Color, modifier: Modifier, onClick: () -> Unit) {
    val forma = RoundedCornerShape(22.dp)
    Column(
        modifier.clip(forma)
            .background(Brush.linearGradient(listOf(cor.copy(alpha = 0.32f), Cor.Card)))
            .border(1.dp, cor.copy(alpha = 0.5f), forma)
            .clickable(onClick = onClick)
            .padding(16.dp)
    ) {
        Box(
            Modifier.size(46.dp).clip(CircleShape).background(cor.copy(alpha = 0.28f)),
            contentAlignment = Alignment.Center
        ) { Text(emoji, fontSize = 22.sp) }
        Spacer(Modifier.height(12.dp))
        Text(titulo, color = Cor.Texto, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(2.dp))
        Text(sub, color = Cor.Muted, fontSize = 12.sp, maxLines = 2)
    }
}

@Composable
fun Secao(tela: Tela, onVoltar: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(Cor.Card2).clickable(onClick = onVoltar),
                contentAlignment = Alignment.Center
            ) { Text("←", color = Cor.Texto, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.width(12.dp))
            Text(tela.emoji + "  " + tela.titulo, color = Cor.Texto, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
        }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (tela) {
                Tela.MENSAGENS -> MensagensTela()
                Tela.SALAS -> SalasTela()
                Tela.CONTA -> ContaTela()
                Tela.PIX -> PixTela()
                Tela.CONEXAO -> ConexaoTela()
                Tela.FONTE -> FonteTela()
                Tela.APPS -> AppsTela()
                Tela.PERMISSAO -> PermissaoTela()
                Tela.ATIVIDADE -> AtividadeTela()
                Tela.HOME -> {}
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

// ───────────────────────── início ─────────────────────────

@Composable
fun Home(ir: (Tela) -> Unit) {
    val ctx = LocalContext.current
    val perm = remember(Estado.tick) { permissaoOk(ctx) }
    val ultimo = Estado.pix.firstOrNull()

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("ZEROUN", color = Cor.Roxo, fontSize = 13.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
                Text("AUTOMED", color = Cor.Texto, fontSize = 28.sp, fontWeight = FontWeight.Black)
            }
            if (Estado.online) Pill("Online", Cor.Verde) else Pill("Desconectado", Cor.Vermelho)
        }

        // último Pix lido
        val forma = RoundedCornerShape(26.dp)
        Column(
            Modifier.fillMaxWidth().clip(forma)
                .background(Brush.linearGradient(listOf(Cor.Roxo.copy(alpha = 0.55f), Cor.Card, Cor.Ciano.copy(alpha = 0.25f))))
                .border(1.dp, Color.White.copy(alpha = 0.1f), forma)
                .clickable { ir(Tela.PIX) }
                .padding(20.dp)
        ) {
            Text("ÚLTIMO PIX LIDO", color = Cor.Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Spacer(Modifier.height(8.dp))
            if (ultimo == null) {
                Text("Aguardando o próximo Pix…", color = Cor.Texto, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text("Toque para ver os Pix lidos", color = Cor.Muted, fontSize = 12.sp)
            } else {
                Text(brl(ultimo.valor), color = Cor.Verde, fontSize = 34.sp, fontWeight = FontWeight.Black)
                Text(ultimo.nome.ifBlank { "Sem nome" }, color = Cor.Texto, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(origemTxt(ultimo) + "  •  " + hora(ultimo.ts), color = Cor.Muted, fontSize = 12.sp)
            }
        }

        TituloGrupo("CONFIGURAR O BOT", Cor.Roxo)
        GradeCategorias(
            listOf(
                Triple(
                    Tela.MENSAGENS, Cor.Rosa,
                    if (!Painel.carregado) "Textos, variáveis e modo fantasma"
                    else (if (Painel.fantasma) "👻 Fantasma ligado · " else "") + "${Painel.variaveis.size} variável(is)"
                ),
                Triple(Tela.SALAS, Cor.Laranja, "Normal, infinita, full capa, tática, speed"),
                Triple(
                    Tela.CONTA, Cor.Ciano,
                    if (!Painel.carregado) "Conta, servidores e antiban"
                    else "${Painel.servidores.size} servidor(es) · ${Painel.servidores.count { it.antiban }} antiban"
                )
            ),
            ir
        )

        TituloGrupo("PAGAMENTOS", Cor.Verde)
        GradeCategorias(
            listOf(
                Triple(Tela.PIX, Cor.Verde, "Hoje: ${Estado.hoje} • ${brl(Estado.totalHoje)}"),
                Triple(Tela.ATIVIDADE, Cor.Azul, "${Estado.eventos.size} notificações vistas")
            ),
            ir
        )

        TituloGrupo("ESTE CELULAR", Cor.Laranja)
        GradeCategorias(
            listOf(
                Triple(Tela.CONEXAO, Cor.Roxo, if (Estado.online) "Online" else "Desconectado"),
                Triple(Tela.FONTE, Cor.Rosa, if (Estado.gmail) "Gmail" else "Apps escolhidos"),
                Triple(Tela.APPS, Cor.Azul, "${Estado.apps.size}/5 selecionados"),
                Triple(Tela.PERMISSAO, Cor.Laranja, if (perm) "Liberada ✓" else "Pendente — toque")
            ),
            ir
        )
        Spacer(Modifier.height(10.dp))
        Text(
            "Zeroun Store • sempre em outro nível", color = Cor.Muted, fontSize = 11.sp,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
        )
    }
}

// ───────────────────────── Pix lidos ─────────────────────────

@Composable
fun PixTela() {
    LaunchedEffect(Unit) { if (Prefs.conectado) Estado.atualizar() }

    Cartao {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("HOJE", color = Cor.Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text(brl(Estado.totalHoje), color = Cor.Verde, fontSize = 28.sp, fontWeight = FontWeight.Black)
                Text("${Estado.hoje} Pix lido(s)", color = Cor.Muted, fontSize = 12.sp)
            }
            Botao(
                if (Estado.atualizando) "…" else "Atualizar", Cor.Card2,
                Modifier.width(120.dp)
            ) { Estado.atualizar() }
        }
    }

    if (Estado.ativoApp == false) {
        Cartao(Modifier.border(1.dp, Cor.Laranja.copy(alpha = 0.6f), RoundedCornerShape(20.dp))) {
            Text("⚠️ Notificações do app desligadas no bot", color = Cor.Laranja, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(
                "No Discord, ligue \"Ativar notificações app\". Enquanto estiver desligado, o bot ignora o celular e lê só o Gmail.",
                color = Cor.Muted, fontSize = 12.sp
            )
        }
    }
    if (Estado.msgServidor.isNotBlank()) {
        Text(Estado.msgServidor, color = Cor.Vermelho, fontSize = 12.sp)
    }

    if (Estado.pix.isEmpty()) {
        Cartao {
            Text("Nenhum Pix lido ainda.", color = Cor.Texto, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(
                "Se você já recebeu Pix e nada apareceu, abra \"Atividade\" para ver o que o celular recebeu e o que o bot respondeu.",
                color = Cor.Muted, fontSize = 12.sp
            )
        }
    } else {
        Estado.pix.forEach { PixLinha(it) }
    }
}

@Composable
fun PixLinha(p: PixItem) {
    val cor = if (p.origem == "gmail") Cor.Rosa else Cor.Ciano
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Cor.Card)
            .border(1.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(18.dp)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(44.dp).clip(CircleShape).background(cor.copy(alpha = 0.22f)),
            contentAlignment = Alignment.Center
        ) {
            Text(p.nome.trim().take(1).uppercase().ifBlank { "?" }, color = cor, fontWeight = FontWeight.Black, fontSize = 18.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(p.nome.ifBlank { "Sem nome" }, color = Cor.Texto, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
            Text(origemTxt(p), color = cor, fontSize = 11.sp, maxLines = 1)
            Text(hora(p.ts), color = Cor.Muted, fontSize = 11.sp)
        }
        Spacer(Modifier.width(8.dp))
        Text(brl(p.valor), color = Cor.Verde, fontWeight = FontWeight.Black, fontSize = 17.sp)
    }
}

// ───────────────────────── conexão ─────────────────────────

@Composable
fun ConexaoTela() {
    var url by remember { mutableStateOf(Prefs.url) }
    var key by remember { mutableStateOf(Prefs.key) }
    var msg by remember { mutableStateOf("") }
    var carregando by remember { mutableStateOf(false) }

    Cartao {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Status", color = Cor.Muted, modifier = Modifier.weight(1f))
            if (Estado.online) Pill("Online", Cor.Verde) else Pill("Desconectado", Cor.Vermelho)
        }
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            value = url, onValueChange = { url = it }, singleLine = true,
            label = { Text("Endereço do bot (ex.: http://192.168.0.10:3000)") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = key, onValueChange = { key = it }, singleLine = true,
            label = { Text("Key ZEROUN-AUTOMED-…") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(14.dp))
        Botao(if (carregando) "Conectando…" else if (Estado.online) "Reconectar" else "Conectar") {
            if (!carregando) {
                carregando = true; msg = ""
                Prefs.url = url.trim()
                Prefs.key = key.trim().uppercase()
                Thread {
                    val r = Net.post("/api/key", Net.corpo())
                    val ok = r?.optBoolean("ok", false) == true
                    val m = if (r == null) "Sem resposta do bot. Confira o endereço." else r.optString("msg", "")
                    if (ok) Net.post("/api/modo", Net.corpo().put("modo", if (Prefs.gmail) "gmail" else "apps"))
                    Prefs.conectado = ok
                    Estado.ui { Estado.online = ok; msg = m; carregando = false }
                    if (ok) Estado.atualizar()
                }.start()
            }
        }
    }
    if (msg.isNotBlank()) {
        Text(msg, color = if (Estado.online) Cor.Verde else Cor.Vermelho, fontSize = 13.sp)
    }
}

// ───────────────────────── fonte ─────────────────────────

@Composable
fun Opcao(emoji: String, titulo: String, sub: String, cor: Color, marcada: Boolean, onClick: () -> Unit) {
    val forma = RoundedCornerShape(20.dp)
    Row(
        Modifier.fillMaxWidth().clip(forma)
            .background(if (marcada) cor.copy(alpha = 0.18f) else Cor.Card)
            .border(BorderStroke(if (marcada) 2.dp else 1.dp, if (marcada) cor else Color.White.copy(alpha = 0.08f)), forma)
            .clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(46.dp).clip(CircleShape).background(cor.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) {
            Text(emoji, fontSize = 22.sp)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(titulo, color = Cor.Texto, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(sub, color = Cor.Muted, fontSize = 12.sp)
        }
        if (marcada) Text("✓", color = cor, fontSize = 22.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
fun FonteTela() {
    Text("De onde o celular deve ler os Pix?", color = Cor.Muted, fontSize = 13.sp)
    Opcao("✉️", "Ler notificações do Gmail", "Só as notificações do app Gmail", Cor.Rosa, Estado.gmail) { Estado.definirFonte(true) }
    Opcao("📱", "Ler notificações dos apps escolhidos", "Até 5 apps (Nubank, bancos…)", Cor.Azul, !Estado.gmail) { Estado.definirFonte(false) }
    Cartao {
        Text("Dica", color = Cor.Texto, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(
            "Cada Pix lido mostra de onde veio: \"🔔 Notificação\" (celular) ou \"✉️ E-mail Gmail (bot)\" (o bot leu o e-mail).",
            color = Cor.Muted, fontSize = 12.sp
        )
    }
}

// ───────────────────────── apps ─────────────────────────

@Suppress("DEPRECATION")
fun carregarApps(c: Context): List<Pair<String, String>> {
    val pm = c.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .map { Pair(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
        .filter { it.first != c.packageName }
        .distinctBy { it.first }
        .sortedBy { it.second.lowercase() }
}

@Composable
fun AppsTela() {
    val ctx = LocalContext.current
    var lista by remember { mutableStateOf<List<Pair<String, String>>?>(null) }
    var aviso by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        Thread {
            val r = carregarApps(ctx)
            Estado.ui { lista = r }
        }.start()
    }

    Cartao {
        Text("Selecionados: ${Estado.apps.size}/5", color = Cor.Texto, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(2.dp))
        Text(
            if (Estado.gmail) "A fonte atual é o Gmail — mude em \"Fonte dos Pix\" para usar estes apps."
            else "O app lê as notificações destes apps.",
            color = Cor.Muted, fontSize = 12.sp
        )
        if (aviso.isNotBlank()) { Spacer(Modifier.height(6.dp)); Text(aviso, color = Cor.Laranja, fontSize = 12.sp) }
    }

    val itens = lista
    if (itens == null) {
        Text("Carregando apps…", color = Cor.Muted)
    } else {
        itens.forEach { (pkg, nome) ->
            val marcado = Estado.apps.contains(pkg)
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                    .background(if (marcado) Cor.Azul.copy(alpha = 0.18f) else Cor.Card)
                    .clickable {
                        aviso = ""
                        if (marcado) Estado.salvarApps(Estado.apps - pkg)
                        else if (Estado.apps.size >= 5) aviso = "Máximo de 5 apps. Desmarque um para escolher outro."
                        else Estado.salvarApps(Estado.apps + pkg)
                    }
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = marcado, onCheckedChange = null,
                    colors = CheckboxDefaults.colors(checkedColor = Cor.Azul)
                )
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(nome, color = Cor.Texto, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    Text(pkg, color = Cor.Muted, fontSize = 10.sp, maxLines = 1)
                }
            }
        }
    }
}

// ───────────────────────── permissão ─────────────────────────

@Composable
fun PermissaoTela() {
    val ctx = LocalContext.current
    val ok = remember(Estado.tick) { permissaoOk(ctx) }
    Cartao {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Acesso às notificações", color = Cor.Texto, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (ok) Pill("Liberado", Cor.Verde) else Pill("Pendente", Cor.Laranja)
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "Sem essa permissão o app não consegue ler as notificações de Pix.",
            color = Cor.Muted, fontSize = 12.sp
        )
        Spacer(Modifier.height(14.dp))
        Botao("Permitir acesso às notificações", Cor.Laranja) {
            ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
    Cartao {
        Text("Android bloqueou?", color = Cor.Texto, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(
            "Em Configurações → Apps → ZEROUN AUTOMED → menu ⋮ → \"Permitir configurações restritas\". Depois volte e ative o acesso.",
            color = Cor.Muted, fontSize = 12.sp
        )
    }
}

// ───────────────────────── atividade ─────────────────────────

@Composable
fun AtividadeTela() {
    Text(
        "Tudo que o celular enviou ao bot e o que o bot respondeu. Útil para descobrir por que um Pix não apareceu.",
        color = Cor.Muted, fontSize = 12.sp
    )
    if (Estado.eventos.isNotEmpty()) {
        Botao("Limpar", Cor.Card2, Modifier.width(120.dp)) { Estado.limparEventos() }
    }
    if (Estado.eventos.isEmpty()) {
        Cartao { Text("Nenhuma notificação lida ainda.", color = Cor.Texto, fontWeight = FontWeight.Bold) }
    }
    Estado.eventos.forEach { e ->
        val cor = when (e.tipo) { 1 -> Cor.Verde; 2 -> Cor.Laranja; else -> Cor.Muted }
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Cor.Card)
                .border(1.dp, cor.copy(alpha = 0.35f), RoundedCornerShape(16.dp)).padding(14.dp)
        ) {
            Row {
                Text(e.app, color = Cor.Texto, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1)
                Text(hora(e.ts), color = Cor.Muted, fontSize = 11.sp)
            }
            Spacer(Modifier.height(4.dp))
            Text(e.texto, color = Cor.Muted, fontSize = 12.sp, maxLines = 3)
            Spacer(Modifier.height(6.dp))
            Text(e.resultado, color = cor, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}
