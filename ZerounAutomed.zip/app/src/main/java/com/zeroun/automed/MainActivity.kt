package com.zeroun.automed

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalance
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Cancel
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home as IcoHome
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.Paid
import androidx.compose.material.icons.rounded.Payments
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Science
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Settings as IcoConfig
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.SystemUpdate
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material.icons.rounded.VpnKey
import androidx.compose.material.icons.rounded.ArrowBackIosNew
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.material3.Switch
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.Path
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Abas da barra de baixo (igual à foto). */
enum class Aba(val icone: ImageVector, val rotulo: String) {
    INICIO(Icons.Rounded.IcoHome, "Início"),
    BANCO(Icons.Rounded.AccountBalance, "Banco"),
    FINANCAS(Icons.Rounded.AccountBalanceWallet, "Finanças"),
    SALAS(Icons.Rounded.SportsEsports, "Salas"),
    MUSICA(Icons.Rounded.MusicNote, "Música"),
    CONTROLE(Icons.Rounded.IcoConfig, "Controle"),
    CONFIG(Icons.Rounded.Tune, "Ajustes"),
    ATUALIZACAO(Icons.Rounded.SystemUpdate, "Atualização");

    companion object {
        /** Key de música: só Atualização, Música e Banco. Key normal: todas, menos Atualização (fica em Ajustes). */
        fun visiveis(): List<Aba> =
            if (Estado.soMusica) listOf(ATUALIZACAO, MUSICA, BANCO)
            else values().filter { it != ATUALIZACAO }
    }
}

/** Telas que abrem por cima (a partir das abas, do sino ou do perfil). */
enum class Tela(val icone: ImageVector, val titulo: String) {
    LUCROS(Icons.Rounded.Paid, "Lucros"),
    IA(Icons.Rounded.SmartToy, "IA e canais de regras"),
    CONTA(Icons.Rounded.Person, "Conta e servidores"),
    PIX(Icons.Rounded.Payments, "Pix lidos"),
    ATIVIDADE(Icons.Rounded.History, "Atividade"),
    BANCOS(Icons.Rounded.AccountBalance, "Bancos vigiados"),
    AVISOS(Icons.Rounded.Notifications, "Notificações")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Estado.init(applicationContext)
        MusicaStore.init(applicationContext)
        Avisos.iniciar()
        Tema.escuro = Prefs.escuro
        setContent {
            val escuro = Tema.escuro
            val view = LocalView.current
            val janela = this@MainActivity.window
            SideEffect {
                janela.statusBarColor = Cor.Fundo.toArgb()
                janela.navigationBarColor = Cor.Fundo.toArgb()
                val ctl = WindowCompat.getInsetsController(janela, view)
                ctl.isAppearanceLightStatusBars = !escuro
                ctl.isAppearanceLightNavigationBars = !escuro
            }
            val esquema = if (escuro) darkColorScheme(
                primary = Cor.Marca, onPrimary = Cor.SobreMarca, secondary = Cor.Azul,
                background = Cor.Fundo, surface = Cor.Card, onBackground = Cor.Texto, onSurface = Cor.Texto,
                outline = Cor.Muted, outlineVariant = Cor.Borda
            ) else lightColorScheme(
                primary = Cor.Marca, onPrimary = Cor.SobreMarca, secondary = Cor.Azul,
                background = Cor.Fundo, surface = Cor.Card, onBackground = Cor.Texto, onSurface = Cor.Texto,
                outline = Cor.Muted, outlineVariant = Cor.Borda
            )
            val fam = remember { Fonte.familia(this@MainActivity) }
            MaterialTheme(colorScheme = esquema, typography = Fonte.tipografia(fam)) {
                CompositionLocalProvider(LocalTextStyle provides TextStyle(fontFamily = fam)) { App() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        Estado.tick = Estado.tick + 1
        if (Prefs.conectado) { Estado.atualizar(); Painel.carregar(); Gestao.carregarSistema(); Gestao.carregarLucros() }
    }
}

// ───────────────────────── utilidades ─────────────────────────

fun brl(v: Double): String = String.format(Locale("pt", "BR"), "R$ %,.2f", v)
fun hora(ts: Long): String = SimpleDateFormat("dd/MM HH:mm", Locale("pt", "BR")).format(Date(ts))
fun permissaoOk(c: Context): Boolean =
    NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)

fun bateriaOk(c: Context): Boolean = try {
    (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(c.packageName)
} catch (e: Exception) { false }

fun abrirPermissaoNotificacoes(c: Context) {
    try { c.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
}

fun pedirBateria(c: Context) {
    try {
        c.startActivity(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + c.packageName))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {
        try { c.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e2: Exception) { }
    }
}

fun nomeApp(c: Context, pkg: String): String = try {
    c.packageManager.getApplicationLabel(c.packageManager.getApplicationInfo(pkg, 0)).toString()
} catch (e: Exception) { pkg }

fun origemTxt(p: PixItem): String =
    if (p.origem == "gmail") "✉️ E-mail Gmail (bot)"
    else "🔔 Notificação · " + p.fonte.ifBlank { "app" }

// ───────────────────────── raiz: login → configuração → painel ─────────────────────────

@Composable
fun App() {
    val ctxApp = LocalContext.current
    val atualizacaoOk = remember(Estado.tick) { Atualizador.podeInstalar(ctxApp) }
    Box(Modifier.fillMaxSize().decoracao()) {
        when {
            !Estado.logado -> LoginTela()
            (!Estado.setupOk && !Estado.soMusica) || !atualizacaoOk -> SetupTela()
            else -> Principal()
        }
    }
}

@Composable
fun Principal() {
    val abaInicial = if (Estado.soMusica) Aba.MUSICA else Aba.INICIO
    var aba by remember { mutableStateOf(abaInicial) }
    var sub by remember { mutableStateOf<Tela?>(null) }
    val ctxP = LocalContext.current
    LaunchedEffect(Estado.tick) { Atualizador.verificar(ctxP, false) }

    // vigia o bot em qualquer aba (é daqui que o sino fica atualizado)
    LaunchedEffect(Unit) {
        while (true) {
            delay(10_000)
            if (Prefs.conectado && !Estado.soMusica) { Estado.atualizar(); Gestao.carregarSistema() }
        }
    }

    BackHandler(enabled = sub != null || aba != abaInicial) {
        if (sub != null) sub = null else aba = abaInicial
    }

    /** O que cada botão dos avisos faz. */
    val abrir: (Destino) -> Unit = { d ->
        when (d) {
            Destino.PERMISSAO -> abrirPermissaoNotificacoes(ctxP)
            Destino.BATERIA -> pedirBateria(ctxP)
            Destino.RECONECTAR -> { Estado.atualizar(); Gestao.carregarSistema(); Painel.carregar() }
            Destino.ABA_CONFIG -> { sub = null; aba = Aba.CONFIG }
            Destino.ABA_CONTROLE -> { sub = null; aba = Aba.CONTROLE }
            Destino.TELA_CONTA -> { sub = Tela.CONTA }
            Destino.TELA_BANCOS -> { sub = Tela.BANCOS }
            Destino.TELA_ATIVIDADE -> { sub = Tela.ATIVIDADE }
            Destino.NENHUM -> { }
        }
    }

    CompositionLocalProvider(LocalAbrirAvisos provides { sub = Tela.AVISOS }) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) {
                val s = sub
                if (s != null) {
                    Secao(s, abrir) { sub = null }
                } else {
                    when (aba) {
                        Aba.INICIO -> Home(irAba = { aba = it }, irSub = { sub = it })
                        Aba.BANCO -> BancoAba()
                        Aba.FINANCAS -> FinancasAba()
                        Aba.SALAS -> ComandosAba()
                        Aba.MUSICA -> MusicaAba()
                        Aba.CONTROLE -> ControleAba(irSub = { sub = it })
                        Aba.CONFIG -> ConfigAba(irSub = { sub = it })
                        Aba.ATUALIZACAO -> AtualizacaoAba()
                    }
                }
            }
            if (sub == null) BarraInferior(aba) { aba = it }
        }
    }
}

// ───────────────────────── estrutura das páginas ─────────────────────────

/** Página de uma aba: título grande + sino de avisos + conteúdo rolável. */
@Composable
fun Pagina(titulo: String, sub: String, conteudo: @Composable () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(titulo, color = Cor.Texto, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
                Text(sub, color = Cor.Muted, fontSize = 15.sp)
            }
            Sino()
        }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            conteudo()
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
fun CabecalhoVoltar(titulo: String, icone: ImageVector?, onVoltar: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(44.dp).suave(CircleShape).clip(CircleShape).background(Cor.Card)
                .border(1.dp, Cor.Borda, CircleShape).clickable(onClick = onVoltar),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.ArrowBackIosNew, "Voltar", tint = Cor.Texto, modifier = Modifier.size(18.dp)) }
        Spacer(Modifier.width(12.dp))
        if (icone != null) { Icon(icone, null, tint = Cor.Texto, modifier = Modifier.size(24.dp)); Spacer(Modifier.width(8.dp)) }
        Text(titulo, color = Cor.Texto, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun Secao(tela: Tela, abrir: (Destino) -> Unit, onVoltar: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        CabecalhoVoltar(tela.titulo, tela.icone, onVoltar)
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (tela) {
                Tela.LUCROS -> LucrosTela()
                Tela.IA -> IaTela()
                Tela.CONTA -> ContaTela()
                Tela.PIX -> PixTela()
                Tela.ATIVIDADE -> AtividadeTela()
                Tela.BANCOS -> BancosConteudo()
                Tela.AVISOS -> AvisosTela(abrir)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

/** Barra de baixo flutuante: contorno arredondado, item ativo com fundo e traço embaixo (como na foto). */
@Composable
fun BarraInferior(sel: Aba, onSel: (Aba) -> Unit) {
    val forma = RoundedCornerShape(30.dp)
    Box(Modifier.fillMaxWidth().padding(start = 10.dp, end = 10.dp, top = 4.dp, bottom = 8.dp)) {
        Row(
            Modifier.fillMaxWidth().suave(forma).clip(forma).background(Cor.Card)
                .border(1.dp, Cor.Borda, forma).padding(horizontal = 4.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(1.dp)
        ) {
            Aba.visiveis().forEach { a ->
                val on = a == sel
                val item = RoundedCornerShape(22.dp)
                Column(
                    Modifier.weight(1f).clip(item)
                        .background(if (on) Cor.Card2 else Color.Transparent)
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onSel(a) }
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(a.icone, a.rotulo, tint = if (on) Cor.Texto else Cor.Muted, modifier = Modifier.size(24.dp))
                    Spacer(Modifier.height(3.dp))
                    Text(
                        a.rotulo, color = if (on) Cor.Texto else Cor.Muted, fontSize = 9.5.sp,
                        fontWeight = if (on) FontWeight.SemiBold else FontWeight.Medium,
                        maxLines = 1, softWrap = false
                    )
                    Spacer(Modifier.height(4.dp))
                    Box(Modifier.width(30.dp).height(2.dp).clip(RoundedCornerShape(1.dp)).background(if (on) Cor.Texto else Color.Transparent))
                }
            }
        }
    }
}

// ───────────────────────── 1) LOGIN COM A KEY ─────────────────────────

@Composable
fun LoginTela() {
    var key by remember { mutableStateOf(Prefs.key) }
    var msg by remember { mutableStateOf("") }
    var carregando by remember { mutableStateOf(false) }
    val clip = LocalClipboardManager.current

    fun conectar() {
        if (carregando) return
        if (key.isBlank()) { msg = "Digite a sua key."; return }
        carregando = true; msg = ""
        Prefs.key = key.trim().uppercase()
        Thread {
            val r = Net.post("/api/key", Net.corpo())
            val ok = r?.optBoolean("ok", false) == true
            val m = if (r == null) "Sem resposta do bot. Confira a internet." else r.optString("msg", if (ok) "" else "Key inválida.")
            if (ok && !Prefs.ehKeyMusica(r, Prefs.key)) {
                // instalação nova: o padrão é ler os apps dos bancos (não o Gmail)
                if (Prefs.apps.isEmpty()) Prefs.gmail = false
                Net.post("/api/modo", Net.corpo().put("modo", if (Prefs.gmail) "gmail" else "apps"))
            }
            Prefs.conectado = ok
            if (ok) Prefs.soMusica = Prefs.ehKeyMusica(r, Prefs.key)
            Estado.ui {
                carregando = false
                if (ok) { Estado.soMusica = Prefs.soMusica; Estado.gmail = Prefs.gmail; Estado.online = true; Estado.logado = true } else { Estado.online = false; msg = m }
            }
            if (ok && !Prefs.soMusica) { Estado.atualizar(); Painel.carregar(); Gestao.carregarSistema(); Gestao.carregarLucros() }
        }.start()
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { BotaoTema() }
        Spacer(Modifier.height(8.dp))
        LogoFoto(120.dp)
        Spacer(Modifier.height(16.dp))
        Text("AUTOMED", color = Cor.Azul, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 9.sp)
        Spacer(Modifier.height(14.dp))
        Text(
            "Confirme o Pix de qualquer banco", color = Cor.Texto, fontSize = 38.sp, lineHeight = 46.sp,
            fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(14.dp))
        Text(
            "O app vê o aviso de Pix do seu banco e conta pro seu Automed na hora.",
            color = Cor.Muted, fontSize = 17.sp, lineHeight = 25.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(28.dp))

        Cartao {
            Text("Digite a key", color = Cor.Texto, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(8.dp))
            Text(
                "No Discord, vá no canal do App Automed e toque em Pegar minha key. Vai aparecer a sua key.",
                color = Cor.Muted, fontSize = 16.sp, lineHeight = 23.sp
            )
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(
                value = key, onValueChange = { key = it.uppercase().replace(" ", ""); msg = "" },
                singleLine = true, shape = RoundedCornerShape(22.dp),
                placeholder = { Text("ZEROUN-AUTOMED-…", color = Cor.Muted.copy(alpha = 0.7f)) },
                leadingIcon = { Icon(Icons.Rounded.VpnKey, null, tint = Cor.Azul) },
                trailingIcon = {
                    Text(
                        "Colar", color = Cor.Azul, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp,
                        modifier = Modifier.padding(end = 8.dp).clip(RoundedCornerShape(12.dp))
                            .clickable { clip.getText()?.text?.let { key = it.trim().uppercase().replace(" ", ""); msg = "" } }
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                    )
                },
                textStyle = TextStyle(fontSize = 17.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, color = Cor.Texto),
                colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Cor.Azul, unfocusedBorderColor = Cor.Borda,
                    focusedContainerColor = Cor.Card2, unfocusedContainerColor = Cor.Card2
                ),
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters, imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { conectar() }),
                modifier = Modifier.fillMaxWidth().height(66.dp)
            )
            Spacer(Modifier.height(18.dp))
            Botao(if (carregando) "Conectando…" else "Conectar", icone = Icons.Rounded.Link, enabled = !carregando) { conectar() }
            if (msg.isNotBlank()) {
                Spacer(Modifier.height(12.dp))
                Text("⚠️ " + msg, color = Cor.Vermelho, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(Modifier.height(18.dp))
        Cartao {
            Text("Como funciona?", color = Cor.Texto, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(18.dp))
            PassoComo(Icons.Rounded.Notifications, Cor.Azul, "1", "O banco avisa no celular: \"Pix recebido\"")
            Spacer(Modifier.height(16.dp))
            PassoComo(Icons.Rounded.Send, Cor.Ciano, "2", "O app manda esse aviso pro seu Automed")
            Spacer(Modifier.height(16.dp))
            PassoComo(Icons.Rounded.CheckCircle, Cor.Verde, "3", "O Automed confere nome e valor e aprova a aposta")
        }
        Spacer(Modifier.height(22.dp))
        Text("Zeroun Store • sempre em outro nível", color = Cor.Muted, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun PassoComo(icone: ImageVector, cor: Color, n: String, texto: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(58.dp).clip(CircleShape).background(cor.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
            Icon(icone, null, tint = cor, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.width(14.dp))
        Text(n + ".", color = cor, fontWeight = FontWeight.ExtraBold, fontSize = 19.sp)
        Spacer(Modifier.width(8.dp))
        Text(texto, color = Cor.Texto, fontSize = 17.sp, lineHeight = 24.sp, modifier = Modifier.weight(1f))
    }
}

// ───────────────────────── 2) CONFIGURAÇÃO INICIAL ─────────────────────────

@Composable
fun PassoCard(
    icone: ImageVector, titulo: String, desc: String, ok: Boolean, cor: Color,
    opcional: Boolean = false, acaoPendente: String, acaoPronto: String? = null,
    extra: String? = null, onAcao: () -> Unit
) {
    val forma = RoundedCornerShape(30.dp)
    Row(
        Modifier.fillMaxWidth().suave(forma).clip(forma).background(Cor.Card)
            .border(if (ok) 1.5.dp else 1.dp, if (ok) Cor.Verde.copy(alpha = 0.55f) else Cor.Borda, forma).padding(18.dp)
    ) {
        Box(
            Modifier.size(52.dp).clip(CircleShape).background(if (ok) Cor.Verde else cor.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) {
            if (ok) Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(30.dp))
            else Icon(icone, null, tint = cor, modifier = Modifier.size(26.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(titulo, color = Cor.Texto, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f, fill = false))
                if (opcional) { Spacer(Modifier.width(8.dp)); Selo("opcional", Cor.Muted) }
            }
            Spacer(Modifier.height(3.dp))
            Text(desc, color = Cor.Muted, fontSize = 16.sp, lineHeight = 22.sp)
            if (extra != null) { Spacer(Modifier.height(6.dp)); Text(extra, color = Cor.Texto, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(10.dp))
            if (ok) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.CheckCircle, null, tint = Cor.Verde, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Pronto", color = Cor.Verde, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                }
                if (acaoPronto != null) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        acaoPronto, color = Cor.Azul, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp,
                        modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onAcao).padding(vertical = 4.dp)
                    )
                }
            } else {
                Botao(acaoPendente, if (opcional) Cor.Card2 else Cor.Marca, Modifier.fillMaxWidth(), onClick = onAcao)
            }
        }
    }
}

@Composable
fun SetupTela() {
    val ctx = LocalContext.current
    val perm = remember(Estado.tick) { permissaoOk(ctx) }
    val bateria = remember(Estado.tick) { bateriaOk(ctx) }
    val podeAtualizar = remember(Estado.tick) { Atualizador.podeInstalar(ctx) }
    var escolhendo by remember { mutableStateOf(false) }
    BackHandler(enabled = escolhendo) { escolhendo = false }

    if (escolhendo) {
        Column(Modifier.fillMaxSize()) {
            CabecalhoVoltar("Escolha seus bancos", Icons.Rounded.AccountBalance) { escolhendo = false }
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                BancosConteudo()
                Botao("Concluir", Cor.Verde, icone = Icons.Rounded.CheckCircle) { escolhendo = false }
                Spacer(Modifier.height(24.dp))
            }
        }
        return
    }

    val nomes = remember(Estado.apps) { Estado.apps.map { nomeApp(ctx, it) }.sorted() }
    val bancosOk = Estado.gmail || Estado.apps.isNotEmpty()
    val passos = (if (perm) 1 else 0) + (if (bancosOk) 1 else 0) + (if (podeAtualizar) 1 else 0)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 14.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text("Falta pouco!", color = Cor.Texto, fontSize = 42.sp, fontWeight = FontWeight.ExtraBold)
                Text("Faça estes passos (leva 1 minuto).", color = Cor.Muted, fontSize = 17.sp)
            }
            BotaoTema()
        }
        Spacer(Modifier.height(14.dp))
        // barra de progresso
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (i in 0 until 3) {
                Box(Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(50)).background(if (i < passos) Cor.Verde else Cor.Card2))
            }
        }
        Spacer(Modifier.height(6.dp))
        Text("$passos de 3 passos obrigatórios", color = Cor.Muted, fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))

        PassoCard(
            Icons.Rounded.Notifications, "Ler as notificações", "É assim que o app vê o aviso \"Pix recebido\".",
            perm, Cor.Azul, acaoPendente = "Permitir acesso"
        ) { abrirPermissaoNotificacoes(ctx) }
        if (!perm) {
            Spacer(Modifier.height(6.dp))
            Text(
                "Android bloqueou? Configurações → Apps → ZEROUN AUTOMED → menu ⋮ → Permitir configurações restritas.",
                color = Cor.Muted, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 6.dp)
            )
        }
        Spacer(Modifier.height(12.dp))

        PassoCard(
            Icons.Rounded.AccountBalance, "Escolha seus bancos",
            if (Estado.gmail) "Lendo as notificações do Gmail." else "Escolha até 5 apps de banco para vigiar.",
            bancosOk, Cor.Ciano, acaoPendente = "Escolher bancos", acaoPronto = "Trocar bancos",
            extra = if (Estado.gmail) null else if (nomes.isEmpty()) null else "Vigiando: " + nomes.joinToString(", ") + "."
        ) { escolhendo = true }
        Spacer(Modifier.height(12.dp))

        PassoCard(
            Icons.Rounded.BatteryChargingFull, "Deixe sempre ligado", "Pro celular não fechar o app sozinho.",
            bateria, Cor.Laranja, opcional = true, acaoPendente = "Tirar otimização de bateria"
        ) { pedirBateria(ctx) }
        Spacer(Modifier.height(12.dp))

        PassoCard(
            Icons.Rounded.SystemUpdate, "Atualizar sozinho", "Deixe o app se atualizar sozinho quando sair versão nova.",
            podeAtualizar && Prefs.autoUpdate, Cor.Verde, acaoPendente = "Permitir atualizações",
            acaoPronto = null
        ) { Prefs.autoUpdate = true; Atualizador.pedirPermissaoInstalar(ctx) }

        Spacer(Modifier.height(20.dp))
        Botao("Pronto, começar!", icone = Icons.Rounded.Bolt, enabled = perm && bancosOk && podeAtualizar) {
            Prefs.setupOk = true; Estado.setupOk = true
            Estado.atualizar(); Painel.carregar()
        }
        if (!(perm && bancosOk && podeAtualizar)) {
            Spacer(Modifier.height(8.dp))
            Text(
                "Termine os passos obrigatórios para continuar.",
                color = Cor.Muted, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
            )
        }
        Spacer(Modifier.height(10.dp))
        Text(
            "Trocar de key", color = Cor.Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { Estado.sair() }.padding(10.dp)
        )
    }
}

// ───────────────────────── 3) INÍCIO ─────────────────────────

@Composable
private fun LinhaTeste(rotulo: String, ok: Boolean?) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 6.dp)) {
        when (ok) {
            true -> Icon(Icons.Rounded.CheckCircle, null, tint = Cor.Verde, modifier = Modifier.size(24.dp))
            false -> Icon(Icons.Rounded.Cancel, null, tint = Cor.Vermelho, modifier = Modifier.size(24.dp))
            null -> Icon(Icons.Rounded.Refresh, null, tint = Cor.Muted, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.width(12.dp))
        Text(rotulo, color = Cor.Texto, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Text(
            when (ok) { true -> "OK"; false -> "Problema"; null -> "Verificando…" },
            color = when (ok) { true -> Cor.Verde; false -> Cor.Vermelho; null -> Cor.Muted },
            fontSize = 12.sp, fontWeight = FontWeight.Bold
        )
    }
}

/** Teste sem risco: confere tudo que o app precisa para funcionar (não envia Pix falso ao bot). */
@Composable
fun DialogTeste(onFechar: () -> Unit) {
    val ctx = LocalContext.current
    var conexao by remember { mutableStateOf<Boolean?>(null) }
    LaunchedEffect(Unit) {
        Thread {
            val r = Net.post("/api/key", Net.corpo())
            val ok = r?.optBoolean("ok", false) == true
            Estado.ui { conexao = ok; Estado.online = ok }
        }.start()
        Gestao.carregarSistema()
    }
    AlertDialog(
        onDismissRequest = onFechar,
        containerColor = Cor.Card, titleContentColor = Cor.Texto, textContentColor = Cor.Muted,
        title = { Text("Testar o app", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                LinhaTeste("Acesso às notificações", permissaoOk(ctx))
                LinhaTeste("Bancos escolhidos", Estado.gmail || Estado.apps.isNotEmpty())
                LinhaTeste("Conexão com o bot", conexao)
                LinhaTeste("Bot ligado", Gestao.sisAtivo)
                Spacer(Modifier.height(10.dp))
                Text("Para um teste de verdade, faça um Pix pequeno para você mesmo e veja ele aparecer em Últimos Pix.", fontSize = 12.sp)
            }
        },
        confirmButton = { TextButton(onClick = onFechar) { Text("Fechar", color = Cor.Azul, fontWeight = FontWeight.Bold) } }
    )
}

@Composable
fun PixLinha(p: PixItem) {
    val cor = if (p.origem == "gmail") Cor.Rosa else Cor.Azul
    val forma = RoundedCornerShape(20.dp)
    Row(
        Modifier.fillMaxWidth().suave(forma).clip(forma).background(Cor.Card)
            .border(1.dp, Cor.Borda, forma).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(p.nome, cor, 46)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(p.nome.ifBlank { "Sem nome" }, color = Cor.Texto, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(origemTxt(p), color = cor, fontSize = 11.sp, maxLines = 1)
            Text(hora(p.ts), color = Cor.Muted, fontSize = 11.sp)
        }
        Spacer(Modifier.width(8.dp))
        Text("+" + brl(p.valor), color = Cor.Verde, fontWeight = FontWeight.Black, fontSize = 17.sp)
    }
}

// ───────────────────────── Pix lidos / atividade ─────────────────────────

@Composable
fun PixTela() {
    LaunchedEffect(Unit) { if (Prefs.conectado) Estado.atualizar() }

    Cartao {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("HOJE", color = Cor.Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text(brl(Estado.totalHoje), color = Cor.Verde, fontSize = 28.sp, fontWeight = FontWeight.Black)
                Text("${Estado.hoje} Pix lido(s)", color = Cor.Muted, fontSize = 12.sp)
            }
            Botao(if (Estado.atualizando) "…" else "Atualizar", Cor.Card2, Modifier.width(130.dp), icone = Icons.Rounded.Refresh) { Estado.atualizar() }
        }
    }

    if (Estado.ativoApp == false) {
        Cartao(Modifier.border(1.dp, Cor.Laranja.copy(alpha = 0.6f), RoundedCornerShape(22.dp))) {
            Text("⚠️ Notificações do app desligadas no bot", color = Cor.Laranja, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(
                "No Discord, ligue \"Ativar notificações app\". Enquanto estiver desligado, o bot ignora o celular e lê só o Gmail.",
                color = Cor.Muted, fontSize = 12.sp
            )
        }
    }
    if (Estado.msgServidor.isNotBlank()) {
        Text(Estado.msgServidor, color = Cor.Vermelho, fontSize = 12.sp)
    }

    if (Estado.pix.isEmpty()) {
        Cartao {
            Text("Nenhum Pix lido ainda.", color = Cor.Texto, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(
                "Se você já recebeu Pix e nada apareceu, abra \"Atividade\" em Gerenciar para ver o que o celular recebeu e o que o bot respondeu.",
                color = Cor.Muted, fontSize = 12.sp
            )
        }
    } else {
        Estado.pix.forEach { PixLinha(it) }
    }
}

@Composable
fun AtividadeTela() {
    Text(
        "Tudo que o celular enviou ao bot e o que o bot respondeu. Útil para descobrir por que um Pix não apareceu.",
        color = Cor.Muted, fontSize = 12.sp
    )
    if (Estado.eventos.isNotEmpty()) {
        Botao("Limpar", Cor.Card2, Modifier.width(130.dp)) { Estado.limparEventos() }
    }
    if (Estado.eventos.isEmpty()) {
        Cartao { Text("Nenhuma notificação lida ainda.", color = Cor.Texto, fontWeight = FontWeight.Bold) }
    }
    Estado.eventos.forEach { e ->
        val cor = when (e.tipo) { 1 -> Cor.Verde; 2 -> Cor.Laranja; else -> Cor.Muted }
        val forma = RoundedCornerShape(18.dp)
        Column(
            Modifier.fillMaxWidth().clip(forma).background(Cor.Card)
                .border(1.dp, cor.copy(alpha = 0.4f), forma).padding(14.dp)
        ) {
            Row {
                Text(e.app, color = Cor.Texto, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1)
                Text(hora(e.ts), color = Cor.Muted, fontSize = 11.sp)
            }
            Spacer(Modifier.height(4.dp))
            Text(e.texto, color = Cor.Muted, fontSize = 12.sp, maxLines = 3)
            Spacer(Modifier.height(6.dp))
            Text(e.resultado, color = cor, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

// ───────────────────────── BANCOS (escolher os apps) ─────────────────────────

data class AppInfo(val pkg: String, val nome: String, val icone: ImageBitmap?)

/** Lista de apps instalados, carregada uma vez só (as ícones demoram um pouco). */
object CacheApps {
    var lista by mutableStateOf<List<AppInfo>?>(null)
    var carregando = false
}

@Suppress("DEPRECATION")
fun carregarApps(c: Context): List<AppInfo> {
    val pm = c.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .map { Pair(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
        .filter { it.first != c.packageName }
        .distinctBy { it.first }
        .sortedBy { it.second.lowercase() }
        .map { (pkg, nome) ->
            val ic = try { pm.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap() } catch (e: Exception) { null }
            AppInfo(pkg, nome, ic)
        }
}

@Composable
fun LinhaApp(a: AppInfo, marcado: Boolean, onClick: () -> Unit) {
    val forma = RoundedCornerShape(18.dp)
    Row(
        Modifier.fillMaxWidth().clip(forma)
            .background(if (marcado) Cor.Azul.copy(alpha = 0.10f) else Cor.Card)
            .border(1.dp, if (marcado) Cor.Azul else Cor.Borda, forma)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (a.icone != null) {
            Image(bitmap = a.icone, contentDescription = a.nome, modifier = Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)))
        } else {
            Avatar(a.nome, Cor.Azul, 44)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(a.nome, color = Cor.Texto, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(a.pkg, color = Cor.Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(8.dp))
        if (marcado) {
            Box(Modifier.size(26.dp).clip(CircleShape).background(Cor.Azul), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.CheckCircle, null, tint = Color.White, modifier = Modifier.size(18.dp))
            }
        } else {
            Box(Modifier.size(26.dp).clip(CircleShape).border(2.dp, Cor.Muted.copy(alpha = 0.5f), CircleShape))
        }
    }
}

@Composable
fun BancosConteudo() {
    val ctx = LocalContext.current
    var aviso by remember { mutableStateOf("") }
    var busca by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        if (CacheApps.lista == null && !CacheApps.carregando) {
            CacheApps.carregando = true
            Thread {
                val r = carregarApps(ctx)
                Estado.ui { CacheApps.lista = r; CacheApps.carregando = false }
            }.start()
        }
    }

    fun alternar(a: AppInfo) {
        aviso = ""
        if (Estado.apps.contains(a.pkg)) {
            Estado.salvarApps(Estado.apps - a.pkg)
        } else if (Estado.apps.size >= 5) {
            aviso = "Máximo de 5 apps. Desmarque um para escolher outro."
        } else {
            Estado.salvarApps(Estado.apps + a.pkg)
            if (Estado.gmail) Estado.definirFonte(false) // escolheu um banco: passa a ler os apps
        }
    }

    Cartao {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconeCaixa(Icons.Rounded.AccountBalance, Cor.Ciano, 46)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Bancos vigiados", color = Cor.Texto, fontSize = 18.sp, fontWeight = FontWeight.Black)
                Text("${Estado.apps.size}/5 selecionados", color = Cor.Muted, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(14.dp))
        Text("De onde ler os Pix?", color = Cor.Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("📱 Apps dos bancos", Cor.Azul, !Estado.gmail) { Estado.definirFonte(false) }
            Chip("✉️ Gmail", Cor.Rosa, Estado.gmail) { Estado.definirFonte(true) }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            if (Estado.gmail) "Agora o app lê só as notificações do Gmail. Toque em \"Apps dos bancos\" para usar os apps abaixo."
            else "O app lê as notificações dos apps marcados abaixo (Nubank, Itaú, Inter…).",
            color = Cor.Muted, fontSize = 12.sp
        )
        if (aviso.isNotBlank()) { Spacer(Modifier.height(8.dp)); Text(aviso, color = Cor.Laranja, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
    }

    val itens = CacheApps.lista
    if (itens == null) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) { Pill("Carregando apps…", Cor.Azul) }
        return
    }

    val escolhidos = itens.filter { Estado.apps.contains(it.pkg) }
    if (escolhidos.isNotEmpty()) {
        TituloGrupo("SELECIONADOS", Cor.Azul)
        escolhidos.forEach { a -> LinhaApp(a, true) { alternar(a) } }
    }

    TituloGrupo("TODOS OS APPS", Cor.Muted)
    OutlinedTextField(
        value = busca, onValueChange = { busca = it }, singleLine = true, shape = RoundedCornerShape(16.dp),
        label = { Text("Buscar app") }, modifier = Modifier.fillMaxWidth()
    )
    itens.filter { !Estado.apps.contains(it.pkg) && (busca.isBlank() || it.nome.contains(busca, ignoreCase = true)) }
        .forEach { a -> LinhaApp(a, false) { alternar(a) } }
}

// ───────────────────────── COMANDOS ─────────────────────────

@Composable
fun ComandosAba() {
    var modo by remember { mutableStateOf(0) }
    Pagina("Salas", "Comandos de sala, Meet e mensagens") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("🎮 Salas e Meet", Cor.Verde, modo == 0) { modo = 0 }
            Chip("💬 Mensagens", Cor.Rosa, modo == 1) { modo = 1 }
        }
        if (modo == 0) SalasTela() else MensagensTela()
    }
}

// ───────────────────────── FINANÇAS ─────────────────────────

@Composable
fun FinancasAba() {
    Pagina("Finanças", "Lucros e Pix recebidos") {
        LucrosTela()
        TituloGrupo("PIX LIDOS", Cor.Verde)
        PixTela()
    }
}

// ───────────────────────── CONTROLE ─────────────────────────

@Composable
fun ControleAba(irSub: (Tela) -> Unit) {
    Pagina("Controle", "Ligue o bot, veja a key e mais") {
        SistemaTela()

        TituloGrupo("FERRAMENTAS", Cor.Azul)
        LinhaMenu(Icons.Rounded.SmartToy, "IA e canais de regras", "Canais que a IA lê em cada servidor", Cor.Azul) { irSub(Tela.IA) }
        LinhaMenu(Icons.Rounded.Person, "Conta e servidores", "Conta, servidores e antiban", Cor.Ciano) { irSub(Tela.CONTA) }
        LinhaMenu(Icons.Rounded.History, "Atividade", "${Estado.eventos.size} notificações vistas", Cor.Rosa) { irSub(Tela.ATIVIDADE) }
    }
}

// ───────────────────────── CONFIGURAÇÕES ─────────────────────────

/** Aba só para key de música: atualização do app e trocar de key. */
@Composable
fun AtualizacaoAba() {
    var confirmarSair by remember { mutableStateOf(false) }
    Pagina("Atualização", "Versão do app e troca de key") {
        TituloGrupo("ATUALIZAÇÃO DO APP", Cor.Laranja)
        CartaoAtualizacao()
        TituloGrupo("ESTE APP", Cor.Muted)
        Botao("Sair e trocar de key", Cor.Card2, icone = Icons.Rounded.SwapHoriz) { confirmarSair = true }
    }
    if (confirmarSair) {
        AlertDialog(
            onDismissRequest = { confirmarSair = false },
            containerColor = Cor.Card, titleContentColor = Cor.Texto, textContentColor = Cor.Muted,
            title = { Text("Sair da key atual?", fontWeight = FontWeight.Bold) },
            text = { Text("O app volta para a tela de digitar a key. Suas músicas e playlists continuam salvas.") },
            confirmButton = {
                TextButton(onClick = { confirmarSair = false; Estado.sair() }) {
                    Text("Sair", color = Cor.Vermelho, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { confirmarSair = false }) { Text("Cancelar", color = Cor.Muted) } }
        )
    }
}

@Composable
fun ConfigAba(irSub: (Tela) -> Unit) {
    var confirmarSair by remember { mutableStateOf(false) }
    var testar by remember { mutableStateOf(false) }
    Pagina("Configurações", "Bancos, tema e atualização") {
        TituloGrupo("PIX", Cor.Verde)
        LinhaMenu(
            Icons.Rounded.AccountBalance, "Bancos vigiados",
            if (Estado.gmail) "Lendo o Gmail" else "${Estado.apps.size} app(s) escolhido(s)", Cor.Verde
        ) { irSub(Tela.BANCOS) }
        LinhaMenu(Icons.Rounded.Science, "Testar o app", "Confere permissão, bot e leitura de Pix", Cor.Ciano) { testar = true }

        TituloGrupo("APARÊNCIA", Cor.Roxo)
        val formaT = RoundedCornerShape(20.dp)
        Row(
            Modifier.fillMaxWidth().suave(formaT).clip(formaT).background(Cor.Card)
                .border(1.dp, Cor.Borda, formaT).clickable { Tema.alternar() }.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconeCaixa(if (Tema.escuro) Icons.Rounded.DarkMode else Icons.Rounded.LightMode, Cor.Roxo)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Tema escuro", color = Cor.Texto, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(if (Tema.escuro) "Fundo preto (padrão)" else "Fundo claro", color = Cor.Muted, fontSize = 12.sp)
            }
            Switch(checked = Tema.escuro, onCheckedChange = { Tema.alternar() })
        }

        TituloGrupo("ATUALIZAÇÃO DO APP", Cor.Laranja)
        CartaoAtualizacao()

        TituloGrupo("ESTE APP", Cor.Muted)
        Botao("Sair e trocar de key", Cor.Card2, icone = Icons.Rounded.SwapHoriz) { confirmarSair = true }
    }
    if (testar) DialogTeste { testar = false }
    if (confirmarSair) {
        AlertDialog(
            onDismissRequest = { confirmarSair = false },
            containerColor = Cor.Card, titleContentColor = Cor.Texto, textContentColor = Cor.Muted,
            title = { Text("Sair da key atual?", fontWeight = FontWeight.Bold) },
            text = { Text("O app volta para a tela de digitar a key. O bot continua do jeito que está.") },
            confirmButton = {
                TextButton(onClick = { confirmarSair = false; Estado.sair() }) {
                    Text("Sair", color = Cor.Vermelho, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { confirmarSair = false }) { Text("Cancelar", color = Cor.Muted) } }
        )
    }
}
