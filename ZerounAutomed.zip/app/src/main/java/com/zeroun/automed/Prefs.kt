package com.zeroun.automed

import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings
import java.util.UUID

/** Mesmo arquivo/chaves do app anterior ("zeroun"), então atualizar por cima mantém key, endereço e deviceId. */
object Prefs {
    private var sp: SharedPreferences? = null
    private var ctx: Context? = null

    fun init(c: Context) {
        if (sp == null) {
            ctx = c.applicationContext
            sp = c.applicationContext.getSharedPreferences("zeroun", Context.MODE_PRIVATE)
        }
    }

    private fun p(): SharedPreferences = sp ?: error("Prefs.init() não foi chamado")

    /** Sempre o endereço fixo do bot. */
    var url: String
        get() = Net.URL_FIXA
        set(@Suppress("UNUSED_PARAMETER") v) { }

    var key: String
        get() = p().getString("key", "") ?: ""
        set(v) { p().edit().putString("key", v).apply() }

    var gmail: Boolean
        get() = p().getBoolean("gmail", true)
        set(v) { p().edit().putBoolean("gmail", v).apply() }

    var apps: Set<String>
        get() = p().getStringSet("apps", emptySet()) ?: emptySet()
        set(v) { p().edit().putStringSet("apps", HashSet(v)).apply() }

    var conectado: Boolean
        get() = p().getBoolean("conectado", false)
        set(v) { p().edit().putBoolean("conectado", v).apply() }

    var pixJson: String
        get() = p().getString("pixJson", "[]") ?: "[]"
        set(v) { p().edit().putString("pixJson", v).apply() }

    /**
     * ID do celular: se já existe, mantém (quem já está vinculado não muda).
     * Se for instalação nova, usa o ANDROID_ID do aparelho, que é o MESMO depois de desinstalar e instalar de novo
     * (enquanto o app for assinado com a mesma chave, ou seja, gerado no mesmo computador/Android Studio).
     */
    val deviceId: String
        get() {
            val atual = p().getString("deviceId", null)
            if (!atual.isNullOrBlank()) return atual
            val aid = try { Settings.Secure.getString(ctx?.contentResolver, Settings.Secure.ANDROID_ID) } catch (e: Exception) { null }
            val novo = if (!aid.isNullOrBlank() && aid != "9774d56d682e549c") "and-$aid" else UUID.randomUUID().toString()
            p().edit().putString("deviceId", novo).apply()
            return novo
        }
}
