# Atualização automática do app (via GitHub Actions)

## Como lançar uma versão nova (só isso)
1. No GitHub, abra o repositório > **Add file > Upload files** e envie o **.zip do projeto** (branch `main`).
2. Pronto. Em ~5 min o GitHub extrai o zip, compila o APK, define a versão (1 acima da última Release) e **cria a Release sozinho**.
3. No celular, **Procurar atualização** já mostra a versão nova (e o app também checa sozinho a cada ~15 min e instala).

Você nunca cria Release na mão. Acompanhe na aba **Actions** (✅ verde = publicou, ❌ vermelho = erro de compilação; abra o item para ver o log).

## Primeira vez (uma vez só)
- O arquivo `.github/workflows/lancar.yml` precisa estar no repositório (suba esta pasta inteira uma vez, ou só esse arquivo).
- Em **Settings > Actions > General > Workflow permissions**, marque **Read and write permissions**.

## Importante
- O zip pode ter ou não uma pasta por fora; o workflow acha o projeto sozinho.
- Mudou só o `index.js` (bot)? NÃO precisa lançar app. Troque o arquivo no servidor e reinicie.
- O arquivo `.github/workflows/lancar.yml` precisa estar no repositório.
- A assinatura é fixa (`app/zeroun.jks`): não troque, senão o Android recusa instalar por cima.
- Repositório deve ser PÚBLICO.
- Para pular de versão (ex.: 3.4.0), mude `versaoBase` em `app/build.gradle.kts`.

## O app diz "Nenhuma versão mais nova" mas eu subi no GitHub
1. Abra a aba **Actions** do repositório. Se a última execução estiver ❌ vermelha, o APK não foi compilado e **não existe Release nova** — abra o log e corrija o erro.
2. Se estiver ✅ verde, abra **Releases**: o número da versão nova precisa ser MAIOR que o instalado no celular.
   O app mostra os dois números ao tocar em "Procurar atualização" (Instalada x Última no GitHub).
3. Se o celular já está com um número igual ou maior, suba `versaoBase` em `app/build.gradle.kts` (agora está 3.4.0).
