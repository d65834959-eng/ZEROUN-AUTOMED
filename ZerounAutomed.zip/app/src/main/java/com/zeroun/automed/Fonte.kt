package com.zeroun.automed

import android.content.Context
import androidx.compose.material3.Typography
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

/**
 * Usa a fonte Poppins (a da foto) se os arquivos estiverem em app/src/main/res/font/:
 * poppins_regular.ttf, poppins_medium.ttf, poppins_semibold.ttf, poppins_bold.ttf, poppins_extrabold.ttf, poppins_black.ttf
 * (qualquer um que faltar é ignorado). Sem os arquivos, usa a fonte padrão do Android.
 */
object Fonte {
    fun familia(c: Context): FontFamily {
        val lista = ArrayList<Font>()
        val pesos = listOf(
            "poppins_regular" to FontWeight.Normal, "poppins_medium" to FontWeight.Medium,
            "poppins_semibold" to FontWeight.SemiBold, "poppins_bold" to FontWeight.Bold,
            "poppins_extrabold" to FontWeight.ExtraBold, "poppins_black" to FontWeight.Black
        )
        for ((nome, peso) in pesos) {
            val id = c.resources.getIdentifier(nome, "font", c.packageName)
            if (id != 0) lista.add(Font(id, peso))
        }
        return if (lista.isEmpty()) FontFamily.SansSerif else FontFamily(lista)
    }

    fun tipografia(f: FontFamily): Typography {
        val b = Typography()
        return b.copy(
            displayLarge = b.displayLarge.copy(fontFamily = f), displayMedium = b.displayMedium.copy(fontFamily = f),
            displaySmall = b.displaySmall.copy(fontFamily = f), headlineLarge = b.headlineLarge.copy(fontFamily = f),
            headlineMedium = b.headlineMedium.copy(fontFamily = f), headlineSmall = b.headlineSmall.copy(fontFamily = f),
            titleLarge = b.titleLarge.copy(fontFamily = f), titleMedium = b.titleMedium.copy(fontFamily = f),
            titleSmall = b.titleSmall.copy(fontFamily = f), bodyLarge = b.bodyLarge.copy(fontFamily = f),
            bodyMedium = b.bodyMedium.copy(fontFamily = f), bodySmall = b.bodySmall.copy(fontFamily = f),
            labelLarge = b.labelLarge.copy(fontFamily = f), labelMedium = b.labelMedium.copy(fontFamily = f),
            labelSmall = b.labelSmall.copy(fontFamily = f)
        )
    }
}
