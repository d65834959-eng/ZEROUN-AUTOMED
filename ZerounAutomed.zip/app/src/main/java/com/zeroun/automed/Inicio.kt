package com.zeroun.automed

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalanceWallet
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.ChatBubble
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.LocalOffer
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material.icons.rounded.Error
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ───────────────────────── logo "Z" ─────────────────────────

/** Desenha o Z do logo (traço próprio, sem precisar de arquivo de imagem). */
@Composable
fun LogoZ(modifier: Modifier, cor: Color) {
    Canvas(modifier) {
        val sx = size.width / 105f
        val sy = size.height / 76f
        fun pt(x: Float, y: Float) = Offset(x * sx, y * sy)
        val z = Path()
        val pts = listOf(
            0f to 0f, 105f to 0f, 105f to 17f, 42f to 59f, 105f to 59f, 105f to 76f,
            0f to 76f, 0f to 59f, 63f to 17f, 0f to 17f
        )
        pts.forEachIndexed { i, (x, y) ->
            val o = pt(x, y)
            if (i == 0) z.moveTo(o.x, o.y) else z.lineTo(o.x, o.y)
        }
        z.close()
        drawPath(z, cor)
    }
}

// ───────────────────────── peças do Início ─────────────────────────

private fun tamanhoValor(t: String): TextUnit = when {
    t.length <= 8 -> 24.sp
    t.length <= 11 -> 20.sp
    else -> 16.sp
}

/** "Hoje, 17:42" ou "15/11, 17:42". */
private fun quando(ts: Long): String {
    val dia = SimpleDateFormat("yyyyMMdd", Locale("pt", "BR"))
    val h = SimpleDateFormat("HH:mm", Locale("pt", "BR")).format(Date(ts))
    return if (dia.format(Date(ts)) == dia.format(Date())) "Hoje, $h"
    else SimpleDateFormat("dd/MM", Locale("pt", "BR")).format(Date(ts)) + ", " + h
}

@Composable
private fun CartaoNumero(
    icone: ImageVector, rotulo: String, valor: String, sub: String, subCor: Color,
    subIcone: ImageVector?, modifier: Modifier, onClick: () -> Unit
) {
    val forma = RoundedCornerShape(24.dp)
    Row(
        modifier.clip(forma).background(Cor.Card).border(1.dp, Cor.Borda, forma)
            .clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Cor.Card2), contentAlignment = Alignment.Center) {
            Icon(icone, null, tint = Cor.Texto, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.Top) {
                Text(rotulo, color = Cor.Texto, fontSize = 12.sp, lineHeight = 14.sp, maxLines = 2, modifier = Modifier.weight(1f))
                Icon(Icons.Rounded.ChevronRight, null, tint = Cor.Muted, modifier = Modifier.size(18.dp))
            }
            Text(valor, color = Cor.Texto, fontSize = tamanhoValor(valor), fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false)
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (subIcone != null) {
                    Icon(subIcone, null, tint = subCor, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(3.dp))
                }
                Text(sub, color = subCor, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

/** Linha suave com preenchimento e bolinha no fim, com grade vertical leve (como na foto). */
@Composable
fun GraficoDesempenho(valores: List<Double>, modifier: Modifier) {
    val linhaCor = Cor.Texto
    val grade = Cor.Texto.copy(alpha = 0.10f)
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val fino = 1.dp.toPx()
        for (i in 0..4) {
            val x = w * i / 4f
            drawLine(grade, Offset(x, 0f), Offset(x, h), strokeWidth = fino)
        }
        drawLine(grade, Offset(0f, h), Offset(w, h), strokeWidth = fino)
        val n = valores.size
        if (n < 2) return@Canvas
        val max = (valores.maxOrNull() ?: 0.0).coerceAtLeast(1.0)
        fun px(i: Int) = w * i / (n - 1)
        fun py(v: Double) = h - (v / max).toFloat() * h * 0.80f - h * 0.08f
        val linha = Path()
        linha.moveTo(px(0), py(valores[0]))
        for (i in 1 until n) {
            val x0 = px(i - 1); val y0 = py(valores[i - 1]); val x1 = px(i); val y1 = py(valores[i])
            val mx = (x0 + x1) / 2f
            linha.cubicTo(mx, y0, mx, y1, x1, y1)
        }
        val area = Path()
        area.addPath(linha)
        area.lineTo(w, h)
        area.lineTo(0f, h)
        area.close()
        drawPath(area, Brush.verticalGradient(listOf(linhaCor.copy(alpha = 0.22f), Color.Transparent)))
        drawPath(linha, linhaCor, style = Stroke(width = 1.6.dp.toPx(), cap = StrokeCap.Round))
        drawCircle(linhaCor, 4.dp.toPx(), Offset(px(n - 1), py(valores[n - 1])))
    }
}

/** Horas reais dos pontos do gráfico (a lista do bot é das últimas 24h, terminando agora). */
private fun rotulosHoras(n: Int): List<String> {
    val agora = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return (0..4).map { i ->
        if (i == 4) "agora"
        else {
            val idx = (i * (n - 1)) / 4
            val h = ((agora - (n - 1 - idx)) % 24 + 24) % 24
            String.format(Locale.US, "%02dh", h)
        }
    }
}

// ───────────────────────── tela Início ─────────────────────────

@Composable
fun Home(irAba: (Aba) -> Unit, irSub: (Tela) -> Unit) {
    val ctx = LocalContext.current
    val perm = remember(Estado.tick) { permissaoOk(ctx) }
    val abrirAvisos = LocalAbrirAvisos.current
    val avisos = avisosAtuais()
    val erro = avisos.firstOrNull { it.nivel == Nivel.ERRO }

    LaunchedEffect(Unit) {
        Resumo.carregar()
        while (true) {
            delay(10_000)
            if (Prefs.conectado) Resumo.carregar()
        }
    }

    // estado do bot (cor, texto e o que acontece ao tocar)
    val cor: Color
    val textoStatus: String
    val sub: String
    val icone: ImageVector
    when {
        !Estado.online -> { cor = Cor.Vermelho; textoStatus = "Sem conexão"; sub = "Não consegui falar com o bot"; icone = Icons.Rounded.WifiOff }
        erro != null -> { cor = Cor.Vermelho; textoStatus = "Com erro"; sub = erro.titulo; icone = Icons.Rounded.Error }
        !perm -> { cor = Cor.Laranja; textoStatus = "Falta uma permissão"; sub = "Toque para liberar as notificações"; icone = Icons.Rounded.NotificationsOff }
        Gestao.sisAtivo == false -> { cor = Cor.Laranja; textoStatus = "Bot desligado"; sub = "Toque para ligar em Controle"; icone = Icons.Rounded.PowerSettingsNew }
        else -> { cor = Cor.Verde; textoStatus = "Online"; sub = "Tudo funcionando perfeitamente!"; icone = Icons.Rounded.SmartToy }
    }
    val tudoBem = cor == Cor.Verde

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // ── cabeçalho: logo + sino + perfil ──
        Row(verticalAlignment = Alignment.CenterVertically) {
            LogoZ(Modifier.width(50.dp).height(36.dp), Cor.Texto)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("ZEROUN", color = Cor.Texto, fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp, maxLines = 1)
                Text("AUTOMED", color = Cor.Texto, fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 9.sp, maxLines = 1)
            }
            Sino()
            Spacer(Modifier.width(10.dp))
            BotaoPerfil { irSub(Tela.CONTA) }
        }
        Text("Seu bot, na palma da sua mão.", color = Cor.Muted, fontSize = 14.sp)

        // ── cartão do bot ──
        val formaB = RoundedCornerShape(26.dp)
        Row(
            Modifier.fillMaxWidth().clip(formaB).background(Cor.Card)
                .border(1.dp, if (tudoBem) Cor.Borda else cor.copy(alpha = 0.6f), formaB)
                .clickable {
                    when {
                        !Estado.online -> { Estado.atualizar(); Gestao.carregarSistema() }
                        erro != null -> abrirAvisos()
                        !perm -> abrirPermissaoNotificacoes(ctx)
                        Gestao.sisAtivo == false -> irAba(Aba.CONTROLE)
                        else -> irAba(Aba.CONTROLE)
                    }
                }
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(62.dp).clip(CircleShape).background(Cor.Card2), contentAlignment = Alignment.Center) {
                Icon(icone, null, tint = Cor.Texto, modifier = Modifier.size(34.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Bot " + Painel.nome.ifBlank { "Zeroun" }, color = Cor.Texto, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(11.dp).clip(CircleShape).background(cor))
                    Spacer(Modifier.width(8.dp))
                    Text(textoStatus, color = Cor.Texto, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                }
                Text(sub, color = Cor.Muted, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Icon(Icons.Rounded.ChevronRight, null, tint = Cor.Muted, modifier = Modifier.size(26.dp))
        }

        // ── salas ativas + total de vendas ──
        val recebido = if (Resumo.carregado) Resumo.recebidoHoje else Estado.totalHoje
        val pixHoje = if (Resumo.carregado) Resumo.pixHoje else Estado.hoje
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            CartaoNumero(
                Icons.Rounded.Groups, "Salas ativas", Resumo.salasAtivas.toString(),
                if (Resumo.salasHoje > 0) "+${Resumo.salasHoje} hoje" else "nenhuma hoje",
                if (Resumo.salasHoje > 0) Cor.Verde else Cor.Muted,
                if (Resumo.salasHoje > 0) Icons.Rounded.ArrowUpward else null,
                Modifier.weight(1f).fillMaxHeight()
            ) { irAba(Aba.SALAS) }
            CartaoNumero(
                Icons.Rounded.AccountBalanceWallet, "Total de vendas", brl(recebido),
                if (pixHoje > 0) "$pixHoje Pix hoje" else "nenhum Pix hoje",
                if (pixHoje > 0) Cor.Verde else Cor.Muted,
                if (pixHoje > 0) Icons.Rounded.ArrowUpward else null,
                Modifier.weight(1f).fillMaxHeight()
            ) { irAba(Aba.FINANCAS) }
        }

        // ── saldo da carteira + desempenho 24h ──
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
            CartaoNumero(
                Icons.Rounded.AccountBalanceWallet, "Saldo da carteira", brl(Gestao.lucAcumulado),
                "Disponível", Cor.Muted, null, Modifier.weight(1f)
            ) { irAba(Aba.FINANCAS) }

            val formaD = RoundedCornerShape(24.dp)
            Column(
                Modifier.weight(1f).clip(formaD).background(Cor.Card).border(1.dp, Cor.Borda, formaD)
                    .clickable { irAba(Aba.FINANCAS) }.padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.BarChart, null, tint = Cor.Texto, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Desempenho", color = Cor.Texto, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, modifier = Modifier.weight(1f))
                    Icon(Icons.Rounded.ChevronRight, null, tint = Cor.Muted, modifier = Modifier.size(18.dp))
                }
                Row(Modifier.fillMaxWidth().padding(top = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("(24h)", color = Cor.Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Text(brl(Resumo.horas.sum()), color = Cor.Texto, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
                Spacer(Modifier.height(8.dp))
                GraficoDesempenho(Resumo.horas, Modifier.fillMaxWidth().height(92.dp))
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    rotulosHoras(Resumo.horas.size).forEach { Text(it, color = Cor.Muted, fontSize = 10.sp, maxLines = 1) }
                }
            }
        }

        // ── atividade recente ──
        val formaA = RoundedCornerShape(26.dp)
        Column(Modifier.fillMaxWidth().clip(formaA).background(Cor.Card).border(1.dp, Cor.Borda, formaA).padding(horizontal = 16.dp, vertical = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Bolt, null, tint = Cor.Texto, modifier = Modifier.size(28.dp))
                Spacer(Modifier.width(10.dp))
                Text("Atividade recente", color = Cor.Texto, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                Row(
                    Modifier.clip(RoundedCornerShape(10.dp)).clickable { irSub(Tela.ATIVIDADE) }.padding(horizontal = 4.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Ver todas", color = Cor.Muted, fontSize = 14.sp)
                    Icon(Icons.Rounded.ChevronRight, null, tint = Cor.Muted, modifier = Modifier.size(20.dp))
                }
            }
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(Cor.Borda))
            if (Resumo.atividade.isEmpty()) {
                Text(
                    "Quando uma sala for criada ou um Pix cair, aparece aqui.",
                    color = Cor.Muted, fontSize = 14.sp, modifier = Modifier.padding(vertical = 18.dp)
                )
            } else {
                val itens = Resumo.atividade.take(3)
                itens.forEachIndexed { i, a ->
                    val pix = a.tipo == "pix"
                    val msg = a.tipo.contains("msg", true) || a.tipo.contains("mensagem", true)
                    val corA = if (msg) Cor.Roxo else Cor.Verde
                    val ic = if (pix) Icons.Rounded.AccountBalanceWallet else if (msg) Icons.Rounded.ChatBubble else Icons.Rounded.LocalOffer
                    Row(
                        Modifier.fillMaxWidth().clickable { irSub(Tela.ATIVIDADE) }.padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(50.dp).clip(RoundedCornerShape(16.dp)).background(Cor.Card2), contentAlignment = Alignment.Center) {
                            Icon(ic, null, tint = Cor.Texto, modifier = Modifier.size(26.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(a.titulo, color = Cor.Texto, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(a.sub, color = Cor.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Spacer(Modifier.width(8.dp))
                        Column(horizontalAlignment = Alignment.End) {
                            if (pix) Text(brl(a.valor), color = Cor.Texto, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(9.dp).clip(CircleShape).background(corA))
                                Spacer(Modifier.width(6.dp))
                                Text(quando(a.ts), color = Cor.Muted, fontSize = 12.sp, maxLines = 1)
                            }
                        }
                        Spacer(Modifier.width(6.dp))
                        Icon(Icons.Rounded.ChevronRight, null, tint = Cor.Muted, modifier = Modifier.size(20.dp))
                    }
                    if (i < itens.lastIndex) Box(Modifier.fillMaxWidth().height(1.dp).background(Cor.Borda))
                }
            }
        }
        Spacer(Modifier.height(6.dp))
    }
}
