package com.zeroun.automed

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.SystemUpdate
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

data class InfoAtualizacao(val codigo: Long, val nome: String, val url: String, val notas: String, val sha256: String)

/**
 * Atualização dentro do app: lê um versao.json no servidor, baixa o APK novo e abre o instalador do Android.
 * O APK novo é instalado POR CIMA (mesma assinatura), então key, celular vinculado e configurações continuam.
 */
object Atualizador {
    /** TROQUE pelo seu repositório do GitHub, no formato "usuario/repositorio" (precisa ser público). */
    const val GITHUB_REPO = "SEU-USUARIO/SEU-REPOSITORIO"

    /** "v3.2.0" -> 30200 (mesma conta do build.gradle.kts, que gera o versionCode a partir do versionName). */
    fun codigoDe(v: String): Long {
        val p = Regex("\\d+").findAll(v).map { it.value.toLong() }.toList()
        return p.getOrElse(0) { 0L } * 10000 + p.getOrElse(1) { 0L } * 100 + p.getOrElse(2) { 0L }
    }

    var disponivel by mutableStateOf<InfoAtualizacao?>(null)
    var verificando by mutableStateOf(false)
    var baixando by mutableStateOf(false)
    var progresso by mutableStateOf(0f)
    var arquivoPronto by mutableStateOf<File?>(null)
    var msg by mutableStateOf("")
    var msgErro by mutableStateOf(false)
    private var ultimaChecagem = 0L

    @Suppress("DEPRECATION")
    fun versaoAtual(c: Context): Pair<Long, String> = try {
        val i = c.packageManager.getPackageInfo(c.packageName, 0)
        val cod = if (Build.VERSION.SDK_INT >= 28) i.longVersionCode else i.versionCode.toLong()
        Pair(cod, i.versionName ?: "")
    } catch (e: Exception) { Pair(0L, "") }

    fun verificar(c: Context, manual: Boolean) {
        if (verificando || baixando) return
        if (!manual && System.currentTimeMillis() - ultimaChecagem < 3_600_000L) return
        verificando = true
        if (manual) msg = ""
        val app = c.applicationContext
        Thread {
            var info: InfoAtualizacao? = null
            var erro = ""
            try {
                if (GITHUB_REPO.startsWith("SEU-")) throw IllegalStateException("repo")
                val con = URL("https://api.github.com/repos/$GITHUB_REPO/releases/latest").openConnection() as HttpURLConnection
                con.connectTimeout = 8000; con.readTimeout = 10000
                con.setRequestProperty("Accept", "application/vnd.github+json")
                con.setRequestProperty("User-Agent", "ZerounAutomed")
                val codHttp = con.responseCode
                if (codHttp == 404) {
                    erro = "Nenhuma Release encontrada no GitHub. O repositório é público e já tem uma Release publicada?"
                } else if (codHttp !in 200..299) {
                    erro = "O GitHub respondeu $codHttp. Tente de novo daqui a pouco."
                } else {
                    val o = JSONObject(con.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() })
                    val tag = o.optString("tag_name", "")
                    val cod = codigoDe(tag)
                    if (cod > versaoAtual(app).first) {
                        var url = ""
                        var sha = ""
                        val assets = o.optJSONArray("assets")
                        if (assets != null) for (i in 0 until assets.length()) {
                            val a = assets.getJSONObject(i)
                            if (a.optString("name", "").endsWith(".apk", true)) {
                                url = a.optString("browser_download_url", "")
                                val d = a.optString("digest", "")
                                if (d.startsWith("sha256:")) sha = d.removePrefix("sha256:").lowercase()
                                break
                            }
                        }
                        if (url.isBlank()) erro = "A Release $tag não tem o arquivo .apk anexado."
                        else info = InfoAtualizacao(cod, tag.removePrefix("v").removePrefix("V"), url, o.optString("body", ""), sha)
                    }
                }
                con.disconnect()
            } catch (e: IllegalStateException) {
                erro = "Falta configurar o GitHub: troque GITHUB_REPO em Atualizador.kt."
            } catch (e: Exception) { erro = "Não consegui verificar atualização. Confira a internet." }
            val achou = info
            val err = erro
            Estado.ui {
                verificando = false
                ultimaChecagem = System.currentTimeMillis()
                disponivel = if (achou != null && achou.url.isNotBlank()) achou else null
                val d = disponivel
                if (d != null && Prefs.autoUpdate && podeInstalar(app) && Prefs.tentouAuto != d.codigo) {
                    Prefs.tentouAuto = d.codigo
                    baixar(app, d)
                }
                if (manual) {
                    if (err.isNotBlank()) { msg = err; msgErro = true }
                    else if (disponivel == null) { msg = "Você já está na versão mais recente."; msgErro = false }
                }
            }
        }.start()
    }

    fun baixar(c: Context, info: InfoAtualizacao) {
        if (baixando) return
        val app = c.applicationContext
        baixando = true; progresso = 0f; msg = ""; arquivoPronto = null
        Thread {
            var erro = ""
            var arq: File? = null
            try {
                val dir = File(app.cacheDir, "updates")
                dir.mkdirs()
                dir.listFiles()?.forEach { it.delete() }
                val f = File(dir, "automed-${info.codigo}.apk")
                val con = URL(info.url).openConnection() as HttpURLConnection
                con.connectTimeout = 10000; con.readTimeout = 20000
                if (con.responseCode !in 200..299) throw Exception("servidor respondeu ${con.responseCode}")
                val total = con.contentLengthLong
                val md = MessageDigest.getInstance("SHA-256")
                con.inputStream.use { ins ->
                    f.outputStream().use { out ->
                        val buf = ByteArray(32768)
                        var lido = 0L
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n); md.update(buf, 0, n); lido += n
                            if (total > 0) { val p = lido.toFloat() / total; Estado.ui { progresso = p } }
                        }
                    }
                }
                con.disconnect()
                val hash = md.digest().joinToString("") { "%02x".format(it) }
                if (info.sha256.isNotBlank() && hash != info.sha256) {
                    f.delete(); throw Exception("o arquivo não bate com o sha256 do versao.json")
                }
                arq = f
            } catch (e: Exception) { erro = "Falha ao baixar: " + (e.message ?: "erro") }
            val pronto = arq
            val err = erro
            Estado.ui {
                baixando = false
                if (pronto != null) { arquivoPronto = pronto; instalar(app, pronto) } else { msg = err; msgErro = true }
            }
        }.start()
    }

    fun podeInstalar(c: Context): Boolean =
        Build.VERSION.SDK_INT < 26 || c.packageManager.canRequestPackageInstalls()

    /** Abre a tela do Android onde se libera "Permitir desta fonte" para este app. */
    fun pedirPermissaoInstalar(c: Context) {
        try {
            c.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + c.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) { }
    }

    /**
     * Instala o APK pelo PackageInstaller. No Android 12+, depois que o próprio app já instalou uma vez,
     * as próximas atualizações entram sem pedir confirmação. Se o Android pedir, o InstalarReceiver abre a confirmação.
     */
    fun instalar(c: Context, f: File) {
        val app = c.applicationContext
        if (!podeInstalar(app)) {
            pedirPermissaoInstalar(app)
            msg = "Ative \"Permitir desta fonte\", volte e toque em Instalar agora."; msgErro = false
            return
        }
        try {
            val pi = app.packageManager.packageInstaller
            val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
            params.setAppPackageName(app.packageName)
            if (Build.VERSION.SDK_INT >= 31) params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
            val id = pi.createSession(params)
            pi.openSession(id).use { session ->
                f.inputStream().use { ins ->
                    session.openWrite("automed.apk", 0, f.length()).use { out ->
                        ins.copyTo(out)
                        session.fsync(out)
                    }
                }
                val intencao = Intent(app, InstalarReceiver::class.java).setAction("com.zeroun.automed.INSTALAR")
                val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
                session.commit(PendingIntent.getBroadcast(app, id, intencao, flags).intentSender)
            }
            msg = "Instalando… o app pode fechar e abrir sozinho."; msgErro = false
        } catch (e: Exception) { msg = "Não consegui instalar: " + (e.message ?: "erro"); msgErro = true }
    }
}

/** Recebe o resultado da instalação (e abre a confirmação do Android quando ela for exigida). */
class InstalarReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(c: Context, i: Intent) {
        when (i.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                val conf = if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
                else i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                try {
                    if (conf != null) c.startActivity(conf.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                    Estado.ui { Atualizador.msg = "O Android quer a sua confirmação: abra o app e toque em Instalar agora."; Atualizador.msgErro = false }
                }
            }
            PackageInstaller.STATUS_SUCCESS -> { }
            else -> {
                val m = i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "erro"
                Estado.ui { Atualizador.msg = "Falha ao instalar: $m"; Atualizador.msgErro = true }
            }
        }
    }
}

@Composable
fun CartaoAtualizacao() {
    val ctx = LocalContext.current
    val (codAtual, nomeAtual) = Atualizador.versaoAtual(ctx)
    val info = Atualizador.disponivel?.takeIf { it.codigo > codAtual }
    val cor = if (info != null) Cor.Laranja else Cor.Verde
    Cartao {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconeCaixa(Icons.Rounded.SystemUpdate, cor, 46)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(if (info != null) "Nova versão ${info.nome}" else "App atualizado", color = Cor.Texto, fontSize = 17.sp, fontWeight = FontWeight.Black)
                Text("Versão instalada: $nomeAtual", color = Cor.Muted, fontSize = 12.sp)
            }
        }
        if (info != null && info.notas.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(info.notas, color = Cor.Muted, fontSize = 13.sp)
        }
        Spacer(Modifier.height(12.dp))
        if (Atualizador.baixando) {
            LinearProgressIndicator(
                progress = { Atualizador.progresso }, modifier = Modifier.fillMaxWidth().height(8.dp),
                color = Cor.Azul, trackColor = Cor.Card2
            )
            Spacer(Modifier.height(6.dp))
            Text("Baixando… ${(Atualizador.progresso * 100).toInt()}%", color = Cor.Muted, fontSize = 12.sp)
        } else if (info != null) {
            val pronto = Atualizador.arquivoPronto
            if (pronto != null) Botao("Instalar agora", Cor.Verde, icone = Icons.Rounded.Download) { Atualizador.instalar(ctx, pronto) }
            else Botao("Baixar e instalar", Cor.Verde, icone = Icons.Rounded.Download) { Atualizador.baixar(ctx, info) }
        } else {
            Botao(if (Atualizador.verificando) "Procurando…" else "Procurar atualização", Cor.Card2, icone = Icons.Rounded.Refresh, enabled = !Atualizador.verificando) {
                Atualizador.verificar(ctx, true)
            }
        }
        if (Atualizador.msg.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(Atualizador.msg, color = if (Atualizador.msgErro) Cor.Vermelho else Cor.Verde, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        var auto by remember { mutableStateOf(Prefs.autoUpdate) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Atualizar sozinho", color = Cor.Texto, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(
                    if (Atualizador.podeInstalar(ctx)) "Baixa e instala quando sair versão nova." else "Falta permitir a instalação (toque no botão ao lado).",
                    color = Cor.Muted, fontSize = 11.sp
                )
            }
            Switch(
                checked = auto,
                onCheckedChange = { novo ->
                    auto = novo; Prefs.autoUpdate = novo
                    if (novo && !Atualizador.podeInstalar(ctx)) Atualizador.pedirPermissaoInstalar(ctx)
                },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White, checkedTrackColor = Cor.Verde, checkedBorderColor = Color.Transparent,
                    uncheckedThumbColor = Cor.Muted, uncheckedTrackColor = Cor.Card2, uncheckedBorderColor = Color.Transparent
                )
            )
        }
        Spacer(Modifier.height(8.dp))
        Text("A atualização entra por cima: sua key, o celular vinculado e as configurações continuam.", color = Cor.Muted, fontSize = 11.sp)
    }
}
