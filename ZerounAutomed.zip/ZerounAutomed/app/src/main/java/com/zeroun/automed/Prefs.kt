package com.zeroun.automed

import android.content.Context
import java.util.UUID

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("zeroun", Context.MODE_PRIVATE)
    var url: String get() = sp.getString("url", "") ?: ""; set(v) = sp.edit().putString("url", v.trim().trimEnd('/')).apply()
    var key: String get() = sp.getString("key", "") ?: ""; set(v) = sp.edit().putString("key", v.trim().uppercase()).apply()
    var dark: Boolean get() = sp.getBoolean("dark", false); set(v) = sp.edit().putBoolean("dark", v).apply()
    var gmail: Boolean get() = sp.getBoolean("gmail", true); set(v) = sp.edit().putBoolean("gmail", v).apply()
    var pag: Boolean get() = sp.getBoolean("pag", true); set(v) = sp.edit().putBoolean("pag", v).apply()
    var apps: Set<String> get() = sp.getStringSet("apps", emptySet()) ?: emptySet(); set(v) = sp.edit().putStringSet("apps", v).apply()
    var connected: Boolean get() = sp.getBoolean("connected", false); set(v) = sp.edit().putBoolean("connected", v).apply()
    val deviceId: String get() = sp.getString("dev", null) ?: UUID.randomUUID().toString().also { sp.edit().putString("dev", it).apply() }
}
