# Link curto de playlist (app + servidor)

Antes: o link levava a playlist INTEIRA dentro dele (~50 caracteres por música).
Agora: `zeroun://playlist/k7Qx2mP` — só um código. A playlist fica no servidor e o app busca lá.

- Compartilhar a mesma playlist de novo gera o **mesmo link** e atualiza as músicas dele.
- Quem importa recebe uma **cópia nova** (não mexe nas playlists dele).
- Se o servidor estiver fora do ar ao compartilhar, o app gera o **link longo antigo** (plano B). Links longos antigos continuam funcionando.

## Servidor (obrigatório para o link curto)
1. Copie `docs/servidor-playlist-link.js` para a pasta do `index.js` com o nome `playlist-link.js`.
2. No `index.js`, no topo: `const PL = require('./playlist-link');`
3. Crie 2 rotas (POST, corpo JSON, resposta JSON — do mesmo jeito que as rotas `/api/...` já respondem):

```js
// salvar: valide a key/celular como nas outras rotas e só então chame PL.salvar
if (req.method === 'POST' && path === '/musica/playlist/salvar') {
  // if (!keyValida(body.key, body.deviceId)) return responder({ ok:false, msg:'Key inválida.' });
  return responder(PL.salvar(body));
}
// ler: sem key (quem recebe o link pode ter outra key ou nenhuma)
if (req.method === 'POST' && path === '/musica/playlist/ler') {
  return responder(PL.ler(body));
}
```
4. Reinicie o bot. As playlists ficam em `app_playlists.json` (faça backup junto do `keys.json`).

Teste rápido sem o app: `POST /musica/playlist/salvar` com `{"key":"SUAKEY","deviceId":"x","pid":"p1","nome":"Teste","faixas":[["dQw4w9WgXcQ","Titulo","Artista",200]]}` → `{ok:true,codigo:"..."}`; depois `POST /musica/playlist/ler` com `{"codigo":"..."}`.

## App
`LinkPlaylist` (Musica.kt): `compartilhar()` publica e devolve o link; `ler()` busca o código no servidor (ou decodifica o link longo na hora). As telas Compartilhar e Colar link (MusicaUI.kt) agora esperam a rede ("Gerando link…" / "Buscando playlist…").
