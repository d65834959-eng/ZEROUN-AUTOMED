package com.zeroun.automed

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.json.JSONObject

// ───────────────────────── modelos ─────────────────────────

data class Faixa(val salas: Int, val valor: Double)
data class Ganho(val ts: Long, val valor: Double, val servidor: String, val sala: String)
data class CanalInfo(val id: String, val nome: String, val cat: String)
data class ServidorIA(val id: String, val nome: String, val canais: Int)

// ───────────────────────── estado + rede das telas novas ─────────────────────────

object Gestao {
    // ---- sistema ----
    var sisCarregado by mutableStateOf(false)
    var sisErro by mutableStateOf("")
    var sisAtivo by mutableStateOf<Boolean?>(null)
    var sisExpiraTs by mutableStateOf(0L)
    var sisExpiraTxt by mutableStateOf("")
    var sisPlano by mutableStateOf("")
    var sisEstado by mutableStateOf("")
    var sisCongelada by mutableStateOf(false)
    var sisOcupado by mutableStateOf(false)

    // ---- lucros ----
    var lucCarregado by mutableStateOf(false)
    var lucErro by mutableStateOf("")
    var valorSala by mutableStateOf(0.0)
    var lucHoje by mutableStateOf(Faixa(0, 0.0))
    var lucSemana by mutableStateOf(Faixa(0, 0.0))
    var lucMes by mutableStateOf(Faixa(0, 0.0))
    var lucTotal by mutableStateOf(Faixa(0, 0.0))
    var lucAcumulado by mutableStateOf(0.0)
    var historico by mutableStateOf<List<Ganho>>(emptyList())

    // ---- IA e canais de regras ----
    var iaCarregado by mutableStateOf(false)
    var iaCarregando by mutableStateOf(false)
    var iaErro by mutableStateOf("")
    var iaConfigurada by mutableStateOf(false)
    var iaModelo by mutableStateOf("")
    var iaMax by mutableStateOf(5)
    var iaOnline by mutableStateOf(false)
    var iaServidores by mutableStateOf<List<ServidorIA>>(emptyList())
    var iaGuild by mutableStateOf("")
    var iaCanais by mutableStateOf<List<CanalInfo>>(emptyList())
    var iaSelecionados by mutableStateOf<List<String>>(emptyList())

    // ───── helpers ─────
    private fun chamar(path: String, corpo: JSONObject = Net.corpo(), fim: (JSONObject?) -> Unit) {
        Thread {
            val r = Net.post(path, corpo)
            Estado.ui { fim(r) }
        }.start()
    }

    private fun erroDe(r: JSONObject?): String =
        if (r == null) "Sem resposta do bot. Confira a internet." else r.optString("msg", "Erro ao falar com o bot.")

    private fun acao(corpo: JSONObject, aoOk: () -> Unit = {}) {
        Thread {
            val r = Net.post("/api/acao", corpo)
            val ok = r != null && r.optBoolean("ok", false)
            val msg = if (r == null) "Sem resposta do bot." else r.optString("msg", if (ok) "Salvo." else "Erro.")
            Painel.mostrar(msg, ok)
            if (ok) Estado.ui { aoOk() }
        }.start()
    }

    private fun faixa(o: JSONObject?): Faixa = Faixa(o?.optInt("salas", 0) ?: 0, o?.optDouble("valor", 0.0) ?: 0.0)

    // ───── sistema ─────
    fun carregarSistema() {
        if (sisOcupado) return
        sisOcupado = true
        chamar("/api/sistema") { r ->
            sisOcupado = false
            if (r != null && r.optBoolean("ok", false)) {
                sisErro = ""
                sisAtivo = if (r.has("ativo")) r.optBoolean("ativo") else null
                sisExpiraTs = r.optLong("expiraTs", 0L)
                sisExpiraTxt = r.optString("expira", "")
                sisPlano = r.optString("plano", "")
                sisEstado = r.optString("estado", "")
                sisCongelada = r.optBoolean("congelada", false)
            } else {
                sisErro = erroDe(r)
            }
            sisCarregado = true
        }
    }

    fun definirAtivo(ativar: Boolean) {
        if (sisOcupado) return
        sisOcupado = true
        Thread {
            val r = Net.post("/api/acao", Painel.corpoAcao("sistema_ativar").put("valor", ativar))
            val ok = r != null && r.optBoolean("ok", false)
            val msg = if (r == null) "Sem resposta do bot." else r.optString("msg", if (ok) (if (ativar) "Bot ativado." else "Bot desligado.") else "Erro.")
            Painel.mostrar(msg, ok)
            Estado.ui { sisOcupado = false; if (ok) sisAtivo = ativar }
            if (ok) Estado.ui { carregarSistema() }
        }.start()
    }

    fun reiniciar() {
        acao(Painel.corpoAcao("sistema_reiniciar")) { carregarSistema() }
    }

    // ───── lucros ─────
    fun carregarLucros() {
        chamar("/api/lucros") { r ->
            if (r != null && r.optBoolean("ok", false)) {
                lucErro = ""
                valorSala = r.optDouble("valorPorSala", 0.0)
                lucAcumulado = r.optDouble("acumulado", 0.0)
                lucHoje = faixa(r.optJSONObject("hoje"))
                lucSemana = faixa(r.optJSONObject("semana"))
                lucMes = faixa(r.optJSONObject("mes"))
                lucTotal = faixa(r.optJSONObject("total"))
                val arr = r.optJSONArray("historico")
                val lista = ArrayList<Ganho>()
                if (arr != null) for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    lista.add(Ganho(o.optLong("ts", 0L), o.optDouble("valor", 0.0), o.optString("servidor", ""), o.optString("sala", "")))
                }
                historico = lista
            } else {
                lucErro = erroDe(r)
            }
            lucCarregado = true
        }
    }

    fun salvarValorSala(v: Double) {
        acao(Painel.corpoAcao("lucro_valor").put("valor", v)) { valorSala = v; carregarLucros() }
    }

    // ───── IA e canais de regras ─────
    fun carregarIA(guildId: String? = null) {
        iaCarregando = true
        val corpo = Net.corpo()
        if (!guildId.isNullOrBlank()) corpo.put("guildId", guildId)
        chamar("/api/ia", corpo) { r ->
            iaCarregando = false
            if (r != null && r.optBoolean("ok", false)) {
                iaErro = ""
                iaConfigurada = r.optBoolean("configurada", false)
                iaModelo = r.optString("modelo", "")
                iaMax = r.optInt("max", 5)
                iaOnline = r.optBoolean("online", false)
                val sv = ArrayList<ServidorIA>()
                val a = r.optJSONArray("servidores")
                if (a != null) for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    sv.add(ServidorIA(o.optString("id", ""), o.optString("nome", ""), o.optInt("canais", 0)))
                }
                iaServidores = sv
                if (r.has("guildId")) {
                    iaGuild = r.optString("guildId", "")
                    val cs = ArrayList<CanalInfo>()
                    val ac = r.optJSONArray("canais")
                    if (ac != null) for (i in 0 until ac.length()) {
                        val o = ac.getJSONObject(i)
                        cs.add(CanalInfo(o.optString("id", ""), o.optString("nome", ""), o.optString("cat", "")))
                    }
                    iaCanais = cs
                    val sl = ArrayList<String>()
                    val asl = r.optJSONArray("selecionados")
                    if (asl != null) for (i in 0 until asl.length()) sl.add(asl.optString(i, ""))
                    iaSelecionados = sl
                }
            } else {
                iaErro = erroDe(r)
            }
            iaCarregado = true
        }
    }

    fun salvarCanaisIA(guildId: String, ids: List<String>) {
        acao(
            Painel.corpoAcao("ia_canais").put("guildId", guildId).put("canais", org.json.JSONArray(ids))
        ) { carregarIA(guildId) }
    }

    fun limparMemoriaIA() {
        acao(Painel.corpoAcao("ia_limpar"))
    }
}

// ───────────────────────── utilidades ─────────────────────────

fun restante(ts: Long, agora: Long): String {
    val d = ts - agora
    if (d <= 0) return "Expirada"
    val dias = d / 86_400_000
    val horas = (d / 3_600_000) % 24
    val min = (d / 60_000) % 60
    return when {
        dias > 0 -> "${dias}d ${horas}h ${min}min"
        horas > 0 -> "${horas}h ${min}min"
        else -> "${min}min"
    }
}

fun mascararKey(k: String): String {
    if (k.isBlank()) return "—"
    if (k.length <= 12) return "•".repeat(k.length)
    return k.take(8) + "•".repeat((k.length - 12).coerceAtMost(14)) + k.takeLast(4)
}

fun lerValor(s: String): Double? =
    s.trim().replace("R$", "").replace(" ", "").replace(",", ".").toDoubleOrNull()?.takeIf { it >= 0.0 }

@Composable
private fun CartaoErro(msg: String, aoTentar: () -> Unit) {
    Cartao(Modifier.border(1.dp, Cor.Laranja.copy(alpha = 0.6f), RoundedCornerShape(20.dp))) {
        Text("⚠️ " + msg, color = Cor.Laranja, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(Modifier.height(4.dp))
        Text(
            "Se aparecer \"Endpoint desconhecido\", o servidor do bot ainda não tem essa função (veja API-NOVOS-ENDPOINTS.md).",
            color = Cor.Muted, fontSize = 11.sp
        )
        Spacer(Modifier.height(10.dp))
        Botao("Tentar de novo", Cor.Card2) { aoTentar() }
    }
}

@Composable
private fun PedirConexao() {
    Cartao {
        Text("🔗 Conecte o app primeiro", color = Cor.Laranja, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text("Abra \"Conexão\" no início e coloque a key. Depois essa tela carrega sozinha.", color = Cor.Muted, fontSize = 12.sp)
    }
}

@Composable
private fun CartaoNumero(valor: String, rotulo: String, sub: String, cor: Color, modifier: Modifier) {
    val forma = RoundedCornerShape(18.dp)
    Column(
        modifier.clip(forma).background(cor.copy(alpha = 0.14f)).border(1.dp, cor.copy(alpha = 0.35f), forma).padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(valor, color = cor, fontSize = 15.sp, fontWeight = FontWeight.Black, maxLines = 1)
        Text(rotulo, color = Cor.Texto, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text(sub, color = Cor.Muted, fontSize = 10.sp)
    }
}

@Composable
private fun CorSwitch() = SwitchDefaults.colors(
    checkedThumbColor = Color.White, checkedTrackColor = Cor.Verde, checkedBorderColor = Color.Transparent,
    uncheckedThumbColor = Cor.Muted, uncheckedTrackColor = Cor.Card2, uncheckedBorderColor = Color.Transparent
)

// ───────────────────────── GERENCIAR SISTEMA ─────────────────────────

@Composable
fun SistemaTela() {
    LaunchedEffect(Unit) { while (true) { if (Prefs.conectado) Gestao.carregarSistema(); delay(5000) } }
    var agora by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(15_000); agora = System.currentTimeMillis() } }
    var mostrarKey by remember { mutableStateOf(false) }
    var copiado by remember { mutableStateOf(false) }
    var confirmarDesligar by remember { mutableStateOf(false) }
    val clip = LocalClipboardManager.current

    AvisoBarra()
    if (!Prefs.conectado) { PedirConexao(); return }

    val ativo = Gestao.sisAtivo
    val cor = when (ativo) { true -> Cor.Verde; false -> Cor.Vermelho; null -> Cor.Laranja }

    // ── cartão principal: status + botão ──
    val forma = RoundedCornerShape(26.dp)
    Column(
        Modifier.fillMaxWidth().clip(forma)
            .background(Brush.linearGradient(listOf(cor.copy(alpha = 0.40f), Cor.Card, Cor.Roxo.copy(alpha = 0.22f))))
            .border(1.dp, cor.copy(alpha = 0.5f), forma).padding(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(56.dp).clip(CircleShape).background(cor.copy(alpha = 0.28f)), contentAlignment = Alignment.Center) {
                Text(if (ativo == true) "⚡" else if (ativo == false) "💤" else "❔", fontSize = 28.sp)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("STATUS DO BOT", color = Cor.Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text(
                    when (Gestao.sisEstado) {
                        "online" -> "Bot online"
                        "conectando" -> "Conectando…"
                        "parado" -> "Bot desligado"
                        "sem" -> "Não configurado"
                        else -> when (ativo) { true -> "Bot ativo"; false -> "Bot desligado"; null -> if (Gestao.sisCarregado) "Status desconhecido" else "Verificando…" }
                    },
                    color = Cor.Texto, fontSize = 24.sp, fontWeight = FontWeight.Black
                )
                if (Gestao.sisEstado == "sem") Text("Falta o token ou o Gmail no Discord (/central).", color = Cor.Muted, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
        if (Gestao.sisCongelada) {
            Text("🧊 Key congelada: o tempo está pausado. Descongele no Discord (Gerenciar sistema).", color = Cor.Laranja, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
        }
        if (ativo == true) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Botao("🔄  Reiniciar", Cor.Azul, Modifier.weight(1f)) { Gestao.reiniciar() }
                Botao(if (Gestao.sisOcupado) "Aguarde…" else "⏻  Desligar", Cor.Vermelho, Modifier.weight(1f)) { confirmarDesligar = true }
            }
        } else {
            Botao(if (Gestao.sisOcupado) "Aguarde…" else "⚡  Ativar bot", Cor.Verde) { Gestao.definirAtivo(true) }
        }
    }

    if (Gestao.sisErro.isNotBlank()) CartaoErro(Gestao.sisErro) { Gestao.carregarSistema() }

    // ── tempo restante ──
    TituloGrupo("TEMPO RESTANTE", Cor.Ciano)
    val temTs = Gestao.sisExpiraTs > 0
    val txtRestante = if (temTs) restante(Gestao.sisExpiraTs, agora) else Gestao.sisExpiraTxt.ifBlank { Painel.expira }.ifBlank { "—" }
    val acabando = temTs && Gestao.sisExpiraTs - agora < 3 * 86_400_000L
    val corTempo = if (temTs && Gestao.sisExpiraTs <= agora) Cor.Vermelho else if (acabando) Cor.Laranja else Cor.Ciano
    Cartao {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("⏳", fontSize = 30.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(txtRestante, color = corTempo, fontSize = 26.sp, fontWeight = FontWeight.Black)
                val sub = if (temTs) "Expira em " + hora(Gestao.sisExpiraTs) else "Prazo informado pelo bot"
                Text(sub, color = Cor.Muted, fontSize = 12.sp)
            }
        }
        if (acabando) {
            Spacer(Modifier.height(10.dp))
            Text("⚠️ Sua key está perto de vencer. Renove para o bot não parar.", color = Cor.Laranja, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }

    // ── key ──
    TituloGrupo("SUA KEY", Cor.Roxo)
    Cartao {
        Text(
            if (mostrarKey) Prefs.key.ifBlank { "—" } else mascararKey(Prefs.key),
            color = Cor.Roxo, fontSize = 15.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace,
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Cor.Fundo).padding(12.dp)
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BotaoMini(if (mostrarKey) "🙈 Ocultar" else "👁️ Mostrar", Cor.Azul) { mostrarKey = !mostrarKey }
            BotaoMini(if (copiado) "✅ Copiada" else "📋 Copiar", Cor.Verde) {
                clip.setText(AnnotatedString(Prefs.key)); copiado = true
            }
        }
        if (Gestao.sisPlano.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Selo("Plano • " + Gestao.sisPlano, Cor.Ciano)
        }
    }

    // ── detalhes ──
    TituloGrupo("DETALHES", Cor.Azul)
    Cartao {
        LinhaInfo("👤", "Conta Discord", Painel.nome.ifBlank { "—" })
        Spacer(Modifier.height(12.dp))
        LinhaInfo("🟢", "Conta", if (Painel.contaOnline) "Online" else "Offline")
        Spacer(Modifier.height(12.dp))
        LinhaInfo("🤖", "AutoMed", if (Painel.automed) "Ligado" else "Desligado")
        Spacer(Modifier.height(12.dp))
        LinhaInfo("📱", "Este celular", Prefs.deviceId.takeLast(10))
    }
    Botao("🔄  Atualizar", Cor.Card2) { Gestao.carregarSistema(); Painel.carregar() }

    if (confirmarDesligar) {
        AlertDialog(
            onDismissRequest = { confirmarDesligar = false },
            containerColor = Cor.Card, titleContentColor = Cor.Texto, textContentColor = Cor.Muted,
            title = { Text("⏻  Desligar o bot?", fontWeight = FontWeight.Bold) },
            text = { Text("O bot para de criar salas e de responder até você ativar de novo.") },
            confirmButton = {
                TextButton(onClick = { confirmarDesligar = false; Gestao.definirAtivo(false) }) {
                    Text("Desligar", color = Cor.Vermelho, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { confirmarDesligar = false }) { Text("Cancelar", color = Cor.Muted) } }
        )
    }
}

// ───────────────────────── LUCROS ─────────────────────────

@Composable
fun LucrosTela() {
    LaunchedEffect(Unit) { while (true) { if (Prefs.conectado) Gestao.carregarLucros(); delay(8000) } }
    var campo by remember(Gestao.valorSala) { mutableStateOf(if (Gestao.valorSala > 0) String.format(java.util.Locale.US, "%.2f", Gestao.valorSala).replace(".", ",") else "") }
    var erroCampo by remember { mutableStateOf("") }

    AvisoBarra()
    if (!Prefs.conectado) { PedirConexao(); return }
    if (Gestao.lucErro.isNotBlank()) CartaoErro(Gestao.lucErro) { Gestao.carregarLucros() }
    if (!Gestao.lucCarregado) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) { Pill("Carregando…", Cor.Ciano) }
    }

    // ── destaque: lucro de hoje ──
    val forma = RoundedCornerShape(26.dp)
    Column(
        Modifier.fillMaxWidth().clip(forma)
            .background(Brush.linearGradient(listOf(Cor.Verde.copy(alpha = 0.45f), Cor.Card, Cor.Ciano.copy(alpha = 0.2f))))
            .border(1.dp, Color.White.copy(alpha = 0.1f), forma).padding(20.dp)
    ) {
        Text("LUCRO DE HOJE", color = Cor.Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(6.dp))
        Text(brl(Gestao.lucHoje.valor), color = Cor.Verde, fontSize = 36.sp, fontWeight = FontWeight.Black)
        Text("${Gestao.lucHoje.salas} sala(s) criada(s) hoje", color = Cor.Texto, fontSize = 13.sp)
    }

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        CartaoNumero(brl(Gestao.lucSemana.valor), "Esta semana", "${Gestao.lucSemana.salas} salas", Cor.Azul, Modifier.weight(1f))
        CartaoNumero(brl(Gestao.lucMes.valor), "Este mês", "${Gestao.lucMes.salas} salas", Cor.Roxo, Modifier.weight(1f))
        CartaoNumero(brl(Gestao.lucTotal.valor), "Total", "${Gestao.lucTotal.salas} salas", Cor.Rosa, Modifier.weight(1f))
    }

    // ── valor por sala ──
    TituloGrupo("VALOR POR SALA CRIADA", Cor.Laranja)
    Cartao {
        Text("💰 Quanto você ganha a cada sala", color = Cor.Texto, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text("Cada sala criada pelo bot soma esse valor ao seu lucro.", color = Cor.Muted, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = campo, onValueChange = { campo = it.take(10); erroCampo = "" }, singleLine = true,
            label = { Text("Valor (R$)") }, placeholder = { Text("Ex.: 1,50") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth()
        )
        if (erroCampo.isNotBlank()) { Spacer(Modifier.height(4.dp)); Text(erroCampo, color = Cor.Vermelho, fontSize = 12.sp) }
        Spacer(Modifier.height(6.dp))
        Text("Valor atual: " + brl(Gestao.valorSala), color = Cor.Muted, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        Botao("Salvar valor", Cor.Verde) {
            val v = lerValor(campo)
            if (v == null) erroCampo = "Digite um valor válido (ex.: 1,50)." else Gestao.salvarValorSala(v)
        }
    }

    Cartao {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("📈", fontSize = 24.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Acumulado (.lucro)", color = Cor.Muted, fontSize = 12.sp)
                Text(brl(Gestao.lucAcumulado), color = Cor.Texto, fontWeight = FontWeight.Black, fontSize = 18.sp)
            }
        }
    }

    // ── pix lidos (do celular) ──
    TituloGrupo("PIX RECEBIDOS HOJE", Cor.Ciano)
    Cartao {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("💸", fontSize = 26.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(brl(Estado.totalHoje), color = Cor.Ciano, fontWeight = FontWeight.Black, fontSize = 20.sp)
                Text("${Estado.hoje} Pix lido(s) pelo celular/Gmail", color = Cor.Muted, fontSize = 12.sp)
            }
        }
    }

    // ── histórico ──
    TituloGrupo("ÚLTIMAS SALAS", Cor.Rosa)
    if (Gestao.historico.isEmpty()) {
        Cartao { Text("Nenhuma sala registrada ainda.", color = Cor.Muted, fontSize = 12.sp) }
    }
    Gestao.historico.take(30).forEach { g ->
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Cor.Card)
                .border(1.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(16.dp)).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Avatar(g.servidor.ifBlank { "S" }, Cor.Verde, 38)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(g.sala.ifBlank { "Sala criada" }, color = Cor.Texto, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(g.servidor.ifBlank { "—" } + "  •  " + hora(g.ts), color = Cor.Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text("+" + brl(g.valor), color = Cor.Verde, fontWeight = FontWeight.Black, fontSize = 15.sp)
        }
    }
}

// ───────────────────────── IA E CANAIS DE REGRAS ─────────────────────────

@Composable
fun DialogCanais(titulo: String, canais: List<CanalInfo>, marcados: List<String>, maximo: Int, onSalvar: (List<String>) -> Unit, onFechar: () -> Unit) {
    var busca by remember { mutableStateOf("") }
    var sel by remember { mutableStateOf(marcados) }
    var aviso by remember { mutableStateOf("") }
    val lista = canais.filter { busca.isBlank() || it.nome.contains(busca, ignoreCase = true) || it.cat.contains(busca, ignoreCase = true) }
    AlertDialog(
        onDismissRequest = onFechar,
        containerColor = Cor.Card, titleContentColor = Cor.Texto, textContentColor = Cor.Texto,
        title = {
            Column {
                Text("📌  " + titulo, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("Escolhidos: ${sel.size}/$maximo", color = if (sel.size >= maximo) Cor.Laranja else Cor.Muted, fontSize = 12.sp)
            }
        },
        text = {
            Column {
                OutlinedTextField(
                    value = busca, onValueChange = { busca = it }, singleLine = true,
                    label = { Text("Buscar canal") }, modifier = Modifier.fillMaxWidth()
                )
                if (aviso.isNotBlank()) { Spacer(Modifier.height(6.dp)); Text(aviso, color = Cor.Laranja, fontSize = 12.sp) }
                Spacer(Modifier.height(10.dp))
                Column(Modifier.heightIn(max = 340.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (lista.isEmpty()) {
                        Text(
                            if (canais.isEmpty()) "Nenhum canal carregado. A conta precisa estar online (ative em Gerenciar sistema)." else "Nenhum canal encontrado.",
                            color = Cor.Muted, fontSize = 12.sp
                        )
                    }
                    lista.forEach { c ->
                        val on = sel.contains(c.id)
                        val forma = RoundedCornerShape(12.dp)
                        Row(
                            Modifier.fillMaxWidth().clip(forma)
                                .background(if (on) Cor.Verde.copy(alpha = 0.16f) else Cor.Card2.copy(alpha = 0.7f))
                                .border(1.dp, if (on) Cor.Verde else Color.White.copy(alpha = 0.06f), forma)
                                .clickable {
                                    aviso = ""
                                    if (on) sel = sel - c.id
                                    else if (sel.size >= maximo) aviso = "Máximo de $maximo canais. Desmarque um antes."
                                    else sel = sel + c.id
                                }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text("#  " + c.nome, color = Cor.Texto, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                if (c.cat.isNotBlank()) Text(c.cat, color = Cor.Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            if (on) Text("✓", color = Cor.Verde, fontWeight = FontWeight.Black, fontSize = 18.sp)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onSalvar(sel) }) { Text("Salvar", color = Cor.Verde, fontWeight = FontWeight.Bold) } },
        dismissButton = {
            Row {
                TextButton(onClick = { onSalvar(emptyList()) }) { Text("Limpar", color = Cor.Laranja) }
                TextButton(onClick = onFechar) { Text("Cancelar", color = Cor.Muted) }
            }
        }
    )
}

@Composable
fun IaTela() {
    LaunchedEffect(Unit) { if (Prefs.conectado) Gestao.carregarIA(null) }
    var busca by remember { mutableStateOf("") }
    var abrir by remember { mutableStateOf<ServidorIA?>(null) }

    AvisoBarra()
    if (!Prefs.conectado) { PedirConexao(); return }
    if (Gestao.iaErro.isNotBlank()) { CartaoErro(Gestao.iaErro) { Gestao.carregarIA(null) }; return }
    if (!Gestao.iaCarregado) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) { Pill("Carregando…", Cor.Ciano) }
        return
    }

    val cor = if (Gestao.iaConfigurada) Cor.Azul else Cor.Laranja
    val forma = RoundedCornerShape(26.dp)
    Column(
        Modifier.fillMaxWidth().clip(forma)
            .background(Brush.linearGradient(listOf(cor.copy(alpha = 0.45f), Cor.Card, Cor.Roxo.copy(alpha = 0.2f))))
            .border(1.dp, cor.copy(alpha = 0.5f), forma).padding(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp).clip(CircleShape).background(cor.copy(alpha = 0.3f)), contentAlignment = Alignment.Center) { Text("🤖", fontSize = 26.sp) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("IA ZEROUN", color = Cor.Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text(if (Gestao.iaConfigurada) "IA pronta" else "IA sem chave", color = Cor.Texto, fontSize = 22.sp, fontWeight = FontWeight.Black)
            }
            if (Gestao.iaModelo.isNotBlank()) Selo(Gestao.iaModelo.substringAfterLast('/').take(22), Cor.Azul)
        }
        Spacer(Modifier.height(12.dp))
        Text(
            if (Gestao.iaConfigurada)
                "No Discord use .ia pergunta (ou responda uma pergunta com .ia). A IA procura a resposta só nos canais que você escolher abaixo, como regras e avisos."
            else
                "O servidor do bot está sem a GEMINI_API_KEY, então a IA não consegue responder. Você ainda pode escolher os canais, mas precisa colocar a chave no .env do bot.",
            color = Cor.Muted, fontSize = 12.sp
        )
    }

    if (!Gestao.iaOnline) {
        Cartao(Modifier.border(1.dp, Cor.Laranja.copy(alpha = 0.6f), RoundedCornerShape(20.dp))) {
            Text("⚠️ Conta offline", color = Cor.Laranja, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("A lista de canais só carrega com a conta online. Ative o bot em Gerenciar sistema.", color = Cor.Muted, fontSize = 12.sp)
        }
    }

    TituloGrupo("CANAIS DE REGRAS POR SERVIDOR", Cor.Rosa)
    Text("Escolha até ${Gestao.iaMax} canais por servidor para a IA ler.", color = Cor.Muted, fontSize = 12.sp)
    OutlinedTextField(
        value = busca, onValueChange = { busca = it }, singleLine = true,
        label = { Text("Buscar servidor") }, modifier = Modifier.fillMaxWidth()
    )
    val lista = Gestao.iaServidores.filter { busca.isBlank() || it.nome.contains(busca, ignoreCase = true) }
    if (Gestao.iaServidores.isEmpty()) {
        Cartao { Text("Nenhum servidor carregado. A conta precisa estar online.", color = Cor.Muted, fontSize = 12.sp) }
    }
    lista.forEach { sv ->
        val forma2 = RoundedCornerShape(16.dp)
        Row(
            Modifier.fillMaxWidth().clip(forma2).background(Cor.Card)
                .border(1.dp, (if (sv.canais > 0) Cor.Verde else Color.White).copy(alpha = if (sv.canais > 0) 0.4f else 0.06f), forma2)
                .clickable { abrir = sv; Gestao.carregarIA(sv.id) }
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Avatar(sv.nome, if (sv.canais > 0) Cor.Verde else Cor.Roxo, 42)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(sv.nome, color = Cor.Texto, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(4.dp))
                if (sv.canais > 0) Selo("${sv.canais}/${Gestao.iaMax} canais", Cor.Verde) else Selo("nenhum canal", Cor.Muted)
            }
            Text("›", color = Cor.Rosa, fontSize = 24.sp, fontWeight = FontWeight.Black)
        }
    }

    TituloGrupo("MEMÓRIA DA IA", Cor.Azul)
    Cartao {
        Text("🧹 A IA guarda por 5 minutos o que leu", color = Cor.Texto, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text("Mudou as regras no Discord? Toque abaixo para a IA reler os canais na próxima pergunta.", color = Cor.Muted, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        Botao("Atualizar o que a IA leu", Cor.Card2) { Gestao.limparMemoriaIA() }
    }

    val a = abrir
    if (a != null) {
        if (Gestao.iaGuild == a.id && !Gestao.iaCarregando) {
            DialogCanais(a.nome, Gestao.iaCanais, Gestao.iaSelecionados, Gestao.iaMax,
                onSalvar = { ids -> Gestao.salvarCanaisIA(a.id, ids); abrir = null },
                onFechar = { abrir = null })
        } else {
            AlertDialog(
                onDismissRequest = { abrir = null },
                containerColor = Cor.Card, titleContentColor = Cor.Texto, textContentColor = Cor.Muted,
                title = { Text("📌  " + a.nome, fontWeight = FontWeight.Bold, maxLines = 1) },
                text = { Text("Carregando canais…") },
                confirmButton = {},
                dismissButton = { TextButton(onClick = { abrir = null }) { Text("Cancelar", color = Cor.Muted) } }
            )
        }
    }
}
