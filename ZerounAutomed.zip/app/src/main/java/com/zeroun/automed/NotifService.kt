package com.zeroun.automed

import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONObject

class NotifService : NotificationListenerService() {

    private val h = Handler(Looper.getMainLooper())
    private val checarAtualizacao = object : Runnable {
        override fun run() {
            try { Atualizador.verificar(applicationContext, false) } catch (e: Exception) { }
            h.postDelayed(this, 900_000L)
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        Estado.init(applicationContext)
        h.removeCallbacks(checarAtualizacao)
        h.post(checarAtualizacao)
    }

    override fun onListenerDisconnected() {
        h.removeCallbacks(checarAtualizacao)
        super.onListenerDisconnected()
    }

    override fun onCreate() {
        super.onCreate()
        Estado.init(applicationContext)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            Estado.init(applicationContext)
            val pkg = sbn.packageName ?: return
            if (pkg == packageName) return
            if (Prefs.key.isBlank() || Prefs.url.isBlank() || Prefs.soMusica) return

            val permitido = if (Prefs.gmail) pkg == "com.google.android.gm" else Prefs.apps.contains(pkg)
            if (!permitido) return

            val ex = sbn.notification.extras
            val titulo = ex.getCharSequence("android.title")?.toString() ?: ""
            val texto = (ex.getCharSequence("android.bigText") ?: ex.getCharSequence("android.text"))?.toString() ?: ""
            if (titulo.isBlank() && texto.isBlank()) return
            // Alguns bancos escondem o nome em outros campos da notificação
            val extra = listOfNotNull(
                ex.getCharSequence("android.subText")?.toString(),
                ex.getCharSequence("android.summaryText")?.toString(),
                ex.getCharSequence("android.infoText")?.toString(),
                ex.getCharSequenceArray("android.textLines")?.joinToString(" ") { it.toString() },
                sbn.notification.tickerText?.toString()
            ).filter { it.isNotBlank() }.joinToString(" | ")

            val label = try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) { pkg }
            val ts = sbn.postTime

            Thread {
                val corpo = Net.corpo()
                    .put("app", label)
                    .put("pkg", pkg)
                    .put("pacote", pkg)
                    .put("titulo", titulo)
                    .put("texto", texto)
                    .put("extra", extra)
                    .put("ts", ts)
                tratarResposta(label, titulo, texto + " " + extra, ts, Net.post("/api/notificacao", corpo))
            }.start()
        } catch (e: Exception) { /* nunca derruba o serviço */ }
    }

    private fun tratarResposta(app: String, titulo: String, texto: String, ts: Long, r: JSONObject?) {
        val resumo = (titulo + " — " + texto).replace(Regex("\\s+"), " ").trim().take(140)
        var res: String
        var tipo = 0
        if (r == null) {
            res = "Sem resposta do bot"; tipo = 2
        } else if (!r.optBoolean("ok", false)) {
            res = r.optString("msg", "Erro no bot"); tipo = 2
        } else if (r.has("ativo") && !r.optBoolean("ativo", true)) {
            res = "Bot ignorou: \"Ativar notificações app\" está desligado no Discord"; tipo = 2
            Estado.ui { Estado.ativoApp = false }
        } else if (r.optBoolean("pix", false)) {
            val valor = r.optDouble("valor", 0.0)
            var nome = if (r.isNull("nome")) "" else r.optString("nome", "").trim()
            if (nome.isBlank() || nome.equals("null", true)) nome = extrairNome(titulo, texto)
            if (r.optBoolean("repetido", false)) {
                res = "Pix já lido antes (repetido)"
            } else {
                res = "Pix lido"
                tipo = 1
                Estado.addPix(PixItem(nome, valor, app, "app", ts))
            }
            Estado.ui { Estado.ativoApp = true; Estado.online = true }
        } else {
            res = "Ignorada (não parece Pix recebido)"
            Estado.ui { Estado.online = true }
        }
        Estado.addEvento(Evento(app, resumo, res, tipo, System.currentTimeMillis()))
    }

    /** Plano B: tenta achar o nome no texto quando o bot não achou. */
    private fun extrairNome(titulo: String, texto: String): String {
        val t = (titulo + " | " + texto).replace(Regex("\\s+"), " ")
        val nomeRx = "([\\p{L}][\\p{L}'.\\- ]{2,60}?)"
        val fim = "(?=\\s*(?:[.!,|\\n]|\\bvia\\b|\\bpelo\\b|\\bna\\b|\\bno\\b|\\bpara\\b|\\bàs\\b|$))"
        val padroes = listOf(
            // "recebeu R$ 1.000,00 de FULANO"
            Regex("R\\$\\s*[\\d.]+,\\d{2}\\s+(?:de|da|do)\\s+" + nomeRx + fim, RegexOption.IGNORE_CASE),
            // "Pix recebido de FULANO" / "transferência de FULANO"
            Regex("(?:pix|transfer[êe]ncia)(?:\\s+recebid[oa])?\\s+(?:de|da|do)\\s+(?!R\\$)" + nomeRx + fim, RegexOption.IGNORE_CASE),
            // "FULANO te enviou R$ ..."
            Regex("(?:^|\\| )" + nomeRx + "\\s+(?:te\\s+)?(?:enviou|transferiu|fez um pix)", RegexOption.IGNORE_CASE)
        )
        for (rx in padroes) {
            val n = rx.find(t)?.groupValues?.get(1)?.trim().orEmpty()
            if (n.length >= 3 && !n.contains("R$") && !n.matches(Regex(".*\\d.*"))) return n
        }
        return ""
    }
}
