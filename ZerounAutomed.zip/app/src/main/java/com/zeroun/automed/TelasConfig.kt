package com.zeroun.automed

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.json.JSONArray

// ───────────────────────── ícones e cores por tipo ─────────────────────────

fun emojiMsg(k: String): String = when (k) {
    "conf" -> "✅"; "nao" -> "❌"; "parcial" -> "⚠️"; "instr" -> "🤖"; "win" -> "🏆"; else -> "💬"
}

fun corMsg(k: String): Color = when (k) {
    "conf" -> Cor.Verde; "nao" -> Cor.Vermelho; "parcial" -> Cor.Laranja; "instr" -> Cor.Azul; "win" -> Cor.Rosa; else -> Cor.Roxo
}

fun emojiSala(k: String): String = when (k) {
    "normal" -> "🎮"; "infinito" -> "♾️"; "fullcapa" -> "🛡️"; "tatico" -> "🎯"; "speed" -> "⚡"; "meet" -> "🎥"; else -> "🏠"
}

fun corSala(k: String): Color = when (k) {
    "normal" -> Cor.Verde; "infinito" -> Cor.Roxo; "fullcapa" -> Cor.Azul; "tatico" -> Cor.Laranja; "speed" -> Cor.Rosa; "meet" -> Cor.Ciano; else -> Cor.Roxo
}

// ───────────────────────── seletor de servidor ─────────────────────────

@Composable
fun LinhaServidor(s: Servidor, onClick: (() -> Unit)?) {
    val forma = RoundedCornerShape(16.dp)
    var m = Modifier.fillMaxWidth().clip(forma).background(Cor.Card2.copy(alpha = 0.7f))
        .border(1.dp, Color.White.copy(alpha = 0.06f), forma)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Row(m.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Avatar(s.nome, if (s.antiban) Cor.Verde else Cor.Roxo, 40)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(s.nome, color = Cor.Texto, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (s.antiban || s.salasAutomed) {
                Spacer(Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (s.antiban) Selo("🛡️ Antiban", Cor.Verde)
                    if (s.salasAutomed) Selo("🤖 Sala automed", Cor.Ciano)
                }
            } else {
                Text("ID " + s.id, color = Cor.Muted, fontSize = 10.sp, maxLines = 1)
            }
        }
    }
}

@Composable
fun DialogServidores(onFechar: () -> Unit, onEscolher: (Servidor) -> Unit) {
    var busca by remember { mutableStateOf("") }
    val lista = Painel.servidores.filter { busca.isBlank() || it.nome.contains(busca, ignoreCase = true) }
    AlertDialog(
        onDismissRequest = onFechar,
        containerColor = Cor.Card,
        titleContentColor = Cor.Texto,
        textContentColor = Cor.Texto,
        title = { Text("🏠  Escolher servidor", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                OutlinedTextField(
                    value = busca, onValueChange = { busca = it }, singleLine = true,
                    label = { Text("Buscar servidor") }, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                Column(
                    Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (lista.isEmpty()) {
                        Text(
                            if (Painel.servidores.isEmpty()) "A conta ainda não carregou os servidores (está offline?)." else "Nenhum servidor encontrado.",
                            color = Cor.Muted, fontSize = 12.sp
                        )
                    }
                    lista.forEach { s -> LinhaServidor(s) { onEscolher(s) } }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onFechar) { Text("Fechar", color = Cor.Muted) } }
    )
}

/** Cartão que mostra o servidor escolhido + botão para trocar. */
@Composable
fun CartaoServidorEscolhido(aoTrocar: () -> Unit) {
    val sel = Painel.servidorSel
    val nome = Painel.detalhe?.nome ?: Painel.servidores.firstOrNull { it.id == sel }?.nome ?: ""
    Cartao {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (sel == null) {
                Box(Modifier.size(44.dp).clip(CircleShape).background(Cor.Card2), contentAlignment = Alignment.Center) { Text("🏠", fontSize = 20.sp) }
            } else {
                Avatar(nome, Cor.Ciano, 44)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("SERVIDOR", color = Cor.Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text(
                    if (sel == null) "Nenhum escolhido" else nome.ifBlank { "Carregando…" },
                    color = Cor.Texto, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            BotaoMini(if (sel == null) "Escolher" else "Trocar", Cor.Ciano, aoTrocar)
        }
    }
}

// ───────────────────────── MENSAGENS ─────────────────────────

fun textoDoEscopo(t: MsgTipo, escopo: String): String {
    if (t.k == "win") return Painel.win
    if (escopo == "global") return Painel.globalMsgs[t.k] ?: ""
    val d = Painel.detalhe
    return if (d != null && d.id == escopo) (d.msgs[t.k] ?: "") else ""
}

fun imagemDoEscopo(escopo: String): String {
    if (escopo == "global") return Painel.globalImagem
    val d = Painel.detalhe
    return if (d != null && d.id == escopo) d.imagem else ""
}

@Composable
fun DialogMensagem(t: MsgTipo, escopo: String, atual: String, imagemAtual: String, onFechar: () -> Unit) {
    var texto by remember { mutableStateOf(atual) }
    var img by remember { mutableStateOf(imagemAtual) }
    var verPadrao by remember { mutableStateOf(false) }
    val phs = t.placeholders.split(" ").filter { it.isNotBlank() }
    val onde = when {
        t.k == "win" -> "Vale para todos os servidores"
        escopo == "global" -> "🌐 Global • todos os servidores"
        else -> "🏠 " + (Painel.detalhe?.nome ?: "Servidor")
    }
    fun salvar(txt: String, im: String) {
        Painel.acao(
            Painel.corpoAcao("msg_salvar").put("tipo", t.k).put("escopo", escopo)
                .put("texto", txt).put("imagem", im)
        )
        onFechar()
    }
    AlertDialog(
        onDismissRequest = onFechar,
        containerColor = Cor.Card,
        titleContentColor = Cor.Texto,
        textContentColor = Cor.Texto,
        title = {
            Column {
                Text(emojiMsg(t.k) + "  " + t.rotulo, fontWeight = FontWeight.Bold)
                Text(onde, color = Cor.Muted, fontSize = 12.sp)
            }
        },
        text = {
            Column(
                Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(t.descricao, color = Cor.Muted, fontSize = 12.sp)
                OutlinedTextField(
                    value = texto, onValueChange = { texto = it },
                    label = { Text("Texto (vazio = padrão)") },
                    minLines = 5, maxLines = 12, modifier = Modifier.fillMaxWidth()
                )
                if (phs.isNotEmpty()) {
                    Text("Toque para inserir uma variável:", color = Cor.Muted, fontSize = 11.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        phs.forEach { p -> BotaoMini(p, Cor.Ciano) { texto = texto + p } }
                    }
                }
                if (t.k == "instr") {
                    OutlinedTextField(
                        value = img, onValueChange = { img = it }, singleLine = true,
                        label = { Text("Link da foto (opcional)") }, modifier = Modifier.fillMaxWidth()
                    )
                }
                PreviaDiscord(if (texto.isBlank()) t.padrao else texto)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BotaoMini(if (verPadrao) "Esconder padrão" else "Ver padrão", Cor.Roxo) { verPadrao = !verPadrao }
                    BotaoMini("Usar padrão como base", Cor.Azul) { texto = t.padrao }
                }
                if (verPadrao) Text(t.padrao, color = Cor.Muted, fontSize = 12.sp)
            }
        },
        confirmButton = { TextButton(onClick = { salvar(texto.trim(), img.trim()) }) { Text("Salvar", color = Cor.Verde, fontWeight = FontWeight.Bold) } },
        dismissButton = {
            Row {
                TextButton(onClick = { salvar("", "") }) { Text("Voltar ao padrão", color = Cor.Laranja) }
                TextButton(onClick = onFechar) { Text("Cancelar", color = Cor.Muted) }
            }
        }
    )
}

@Composable
fun DialogVariavel(inicial: Variavel?, onFechar: () -> Unit) {
    var gatilho by remember { mutableStateOf(inicial?.gatilho ?: "") }
    var mensagem by remember { mutableStateOf(inicial?.mensagem ?: "") }
    AlertDialog(
        onDismissRequest = onFechar,
        containerColor = Cor.Card,
        titleContentColor = Cor.Texto,
        textContentColor = Cor.Texto,
        title = { Text(if (inicial == null) "➕  Nova variável" else "✏️  Editar variável", fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Quando alguém falar o gatilho no chat, o bot manda a mensagem.", color = Cor.Muted, fontSize = 12.sp)
                OutlinedTextField(
                    value = gatilho, onValueChange = { gatilho = it.take(100) }, singleLine = true,
                    label = { Text("Gatilho (ex.: pix)") }, modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = mensagem, onValueChange = { mensagem = it.take(1900) },
                    label = { Text("Mensagem que o bot envia") },
                    minLines = 4, maxLines = 10, modifier = Modifier.fillMaxWidth()
                )
                PreviaDiscord(mensagem)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (gatilho.isNotBlank() && mensagem.isNotBlank()) {
                    Painel.acao(
                        Painel.corpoAcao("var_salvar").put("id", inicial?.id ?: "")
                            .put("gatilho", gatilho.trim()).put("mensagem", mensagem.trim())
                    )
                    onFechar()
                }
            }) { Text("Salvar", color = Cor.Verde, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onFechar) { Text("Cancelar", color = Cor.Muted) } }
    )
}

@Composable
fun CartaoVariavel(v: Variavel, onEditar: () -> Unit, onExcluir: () -> Unit) {
    val forma = RoundedCornerShape(18.dp)
    Column(
        Modifier.fillMaxWidth().clip(forma).background(Cor.Card)
            .border(1.dp, Cor.Rosa.copy(alpha = 0.3f), forma).padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("🔑", fontSize = 18.sp)
            Spacer(Modifier.width(8.dp))
            Text(v.gatilho, color = Cor.Texto, fontWeight = FontWeight.Black, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(6.dp))
        Text(v.mensagem, color = Cor.Muted, fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BotaoMini("✏️ Editar", Cor.Azul, onEditar)
            BotaoMini("🗑️ Excluir", Cor.Vermelho, onExcluir)
        }
    }
}

@Composable
fun MensagensTela() {
    LaunchedEffect(Unit) { while (true) { if (Prefs.conectado) Painel.carregar(); delay(4000) } }
    var editando by remember { mutableStateOf<MsgTipo?>(null) }
    var editVar by remember { mutableStateOf<Variavel?>(null) }
    var novaVar by remember { mutableStateOf(false) }
    var apagarVar by remember { mutableStateOf<Variavel?>(null) }
    var escolherServ by remember { mutableStateOf(false) }

    AvisoBarra()
    if (!EstadoDoPainel()) return

    val escopo = if (Painel.escopoGlobal) "global" else (Painel.servidorSel ?: "")

    // ── modo fantasma ──
    val formaF = RoundedCornerShape(22.dp)
    Row(
        Modifier.fillMaxWidth().clip(formaF)
            .background(Brush.linearGradient(listOf(Cor.Roxo.copy(alpha = if (Painel.fantasma) 0.5f else 0.2f), Cor.Card)))
            .border(1.dp, Cor.Roxo.copy(alpha = 0.5f), formaF).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(48.dp).clip(CircleShape).background(Cor.Roxo.copy(alpha = 0.3f)), contentAlignment = Alignment.Center) { Text("👻", fontSize = 24.sp) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("Modo fantasma", color = Cor.Texto, fontWeight = FontWeight.Black, fontSize = 16.sp)
            Text(
                if (Painel.fantasma) "Ligado: o bot só reage com ✅/❌ e envia o comando de sala."
                else "Desligado: o bot envia as mensagens normais.",
                color = Cor.Muted, fontSize = 12.sp
            )
        }
        Switch(
            checked = Painel.fantasma,
            onCheckedChange = { novo ->
                Painel.fantasma = novo
                Painel.acao(Painel.corpoAcao("fantasma").put("valor", novo))
            },
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White, checkedTrackColor = Cor.Verde, checkedBorderColor = Color.Transparent,
                uncheckedThumbColor = Cor.Muted, uncheckedTrackColor = Cor.Card2, uncheckedBorderColor = Color.Transparent
            )
        )
    }

    // ── onde vale ──
    TituloGrupo("ONDE VALE", Cor.Rosa)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip("🌐 Global", Cor.Roxo, Painel.escopoGlobal) { Painel.escopoGlobal = true }
        Chip("🏠 Por servidor", Cor.Ciano, !Painel.escopoGlobal) {
            Painel.escopoGlobal = false
            if (Painel.servidorSel == null) escolherServ = true
        }
    }
    if (Painel.escopoGlobal) {
        Cartao {
            if (Painel.globalAtivo) {
                Text("🌐 Global ativo", color = Cor.Verde, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text("As mensagens globais valem para todos os servidores e têm prioridade sobre as de cada servidor.", color = Cor.Muted, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                Botao("Desativar global", Cor.Vermelho) { Painel.acao(Painel.corpoAcao("global_desativar")) }
            } else {
                Text("🌐 Nenhuma mensagem global", color = Cor.Texto, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text("Edite uma mensagem abaixo para valer em todos os servidores. Sem global, cada servidor usa a sua (ou o padrão).", color = Cor.Muted, fontSize = 12.sp)
            }
        }
    } else {
        CartaoServidorEscolhido { escolherServ = true }
        if (Painel.globalAtivo) {
            Text("⚠️ Há mensagens globais ativas: do mesmo tipo, a global vale no lugar da do servidor.", color = Cor.Laranja, fontSize = 12.sp)
        }
    }

    // ── mensagens ──
    TituloGrupo("MENSAGENS DO BOT", Cor.Verde)
    Painel.msgTipos.forEach { t ->
        val txt = textoDoEscopo(t, escopo)
        CartaoAcao(
            emojiMsg(t.k), t.rotulo, t.descricao, corMsg(t.k),
            if (txt.isBlank()) "padrão" else "personalizada",
            if (txt.isBlank()) Cor.Muted else Cor.Verde,
            null
        ) {
            if (!Painel.escopoGlobal && Painel.servidorSel == null && t.k != "win") escolherServ = true
            else editando = t
        }
    }

    // ── variáveis ──
    TituloGrupo("VARIÁVEIS  (${Painel.variaveis.size}/25)", Cor.Rosa)
    Cartao {
        Text("🔑 Palavra-gatilho → resposta", color = Cor.Texto, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text("Cria uma resposta automática: quando alguém falar o gatilho no chat, o bot manda a mensagem que você definir.", color = Cor.Muted, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        Botao("➕  Nova variável", Cor.Rosa) { novaVar = true }
    }
    if (Painel.variaveis.isEmpty()) {
        Text("Nenhuma variável criada ainda.", color = Cor.Muted, fontSize = 12.sp)
    }
    Painel.variaveis.forEach { v ->
        CartaoVariavel(v, onEditar = { editVar = v }, onExcluir = { apagarVar = v })
    }

    // ── diálogos ──
    val ed = editando
    if (ed != null) {
        DialogMensagem(ed, escopo, textoDoEscopo(ed, escopo), imagemDoEscopo(escopo)) { editando = null }
    }
    if (novaVar) DialogVariavel(null) { novaVar = false }
    val ev = editVar
    if (ev != null) DialogVariavel(ev) { editVar = null }
    val av = apagarVar
    if (av != null) {
        AlertDialog(
            onDismissRequest = { apagarVar = null },
            containerColor = Cor.Card, titleContentColor = Cor.Texto, textContentColor = Cor.Muted,
            title = { Text("🗑️  Excluir variável?", fontWeight = FontWeight.Bold) },
            text = { Text("O gatilho \"" + av.gatilho + "\" deixa de funcionar.") },
            confirmButton = {
                TextButton(onClick = {
                    Painel.acao(Painel.corpoAcao("var_excluir").put("ids", JSONArray(listOf(av.id))))
                    apagarVar = null
                }) { Text("Excluir", color = Cor.Vermelho, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { apagarVar = null }) { Text("Cancelar", color = Cor.Muted) } }
        )
    }
    if (escolherServ) {
        DialogServidores({ escolherServ = false }) { s ->
            Painel.escolherServidor(s.id)
            escolherServ = false
        }
    }
}

// ───────────────────────── COMANDOS DE SALA ─────────────────────────

@Composable
fun DialogComando(t: SalaTipo, guildId: String, atual: String, onFechar: () -> Unit) {
    var cmd by remember { mutableStateOf(atual) }
    val onde = if (guildId == "global") "Vale para todos os servidores" else "🏠 " + (Painel.detalhe?.nome ?: "Servidor")
    fun salvar(c: String) {
        Painel.acao(Painel.corpoAcao("sala_salvar").put("guildId", guildId).put("tipo", t.k).put("comando", c))
        onFechar()
    }
    AlertDialog(
        onDismissRequest = onFechar,
        containerColor = Cor.Card,
        titleContentColor = Cor.Texto,
        textContentColor = Cor.Texto,
        title = {
            Column {
                Text(emojiSala(t.k) + "  " + t.rotulo, fontWeight = FontWeight.Bold)
                Text(onde, color = Cor.Muted, fontSize = 12.sp)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(t.descricao, color = Cor.Muted, fontSize = 12.sp)
                OutlinedTextField(
                    value = cmd, onValueChange = { cmd = it.take(200) }, singleLine = true,
                    label = { Text("Comando (use / para slash)") },
                    placeholder = { Text("Padrão: " + t.padrao) },
                    modifier = Modifier.fillMaxWidth()
                )
                Text("O bot envia esse comando para criar a sala. Vazio = volta ao padrão (" + t.padrao + ").", color = Cor.Muted, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton(onClick = { salvar(cmd.trim()) }) { Text("Salvar", color = Cor.Verde, fontWeight = FontWeight.Bold) } },
        dismissButton = {
            Row {
                TextButton(onClick = { salvar("") }) { Text("Voltar ao padrão", color = Cor.Laranja) }
                TextButton(onClick = onFechar) { Text("Cancelar", color = Cor.Muted) }
            }
        }
    )
}

@Composable
fun SalasTela() {
    LaunchedEffect(Unit) { while (true) { if (Prefs.conectado) Painel.carregar(); delay(4000) } }
    var editando by remember { mutableStateOf<SalaTipo?>(null) }
    var editandoGeral by remember { mutableStateOf(false) }
    var escolherServ by remember { mutableStateOf(false) }

    AvisoBarra()
    if (!EstadoDoPainel()) return

    val meetTipo = Painel.salaTipos.firstOrNull { it.k == "meet" }
    val salas = Painel.salaTipos.filter { it.k != "meet" }
    val sel = Painel.servidorSel
    val d = Painel.detalhe

    Text(
        "Defina o comando que o bot manda para criar cada tipo de sala. Cada servidor tem os seus; sem personalizar vale o padrão.",
        color = Cor.Muted, fontSize = 12.sp
    )

    TituloGrupo("SERVIDOR", Cor.Ciano)
    CartaoServidorEscolhido { escolherServ = true }

    TituloGrupo("TIPOS DE SALA", Cor.Laranja)
    if (sel == null) {
        Cartao {
            Text("🏠 Escolha um servidor", color = Cor.Texto, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("Os comandos de sala são por servidor. Toque em \"Escolher\" acima.", color = Cor.Muted, fontSize = 12.sp)
        }
    } else if (d == null || d.id != sel) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) { Pill("Carregando comandos…", Cor.Ciano) }
    } else {
        salas.forEach { t ->
            val c = d.comandos[t.k]
            val efetivo = c?.efetivo?.ifBlank { t.padrao } ?: t.padrao
            val custom = c != null && c.custom.isNotBlank()
            CartaoAcao(
                emojiSala(t.k), t.rotulo, t.descricao, corSala(t.k),
                if (custom) "personalizado" else "padrão",
                if (custom) Cor.Verde else Cor.Muted,
                efetivo
            ) { editando = t }
        }
    }

    if (meetTipo != null) {
        TituloGrupo("TELA (MEET)", Cor.Ciano)
        val meetAtual = Painel.meet
        CartaoAcao(
            emojiSala("meet"), meetTipo.rotulo, "Comando enviado quando alguém falar \"tela\" (vale para todos os servidores).", corSala("meet"),
            if (meetAtual.isBlank()) "padrão" else "personalizado",
            if (meetAtual.isBlank()) Cor.Muted else Cor.Verde,
            meetAtual.ifBlank { meetTipo.padrao }
        ) { editandoGeral = true }
    }

    val ed = editando
    if (ed != null && sel != null) {
        DialogComando(ed, sel, d?.comandos?.get(ed.k)?.custom ?: "") { editando = null }
    }
    if (editandoGeral && meetTipo != null) {
        DialogComando(meetTipo, "global", Painel.meet) { editandoGeral = false }
    }
    if (escolherServ) {
        DialogServidores({ escolherServ = false }) { s ->
            Painel.escolherServidor(s.id)
            escolherServ = false
        }
    }
}

// ───────────────────────── CONTA / SERVIDORES / ANTIBAN ─────────────────────────

@Composable
fun ContaAba() {
    val forma = RoundedCornerShape(26.dp)
    val nomeConta = Painel.nome.ifBlank { "Conta sem nome" }
    Column(
        Modifier.fillMaxWidth().clip(forma)
            .background(Brush.linearGradient(listOf(Cor.Roxo.copy(alpha = 0.5f), Cor.Card, Cor.Ciano.copy(alpha = 0.22f))))
            .border(1.dp, Color.White.copy(alpha = 0.1f), forma).padding(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(nomeConta, Cor.Ciano, 60)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("CONTA CONECTADA", color = Cor.Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text(nomeConta, color = Cor.Texto, fontWeight = FontWeight.Black, fontSize = 22.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (Painel.userId.isNotBlank()) Text("ID " + Painel.userId, color = Cor.Muted, fontSize = 11.sp, maxLines = 1)
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (Painel.contaOnline) Pill("Online", Cor.Verde) else Pill("Offline", Cor.Vermelho)
            if (Painel.automed) Pill("AutoMed ligado", Cor.Roxo) else Pill("AutoMed desligado", Cor.Laranja)
        }
    }

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Estatistica(Painel.servidores.size.toString(), "Servidores", Cor.Azul, Modifier.weight(1f))
        Estatistica(Painel.servidores.count { it.antiban }.toString(), "Antiban", Cor.Verde, Modifier.weight(1f))
        Estatistica(Painel.servidores.count { it.salasAutomed }.toString(), "Sala automed", Cor.Ciano, Modifier.weight(1f))
    }

    TituloGrupo("DETALHES", Cor.Roxo)
    Cartao {
        LinhaInfo("⏳", "Key expira em", Painel.expira.ifBlank { "—" })
        Spacer(Modifier.height(12.dp))
        LinhaInfo("✉️", "Gmail (pagamentos)", if (Painel.email.isBlank()) "Não conectado" else Painel.email)
        Spacer(Modifier.height(12.dp))
        LinhaInfo("👻", "Modo fantasma", if (Painel.fantasma) "Ligado" else "Desligado")
        Spacer(Modifier.height(12.dp))
        LinhaInfo("🔐", "Tipo de conta", if (Painel.antibanLivre) "Sem token (100% antiban)" else if (Painel.semToken) "Sem token" else "Com token")
    }
    if (!Painel.contaOnline) {
        Cartao {
            Text("⚠️ Conta offline", color = Cor.Laranja, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("Enquanto a conta estiver offline a lista de servidores pode vir vazia. Ligue o AutoMed no Discord (/central).", color = Cor.Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun LinhaInfo(emoji: String, rotulo: String, valor: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(emoji, fontSize = 18.sp)
        Spacer(Modifier.width(10.dp))
        Text(rotulo, color = Cor.Muted, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(valor, color = Cor.Texto, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1.4f, fill = false))
    }
}

@Composable
fun ServidoresAba() {
    var busca by remember { mutableStateOf("") }
    val lista = Painel.servidores.filter { busca.isBlank() || it.nome.contains(busca, ignoreCase = true) }
    OutlinedTextField(
        value = busca, onValueChange = { busca = it }, singleLine = true,
        label = { Text("Buscar servidor") }, modifier = Modifier.fillMaxWidth()
    )
    Text("${lista.size} de ${Painel.servidores.size} servidor(es)", color = Cor.Muted, fontSize = 12.sp)
    if (Painel.servidores.isEmpty()) {
        Cartao {
            Text("Nenhum servidor carregado", color = Cor.Texto, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("A conta precisa estar online. Depois toque em Atualizar.", color = Cor.Muted, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            Botao(if (Painel.carregando) "…" else "Atualizar", Cor.Card2) { Painel.carregar() }
        }
    }
    lista.forEach { s -> LinhaServidor(s, null) }
}

@Composable
fun AntibanAba() {
    val ativos = Painel.servidores.filter { it.antiban }
    val forma = RoundedCornerShape(22.dp)
    Column(
        Modifier.fillMaxWidth().clip(forma)
            .background(Brush.linearGradient(listOf(Cor.Verde.copy(alpha = 0.35f), Cor.Card)))
            .border(1.dp, Cor.Verde.copy(alpha = 0.45f), forma).padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("🛡️", fontSize = 30.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Antiban", color = Cor.Texto, fontWeight = FontWeight.Black, fontSize = 20.sp)
                Text(
                    if (ativos.isEmpty()) "Nenhum dos seus servidores está em antiban." else "Ativo em ${ativos.size} servidor(es)",
                    color = Cor.Muted, fontSize = 12.sp
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            "Nos servidores com antiban o bot oficial responde no lugar da conta, só nos canais em que você é o mediador, e as mensagens não variam.",
            color = Cor.Muted, fontSize = 12.sp
        )
        if (Painel.antibanLivre) {
            Spacer(Modifier.height(10.dp))
            Selo("Conta sem token • 100% antiban", Cor.Verde)
        }
    }

    TituloGrupo("COM ANTIBAN", Cor.Verde)
    if (ativos.isEmpty()) {
        Cartao { Text("Nada por aqui ainda.", color = Cor.Muted, fontSize = 12.sp) }
    }
    ativos.forEach { s -> LinhaServidor(s, null) }

    val sem = Painel.servidores.filter { !it.antiban }
    if (sem.isNotEmpty()) {
        TituloGrupo("SEM ANTIBAN (${sem.size})", Cor.Muted)
        sem.take(30).forEach { s -> LinhaServidor(s, null) }
        if (sem.size > 30) Text("…e mais ${sem.size - 30} servidor(es). Veja todos na aba Servidores.", color = Cor.Muted, fontSize = 11.sp)
    }
    Text("A ativação do antiban é feita pelo dono do bot, no Discord.", color = Cor.Muted, fontSize = 11.sp)
}

@Composable
fun ContaTela() {
    LaunchedEffect(Unit) { while (true) { if (Prefs.conectado) Painel.carregar(); delay(4000) } }
    var aba by remember { mutableStateOf(0) }

    AvisoBarra()
    if (!EstadoDoPainel()) return

    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip("👤 Conta", Cor.Roxo, aba == 0) { aba = 0 }
        Chip("🏠 Servidores", Cor.Azul, aba == 1) { aba = 1 }
        Chip("🛡️ Antiban", Cor.Verde, aba == 2) { aba = 2 }
    }
    when (aba) {
        0 -> ContaAba()
        1 -> ServidoresAba()
        else -> AntibanAba()
    }
}
