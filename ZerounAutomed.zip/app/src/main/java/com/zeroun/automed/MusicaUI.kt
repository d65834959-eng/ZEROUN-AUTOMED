package com.zeroun.automed

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

// ───────────────────────── utilidades ─────────────────────────

fun duracaoTxt(s: Int): String {
    val h = s / 3600
    val m = (s % 3600) / 60
    val x = s % 60
    return if (h > 0) String.format("%d:%02d:%02d", h, m, x) else String.format("%d:%02d", m, x)
}

fun tempoRel(ts: Long): String {
    val d = (System.currentTimeMillis() - ts) / 1000
    return when {
        d < 60 -> "agora"
        d < 3600 -> "há ${d / 60} min"
        d < 86400 -> "há ${d / 3600} h"
        d < 7 * 86400 -> "há ${d / 86400} d"
        else -> hora(ts)
    }
}

// ───────────────────────── tela: MEDIAÇÃO COM MÚSICA ─────────────────────────

@Composable
fun MusicaAba() {
    val ctx = LocalContext.current
    val v = MusicaStore.versao
    val recentes = remember(v) { MusicaStore.recentes(15) }
    val mais = remember(v) { MusicaStore.maisOuvidas(10) }
    var confirmarLimpar by remember { mutableStateOf(false) }
    var perguntouNotif by remember { mutableStateOf(false) }
    val pedirNotif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun tocar(lista: List<Som>, i: Int) {
        // Android 13+: pede (uma vez) para mostrar os botões da música na notificação
        if (Build.VERSION.SDK_INT >= 33 && !perguntouNotif &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            perguntouNotif = true
            pedirNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        Tocador.tocarLista(ctx, lista, i)
    }

    val resultados = MusicaBusca.resultados

    Column(Modifier.fillMaxSize()) {
        // cabeçalho
        Row(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconeCaixa(Icons.Rounded.Headphones, Cor.Roxo, 52)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "MEDIAÇÃO COM MÚSICA", color = Cor.Texto, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold,
                    maxLines = 1, softWrap = false, letterSpacing = 0.3.sp
                )
                Text("Pesquise, toque e guarde no celular", color = Cor.Muted, fontSize = 14.sp)
            }
            Sino()
        }

        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            BarraBusca()

            // ── resultados da busca ──
            if (MusicaBusca.buscando) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    Pill("Procurando no YouTube…", Cor.Azul)
                }
            }
            if (MusicaBusca.erro.isNotBlank()) {
                Cartao {
                    Text("⚠️ " + MusicaBusca.erro, color = Cor.Vermelho, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    Botao("Tentar de novo", Cor.Card2) { MusicaBusca.pesquisar(true) }
                }
            }
            if (resultados != null) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) { TituloGrupo("RESULTADOS", Cor.Azul) }
                    if (MusicaBusca.doCache) {
                        Selo("salvo no celular", Cor.Verde)
                        Spacer(Modifier.width(8.dp))
                        BotaoMini("Atualizar", Cor.Azul) { MusicaBusca.pesquisar(true) }
                    } else {
                        Selo("do YouTube", Cor.Azul)
                    }
                }
                if (resultados.isEmpty()) {
                    Cartao { Text("Nada encontrado.", color = Cor.Texto, fontWeight = FontWeight.Bold) }
                }
                resultados.forEachIndexed { i, f -> FaixaLinha(f, null) { tocar(resultados, i) } }
            }

            // ── mais ouvidas ──
            if (mais.isNotEmpty()) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) { TituloGrupo("MAIS OUVIDAS", Cor.Laranja) }
                    Icon(Icons.Rounded.LocalFireDepartment, null, tint = Cor.Laranja, modifier = Modifier.size(18.dp))
                }
                val listaMais = mais.map { it.faixa }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    mais.forEachIndexed { i, item -> CartaoTop(i + 1, item) { tocar(listaMais, i) } }
                }
            }

            // ── recentes (só deste usuário) ──
            if (recentes.isNotEmpty()) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) { TituloGrupo("RECENTES", Cor.Ciano) }
                    Icon(Icons.Rounded.History, null, tint = Cor.Ciano, modifier = Modifier.size(18.dp))
                }
                val listaRec = recentes.map { it.faixa }
                recentes.forEachIndexed { i, item -> FaixaLinha(item.faixa, tempoRel(item.uso.ultimo)) { tocar(listaRec, i) } }
            }

            if (resultados == null && mais.isEmpty() && recentes.isEmpty() && !MusicaBusca.buscando) {
                Cartao {
                    Text("🎧 Sua música começa aqui", color = Cor.Texto, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Pesquise pelo nome (ou cole um link do YouTube). Tudo que você tocar aparece em Recentes e, " +
                            "com o tempo, em Mais ouvidas.",
                        color = Cor.Muted, fontSize = 13.sp, lineHeight = 19.sp
                    )
                }
            }

            // ── biblioteca salva no celular ──
            TituloGrupo("SALVO NO CELULAR", Cor.Roxo)
            Cartao {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconeCaixa(Icons.Rounded.LibraryMusic, Cor.Roxo, 46)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Biblioteca do celular", color = Cor.Texto, fontWeight = FontWeight.Black, fontSize = 16.sp)
                        Text(
                            "${MusicaStore.totalFaixas()} música(s) • ${MusicaStore.totalBuscas()} busca(s) guardadas",
                            color = Cor.Muted, fontSize = 12.sp
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    "As músicas e buscas ficam salvas aqui. Se a key acabar, nada se perde: ao comprar outra, " +
                        "tudo continua e não precisa pesquisar de novo.",
                    color = Cor.Muted, fontSize = 12.sp, lineHeight = 17.sp
                )
                if (recentes.isNotEmpty() || mais.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    BotaoMini("Limpar meu histórico", Cor.Vermelho) { confirmarLimpar = true }
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        if (Tocador.atual != null) MiniPlayer()
    }

    if (confirmarLimpar) {
        AlertDialog(
            onDismissRequest = { confirmarLimpar = false },
            containerColor = Cor.Card, titleContentColor = Cor.Texto, textContentColor = Cor.Muted,
            title = { Text("Limpar histórico?", fontWeight = FontWeight.Bold) },
            text = { Text("Apaga Recentes e Mais ouvidas. As músicas e buscas salvas continuam no celular.") },
            confirmButton = {
                TextButton(onClick = { confirmarLimpar = false; MusicaStore.limparHistorico() }) {
                    Text("Limpar", color = Cor.Vermelho, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { confirmarLimpar = false }) { Text("Cancelar", color = Cor.Muted) } }
        )
    }
}

// ───────────────────────── barra de pesquisa ─────────────────────────

@Composable
private fun BarraBusca() {
    val foco = LocalFocusManager.current
    OutlinedTextField(
        value = MusicaBusca.texto, onValueChange = { MusicaBusca.texto = it },
        singleLine = true, shape = RoundedCornerShape(26.dp),
        placeholder = { Text("Pesquisar música ou colar link…", color = Cor.Muted.copy(alpha = 0.8f)) },
        leadingIcon = { Icon(Icons.Rounded.Search, null, tint = Cor.Azul) },
        trailingIcon = {
            if (MusicaBusca.texto.isNotEmpty()) {
                Icon(
                    Icons.Rounded.Close, "Limpar", tint = Cor.Muted,
                    modifier = Modifier.padding(end = 6.dp).clip(CircleShape).clickable { MusicaBusca.limpar() }.padding(8.dp)
                )
            }
        },
        textStyle = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Cor.Texto),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Cor.Azul, unfocusedBorderColor = Cor.Borda,
            focusedContainerColor = Cor.Card, unfocusedContainerColor = Cor.Card
        ),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { foco.clearFocus(); MusicaBusca.pesquisar() }),
        modifier = Modifier.fillMaxWidth()
    )
    Botao(
        if (MusicaBusca.buscando) "Procurando…" else "Buscar música", icone = Icons.Rounded.Search,
        enabled = !MusicaBusca.buscando && MusicaBusca.texto.isNotBlank()
    ) { foco.clearFocus(); MusicaBusca.pesquisar() }
}

// ───────────────────────── componentes ─────────────────────────

/** Capa da música: baixa uma vez, guarda no celular e abre na hora depois. */
@Composable
fun Capa(id: String, modifier: Modifier, forma: Shape) {
    val img by produceState<ImageBitmap?>(initialValue = Capas.memoria(id), key1 = id) {
        if (value == null) value = withContext(Dispatchers.IO) { Capas.carregar(id) }
    }
    Box(modifier.clip(forma).background(Cor.Card2), contentAlignment = Alignment.Center) {
        val i = img
        if (i != null) {
            Image(bitmap = i, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Icon(Icons.Rounded.MusicNote, null, tint = Cor.Muted, modifier = Modifier.size(24.dp))
        }
    }
}

@Composable
private fun BotaoRedondo(icone: androidx.compose.ui.graphics.vector.ImageVector, tam: Dp, fundo: Color, tint: Color, onClick: () -> Unit) {
    Box(
        Modifier.size(tam).clip(CircleShape).background(fundo).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icone, null, tint = tint, modifier = Modifier.size(tam * 0.55f)) }
}

/** Linha de música (resultado ou recente). Tocar na que já está tocando = pausar/continuar. */
@Composable
private fun FaixaLinha(f: Som, direita: String?, onClick: () -> Unit) {
    val forma = RoundedCornerShape(20.dp)
    val ativa = Tocador.atual?.id == f.id
    Row(
        Modifier.fillMaxWidth().suave(forma).clip(forma)
            .background(if (ativa) Cor.Verde.copy(alpha = 0.10f) else Cor.Card)
            .border(if (ativa) 1.5.dp else 1.dp, if (ativa) Cor.Verde.copy(alpha = 0.6f) else Cor.Borda, forma)
            .clickable { if (ativa) Tocador.alternar() else onClick() }
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Capa(f.id, Modifier.size(56.dp), RoundedCornerShape(14.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(f.titulo, color = Cor.Texto, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (ativa) {
                    Icon(Icons.Rounded.GraphicEq, null, tint = Cor.Verde, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(4.dp))
                }
                Text(
                    f.artista + " · " + duracaoTxt(f.duracao), color = if (ativa) Cor.Verde else Cor.Muted,
                    fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            if (direita != null) Text(direita, color = Cor.Muted, fontSize = 11.sp)
        }
        Spacer(Modifier.width(8.dp))
        BotaoRedondo(
            if (ativa && Tocador.tocando) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, 40.dp,
            if (ativa) Cor.Verde else Cor.Card2, if (ativa) sobre(Cor.Verde) else Cor.Texto
        ) { if (ativa) Tocador.alternar() else onClick() }
    }
}

/** Cartão grande da lista "Mais ouvidas". */
@Composable
private fun CartaoTop(pos: Int, item: ItemUso, onClick: () -> Unit) {
    val forma = RoundedCornerShape(22.dp)
    val f = item.faixa
    val ativa = Tocador.atual?.id == f.id
    Column(
        Modifier.width(140.dp).suave(forma).clip(forma).background(Cor.Card)
            .border(if (ativa) 1.5.dp else 1.dp, if (ativa) Cor.Verde.copy(alpha = 0.6f) else Cor.Borda, forma)
            .clickable { if (ativa) Tocador.alternar() else onClick() }
            .padding(8.dp)
    ) {
        Box {
            Capa(f.id, Modifier.fillMaxWidth().aspectRatio(1f), RoundedCornerShape(16.dp))
            Text(
                "#$pos", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.align(Alignment.TopStart).padding(6.dp).clip(RoundedCornerShape(50))
                    .background(Color(0xCC000000)).padding(horizontal = 8.dp, vertical = 3.dp)
            )
            if (ativa) {
                Icon(
                    Icons.Rounded.GraphicEq, null, tint = Color.White,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp).size(26.dp).clip(CircleShape)
                        .background(Cor.Verde).padding(4.dp)
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(f.titulo, color = Cor.Texto, fontWeight = FontWeight.Bold, fontSize = 13.sp, minLines = 2, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text(f.artista, color = Cor.Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(6.dp))
        Selo("🔥 " + item.uso.plays + "x ouvida", Cor.Laranja)
    }
}

// ───────────────────────── player (fica embaixo, acima da barra) ─────────────────────────

@Composable
private fun MiniPlayer() {
    val f = Tocador.atual ?: return
    var pos by remember { mutableLongStateOf(0L) }
    var arrastando by remember { mutableStateOf(false) }
    var valorArrasto by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(f.id) {
        while (true) {
            if (!arrastando) pos = Tocador.posicaoMs()
            delay(500)
        }
    }

    val dur = Tocador.duracaoMs.coerceAtLeast(1L)
    val fracao = if (arrastando) valorArrasto else (pos.toFloat() / dur.toFloat()).coerceIn(0f, 1f)
    val forma = RoundedCornerShape(28.dp)

    Column(
        Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 4.dp)
            .suave(forma).clip(forma)
            .background(Brush.linearGradient(listOf(Cor.Verde.copy(alpha = 0.16f), Cor.Card)))
            .border(1.dp, Cor.Verde.copy(alpha = 0.45f), forma)
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Capa(f.id, Modifier.size(52.dp), RoundedCornerShape(14.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(f.titulo, color = Cor.Texto, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                when {
                    Tocador.carregando -> Text("Procurando o áudio…", color = Cor.Azul, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Tocador.erro.isNotBlank() -> Text(Tocador.erro, color = Cor.Vermelho, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    else -> Text(f.artista, color = Cor.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            BotaoRedondo(Icons.Rounded.SkipPrevious, 38.dp, Color.Transparent, Cor.Texto) { Tocador.anterior() }
            Box(
                Modifier.size(46.dp).clip(CircleShape).background(Cor.Verde).clickable { Tocador.alternar() },
                contentAlignment = Alignment.Center
            ) {
                if (Tocador.carregando) {
                    CircularProgressIndicator(Modifier.size(22.dp), color = sobre(Cor.Verde), strokeWidth = 2.5.dp)
                } else {
                    Icon(
                        if (Tocador.tocando) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null,
                        tint = sobre(Cor.Verde), modifier = Modifier.size(26.dp)
                    )
                }
            }
            BotaoRedondo(Icons.Rounded.SkipNext, 38.dp, Color.Transparent, Cor.Texto) { Tocador.proxima() }
            BotaoRedondo(Icons.Rounded.Close, 30.dp, Color.Transparent, Cor.Muted) { Tocador.encerrar() }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(duracaoTxt((fracao * dur / 1000f).toInt()), color = Cor.Muted, fontSize = 11.sp)
            Slider(
                value = fracao,
                onValueChange = { arrastando = true; valorArrasto = it },
                onValueChangeFinished = {
                    val alvo = (valorArrasto * dur).toLong()
                    Tocador.ir(alvo)
                    pos = alvo
                    arrastando = false
                },
                colors = SliderDefaults.colors(
                    thumbColor = Cor.Verde, activeTrackColor = Cor.Verde, inactiveTrackColor = Cor.Card2
                ),
                modifier = Modifier.weight(1f).padding(horizontal = 6.dp).height(28.dp)
            )
            Text(duracaoTxt((dur / 1000L).toInt()), color = Cor.Muted, fontSize = 11.sp)
        }
    }
}
