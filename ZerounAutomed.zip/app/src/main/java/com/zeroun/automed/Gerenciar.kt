package com.zeroun.automed

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.json.JSONObject

// ───────────────────────── modelos ─────────────────────────

data class Faixa(val salas: Int, val valor: Double)
data class Ganho(val ts: Long, val valor: Double, val servidor: String, val sala: String)
data class ModeloIA(val k: String, val rotulo: String)
data class CanalInfo(val id: String, val nome: String)
data class CanalTipo(val k: String, val rotulo: String, val descricao: String, val multiplo: Boolean)
data class CanaisServidor(val guildId: String, val canais: List<CanalInfo>, val config: Map<String, List<String>>)

// ───────────────────────── estado + rede das telas novas ─────────────────────────

object Gestao {
    // ---- sistema ----
    var sisCarregado by mutableStateOf(false)
    var sisErro by mutableStateOf("")
    var sisAtivo by mutableStateOf<Boolean?>(null)
    var sisExpiraTs by mutableStateOf(0L)
    var sisExpiraTxt by mutableStateOf("")
    var sisPlano by mutableStateOf("")
    var sisOcupado by mutableStateOf(false)

    // ---- lucros ----
    var lucCarregado by mutableStateOf(false)
    var lucErro by mutableStateOf("")
    var valorSala by mutableStateOf(0.0)
    var lucHoje by mutableStateOf(Faixa(0, 0.0))
    var lucSemana by mutableStateOf(Faixa(0, 0.0))
    var lucMes by mutableStateOf(Faixa(0, 0.0))
    var lucTotal by mutableStateOf(Faixa(0, 0.0))
    var historico by mutableStateOf<List<Ganho>>(emptyList())

    // ---- IA ----
    var iaCarregado by mutableStateOf(false)
    var iaErro by mutableStateOf("")
    var iaVersao by mutableIntStateOf(0)
    var iaAtiva by mutableStateOf(false)
    var iaPrompt by mutableStateOf("")
    var iaModelo by mutableStateOf("")
    var iaModelos by mutableStateOf<List<ModeloIA>>(emptyList())
    var iaCriatividade by mutableStateOf(0.5f)

    // ---- canais ----
    var canTipos by mutableStateOf<List<CanalTipo>>(emptyList())
    var canDetalhe by mutableStateOf<CanaisServidor?>(null)
    var canErro by mutableStateOf("")
    var canCarregando by mutableStateOf(false)

    // ───── helpers ─────
    private fun chamar(path: String, corpo: JSONObject = Net.corpo(), fim: (JSONObject?) -> Unit) {
        Thread {
            val r = Net.post(path, corpo)
            Estado.ui { fim(r) }
        }.start()
    }

    private fun erroDe(r: JSONObject?): String =
        if (r == null) "Sem resposta do bot. Confira a internet." else r.optString("msg", "Erro ao falar com o bot.")

    private fun acao(corpo: JSONObject, aoOk: () -> Unit = {}) {
        Thread {
            val r = Net.post("/api/acao", corpo)
            val ok = r != null && r.optBoolean("ok", false)
            val msg = if (r == null) "Sem resposta do bot." else r.optString("msg", if (ok) "Salvo." else "Erro.")
            Painel.mostrar(msg, ok)
            if (ok) Estado.ui { aoOk() }
        }.start()
    }

    private fun faixa(o: JSONObject?): Faixa = Faixa(o?.optInt("salas", 0) ?: 0, o?.optDouble("valor", 0.0) ?: 0.0)

    // ───── sistema ─────
    fun carregarSistema() {
        if (sisOcupado) return
        sisOcupado = true
        chamar("/api/sistema") { r ->
            sisOcupado = false
            if (r != null && r.optBoolean("ok", false)) {
                sisErro = ""
                sisAtivo = if (r.has("ativo")) r.optBoolean("ativo") else null
                sisExpiraTs = r.optLong("expiraTs", 0L)
                sisExpiraTxt = r.optString("expira", "")
                sisPlano = r.optString("plano", "")
            } else {
                sisErro = erroDe(r)
            }
            sisCarregado = true
        }
    }

    fun definirAtivo(ativar: Boolean) {
        if (sisOcupado) return
        sisOcupado = true
        Thread {
            val r = Net.post("/api/acao", Painel.corpoAcao("sistema_ativar").put("valor", ativar))
            val ok = r != null && r.optBoolean("ok", false)
            val msg = if (r == null) "Sem resposta do bot." else r.optString("msg", if (ok) (if (ativar) "Bot ativado." else "Bot desligado.") else "Erro.")
            Painel.mostrar(msg, ok)
            Estado.ui { sisOcupado = false; if (ok) sisAtivo = ativar }
            if (ok) Estado.ui { carregarSistema() }
        }.start()
    }

    // ───── lucros ─────
    fun carregarLucros() {
        chamar("/api/lucros") { r ->
            if (r != null && r.optBoolean("ok", false)) {
                lucErro = ""
                valorSala = r.optDouble("valorPorSala", 0.0)
                lucHoje = faixa(r.optJSONObject("hoje"))
                lucSemana = faixa(r.optJSONObject("semana"))
                lucMes = faixa(r.optJSONObject("mes"))
                lucTotal = faixa(r.optJSONObject("total"))
                val arr = r.optJSONArray("historico")
                val lista = ArrayList<Ganho>()
                if (arr != null) for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    lista.add(Ganho(o.optLong("ts", 0L), o.optDouble("valor", 0.0), o.optString("servidor", ""), o.optString("sala", "")))
                }
                historico = lista
            } else {
                lucErro = erroDe(r)
            }
            lucCarregado = true
        }
    }

    fun salvarValorSala(v: Double) {
        acao(Painel.corpoAcao("lucro_valor").put("valor", v)) { valorSala = v; carregarLucros() }
    }

    // ───── IA ─────
    fun carregarIA() {
        chamar("/api/ia") { r ->
            if (r != null && r.optBoolean("ok", false)) {
                iaErro = ""
                iaAtiva = r.optBoolean("ativo", false)
                iaPrompt = r.optString("prompt", "")
                iaModelo = r.optString("modelo", "")
                iaCriatividade = r.optDouble("criatividade", 0.5).toFloat().coerceIn(0f, 1f)
                val arr = r.optJSONArray("modelos")
                val l = ArrayList<ModeloIA>()
                if (arr != null) for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    l.add(ModeloIA(o.optString("k", ""), o.optString("rotulo", o.optString("k", ""))))
                }
                iaModelos = l
                iaVersao = iaVersao + 1
            } else {
                iaErro = erroDe(r)
            }
            iaCarregado = true
        }
    }

    fun salvarIA(ativo: Boolean, prompt: String, modelo: String, criatividade: Float) {
        acao(
            Painel.corpoAcao("ia_salvar").put("ativo", ativo).put("prompt", prompt)
                .put("modelo", modelo).put("criatividade", criatividade.toDouble())
        ) { iaAtiva = ativo; iaPrompt = prompt; iaModelo = modelo; iaCriatividade = criatividade }
    }

    // ───── canais ─────
    fun carregarCanais(guildId: String) {
        canCarregando = true
        canErro = ""
        chamar("/api/canais", Net.corpo().put("guildId", guildId)) { r ->
            canCarregando = false
            if (r != null && r.optBoolean("ok", false)) {
                canErro = ""
                val ts = ArrayList<CanalTipo>()
                val at = r.optJSONArray("tipos")
                if (at != null) for (i in 0 until at.length()) {
                    val o = at.getJSONObject(i)
                    ts.add(CanalTipo(o.optString("k", ""), o.optString("rotulo", ""), o.optString("descricao", ""), o.optBoolean("multiplo", false)))
                }
                canTipos = ts
                val cs = ArrayList<CanalInfo>()
                val ac = r.optJSONArray("canais")
                if (ac != null) for (i in 0 until ac.length()) {
                    val o = ac.getJSONObject(i)
                    cs.add(CanalInfo(o.optString("id", ""), o.optString("nome", "")))
                }
                val cfg = HashMap<String, List<String>>()
                val co = r.optJSONObject("config")
                if (co != null) {
                    val ks = co.keys()
                    while (ks.hasNext()) {
                        val k = ks.next()
                        val a = co.optJSONArray(k)
                        val ids = ArrayList<String>()
                        if (a != null) for (i in 0 until a.length()) ids.add(a.optString(i, ""))
                        cfg[k] = ids
                    }
                }
                canDetalhe = CanaisServidor(guildId, cs, cfg)
            } else {
                canErro = erroDe(r)
            }
        }
    }

    fun salvarCanal(guildId: String, tipo: String, ids: List<String>) {
        acao(
            Painel.corpoAcao("canal_salvar").put("guildId", guildId).put("tipo", tipo)
                .put("canais", org.json.JSONArray(ids))
        ) { carregarCanais(guildId) }
    }
}

// ───────────────────────── utilidades ─────────────────────────

fun restante(ts: Long, agora: Long): String {
    val d = ts - agora
    if (d <= 0) return "Expirada"
    val dias = d / 86_400_000
    val horas = (d / 3_600_000) % 24
    val min = (d / 60_000) % 60
    return when {
        dias > 0 -> "${dias}d ${horas}h ${min}min"
        horas > 0 -> "${horas}h ${min}min"
        else -> "${min}min"
    }
}

fun mascararKey(k: String): String {
    if (k.isBlank()) return "—"
    if (k.length <= 12) return "•".repeat(k.length)
    return k.take(8) + "•".repeat((k.length - 12).coerceAtMost(14)) + k.takeLast(4)
}

fun lerValor(s: String): Double? =
    s.trim().replace("R$", "").replace(" ", "").replace(",", ".").toDoubleOrNull()?.takeIf { it >= 0.0 }

@Composable
private fun CartaoErro(msg: String, aoTentar: () -> Unit) {
    Cartao(Modifier.border(1.dp, Cor.Laranja.copy(alpha = 0.6f), RoundedCornerShape(20.dp))) {
        Text("⚠️ " + msg, color = Cor.Laranja, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(Modifier.height(4.dp))
        Text(
            "Se aparecer \"Endpoint desconhecido\", o servidor do bot ainda não tem essa função (veja API-NOVOS-ENDPOINTS.md).",
            color = Cor.Muted, fontSize = 11.sp
        )
        Spacer(Modifier.height(10.dp))
        Botao("Tentar de novo", Cor.Card2) { aoTentar() }
    }
}

@Composable
private fun PedirConexao() {
    Cartao {
        Text("🔗 Conecte o app primeiro", color = Cor.Laranja, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text("Abra \"Conexão\" no início e coloque a key. Depois essa tela carrega sozinha.", color = Cor.Muted, fontSize = 12.sp)
    }
}

@Composable
private fun CartaoNumero(valor: String, rotulo: String, sub: String, cor: Color, modifier: Modifier) {
    val forma = RoundedCornerShape(18.dp)
    Column(
        modifier.clip(forma).background(cor.copy(alpha = 0.14f)).border(1.dp, cor.copy(alpha = 0.35f), forma).padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(valor, color = cor, fontSize = 15.sp, fontWeight = FontWeight.Black, maxLines = 1)
        Text(rotulo, color = Cor.Texto, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text(sub, color = Cor.Muted, fontSize = 10.sp)
    }
}

@Composable
private fun CorSwitch() = SwitchDefaults.colors(
    checkedThumbColor = Color.White, checkedTrackColor = Cor.Verde, checkedBorderColor = Color.Transparent,
    uncheckedThumbColor = Cor.Muted, uncheckedTrackColor = Cor.Card2, uncheckedBorderColor = Color.Transparent
)

// ───────────────────────── GERENCIAR SISTEMA ─────────────────────────

@Composable
fun SistemaTela() {
    LaunchedEffect(Unit) { while (true) { if (Prefs.conectado) Gestao.carregarSistema(); delay(5000) } }
    var agora by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(15_000); agora = System.currentTimeMillis() } }
    var mostrarKey by remember { mutableStateOf(false) }
    var copiado by remember { mutableStateOf(false) }
    var confirmarDesligar by remember { mutableStateOf(false) }
    val clip = LocalClipboardManager.current

    AvisoBarra()
    if (!Prefs.conectado) { PedirConexao(); return }

    val ativo = Gestao.sisAtivo
    val cor = when (ativo) { true -> Cor.Verde; false -> Cor.Vermelho; null -> Cor.Laranja }

    // ── cartão principal: status + botão ──
    val forma = RoundedCornerShape(26.dp)
    Column(
        Modifier.fillMaxWidth().clip(forma)
            .background(Brush.linearGradient(listOf(cor.copy(alpha = 0.40f), Cor.Card, Cor.Roxo.copy(alpha = 0.22f))))
            .border(1.dp, cor.copy(alpha = 0.5f), forma).padding(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(56.dp).clip(CircleShape).background(cor.copy(alpha = 0.28f)), contentAlignment = Alignment.Center) {
                Text(if (ativo == true) "⚡" else if (ativo == false) "💤" else "❔", fontSize = 28.sp)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("STATUS DO BOT", color = Cor.Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text(
                    when (ativo) { true -> "Bot ativo"; false -> "Bot desligado"; null -> if (Gestao.sisCarregado) "Status desconhecido" else "Verificando…" },
                    color = Cor.Texto, fontSize = 24.sp, fontWeight = FontWeight.Black
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        if (ativo == true) {
            Botao(if (Gestao.sisOcupado) "Aguarde…" else "⏻  Desligar bot", Cor.Vermelho) { confirmarDesligar = true }
        } else {
            Botao(if (Gestao.sisOcupado) "Aguarde…" else "⚡  Ativar bot", Cor.Verde) { Gestao.definirAtivo(true) }
        }
    }

    if (Gestao.sisErro.isNotBlank()) CartaoErro(Gestao.sisErro) { Gestao.carregarSistema() }

    // ── tempo restante ──
    TituloGrupo("TEMPO RESTANTE", Cor.Ciano)
    val temTs = Gestao.sisExpiraTs > 0
    val txtRestante = if (temTs) restante(Gestao.sisExpiraTs, agora) else Gestao.sisExpiraTxt.ifBlank { Painel.expira }.ifBlank { "—" }
    val acabando = temTs && Gestao.sisExpiraTs - agora < 3 * 86_400_000L
    val corTempo = if (temTs && Gestao.sisExpiraTs <= agora) Cor.Vermelho else if (acabando) Cor.Laranja else Cor.Ciano
    Cartao {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("⏳", fontSize = 30.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(txtRestante, color = corTempo, fontSize = 26.sp, fontWeight = FontWeight.Black)
                val sub = if (temTs) "Expira em " + hora(Gestao.sisExpiraTs) else "Prazo informado pelo bot"
                Text(sub, color = Cor.Muted, fontSize = 12.sp)
            }
        }
        if (acabando) {
            Spacer(Modifier.height(10.dp))
            Text("⚠️ Sua key está perto de vencer. Renove para o bot não parar.", color = Cor.Laranja, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }

    // ── key ──
    TituloGrupo("SUA KEY", Cor.Roxo)
    Cartao {
        Text(
            if (mostrarKey) Prefs.key.ifBlank { "—" } else mascararKey(Prefs.key),
            color = Cor.Roxo, fontSize = 15.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace,
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Cor.Fundo).padding(12.dp)
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            BotaoMini(if (mostrarKey) "🙈 Ocultar" else "👁️ Mostrar", Cor.Azul) { mostrarKey = !mostrarKey }
            BotaoMini(if (copiado) "✅ Copiada" else "📋 Copiar", Cor.Verde) {
                clip.setText(AnnotatedString(Prefs.key)); copiado = true
            }
        }
        if (Gestao.sisPlano.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Selo("Plano • " + Gestao.sisPlano, Cor.Ciano)
        }
    }

    // ── detalhes ──
    TituloGrupo("DETALHES", Cor.Azul)
    Cartao {
        LinhaInfo("👤", "Conta Discord", Painel.nome.ifBlank { "—" })
        Spacer(Modifier.height(12.dp))
        LinhaInfo("🟢", "Conta", if (Painel.contaOnline) "Online" else "Offline")
        Spacer(Modifier.height(12.dp))
        LinhaInfo("🤖", "AutoMed", if (Painel.automed) "Ligado" else "Desligado")
        Spacer(Modifier.height(12.dp))
        LinhaInfo("📱", "Este celular", Prefs.deviceId.takeLast(10))
    }
    Botao("🔄  Atualizar", Cor.Card2) { Gestao.carregarSistema(); Painel.carregar() }

    if (confirmarDesligar) {
        AlertDialog(
            onDismissRequest = { confirmarDesligar = false },
            containerColor = Cor.Card, titleContentColor = Cor.Texto, textContentColor = Cor.Muted,
            title = { Text("⏻  Desligar o bot?", fontWeight = FontWeight.Bold) },
            text = { Text("O bot para de criar salas e de responder até você ativar de novo.") },
            confirmButton = {
                TextButton(onClick = { confirmarDesligar = false; Gestao.definirAtivo(false) }) {
                    Text("Desligar", color = Cor.Vermelho, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { confirmarDesligar = false }) { Text("Cancelar", color = Cor.Muted) } }
        )
    }
}

// ───────────────────────── LUCROS ─────────────────────────

@Composable
fun LucrosTela() {
    LaunchedEffect(Unit) { while (true) { if (Prefs.conectado) Gestao.carregarLucros(); delay(8000) } }
    var campo by remember(Gestao.valorSala) { mutableStateOf(if (Gestao.valorSala > 0) String.format(java.util.Locale.US, "%.2f", Gestao.valorSala).replace(".", ",") else "") }
    var erroCampo by remember { mutableStateOf("") }

    AvisoBarra()
    if (!Prefs.conectado) { PedirConexao(); return }
    if (Gestao.lucErro.isNotBlank()) CartaoErro(Gestao.lucErro) { Gestao.carregarLucros() }
    if (!Gestao.lucCarregado) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) { Pill("Carregando…", Cor.Ciano) }
    }

    // ── destaque: lucro de hoje ──
    val forma = RoundedCornerShape(26.dp)
    Column(
        Modifier.fillMaxWidth().clip(forma)
            .background(Brush.linearGradient(listOf(Cor.Verde.copy(alpha = 0.45f), Cor.Card, Cor.Ciano.copy(alpha = 0.2f))))
            .border(1.dp, Color.White.copy(alpha = 0.1f), forma).padding(20.dp)
    ) {
        Text("LUCRO DE HOJE", color = Cor.Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(6.dp))
        Text(brl(Gestao.lucHoje.valor), color = Cor.Verde, fontSize = 36.sp, fontWeight = FontWeight.Black)
        Text("${Gestao.lucHoje.salas} sala(s) criada(s) hoje", color = Cor.Texto, fontSize = 13.sp)
    }

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        CartaoNumero(brl(Gestao.lucSemana.valor), "7 dias", "${Gestao.lucSemana.salas} salas", Cor.Azul, Modifier.weight(1f))
        CartaoNumero(brl(Gestao.lucMes.valor), "30 dias", "${Gestao.lucMes.salas} salas", Cor.Roxo, Modifier.weight(1f))
        CartaoNumero(brl(Gestao.lucTotal.valor), "Total", "${Gestao.lucTotal.salas} salas", Cor.Rosa, Modifier.weight(1f))
    }

    // ── valor por sala ──
    TituloGrupo("VALOR POR SALA CRIADA", Cor.Laranja)
    Cartao {
        Text("💰 Quanto você ganha a cada sala", color = Cor.Texto, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text("Cada sala criada pelo bot soma esse valor ao seu lucro.", color = Cor.Muted, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = campo, onValueChange = { campo = it.take(10); erroCampo = "" }, singleLine = true,
            label = { Text("Valor (R$)") }, placeholder = { Text("Ex.: 1,50") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth()
        )
        if (erroCampo.isNotBlank()) { Spacer(Modifier.height(4.dp)); Text(erroCampo, color = Cor.Vermelho, fontSize = 12.sp) }
        Spacer(Modifier.height(6.dp))
        Text("Valor atual: " + brl(Gestao.valorSala), color = Cor.Muted, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))
        Botao("Salvar valor", Cor.Verde) {
            val v = lerValor(campo)
            if (v == null) erroCampo = "Digite um valor válido (ex.: 1,50)." else Gestao.salvarValorSala(v)
        }
    }

    // ── pix lidos (do celular) ──
    TituloGrupo("PIX RECEBIDOS HOJE", Cor.Ciano)
    Cartao {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("💸", fontSize = 26.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(brl(Estado.totalHoje), color = Cor.Ciano, fontWeight = FontWeight.Black, fontSize = 20.sp)
                Text("${Estado.hoje} Pix lido(s) pelo celular/Gmail", color = Cor.Muted, fontSize = 12.sp)
            }
        }
    }

    // ── histórico ──
    TituloGrupo("ÚLTIMAS SALAS", Cor.Rosa)
    if (Gestao.historico.isEmpty()) {
        Cartao { Text("Nenhuma sala registrada ainda.", color = Cor.Muted, fontSize = 12.sp) }
    }
    Gestao.historico.take(30).forEach { g ->
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Cor.Card)
                .border(1.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(16.dp)).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Avatar(g.servidor.ifBlank { "S" }, Cor.Verde, 38)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(g.sala.ifBlank { "Sala criada" }, color = Cor.Texto, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(g.servidor.ifBlank { "—" } + "  •  " + hora(g.ts), color = Cor.Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text("+" + brl(g.valor), color = Cor.Verde, fontWeight = FontWeight.Black, fontSize = 15.sp)
        }
    }
}

// ───────────────────────── INTELIGÊNCIA ARTIFICIAL ─────────────────────────

@Composable
fun IaTela() {
    LaunchedEffect(Unit) { if (Prefs.conectado) Gestao.carregarIA() }
    var ativa by remember(Gestao.iaVersao) { mutableStateOf(Gestao.iaAtiva) }
    var prompt by remember(Gestao.iaVersao) { mutableStateOf(Gestao.iaPrompt) }
    var modelo by remember(Gestao.iaVersao) { mutableStateOf(Gestao.iaModelo) }
    var criat by remember(Gestao.iaVersao) { mutableStateOf(Gestao.iaCriatividade) }

    AvisoBarra()
    if (!Prefs.conectado) { PedirConexao(); return }
    if (Gestao.iaErro.isNotBlank()) { CartaoErro(Gestao.iaErro) { Gestao.carregarIA() }; return }
    if (!Gestao.iaCarregado) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) { Pill("Carregando…", Cor.Ciano) }
        return
    }

    val formaF = RoundedCornerShape(22.dp)
    Row(
        Modifier.fillMaxWidth().clip(formaF)
            .background(Brush.linearGradient(listOf(Cor.Azul.copy(alpha = if (ativa) 0.5f else 0.2f), Cor.Card)))
            .border(1.dp, Cor.Azul.copy(alpha = 0.5f), formaF).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(48.dp).clip(CircleShape).background(Cor.Azul.copy(alpha = 0.3f)), contentAlignment = Alignment.Center) { Text("🤖", fontSize = 24.sp) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("IA do bot", color = Cor.Texto, fontWeight = FontWeight.Black, fontSize = 16.sp)
            Text(if (ativa) "Ligada: o bot usa a IA para responder." else "Desligada: o bot não usa IA.", color = Cor.Muted, fontSize = 12.sp)
        }
        Switch(
            checked = ativa,
            onCheckedChange = { novo -> ativa = novo; Gestao.salvarIA(novo, prompt.trim(), modelo, criat) },
            colors = CorSwitch()
        )
    }

    if (Gestao.iaModelos.isNotEmpty()) {
        TituloGrupo("MODELO", Cor.Azul)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Gestao.iaModelos.forEach { m -> Chip(m.rotulo, Cor.Azul, modelo == m.k) { modelo = m.k } }
        }
    }

    TituloGrupo("CRIATIVIDADE", Cor.Roxo)
    Cartao {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (criat < 0.34f) "Preciso" else if (criat < 0.67f) "Equilibrado" else "Criativo",
                color = Cor.Texto, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
            )
            Selo(String.format(java.util.Locale.US, "%.0f%%", criat * 100), Cor.Roxo)
        }
        Slider(
            value = criat, onValueChange = { criat = it }, valueRange = 0f..1f,
            colors = SliderDefaults.colors(thumbColor = Cor.Roxo, activeTrackColor = Cor.Roxo, inactiveTrackColor = Cor.Card2)
        )
        Text("Mais baixo = respostas parecidas e diretas. Mais alto = respostas mais variadas.", color = Cor.Muted, fontSize = 11.sp)
    }

    TituloGrupo("INSTRUÇÕES DA IA", Cor.Rosa)
    Cartao {
        Text("📝 Como a IA deve agir", color = Cor.Texto, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text("Explique o tom, o que pode e o que não pode responder.", color = Cor.Muted, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = prompt, onValueChange = { prompt = it.take(4000) },
            label = { Text("Instruções") }, minLines = 6, maxLines = 14, modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(4.dp))
        Text("${prompt.length}/4000", color = Cor.Muted, fontSize = 11.sp)
    }
    Botao("💾  Salvar configuração da IA", Cor.Verde) { Gestao.salvarIA(ativa, prompt.trim(), modelo, criat) }
}

// ───────────────────────── CANAIS E REGRAS ─────────────────────────

@Composable
fun DialogCanais(t: CanalTipo, canais: List<CanalInfo>, marcados: List<String>, onSalvar: (List<String>) -> Unit, onFechar: () -> Unit) {
    var busca by remember { mutableStateOf("") }
    var sel by remember { mutableStateOf(marcados) }
    val lista = canais.filter { busca.isBlank() || it.nome.contains(busca, ignoreCase = true) }
    AlertDialog(
        onDismissRequest = onFechar,
        containerColor = Cor.Card, titleContentColor = Cor.Texto, textContentColor = Cor.Texto,
        title = {
            Column {
                Text("📌  " + t.rotulo, fontWeight = FontWeight.Bold)
                Text(if (t.multiplo) "Escolha um ou mais canais" else "Escolha um canal", color = Cor.Muted, fontSize = 12.sp)
            }
        },
        text = {
            Column {
                OutlinedTextField(
                    value = busca, onValueChange = { busca = it }, singleLine = true,
                    label = { Text("Buscar canal") }, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                Column(Modifier.heightIn(max = 340.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (lista.isEmpty()) Text("Nenhum canal encontrado.", color = Cor.Muted, fontSize = 12.sp)
                    lista.forEach { c ->
                        val on = sel.contains(c.id)
                        val forma = RoundedCornerShape(12.dp)
                        Row(
                            Modifier.fillMaxWidth().clip(forma)
                                .background(if (on) Cor.Verde.copy(alpha = 0.16f) else Cor.Card2.copy(alpha = 0.7f))
                                .border(1.dp, if (on) Cor.Verde else Color.White.copy(alpha = 0.06f), forma)
                                .clickable {
                                    sel = if (on) sel - c.id else if (t.multiplo) sel + c.id else listOf(c.id)
                                }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("#  " + c.nome, color = Cor.Texto, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            if (on) Text("✓", color = Cor.Verde, fontWeight = FontWeight.Black, fontSize = 18.sp)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onSalvar(sel) }) { Text("Salvar", color = Cor.Verde, fontWeight = FontWeight.Bold) } },
        dismissButton = {
            Row {
                TextButton(onClick = { onSalvar(emptyList()) }) { Text("Limpar", color = Cor.Laranja) }
                TextButton(onClick = onFechar) { Text("Cancelar", color = Cor.Muted) }
            }
        }
    )
}

@Composable
fun CanaisTela() {
    LaunchedEffect(Unit) { if (Prefs.conectado) Painel.carregar() }
    var escolherServ by remember { mutableStateOf(false) }
    var editando by remember { mutableStateOf<CanalTipo?>(null) }
    val sel = Painel.servidorSel
    LaunchedEffect(sel) { if (sel != null && Prefs.conectado) Gestao.carregarCanais(sel) }

    AvisoBarra()
    if (!EstadoDoPainel()) return

    Text(
        "Defina quais canais o bot usa em cada servidor: regras, logs e outros. Cada servidor tem os seus.",
        color = Cor.Muted, fontSize = 12.sp
    )
    TituloGrupo("SERVIDOR", Cor.Ciano)
    CartaoServidorEscolhido { escolherServ = true }

    TituloGrupo("CANAIS", Cor.Laranja)
    val d = Gestao.canDetalhe
    if (sel == null) {
        Cartao {
            Text("🏠 Escolha um servidor", color = Cor.Texto, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("Toque em \"Escolher\" acima para ver e configurar os canais.", color = Cor.Muted, fontSize = 12.sp)
        }
    } else if (Gestao.canErro.isNotBlank()) {
        CartaoErro(Gestao.canErro) { Gestao.carregarCanais(sel) }
    } else if (d == null || d.guildId != sel) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) { Pill("Carregando canais…", Cor.Ciano) }
    } else {
        val cores = listOf(Cor.Rosa, Cor.Laranja, Cor.Azul, Cor.Verde, Cor.Roxo, Cor.Ciano)
        Gestao.canTipos.forEachIndexed { i, t ->
            val ids = d.config[t.k] ?: emptyList()
            val nomes = ids.mapNotNull { id -> d.canais.firstOrNull { it.id == id }?.nome }
            val emoji = if (t.k.contains("regra")) "📜" else if (t.k.contains("log")) "🧾" else "📌"
            CartaoAcao(
                emoji, t.rotulo, t.descricao, cores[i % cores.size],
                if (ids.isEmpty()) "não definido" else "${ids.size} canal(is)",
                if (ids.isEmpty()) Cor.Muted else Cor.Verde,
                if (nomes.isEmpty()) null else nomes.take(2).joinToString(" • ") { "#$it" } + if (nomes.size > 2) " +${nomes.size - 2}" else ""
            ) { editando = t }
        }
        if (Gestao.canTipos.isEmpty()) Text("O bot não enviou nenhum tipo de canal para configurar.", color = Cor.Muted, fontSize = 12.sp)
    }

    val ed = editando
    val det = Gestao.canDetalhe
    if (ed != null && sel != null && det != null) {
        DialogCanais(ed, det.canais, det.config[ed.k] ?: emptyList(), onSalvar = { ids ->
            Gestao.salvarCanal(sel, ed.k, ids); editando = null
        }, onFechar = { editando = null })
    }
    if (escolherServ) {
        DialogServidores({ escolherServ = false }) { s ->
            Painel.escolherServidor(s.id)
            escolherServ = false
        }
    }
}
