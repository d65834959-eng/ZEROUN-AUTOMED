package com.zeroun.automed

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Net {
    /** Endereço FIXO do bot (não precisa digitar no app). */
    const val URL_FIXA = "https://zeroun-selfbots.shardweb.app"

    fun base(): String = URL_FIXA

    /** Corpo padrão: key + deviceId (o servidor valida o celular vinculado). */
    fun corpo(): JSONObject = JSONObject()
        .put("key", Prefs.key.trim().uppercase())
        .put("deviceId", Prefs.deviceId)

    /** POST JSON. Retorna null se não houve resposta válida. */
    fun post(path: String, body: JSONObject): JSONObject? {
        return try {
            val b = base()
            if (b.isEmpty()) return null
            val c = URL(b + path).openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 8000
            c.readTimeout = 15000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
            val txt = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            c.disconnect()
            JSONObject(txt)
        } catch (e: Exception) {
            null
        }
    }
}
