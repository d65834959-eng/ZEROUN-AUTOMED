<div align="center">

# ⚡ ZEROUN AUTOMED

**App Android do bot • lê os Pix, controla o bot e se atualiza sozinho**

![Android](https://img.shields.io/badge/Android-8.0%2B-3DDC84?logo=android&logoColor=white)
![Kotlin](https://img.shields.io/badge/Kotlin-Compose-7F52FF?logo=kotlin&logoColor=white)
![Releases](https://img.shields.io/badge/Releases-autom%C3%A1ticas-2ea44f?logo=github&logoColor=white)

</div>

---

## 🚀 Lançar uma atualização (a única coisa que você faz)

| Passo | O que fazer |
|:-----:|-------------|
| **1️⃣** | No GitHub: **Add file ➜ Upload files** e envie o **`.zip` do projeto** na branch `main` |
| **2️⃣** | Espere ~5 min. A aba **Actions** mostra ✅ (publicou) ou ❌ (erro de compilação) |
| **3️⃣** | No celular: **Configurações ➜ Procurar atualização** — a versão nova já aparece 🎉 |

> 🤖 O GitHub **extrai o zip, compila o APK, escolhe o número da versão e cria a Release sozinho.**
> Você nunca cria Release na mão.

---

## 🗂️ Como o projeto é organizado

```
ZEROUN-AUTOMED/
├── 📄 README.md                  ← você está aqui
├── 🤖 .github/workflows/
│   └── lancar.yml                ← robô que cria a Release
├── 📚 docs/
│   ├── 1-ATUALIZACAO.md          ← como funciona a atualização
│   ├── 2-SERVIDOR.md             ← configurar o bot/servidor
│   ├── 3-API-ENDPOINTS.md        ← endpoints da API
│   ├── 5-BANCO-API.md            ← 🏦 aba Banco (saldo, extrato, Pix)
│   ├── 6-MUSICA.md               ← 🎵 aba Música (busca, player, JSON no celular)
│   └── 4-HISTORICO-DE-VERSOES.txt
├── 📱 app/
│   ├── zeroun.jks                ← assinatura fixa (NÃO trocar)
│   └── src/main/
│       ├── java/com/zeroun/automed/
│       │   ├── MainActivity.kt   ← telas e navegação
│       │   ├── Atualizador.kt    ← 🔄 procura/baixa/instala updates
│       │   ├── Banco.kt          ← 🏦 aba Banco: saldo, extrato e Pix
│       │   ├── NotifService.kt   ← 🔔 lê notificações dos bancos
│       │   ├── Musica·Tocador·MusicaUI.kt ← 🎵 aba Música
│       │   ├── Avisos.kt         ← sino de avisos
│       │   ├── Net.kt · Estado.kt · Prefs.kt
│       │   └── Inicio / Painel / Gerenciar / Resumo / TelasConfig …
│       └── res/                  ← ícones, cores e tema
├── ⚙️ build.gradle.kts · settings.gradle.kts · gradle.properties
└── 📦 gradle/
```

---

## ✅ Configuração (uma vez só)

- [ ] Repositório **público**
- [ ] `.github/workflows/lancar.yml` enviado ao repositório
- [ ] **Settings ➜ Actions ➜ General ➜ Workflow permissions ➜ Read and write permissions**
- [ ] `GITHUB_REPO` em `Atualizador.kt` apontando para o seu `usuario/repositorio`

---

## ⚠️ Regras de ouro

| 🔒 | Regra |
|----|-------|
| 🔑 | **Nunca troque** `app/zeroun.jks`: com outra assinatura o Android recusa instalar por cima |
| 🔢 | Para pular de versão (ex.: 4.0.0) mude `versaoBase` em `app/build.gradle.kts` |
| 🤖 | Mudou só o `index.js` do bot? **Não** precisa lançar app: troque no servidor e reinicie |

---

## 🆘 Problemas comuns

<details>
<summary><b>O app diz "Nenhuma versão mais nova"</b></summary>

1. Abra **Actions**: se a última execução estiver ❌, o APK não compilou e não existe Release nova.
2. Se estiver ✅, abra **Releases**: o número precisa ser **maior** que o instalado.
3. O app mostra *Instalada x Última no GitHub* ao tocar em **Procurar atualização**.
</details>

<details>
<summary><b>Actions ✅ mas nenhuma Release apareceu</b></summary>

Ative **Read and write permissions** em *Settings ➜ Actions ➜ General ➜ Workflow permissions*.
</details>

<details>
<summary><b>O workflow não rodou ao subir o zip</b></summary>

Confirme que o envio foi para a branch **`main`** e que o `.zip` termina em `.zip`.
Também dá pra rodar à mão: **Actions ➜ Lançar app ➜ Run workflow**.
</details>
