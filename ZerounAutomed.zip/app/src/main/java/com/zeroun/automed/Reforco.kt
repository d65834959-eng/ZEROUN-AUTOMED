package com.zeroun.automed

import android.media.MediaPlayer
import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.LoudnessEnhancer
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Reforço de volume SÓ da música (não mexe no volume do celular).
 *
 * Dois efeitos do Android no áudio do player, antes do volume do sistema:
 *  • LoudnessEnhancer (ganho + limitador)
 *  • DynamicsProcessing (Android 9+): ganho de entrada + limitador
 * Se um não funcionar no aparelho, o outro segura. [status] mostra no player o que pegou.
 *
 * nivel: 0 = desligado • 100 = máximo. Padrão: 100.
 */
object Reforco {
    private const val MAX_MB = 2000      // LoudnessEnhancer: +20 dB
    private const val MAX_DB_DP = 15f    // DynamicsProcessing: +15 dB

    var nivel by mutableIntStateOf(100)
        private set

    /** Texto de diagnóstico mostrado no player. */
    var status by mutableStateOf("")
        private set

    private var le: LoudnessEnhancer? = null
    private var dp: DynamicsProcessing? = null
    private var carregado = false

    fun init() {
        if (carregado) return
        try { nivel = Prefs.reforco; carregado = true } catch (e: Exception) { }
    }

    fun definir(n: Int, salvar: Boolean) {
        nivel = n.coerceIn(0, 100)
        aplicar()
        if (salvar) { try { Prefs.reforco = nivel } catch (e: Exception) { } }
    }

    fun ligar(p: MediaPlayer) {
        init()
        soltar()
        val sessao = try { p.audioSessionId } catch (e: Exception) { 0 }
        val msg = StringBuilder("sessão $sessao")
        if (sessao <= 0) { status = "Reforço indisponível (sem sessão de áudio)"; return }

        try {
            le = LoudnessEnhancer(sessao)
            msg.append(" · LE ok")
        } catch (e: Throwable) {
            le = null
            msg.append(" · LE falhou: ").append(e.javaClass.simpleName)
        }

        if (Build.VERSION.SDK_INT >= 28) {
            try {
                dp = criarDp(sessao)
                msg.append(" · DP ok")
            } catch (e: Throwable) {
                dp = null
                msg.append(" · DP falhou: ").append(e.javaClass.simpleName)
            }
        }
        status = msg.toString()
        aplicar()
    }

    fun soltar() {
        val a = le; le = null
        if (a != null) { try { a.release() } catch (x: Throwable) { } }
        val b = dp; dp = null
        if (b != null) { try { b.release() } catch (x: Throwable) { } }
    }

    @Suppress("NewApi")
    private fun criarDp(sessao: Int): DynamicsProcessing {
        val cfg = DynamicsProcessing.Config.Builder(
            DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
            2, false, 0, false, 0, false, 0, true
        ).build()
        val d = DynamicsProcessing(0, sessao, cfg)
        val lim = DynamicsProcessing.Limiter(true, true, 0, 1f, 60f, 10f, -2f, 0f)
        d.setLimiterAllChannelsTo(lim)
        return d
    }

    @Suppress("NewApi")
    private fun aplicar() {
        val ligado = nivel > 0
        try {
            le?.let {
                it.setTargetGain(nivel * MAX_MB / 100)
                it.setEnabled(ligado)
            }
        } catch (x: Throwable) { }
        try {
            dp?.let {
                it.setInputGainAllChannelsTo(nivel * MAX_DB_DP / 100f)
                it.setEnabled(ligado)
            }
        } catch (x: Throwable) { }
    }
}
