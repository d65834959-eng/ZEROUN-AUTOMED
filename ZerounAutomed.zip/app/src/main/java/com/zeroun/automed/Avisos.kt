package com.zeroun.automed

import android.content.Context
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Notifications as SinoContorno
import androidx.compose.material.icons.rounded.AcUnit
import androidx.compose.material.icons.rounded.AccountBalance
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Error
import androidx.compose.material.icons.rounded.Mail
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.SystemUpdate
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.VpnKey
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ───────────────────────── modelo ─────────────────────────

/** ERRO = algo quebrou • ALERTA = falta configurar / precisa de atenção • INFO = novidade (ex.: atualização). */
enum class Nivel(val rotulo: String) { ERRO("ERRO"), ALERTA("ATENÇÃO"), INFO("NOVIDADE") }

/** Para onde o botão do aviso leva. */
enum class Destino { NENHUM, PERMISSAO, BATERIA, RECONECTAR, ABA_CONFIG, ABA_CONTROLE, TELA_CONTA, TELA_BANCOS, TELA_ATIVIDADE }

data class Aviso(
    val id: String,
    val nivel: Nivel,
    val titulo: String,
    val texto: String,
    val icone: ImageVector,
    val destino: Destino = Destino.NENHUM,
    val acao: String = ""
)

/** Quem abre a tela de avisos (o sino chama isso). Preenchido em Principal(). */
val LocalAbrirAvisos = compositionLocalOf<() -> Unit> { {} }

// ───────────────────────── regras: o que vira aviso ─────────────────────────

object Avisos {
    /** Avisos que a pessoa já viu. Só o que NÃO está aqui conta na bolinha do sino. */
    var vistos by mutableStateOf<Set<String>>(emptySet())
    private var carregou = false

    /** Chamar depois de Prefs.init(). */
    fun iniciar() {
        if (carregou) return
        carregou = true
        vistos = Prefs.avisosVistos
    }

    /** A pessoa abriu a tela de avisos: tudo que está na lista agora conta como visto. */
    fun marcarVistos(lista: List<Aviso>) {
        val novo = lista.map { it.id }.toSet()
        if (novo != vistos) { vistos = novo; Prefs.avisosVistos = novo }
    }

    /** Aviso que sumiu (problema resolvido) sai dos vistos: se voltar, o sino avisa de novo. */
    fun podar(ids: List<String>) {
        val novo = vistos.intersect(ids.toSet())
        if (novo != vistos) { vistos = novo; Prefs.avisosVistos = novo }
    }

    /** Lê o estado do app e do bot e devolve tudo que merece aparecer no sino (erros primeiro). */
    fun montar(c: Context, perm: Boolean, bateria: Boolean): List<Aviso> {
        if (!Prefs.conectado) return emptyList()
        val l = ArrayList<Aviso>()
        val agora = System.currentTimeMillis()

        fun add(n: Nivel, id: String, titulo: String, texto: String, icone: ImageVector, d: Destino = Destino.NENHUM, acao: String = "") {
            l.add(Aviso(id, n, titulo, texto, icone, d, acao))
        }

        // ── ERROS ──
        // Mensagens de erro de rede/servidor (sem repetir o mesmo texto).
        val msgs = LinkedHashSet<String>()
        if (Estado.msgServidor.isNotBlank()) msgs.add(Estado.msgServidor)
        if (Painel.erro.isNotBlank()) msgs.add(Painel.erro)
        if (Gestao.sisErro.isNotBlank()) msgs.add(Gestao.sisErro)
        msgs.forEach { m ->
            val semNet = m.contains("Sem resposta", true) || m.contains("internet", true)
            add(
                Nivel.ERRO, "srv:" + m.hashCode(),
                if (semNet) "Sem conexão com o bot" else "O bot devolveu um erro",
                m, if (semNet) Icons.Rounded.WifiOff else Icons.Rounded.Error,
                Destino.RECONECTAR, "Tentar de novo"
            )
        }
        if (Gestao.sisDicaServidor.isNotBlank()) {
            add(
                Nivel.ERRO, "dica:" + Gestao.sisDicaServidor.hashCode(), "Erro no servidor do bot",
                "O bot respondeu: \"" + Gestao.sisDicaServidor + "\". Veja a explicação em Controle.",
                Icons.Rounded.Error, Destino.ABA_CONTROLE, "Ver em Controle"
            )
        }
        if (Gestao.sisCongelada) {
            add(
                Nivel.ERRO, "congelada", "Key congelada",
                "O tempo da key está pausado e o bot não funciona. Descongele no Discord (Gerenciar sistema).",
                Icons.Rounded.AcUnit
            )
        }
        if (Gestao.sisExpiraTs > 0) {
            if (Gestao.sisExpiraTs <= agora) {
                add(Nivel.ERRO, "key_expirada", "Key expirada", "O tempo da sua key acabou. Renove para o bot voltar a funcionar.", Icons.Rounded.Timer)
            } else if (Gestao.sisExpiraTs - agora < 3 * 86_400_000L) {
                add(
                    Nivel.ALERTA, "key_expira", "Sua key está acabando",
                    "Expira em " + restante(Gestao.sisExpiraTs, agora) + ". Renove antes para o bot não parar.",
                    Icons.Rounded.Timer
                )
            }
        }
        // Erro recente ao mandar notificação ao bot (o "Bot ignorou…" já vira o aviso de "notificações desligadas").
        val ev = Estado.eventos.firstOrNull { it.tipo == 2 && agora - it.ts < 30 * 60_000L && !it.resultado.startsWith("Bot ignorou") }
        if (ev != null) {
            add(
                Nivel.ERRO, "ev:" + ev.ts, "Falha ao enviar notificação ao bot",
                ev.resultado + " (" + ev.app + ")", Icons.Rounded.Error, Destino.TELA_ATIVIDADE, "Ver atividade"
            )
        }
        if (Atualizador.msgErro && Atualizador.msg.isNotBlank()) {
            add(Nivel.ALERTA, "upd_erro:" + Atualizador.msg.hashCode(), "Problema na atualização", Atualizador.msg, Icons.Rounded.SystemUpdate, Destino.ABA_CONFIG, "Abrir")
        }

        // ── CONFIGURAÇÃO QUE FALTA ──
        if (!perm) {
            add(
                Nivel.ALERTA, "perm", "Falta liberar as notificações",
                "Sem essa permissão o app não enxerga os seus Pix.",
                Icons.Rounded.NotificationsOff, Destino.PERMISSAO, "Liberar agora"
            )
        }
        if (!(Estado.gmail || Estado.apps.isNotEmpty())) {
            add(
                Nivel.ALERTA, "bancos", "Nenhum banco escolhido",
                "Escolha os apps de banco que o app deve vigiar (ou use o Gmail).",
                Icons.Rounded.AccountBalance, Destino.TELA_BANCOS, "Escolher bancos"
            )
        }
        if (Gestao.sisCarregado) {
            if (!Gestao.sisResgatada) {
                add(
                    Nivel.ALERTA, "nao_resgatada", "Key ainda não resgatada",
                    "O bot só liga depois que a key é resgatada no Discord (/central).",
                    Icons.Rounded.VpnKey
                )
            }
            if (Gestao.sisEstado == "sem") {
                add(
                    Nivel.ALERTA, "sem_conta", "Conta não configurada",
                    "Falta o token ou o Gmail no Discord (/central).",
                    Icons.Rounded.Person, Destino.TELA_CONTA, "Ver conta"
                )
            }
            if (Gestao.sisAntiban && Gestao.sisServAntiban == 0) {
                add(
                    Nivel.ALERTA, "antiban", "Antiban sem servidor ativo",
                    "Escolha pelo menos um servidor em /central-antiban no Discord para o bot poder ligar.",
                    Icons.Rounded.Shield, Destino.ABA_CONTROLE, "Ver em Controle"
                )
            }
            if (Gestao.sisAtivo == false && Gestao.sisEstado != "sem" && !Gestao.sisCongelada) {
                add(
                    Nivel.ALERTA, "bot_desligado", "Bot desligado",
                    "Enquanto estiver desligado, nenhum Pix é processado.",
                    Icons.Rounded.PowerSettingsNew, Destino.ABA_CONTROLE, "Ligar em Controle"
                )
            }
        }
        if (Estado.ativoApp == false) {
            add(
                Nivel.ALERTA, "ativo_app", "Notificações do app desligadas no bot",
                "No Discord, ligue \"Ativar notificações app\". Desligado, o bot ignora o celular.",
                Icons.Rounded.NotificationsOff
            )
        }
        if (Estado.gmail && Painel.carregado && Painel.email.isBlank()) {
            add(
                Nivel.INFO, "gmail_bot", "Gmail do bot não conectado",
                "Você lê os Pix pelo Gmail, mas a conta do bot ainda não tem um Gmail ligado.",
                Icons.Rounded.Mail, Destino.TELA_CONTA, "Ver conta"
            )
        }
        if (!bateria) {
            add(
                Nivel.INFO, "bateria", "Economia de bateria ligada",
                "O Android pode fechar o app e você perder Pix. Deixe o app sempre ligado.",
                Icons.Rounded.BatteryChargingFull, Destino.BATERIA, "Corrigir"
            )
        }

        // ── NOVIDADE: atualização ──
        val novo = Atualizador.disponivel
        if (novo != null && novo.codigo > Atualizador.versaoAtual(c).first) {
            add(
                Nivel.INFO, "upd:" + novo.codigo, "Nova versão " + novo.nome + " disponível",
                if (novo.notas.isNotBlank()) novo.notas.take(140) else "Toque para baixar e instalar a atualização.",
                Icons.Rounded.SystemUpdate, Destino.ABA_CONFIG, "Atualizar"
            )
        }

        return l.sortedBy { it.nivel.ordinal }
    }
}

/** Lista atual de avisos. Recompõe sozinha quando o estado do bot/app muda; relê permissões ao voltar pro app. */
@Composable
fun avisosAtuais(): List<Aviso> {
    val c = LocalContext.current
    val perm = remember(Estado.tick) { permissaoOk(c) }
    val bateria = remember(Estado.tick) { bateriaOk(c) }
    return Avisos.montar(c, perm, bateria)
}

// ───────────────────────── o sino ─────────────────────────

/** Botão do sino com bolinha de quantidade (vermelha = tem erro novo, laranja = atenção, azul = novidade). */
@Composable
fun Sino() {
    val abrir = LocalAbrirAvisos.current
    val lista = avisosAtuais()
    val ids = lista.map { it.id }
    val novos = lista.filter { it.id !in Avisos.vistos }
    val cor = when {
        novos.any { it.nivel == Nivel.ERRO } -> Cor.Vermelho
        novos.any { it.nivel == Nivel.ALERTA } -> Cor.Laranja
        else -> Cor.Azul
    }
    // só limpa depois que o bot respondeu (senão avisos antigos "voltariam" como novos a cada abertura do app)
    LaunchedEffect(ids, Gestao.sisCarregado) { if (Gestao.sisCarregado) Avisos.podar(ids) }

    // balança quando chega aviso novo
    val giro = remember { Animatable(0f) }
    LaunchedEffect(novos.size) {
        if (novos.isNotEmpty()) {
            repeat(3) { giro.animateTo(16f, tween(70)); giro.animateTo(-16f, tween(70)) }
            giro.animateTo(0f, tween(70))
        }
    }

    Box(Modifier.size(46.dp)) {
        Box(
            Modifier.size(46.dp).clip(CircleShape).background(Cor.Card)
                .border(1.dp, if (novos.isNotEmpty()) cor.copy(alpha = 0.7f) else Cor.Borda, CircleShape)
                .clickable { abrir() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Outlined.SinoContorno, "Notificações", tint = Cor.Texto,
                modifier = Modifier.size(24.dp).rotate(giro.value)
            )
        }
        if (novos.isNotEmpty()) {
            Box(
                Modifier.align(Alignment.TopEnd).offset(x = 2.dp, y = (-2).dp)
                    .size(20.dp).clip(CircleShape).background(cor)
                    .border(2.dp, Cor.Fundo, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (novos.size > 9) "9+" else novos.size.toString(),
                    color = sobre(cor), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center
                )
            }
        }
    }
}

// ───────────────────────── tela "Notificações" ─────────────────────────

@Composable
fun AvisosTela(abrir: (Destino) -> Unit) {
    val lista = avisosAtuais()
    // enquanto a tela está aberta, tudo que aparece conta como visto
    LaunchedEffect(lista.map { it.id }) { Avisos.marcarVistos(lista) }

    if (lista.isEmpty()) {
        Cartao {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconeCaixa(Icons.Rounded.CheckCircle, Cor.Verde, 52)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Tudo certo por aqui", color = Cor.Texto, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Nenhum erro, atualização ou configuração pendente.", color = Cor.Muted, fontSize = 13.sp)
                }
            }
        }
        return
    }

    Text(
        "Os avisos somem sozinhos quando o problema é resolvido.",
        color = Cor.Muted, fontSize = 13.sp
    )
    lista.forEach { a ->
        val cor = when (a.nivel) { Nivel.ERRO -> Cor.Vermelho; Nivel.ALERTA -> Cor.Laranja; Nivel.INFO -> Cor.Azul }
        val forma = RoundedCornerShape(22.dp)
        Column(
            Modifier.fillMaxWidth().clip(forma).background(Cor.Card)
                .border(1.dp, cor.copy(alpha = 0.45f), forma).padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.Top) {
                IconeCaixa(a.icone, cor)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Selo(a.nivel.rotulo, cor)
                    Spacer(Modifier.height(6.dp))
                    Text(a.titulo, color = Cor.Texto, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(2.dp))
                    Text(a.texto, color = Cor.Muted, fontSize = 13.sp)
                }
            }
            if (a.destino != Destino.NENHUM && a.acao.isNotBlank()) {
                Spacer(Modifier.height(12.dp))
                BotaoMini(a.acao, cor) { abrir(a.destino) }
            }
        }
    }
}

// ───────────────────────── botão de perfil (ao lado do sino) ─────────────────────────

@Composable
fun BotaoPerfil(onClick: () -> Unit) {
    Box(
        Modifier.size(46.dp).clip(CircleShape).background(Cor.Card).border(1.dp, Cor.Borda, CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(Icons.Rounded.Person, "Perfil", tint = Cor.Texto, modifier = Modifier.size(24.dp)) }
}
