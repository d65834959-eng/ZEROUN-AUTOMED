# O que o servidor (index.js) precisa ter para as telas novas

Todas as chamadas são `POST` com JSON e já levam `key` e `deviceId` (igual às telas antigas).
Resposta sempre `{ "ok": true, ... }` ou `{ "ok": false, "msg": "texto do erro" }`.
Sem esses endpoints a tela mostra "Endpoint desconhecido" e o resto do app segue normal.

## 1. ⚙️ Gerenciar sistema

`POST /api/sistema`  →
```json
{ "ok": true, "ativo": true, "expiraTs": 1767225600000, "expira": "31/12/2026", "plano": "Mensal" }
```
- `ativo`: se o bot dessa key está ligado (o mesmo que o "ativar" do Gerenciar sistema no Discord)
- `expiraTs`: validade em milissegundos (o app faz a contagem "12d 4h 10min"). Opcional; sem ele o app mostra `expira` (texto)
- `plano`: opcional

`POST /api/acao` com `{ "acao": "sistema_ativar", "valor": true|false }` → liga/desliga o bot.
Responda `{ "ok": true, "msg": "Bot ativado." }`.

## 2. 💰 Lucros

`POST /api/lucros` →
```json
{
  "ok": true,
  "valorPorSala": 1.5,
  "hoje":   { "salas": 12, "valor": 18.0 },
  "semana": { "salas": 80, "valor": 120.0 },
  "mes":    { "salas": 300, "valor": 450.0 },
  "total":  { "salas": 900, "valor": 1350.0 },
  "historico": [ { "ts": 1767225600000, "valor": 1.5, "servidor": "Nome do servidor", "sala": "Sala normal" } ]
}
```
`POST /api/acao` com `{ "acao": "lucro_valor", "valor": 1.5 }` → salva quanto ganha por sala criada.
Sugestão: o servidor multiplica o `valorPorSala` vigente na hora em que a sala é criada e guarda no histórico.

## 3. 🤖 Inteligência artificial

`POST /api/ia` →
```json
{
  "ok": true, "ativo": true, "modelo": "padrao", "criatividade": 0.5,
  "prompt": "Você é o mediador...",
  "modelos": [ { "k": "padrao", "rotulo": "Padrão" }, { "k": "rapido", "rotulo": "Rápido" } ]
}
```
`POST /api/acao` com `{ "acao": "ia_salvar", "ativo": true, "prompt": "...", "modelo": "padrao", "criatividade": 0.5 }`.

## 4. 📌 Canais e regras (por servidor)

`POST /api/canais` com `{ "guildId": "123" }` →
```json
{
  "ok": true,
  "tipos": [
    { "k": "regras", "rotulo": "Canal de regras", "descricao": "Onde o bot lê/posta as regras", "multiplo": false },
    { "k": "logs",   "rotulo": "Canal de logs",   "descricao": "Registro das salas",           "multiplo": false }
  ],
  "canais": [ { "id": "111", "nome": "regras" }, { "id": "222", "nome": "geral" } ],
  "config": { "regras": ["111"], "logs": [] }
}
```
Os tipos vêm do servidor: pode adicionar quantos quiser que o app mostra sozinho.

`POST /api/acao` com `{ "acao": "canal_salvar", "guildId": "123", "tipo": "regras", "canais": ["111"] }` (lista vazia = limpar).
