package com.zeroun.automed

import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/*
 * MÚSICA — "Mediação com música"
 *
 * Como funciona (igual ao index.js do bot de call):
 *   1) PROCURAR  = o index.js usa  yt-dlp ytsearch1:<busca>  → só título + link (rápido, sem baixar nada).
 *                  Aqui o celular faz a mesma busca direto no YouTube (YT.buscar).
 *   2) TOCAR     = o index.js usa  yt-dlp -f bestaudio  → pega o melhor áudio.
 *                  Aqui o celular pede o melhor áudio (YT.resolver) e toca no próprio aparelho (Tocador).
 *   3) CACHE     = o index.js guarda busca → resultado num Map. Aqui tudo fica num JSON no celular
 *                  (files/musica.json): buscas, músicas tocadas, endereço do áudio e histórico de cada usuário.
 *
 * Nada disso usa a key nem o servidor, então continua funcionando (e salvo) mesmo se a key acabar.
 */

/** Uma música do YouTube. */
data class Som(val id: String, val titulo: String, val artista: String, val duracao: Int)

/** Quantas vezes UM usuário ouviu a música e quando foi a última vez. */
data class Uso(val plays: Int, val ultimo: Long)

/** Música + uso (para as listas "Mais ouvidas" e "Recentes"). */
data class ItemUso(val faixa: Som, val uso: Uso)

/** Playlist do usuário (a "favoritas" é fixa e criada sozinha). [faixas] = ids das músicas, na ordem em que foram adicionadas. */
data class Playlist(val id: String, val nome: String, val faixas: List<String>, val criada: Long)

const val ID_FAV = "favoritas"

/** Endereço direto do áudio (vale umas 6 horas) + de qual "cliente" do YouTube ele veio. */
data class Fluxo(
    val url: String, val ua: String, val cliente: String, val expira: Long,
    val titulo: String, val artista: String, val duracao: Int
)

// ───────────────────────── YouTube (o "yt-dlp" do celular) ─────────────────────────

object YT {
    private class Cliente(
        val chave: String, val nome: String, val numero: String, val versao: String,
        val ua: String, val extra: JSONObject
    )

    /**
     * Clientes do YouTube que entregam o link do áudio sem login. Tenta um por um.
     * Se o YouTube mudar algo e a música parar de tocar, atualize as versões aqui (como se atualiza o yt-dlp).
     */
    private val clientes = listOf(
        Cliente(
            "vr", "ANDROID_VR", "28", "1.65.10",
            "com.google.android.apps.youtube.vr.oculus/1.65.10 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip",
            JSONObject().put("deviceMake", "Oculus").put("deviceModel", "Quest 3")
                .put("androidSdkVersion", 32).put("osName", "Android").put("osVersion", "12L")
        ),
        Cliente(
            "ios", "IOS", "5", "20.10.4",
            "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
            JSONObject().put("deviceMake", "Apple").put("deviceModel", "iPhone16,2")
                .put("osName", "iPhone").put("osVersion", "18.3.2.22D82")
        ),
        Cliente(
            "and", "ANDROID", "3", "20.10.38",
            "com.google.android.youtube/20.10.38 (Linux; U; Android 11) gzip",
            JSONObject().put("androidSdkVersion", 30).put("osName", "Android").put("osVersion", "11")
        )
    )

    val total: Int get() = 1

    private const val VERSAO_WEB = "2.20241126.01.00"
    private const val UA_WEB =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"

    private val reLink = Regex(
        "(?:youtu\\.be/|youtube\\.com/(?:watch\\?(?:.*&)?v=|shorts/|embed/|live/))([A-Za-z0-9_-]{11})"
    )
    private val reExpira = Regex("[?&]expire=(\\d+)")

    private fun postar(url: String, corpo: JSONObject, cab: Map<String, String>): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            for ((k, v) in cab) c.setRequestProperty(k, v)
            c.outputStream.use { it.write(corpo.toString().toByteArray(Charsets.UTF_8)) }
            val ok = c.responseCode in 200..299
            val txt = (if (ok) c.inputStream else c.errorStream)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (!ok) {
                // mostra o motivo que o YouTube deu (ex.: "Precondition check failed" = versão do cliente velha demais)
                val motivo = try { JSONObject(txt).optJSONObject("error")?.optString("message").orEmpty() } catch (e: Exception) { "" }
                throw IOException("HTTP " + c.responseCode + (if (motivo.isNotBlank()) " - " + motivo else ""))
            }
            return JSONObject(txt)
        } finally {
            c.disconnect()
        }
    }

    /** Se o texto for um link do YouTube, devolve o id do vídeo (o index.js também aceita link). */
    fun idDoLink(texto: String): String? {
        val t = texto.trim()
        if (!t.startsWith("http", ignoreCase = true)) return null
        return reLink.find(t)?.groupValues?.get(1)
    }

    // ── 1) PROCURAR (igual ao ytsearch1 do index.js, só que trazendo vários resultados) ──

    fun buscar(consulta: String): List<Som> {
        val j = servidor("/musica/buscar?q=" + java.net.URLEncoder.encode(consulta.trim(), "UTF-8") + "&" + auth(), 60_000)
        val arr = j.optJSONArray("itens") ?: JSONArray()
        val lista = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            val id = o.getString("id")
            val prog = o.optString("prog")
            if (prog.startsWith("http")) MusicaStore.guardarDica(id, prog, o.optString("auth"))
            Som(id, o.optString("titulo"), o.optString("artista"), o.optInt("duracao"))
        }
        if (cidSc.isBlank()) Thread { try { clienteSc() } catch (e: Exception) { } }.start()
        if (lista.isEmpty()) throw Exception("Não achei nenhuma música com essa busca.")
        return lista
    }

    fun auth(): String =
        "k=" + java.net.URLEncoder.encode(Prefs.key.trim().uppercase(), "UTF-8") +
            "&d=" + java.net.URLEncoder.encode(Prefs.deviceId, "UTF-8")

    /** GET no bot (o yt-dlp roda lá). Devolve o JSON ou joga o motivo real. */
    private fun servidor(caminho: String, leitura: Int): JSONObject {
        val c = URL(Net.base() + caminho).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = leitura
            val ok = c.responseCode in 200..299
            val txt = (if (ok) c.inputStream else c.errorStream)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            val j = try { JSONObject(txt) } catch (e: Exception) { throw IOException("Servidor respondeu HTTP " + c.responseCode) }
            if (!j.optBoolean("ok")) throw IOException(j.optString("msg").ifBlank { "HTTP " + c.responseCode })
            return j
        } finally {
            c.disconnect()
        }
    }

    fun semRede(e: Exception): Boolean =
        e is java.net.UnknownHostException || e is java.net.ConnectException || e is java.net.SocketTimeoutException

    fun detalhe(e: Exception): String = e.javaClass.simpleName + (if (e.message.isNullOrBlank()) "" else ": " + e.message)

    private fun buscarApi(consulta: String): JSONObject {
        val cliente = JSONObject().put("clientName", "WEB").put("clientVersion", VERSAO_WEB)
            .put("hl", "pt").put("gl", "BR")
        val corpo = JSONObject().put("context", JSONObject().put("client", cliente))
            .put("query", consulta).put("params", "EgIQAQ==") // EgIQAQ== = só vídeos
        return postar(
            "https://www.youtube.com/youtubei/v1/search?prettyPrint=false", corpo,
            mapOf(
                "User-Agent" to UA_WEB, "X-YouTube-Client-Name" to "1", "X-YouTube-Client-Version" to VERSAO_WEB,
                "Accept-Language" to "pt-BR,pt;q=0.9", "Origin" to "https://www.youtube.com", "Cookie" to "SOCS=CAI"
            )
        )
    }

    /** Plano B: abre a página de resultados como o navegador e lê o JSON embutido (ytInitialData). */
    private fun buscarHtml(consulta: String): JSONObject {
        val q = java.net.URLEncoder.encode(consulta, "UTF-8")
        val c = URL("https://www.youtube.com/results?hl=pt&gl=BR&sp=EgIQAQ%253D%253D&search_query=" + q).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.setRequestProperty("User-Agent", UA_WEB)
            c.setRequestProperty("Accept-Language", "pt-BR,pt;q=0.9")
            c.setRequestProperty("Cookie", "SOCS=CAI; CONSENT=YES+1")
            if (c.responseCode !in 200..299) throw IOException("HTTP " + c.responseCode)
            val html = c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val i = html.indexOf("ytInitialData = ")
            if (i < 0) throw IOException("página sem resultados")
            val ini = i + "ytInitialData = ".length
            val fim = html.indexOf(";</script>", ini)
            if (fim < 0) throw IOException("página em formato novo")
            return JSONObject(html.substring(ini, fim))
        } finally {
            c.disconnect()
        }
    }

    private fun lerResultados(r: JSONObject): List<Som> {
        val brutos = ArrayList<JSONObject>()
        coletar(r, brutos)
        val lista = ArrayList<Som>()
        for (v in brutos) {
            val vid = v.optString("videoId")
            if (vid.isBlank() || lista.any { it.id == vid }) continue
            val seg = segundos(texto(v.optJSONObject("lengthText")))
            if (seg <= 0) continue // ao vivo / sem duração
            val titulo = texto(v.optJSONObject("title")).trim()
            if (titulo.isBlank()) continue
            var artista = texto(v.optJSONObject("ownerText")).trim()
            if (artista.isBlank()) artista = texto(v.optJSONObject("longBylineText")).trim()
            artista = artista.removeSuffix(" - Topic").ifBlank { "YouTube" }
            lista.add(Som(vid, titulo, artista, seg))
            if (lista.size >= 12) break
        }
        return lista
    }

    /** Percorre o JSON do YouTube e junta todos os "videoRenderer" (os vídeos do resultado). */
    private fun coletar(n: Any?, out: MutableList<JSONObject>) {
        if (out.size >= 20) return
        if (n is JSONObject) {
            val v = n.optJSONObject("videoRenderer")
            if (v != null) out.add(v)
            val ks = n.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                if (k != "videoRenderer") coletar(n.opt(k), out)
            }
        } else if (n is JSONArray) {
            for (i in 0 until n.length()) coletar(n.opt(i), out)
        }
    }

    private fun texto(o: JSONObject?): String {
        if (o == null) return ""
        val simples = o.optString("simpleText")
        if (simples.isNotBlank()) return simples
        val runs = o.optJSONArray("runs") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until runs.length()) sb.append(runs.optJSONObject(i)?.optString("text") ?: "")
        return sb.toString()
    }

    private fun segundos(t: String): Int {
        if (t.isBlank()) return 0
        var s = 0
        for (p in t.split(":")) {
            val n = p.trim().toIntOrNull() ?: return 0
            s = s * 60 + n
        }
        return s
    }

    // ── 2) PEGAR O ÁUDIO (igual ao "-f bestaudio" do index.js) ──

    /**
     * Pede o áudio ao bot. Se o bot devolver o endereço direto do CDN (SoundCloud), o celular toca direto de lá:
     * só 1 ida ao servidor e a música começa em ~1 s. Se não houver, usa o endereço do próprio bot (/musica/audio).
     */
    fun resolver(id: String, evitar: Set<String>): Fluxo {
        val f0 = MusicaStore.faixa(id)
        val dica = MusicaStore.dica(id)
        if (dica != null) {
            // caminho rápido: o celular pergunta direto ao SoundCloud (sem passar pelo bot)
            try {
                val u = diretoSc(dica.first, dica.second)
                if (u != null) return Fluxo(u, UA_WEB, "cdn", System.currentTimeMillis() + 8 * 60_000L,
                    f0?.titulo ?: "Música", f0?.artista ?: "Artista", f0?.duracao ?: 0)
            } catch (e: Exception) { }
        }
        val j = servidor("/musica/preparar?id=" + id + "&" + auth(), 120_000)
        val f = MusicaStore.faixa(id)
        val titulo = f?.titulo ?: "Música"
        val artista = f?.artista ?: "YouTube"
        val dur = f?.duracao ?: 0
        val direto = j.optString("url")
        if (direto.startsWith("http")) {
            return Fluxo(direto, UA_WEB, "cdn", System.currentTimeMillis() + 8 * 60_000L, titulo, artista, dur)
        }
        return Fluxo(
            url = Net.base() + "/musica/audio?id=" + id + "&" + auth(),
            ua = "ZerounAutomed", cliente = "srv",
            expira = System.currentTimeMillis() + 3 * 3600_000L,
            titulo = titulo, artista = artista, duracao = dur
        )
    }

    @Volatile private var cidSc = ""

    private fun clienteSc(): String {
        if (cidSc.isNotBlank()) return cidSc
        cidSc = servidor("/musica/cid?" + auth(), 10_000).optString("cid")
        return cidSc
    }

    /** Endereço direto do mp3 no CDN do SoundCloud, pedido pelo próprio celular (~0,3 s). null = usa o bot. */
    private fun diretoSc(prog: String, aut: String): String? {
        val cid = clienteSc()
        if (cid.isBlank()) return null
        val url = prog + (if (prog.contains("?")) "&" else "?") + "client_id=" + cid +
            (if (aut.isNotBlank()) "&track_authorization=" + java.net.URLEncoder.encode(aut, "UTF-8") else "")
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 5_000
            c.readTimeout = 6_000
            c.setRequestProperty("User-Agent", UA_WEB)
            if (c.responseCode !in 200..299) { cidSc = ""; return null } // client_id velho: o bot renova
            val u = JSONObject(c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }).optString("url")
            return if (u.startsWith("http")) u else null
        } finally {
            c.disconnect()
        }
    }

    /** Escolhe o melhor áudio: m4a (AAC) de maior qualidade; se não tiver, qualquer áudio; por último o vídeo completo. */
    private fun melhorAudio(sd: JSONObject?): String? {
        if (sd == null) return null
        val ad = sd.optJSONArray("adaptiveFormats")
        var melhor: String? = null
        var nota = -1L
        if (ad != null) {
            for (i in 0 until ad.length()) {
                val f = ad.optJSONObject(i) ?: continue
                val mime = f.optString("mimeType")
                val u = f.optString("url")
                if (!mime.startsWith("audio/") || u.isBlank()) continue
                val n = f.optLong("bitrate", 0L) + (if (mime.contains("mp4")) 1_000_000_000L else 0L)
                if (n > nota) { nota = n; melhor = u }
            }
        }
        if (melhor != null) return melhor
        val fm = sd.optJSONArray("formats")
        if (fm != null) {
            for (i in 0 until fm.length()) {
                val u = fm.optJSONObject(i)?.optString("url").orEmpty()
                if (u.isNotBlank()) return u
            }
        }
        return null
    }
}

// ───────────────────────── JSON no celular ─────────────────────────

/**
 * Tudo num arquivo só: files/musica.json
 *   "faixas"   → músicas que o usuário clicou (não precisa pesquisar de novo)
 *   "streams"  → endereço do áudio já descoberto (toca na hora enquanto não vence)
 *   "buscas"   → resultados de cada pesquisa (repetir a busca não vai ao YouTube)
 *   "usuarios" → por usuário: quantas vezes ouviu e quando (Mais ouvidas / Recentes)
 * Fica no celular: continua aí quando a key acaba e quando se compra outra.
 */
object MusicaStore {
    private const val MAX_BUSCAS = 200
    private const val MAX_FAIXAS = 2000
    private val lock = Any()
    private val gravador = Executors.newSingleThreadExecutor()
    private var arquivo: File? = null
    private var iniciado = false

    private val faixas = LinkedHashMap<String, Som>()
    private val streams = HashMap<String, Fluxo>()
    private val buscas = LinkedHashMap<String, Pair<Long, List<Som>>>()
    private val usuarios = HashMap<String, HashMap<String, Uso>>()
    private val playlists = LinkedHashMap<String, Playlist>()
    private val dicas = HashMap<String, Pair<String, String>>()

    /** Sobe a cada mudança: as telas usam isso pra se atualizar. */
    var versao by mutableIntStateOf(0)
        private set

    fun init(c: Context) {
        if (iniciado) return
        iniciado = true
        val app = c.applicationContext
        Capas.init(app)
        Baixados.init(app)
        Tocador.init(app)
        arquivo = File(app.filesDir, "musica.json")
        carregar()
        synchronized(lock) { garantirFavoritas() }
        versao = versao + 1
    }

    private fun usuario(): String = Prefs.deviceId

    private fun faixaJson(f: Som): JSONObject = JSONObject()
        .put("id", f.id).put("titulo", f.titulo).put("artista", f.artista).put("duracao", f.duracao)

    private fun faixaDe(o: JSONObject): Som = Som(
        o.optString("id"), o.optString("titulo"), o.optString("artista"), o.optInt("duracao", 0)
    )

    private fun carregar() {
        try {
            val f = arquivo ?: return
            if (!f.exists()) return
            val raiz = JSONObject(f.readText(Charsets.UTF_8))
            synchronized(lock) {
                val fa = raiz.optJSONObject("faixas")
                if (fa != null) {
                    val ks = fa.keys()
                    while (ks.hasNext()) {
                        val k = ks.next()
                        val x = faixaDe(fa.getJSONObject(k))
                        if (x.id.isNotBlank()) faixas[k] = x
                    }
                }
                val st = raiz.optJSONObject("streams")
                if (st != null) {
                    val ks = st.keys()
                    while (ks.hasNext()) {
                        val k = ks.next()
                        val o = st.getJSONObject(k)
                        streams[k] = Fluxo(
                            o.optString("url"), o.optString("ua"), o.optString("cliente"), o.optLong("expira"),
                            o.optString("titulo"), o.optString("artista"), o.optInt("duracao")
                        )
                    }
                }
                val bu = raiz.optJSONObject("buscas")
                if (bu != null) {
                    val ks = bu.keys()
                    while (ks.hasNext()) {
                        val k = ks.next()
                        val o = bu.getJSONObject(k)
                        val arr = o.optJSONArray("itens") ?: JSONArray()
                        val lista = ArrayList<Som>()
                        for (i in 0 until arr.length()) lista.add(faixaDe(arr.getJSONObject(i)))
                        buscas[k] = Pair(o.optLong("ts"), lista)
                    }
                }
                val us = raiz.optJSONObject("usuarios")
                if (us != null) {
                    val ks = us.keys()
                    while (ks.hasNext()) {
                        val u = ks.next()
                        val m = HashMap<String, Uso>()
                        val o = us.getJSONObject(u)
                        val ids = o.keys()
                        while (ids.hasNext()) {
                            val id = ids.next()
                            val x = o.getJSONObject(id)
                            m[id] = Uso(x.optInt("plays"), x.optLong("ultimo"))
                        }
                        usuarios[u] = m
                    }
                }
                val di = raiz.optJSONObject("dicas")
                if (di != null) {
                    val ks = di.keys()
                    while (ks.hasNext()) {
                        val k = ks.next()
                        val o = di.optJSONObject(k) ?: continue
                        dicas[k] = Pair(o.optString("p"), o.optString("a"))
                    }
                }
                val pls = raiz.optJSONArray("playlists")
                if (pls != null) {
                    for (i in 0 until pls.length()) {
                        val o = pls.optJSONObject(i) ?: continue
                        val id = o.optString("id")
                        if (id.isBlank()) continue
                        val ids = ArrayList<String>()
                        val arr = o.optJSONArray("faixas") ?: JSONArray()
                        for (k in 0 until arr.length()) ids.add(arr.optString(k))
                        playlists[id] = Playlist(id, o.optString("nome", "Playlist"), ids, o.optLong("criada"))
                    }
                }
            }
            versao = versao + 1
        } catch (e: Exception) {
            // arquivo estragado: começa do zero (o antigo é sobrescrito no próximo salvar)
        }
    }

    /** Monta o JSON agora (dentro do lock) e grava em segundo plano, sem travar a tela. */
    private fun salvar() {
        val alvo = arquivo ?: return
        val txt: String
        synchronized(lock) {
            val raiz = JSONObject()
            val fa = JSONObject(); faixas.forEach { (k, v) -> fa.put(k, faixaJson(v)) }
            val st = JSONObject()
            streams.forEach { (k, v) ->
                st.put(k, JSONObject().put("url", v.url).put("ua", v.ua).put("cliente", v.cliente)
                    .put("expira", v.expira).put("titulo", v.titulo).put("artista", v.artista).put("duracao", v.duracao))
            }
            val bu = JSONObject()
            buscas.forEach { (k, v) ->
                val arr = JSONArray(); v.second.forEach { arr.put(faixaJson(it)) }
                bu.put(k, JSONObject().put("ts", v.first).put("itens", arr))
            }
            val us = JSONObject()
            usuarios.forEach { (u, m) ->
                val o = JSONObject()
                m.forEach { (id, x) -> o.put(id, JSONObject().put("plays", x.plays).put("ultimo", x.ultimo)) }
                us.put(u, o)
            }
            val pl = JSONArray()
            playlists.values.forEach { p ->
                val ids = JSONArray(); p.faixas.forEach { ids.put(it) }
                pl.put(JSONObject().put("id", p.id).put("nome", p.nome).put("criada", p.criada).put("faixas", ids))
            }
            raiz.put("playlists", pl)
            val di = JSONObject()
            dicas.forEach { (k, v) -> di.put(k, JSONObject().put("p", v.first).put("a", v.second)) }
            raiz.put("dicas", di)
            raiz.put("versao", 1).put("faixas", fa).put("streams", st).put("buscas", bu).put("usuarios", us)
            txt = raiz.toString()
        }
        gravador.execute {
            try {
                val tmp = File(alvo.parentFile, "musica.json.tmp")
                tmp.writeText(txt, Charsets.UTF_8)
                if (!tmp.renameTo(alvo)) { alvo.writeText(txt, Charsets.UTF_8); tmp.delete() }
            } catch (e: Exception) { }
        }
    }

    fun mudou() { Estado.ui { versao = versao + 1 } }

    // ── buscas ──

    private fun chave(q: String) = q.trim().lowercase().replace(Regex("\\s+"), " ")

    fun buscaCache(q: String): List<Som>? = synchronized(lock) { buscas[chave(q)]?.second }

    fun guardarBusca(q: String, lista: List<Som>) {
        synchronized(lock) {
            val k = chave(q)
            buscas.remove(k)
            buscas[k] = Pair(System.currentTimeMillis(), lista)
            while (buscas.size > MAX_BUSCAS) buscas.remove(buscas.keys.first())
        }
        salvar(); mudou()
    }

    // ── músicas clicadas ──

    fun guardarFaixa(f: Som) {
        synchronized(lock) {
            faixas.remove(f.id)
            faixas[f.id] = f
            while (faixas.size > MAX_FAIXAS) {
                val emUso = playlists.values.flatMap { it.faixas }.toSet()
                val velho = faixas.keys.firstOrNull { it !in emUso } ?: break
                faixas.remove(velho); streams.remove(velho)
            }
        }
        salvar()
    }

    fun faixa(id: String): Som? = synchronized(lock) { faixas[id] }

    /** Todas as músicas que o app conhece (tocadas, favoritas e de playlists). */
    fun todasFaixas(): List<Som> = synchronized(lock) { faixas.values.toList() }

    // ── playlists (igual ao Spotify) ──

    private fun garantirFavoritas() {
        if (playlists.containsKey(ID_FAV)) return
        val resto = LinkedHashMap(playlists)
        playlists.clear()
        playlists[ID_FAV] = Playlist(ID_FAV, "Músicas Favoritas", emptyList(), System.currentTimeMillis())
        playlists.putAll(resto)
    }

    fun listaPlaylists(): List<Playlist> = synchronized(lock) { playlists.values.toList() }

    fun playlist(id: String): Playlist? = synchronized(lock) { playlists[id] }

    /** Músicas da playlist. Nas Favoritas a mais nova aparece primeiro (como o "Curtidas" do Spotify). */
    fun faixasDaPlaylist(id: String): List<Som> = synchronized(lock) {
        val ids = playlists[id]?.faixas ?: return emptyList()
        val lista = ids.mapNotNull { faixas[it] }
        if (id == ID_FAV) lista.reversed() else lista
    }

    fun criarPlaylist(nome: String): String {
        val n = nome.trim().ifBlank { "Minha playlist" }.take(60)
        val id = "pl_" + System.currentTimeMillis().toString(36) + (100..999).random()
        synchronized(lock) { playlists[id] = Playlist(id, n, emptyList(), System.currentTimeMillis()) }
        salvar(); mudou()
        return id
    }

    fun renomearPlaylist(id: String, nome: String) {
        if (id == ID_FAV) return
        synchronized(lock) {
            val p = playlists[id] ?: return
            playlists[id] = p.copy(nome = nome.trim().ifBlank { p.nome }.take(60))
        }
        salvar(); mudou()
    }

    fun excluirPlaylist(id: String) {
        if (id == ID_FAV) return
        synchronized(lock) { playlists.remove(id) }
        salvar(); mudou()
    }

    fun naPlaylist(plId: String, faixaId: String): Boolean = synchronized(lock) { playlists[plId]?.faixas?.contains(faixaId) == true }

    fun guardarDica(id: String, prog: String, aut: String) {
        synchronized(lock) {
            dicas[id] = Pair(prog, aut)
            if (dicas.size > 3000) dicas.remove(dicas.keys.first())
        }
        salvar()
    }

    fun dica(id: String): Pair<String, String>? = synchronized(lock) { dicas[id] }

    fun emAlgumaPlaylist(id: String): Boolean = synchronized(lock) { playlists.values.any { it.faixas.contains(id) } }

    fun ehFavorita(faixaId: String): Boolean = naPlaylist(ID_FAV, faixaId)

    /** Adiciona se não está / tira se já está. Devolve true se a música ficou DENTRO da playlist. */
    fun alternarNaPlaylist(plId: String, f: Som): Boolean {
        var dentro = false
        synchronized(lock) {
            val p = playlists[plId] ?: return false
            if (!faixas.containsKey(f.id)) faixas[f.id] = f
            if (p.faixas.contains(f.id)) {
                playlists[plId] = p.copy(faixas = p.faixas.filter { it != f.id })
            } else {
                playlists[plId] = p.copy(faixas = p.faixas + f.id)
                dentro = true
            }
        }
        salvar(); mudou()
        if (dentro) Baixados.agendar(f) // entrou numa playlist → baixa para ouvir sem internet
        return dentro
    }

    fun alternarFavorita(f: Som): Boolean = alternarNaPlaylist(ID_FAV, f)

    fun removerDaPlaylist(plId: String, faixaId: String) {
        synchronized(lock) {
            val p = playlists[plId] ?: return
            playlists[plId] = p.copy(faixas = p.faixas.filter { it != faixaId })
        }
        salvar(); mudou()
    }

    // ── endereço do áudio ──

    /** Só devolve se ainda vale por mais de 1 minuto. */
    fun stream(id: String): Fluxo? = synchronized(lock) {
        val s = streams[id]
        if (s != null && s.url.isNotBlank() && s.expira - System.currentTimeMillis() > 60_000L) s else null
    }

    fun guardarStream(id: String, fl: Fluxo) {
        synchronized(lock) { streams[id] = fl }
        salvar()
    }

    // ── histórico do usuário ──

    fun registrarPlay(f: Som) {
        synchronized(lock) {
            val m = usuarios.getOrPut(usuario()) { HashMap() }
            val antes = m[f.id]
            m[f.id] = Uso((antes?.plays ?: 0) + 1, System.currentTimeMillis())
        }
        salvar(); mudou()
    }

    fun recentes(n: Int): List<ItemUso> = synchronized(lock) {
        val m = usuarios[usuario()] ?: return emptyList()
        m.entries.sortedByDescending { it.value.ultimo }
            .mapNotNull { e -> faixas[e.key]?.let { ItemUso(it, e.value) } }
            .take(n)
    }

    fun maisOuvidas(n: Int): List<ItemUso> = synchronized(lock) {
        val m = usuarios[usuario()] ?: return emptyList()
        m.entries.filter { it.value.plays > 0 }
            .sortedWith(compareByDescending<Map.Entry<String, Uso>> { it.value.plays }.thenByDescending { it.value.ultimo })
            .mapNotNull { e -> faixas[e.key]?.let { ItemUso(it, e.value) } }
            .take(n)
    }

    fun limparHistorico() {
        synchronized(lock) { usuarios.remove(usuario()) }
        salvar(); mudou()
    }

    fun totalFaixas(): Int = synchronized(lock) { faixas.size }
    fun totalBuscas(): Int = synchronized(lock) { buscas.size }
}

// ───────────────────────── músicas baixadas (tocam SEM internet) ─────────────────────────

/**
 * Guarda o áudio no celular (files/audio). Música que está em alguma playlist é baixada sozinha;
 * na tela da playlist o botão ⬇ baixa todas. Tocar uma música baixada não usa internet nem servidor.
 */
object Baixados {
    private var dir: File? = null
    private val andando = java.util.Collections.synchronizedSet(HashSet<String>())
    private val fila = Executors.newFixedThreadPool(3)

    private var app: Context? = null
    private val pend = java.util.Collections.synchronizedSet(HashSet<String>())
    private val falhas = java.util.concurrent.ConcurrentHashMap<String, Long>()
    private const val MIN_LIVRE = 1_000_000_000L // para de baixar se sobrar menos de ~1 GB no celular

    fun init(c: Context) {
        app = c.applicationContext
        dir = File(c.filesDir, "audio").apply { mkdirs() }
        // assim que o app abre (e a cada 5 min): baixa TUDO que o app conhece, quando estiver no Wi-Fi
        val t = Thread {
            try { Thread.sleep(8_000L) } catch (e: Exception) { }
            while (true) {
                try { automatico() } catch (e: Exception) { }
                try { Thread.sleep(5 * 60_000L) } catch (e: Exception) { }
            }
        }
        t.isDaemon = true
        t.start()
    }

    /** Wi-Fi (rede sem cobrança por dado). Evita gastar o plano de dados do celular. */
    private fun redeLivre(): Boolean {
        val cm = app?.getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager ?: return false
        val n = cm.activeNetwork ?: return false
        val cap = cm.getNetworkCapabilities(n) ?: return false
        return cap.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            cap.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
    }

    private fun automatico() {
        if (Prefs.key.isBlank() || !redeLivre()) return
        val d = dir ?: return
        if (d.usableSpace < MIN_LIVRE) return
        MusicaStore.todasFaixas().forEach { agendar(it) }
    }

    fun faltam(): Int = MusicaStore.todasFaixas().count { !tem(it.id) }

    fun arquivo(id: String): File? {
        val d = dir ?: return null
        val f = File(d, "$id.audio")
        return if (f.exists() && f.length() > 20_000L) f else null
    }

    fun tem(id: String): Boolean = arquivo(id) != null

    fun baixando(id: String): Boolean = andando.contains(id)

    fun emAndamento(): Int = andando.size

    fun total(): Int = dir?.listFiles()?.count { it.name.endsWith(".audio") } ?: 0

    fun apagar(id: String) {
        try { File(dir ?: return, "$id.audio").delete() } catch (e: Exception) { }
        MusicaStore.mudou()
    }

    fun agendar(f: Som) {
        if (tem(f.id) || andando.contains(f.id)) return
        val ultima = falhas[f.id]
        if (ultima != null && System.currentTimeMillis() - ultima < 3600_000L) return // falhou há pouco: espera 1 h
        if (!pend.add(f.id)) return
        fila.execute {
            try { garantir(f) } finally { pend.remove(f.id) }
        }
    }

    fun baixarLista(lista: List<Som>) { lista.forEach { agendar(it) } }

    private fun garantir(f: Som) {
        if (tem(f.id) || !andando.add(f.id)) return
        MusicaStore.mudou()
        try {
            val fl = MusicaStore.stream(f.id) ?: YT.resolver(f.id, emptySet()).also { MusicaStore.guardarStream(f.id, it) }
            baixar(f.id, fl)
        } catch (e: Exception) {
            falhas[f.id] = System.currentTimeMillis() // sem internet / servidor fora: tenta de novo depois
        } finally {
            andando.remove(f.id)
            MusicaStore.mudou()
        }
    }

    private fun baixar(id: String, fl: Fluxo) {
        val d = dir ?: return
        val tmp = File(d, "$id.tmp")
        val c = URL(fl.url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = 30_000
            c.setRequestProperty("User-Agent", fl.ua)
            if (c.responseCode !in 200..299) throw IOException("HTTP " + c.responseCode)
            c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o, 64 * 1024) } }
        } finally {
            c.disconnect()
        }
        if (tmp.length() < 20_000L || !tmp.renameTo(File(d, "$id.audio"))) {
            tmp.delete()
            throw IOException("download incompleto")
        }
        try { Capas.carregar(id) } catch (e: Exception) { }
    }
}

// ───────────────────────── capas (miniaturas) ─────────────────────────

/** Baixa a capa uma vez e guarda no celular (files/capas) — da próxima vez abre na hora, até sem internet. */
object Capas {
    private var dir: File? = null
    private val mem = object : android.util.LruCache<String, ImageBitmap>(80) {}

    fun init(c: Context) { dir = File(c.filesDir, "capas").apply { mkdirs() } }

    fun memoria(id: String): ImageBitmap? = mem.get(id)

    fun carregar(id: String): ImageBitmap? {
        val cacheado = mem.get(id)
        if (cacheado != null) return cacheado
        val d = dir ?: return null
        val f = File(d, "$id.jpg")
        if (!f.exists() || f.length() < 100L) {
            try {
                val c = URL(Net.base() + "/musica/capa?id=" + id + "&" + YT.auth()).openConnection() as HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 10000
                if (c.responseCode == 200) {
                    val tmp = File(d, "$id.tmp")
                    c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                    tmp.renameTo(f)
                }
                c.disconnect()
            } catch (e: Exception) { }
        }
        val bmp = try { BitmapFactory.decodeFile(f.absolutePath) } catch (e: Exception) { null }
        if (bmp == null) return null
        val img = bmp.asImageBitmap()
        mem.put(id, img)
        return img
    }
}

// ───────────────────────── busca (estado da tela) ─────────────────────────

object MusicaBusca {
    var texto by mutableStateOf("")
    var resultados by mutableStateOf<List<Som>?>(null)
    var doCache by mutableStateOf(false)
    var buscando by mutableStateOf(false)
    var erro by mutableStateOf("")

    fun limpar() { texto = ""; resultados = null; erro = ""; doCache = false }

    /** [forcar] = ignora o que está salvo e pesquisa de novo no YouTube. */
    fun pesquisar(forcar: Boolean = false) {
        val q = texto.trim()
        if (q.isEmpty() || buscando) return
        erro = ""
        if (!forcar) {
            val salvo = MusicaStore.buscaCache(q)
            if (salvo != null) { resultados = salvo; doCache = true; return }
        }
        buscando = true
        Thread {
            try {
                val lista = YT.buscar(q)
                MusicaStore.guardarBusca(q, lista)
                Estado.ui { resultados = lista; doCache = false; buscando = false }
            } catch (e: Exception) {
                val msg = if (YT.semRede(e)) "Sem internet. Você ainda pode tocar as músicas baixadas (aba Playlists)."
                    else (e.message ?: YT.detalhe(e))
                Estado.ui { buscando = false; erro = msg }
            }
        }.start()
    }
}
