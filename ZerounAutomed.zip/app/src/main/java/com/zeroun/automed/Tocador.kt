package com.zeroun.automed

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.io.IOException

/**
 * Toca a música no próprio celular.
 * Fluxo: acha o áudio (cache JSON ou YT.resolver) → MediaPlayer → ao começar, conta +1 no histórico do usuário.
 * Se o endereço salvo já venceu / mudou de rede, pede um novo sozinho e tenta de novo.
 */
object Tocador {
    private var app: Context? = null
    private val main = Handler(Looper.getMainLooper())
    private var mp: MediaPlayer? = null
    private var geracao = 0
    private var focoTemporario = false
    private var foco: AudioFocusRequest? = null

    var fila by mutableStateOf<List<Som>>(emptyList())
        private set
    var indice by mutableIntStateOf(0)
        private set
    var atual by mutableStateOf<Som?>(null)
        private set
    var tocando by mutableStateOf(false)
        private set
    var carregando by mutableStateOf(false)
        private set
    var erro by mutableStateOf("")
        private set
    var duracaoMs by mutableLongStateOf(0L)
        private set
    /** Aleatório (como no Spotify): embaralha o que falta tocar; desligar volta à ordem original. */
    var aleatorio by mutableStateOf(false)
        private set
    /** Repetir: 0 = desligado • 1 = repete a fila toda • 2 = repete a música atual. */
    var repetir by mutableIntStateOf(0)
        private set
    private var filaOriginal: List<Som> = emptyList()
    /** Medidor: quanto tempo levou cada etapa da última música (para achar o que está lento). */
    var diag by mutableStateOf("")
        private set
    private var tInicio = 0L
    private var tPrep = 0L
    private var diagBase = ""
    @Volatile private var etapa = "começando"
    private var previaAtiva = false
    private var previaTerminou = false

    fun init(c: Context) { app = c.applicationContext }

    // ── foco de áudio (pausa quando entra ligação ou outro app de música) ──

    private val ouvinteFoco = AudioManager.OnAudioFocusChangeListener { mudanca ->
        when (mudanca) {
            AudioManager.AUDIOFOCUS_LOSS -> { focoTemporario = false; pausarPorFoco() }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> { focoTemporario = true; pausarPorFoco() }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> { mp?.setVolume(0.25f, 0.25f) }
            AudioManager.AUDIOFOCUS_GAIN -> {
                mp?.setVolume(1f, 1f)
                if (focoTemporario) {
                    focoTemporario = false
                    try { mp?.start(); tocando = mp != null } catch (e: Exception) { }
                    MusicaService.atualizar()
                }
            }
        }
    }

    private fun pausarPorFoco() {
        try { if (mp?.isPlaying == true) mp?.pause() } catch (e: Exception) { }
        tocando = false
        MusicaService.atualizar()
    }

    private fun pedirFoco(): Boolean {
        val am = app?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return true
        val req = foco ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(atributos())
            .setOnAudioFocusChangeListener(ouvinteFoco, main)
            .build().also { foco = it }
        return am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun soltarFoco() {
        val am = app?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        foco?.let { am.abandonAudioFocusRequest(it) }
    }

    private fun atributos() = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    // ── comandos ──

    /** Toca [lista] a partir da posição [i]; ao acabar uma música segue para a próxima da lista. */
    fun tocarLista(c: Context, lista: List<Som>, i: Int) {
        app = c.applicationContext
        if (lista.isEmpty() || i !in lista.indices) return
        filaOriginal = lista
        if (aleatorio) {
            fila = listOf(lista[i]) + lista.filterIndexed { k, _ -> k != i }.shuffled()
            indice = 0
        } else {
            fila = lista
            indice = i
        }
        MusicaService.garantir(c.applicationContext)
        carregar(lista[i], false, emptySet())
    }

    fun alternarAleatorio() {
        val musica = atual
        if (!aleatorio) {
            aleatorio = true
            if (fila.isNotEmpty() && musica != null) {
                filaOriginal = fila
                fila = listOf(musica) + fila.filter { it.id != musica.id }.shuffled()
                indice = 0
            }
        } else {
            aleatorio = false
            if (filaOriginal.isNotEmpty() && musica != null) {
                fila = filaOriginal
                indice = fila.indexOfFirst { it.id == musica.id }.coerceAtLeast(0)
            }
        }
        MusicaService.atualizar()
    }

    fun alternarRepetir() { repetir = (repetir + 1) % 3 }

    fun alternar() {
        val m = mp
        if (m == null) {
            val f = atual
            if (f != null && !carregando) carregar(f, false, emptySet())
            return
        }
        try {
            if (m.isPlaying) {
                m.pause(); tocando = false; focoTemporario = false
            } else if (!carregando && pedirFoco()) {
                m.start(); tocando = true
            }
        } catch (e: Exception) { }
        MusicaService.atualizar()
    }

    fun proxima(auto: Boolean = false) {
        if (auto && repetir == 2) { // repetir a música: volta ao começo sem buscar o áudio de novo
            val m = mp
            if (m != null) {
                try { m.seekTo(0); m.start(); tocando = true; MusicaService.atualizar(); return } catch (e: Exception) { }
            }
            atual?.let { carregar(it, false, emptySet()) }
            return
        }
        val n = indice + 1
        if (n < fila.size) {
            indice = n
            carregar(fila[n], false, emptySet())
        } else if (repetir == 1 && fila.isNotEmpty()) { // repetir a fila: recomeça do início
            indice = 0
            carregar(fila[0], false, emptySet())
        } else if (auto) {
            liberar()
            tocando = false
            MusicaService.atualizar()
        }
    }

    fun anterior() {
        if (posicaoMs() > 3000L || indice <= 0) { ir(0L); return }
        indice -= 1
        carregar(fila[indice], false, emptySet())
    }

    fun ir(ms: Long) {
        try { mp?.seekTo(ms.toInt()) } catch (e: Exception) { }
    }

    fun posicaoMs(): Long = try { (mp?.currentPosition ?: 0).toLong() } catch (e: Exception) { 0L }

    /** Para tudo e some com o player e a notificação. */
    fun encerrar() {
        geracao++
        liberar()
        atual = null; tocando = false; carregando = false; erro = ""
        fila = emptyList(); indice = 0
        MusicaService.parar()
    }

    // ── interno ──

    private fun liberar() {
        val m = mp
        mp = null
        previaAtiva = false
        if (m != null) {
            try { m.setOnCompletionListener(null); m.setOnErrorListener(null); m.setOnPreparedListener(null) } catch (e: Exception) { }
            try { m.release() } catch (e: Exception) { }
        }
        soltarFoco()
    }

    /** [forcarNovo] = ignora o endereço salvo • [evitar] = clientes do YouTube que já falharam. */
    private fun carregar(f: Som, forcarNovo: Boolean, evitar: Set<String>) {
        val g = ++geracao
        tInicio = System.currentTimeMillis()
        diag = ""
        liberar()
        atual = f; carregando = true; tocando = false; erro = ""
        duracaoMs = f.duracao * 1000L
        focoTemporario = false
        previaTerminou = false
        etapa = "procurando o link"
        // relógio na tela (mostra a etapa e os segundos) + limite de 30 s: nunca mais fica "Carregando…" para sempre
        val relogio = object : Runnable {
            override fun run() {
                if (g != geracao || !carregando) return
                val seg = (System.currentTimeMillis() - tInicio) / 1000
                if (seg >= 30) {
                    geracao++
                    liberar()
                    carregando = false; tocando = false
                    erro = "Demorou demais (" + etapa + "). Toque em ▶ para tentar de novo."
                    MusicaService.atualizar()
                    return
                }
                diag = etapa + " · " + seg + "s"
                main.postDelayed(this, 1000L)
            }
        }
        main.postDelayed(relogio, 1000L)
        MusicaStore.guardarFaixa(f) // clicou → fica salva no JSON, não precisa pesquisar de novo
        MusicaService.atualizar()
        Thread {
            try {
                var local = if (forcarNovo) null else (Baixados.arquivo(f.id) ?: Pre.arquivo(f.id))
                // pré-carga quase pronta: espera até 3 s por ela (abre na hora, sem streaming)
                if (local == null && !forcarNovo && Pre.emAndamento(f.id)) {
                    var k = 0
                    while (k < 30 && local == null && Pre.emAndamento(f.id)) { Thread.sleep(100); local = Pre.arquivo(f.id); k++ }
                    if (local == null) local = Pre.arquivo(f.id)
                }
                if (local == null && f.id.startsWith("dz_") && !forcarNovo && evitar.isEmpty()) {
                    // toca a prévia do Deezer (30 s) agora; a música completa troca por cima quando for achada
                    val pv = YT.previa(f.id)
                    if (pv.isNotBlank()) {
                        val fp = Fluxo(pv, "ZerounAutomed", "prev", Long.MAX_VALUE, f.titulo, f.artista, 30)
                        Estado.ui { if (g == geracao && mp == null) iniciar(f, fp, false, evitar, g, null, true) }
                    }
                }
                if (local != null) {
                    // música baixada: toca do próprio celular, sem internet
                    val fl = Fluxo(local.absolutePath, "", "local", Long.MAX_VALUE, f.titulo, f.artista, f.duracao)
                    Estado.ui { if (g == geracao) iniciar(f, fl, false, evitar, g, null, false) }
                } else {
                    val salvo = if (forcarNovo || evitar.isNotEmpty()) null else MusicaStore.stream(f.id)
                    var fl: Fluxo? = salvo
                    if (fl == null) {
                        try {
                            fl = resolverComRecuperacao(f, evitar).also { MusicaStore.guardarStream(f.id, it) }
                        } catch (e: Exception) {
                            if (YT.semRede(e)) throw e
                            // plano B: toca a mesma música pelo YouTube
                            etapa = "plano B (YouTube)"
                            val alt = YT.equivalenteYt(f) ?: throw e
                            fl = alt.second
                        }
                    }
                    val flf: Fluxo = fl!!
                    Estado.ui { if (g == geracao) iniciar(f, flf, salvo != null, evitar, g, if (previaAtiva) mp else null, false) }
                }
            } catch (e: Exception) {
                val msg = if (YT.semRede(e)) "Sem internet. Essa música ainda não foi baixada."
                    else (e.message ?: YT.detalhe(e))
                Estado.ui {
                    if (g == geracao) { carregando = false; erro = msg; MusicaService.atualizar() }
                }
            }
        }.start()
    }

    /** Se o bot esqueceu a música (reiniciou), pesquisa de novo em silêncio e tenta outra vez. */
    private fun resolverComRecuperacao(f: Som, evitar: Set<String>): Fluxo {
        try {
            return YT.resolver(f.id, evitar)
        } catch (e: Exception) {
            if ((e.message ?: "").contains("Busque a música")) {
                try { YT.buscar(f.titulo + " " + f.artista) } catch (x: Exception) { }
                return YT.resolver(f.id, evitar)
            }
            throw e
        }
    }

    /** Deixa o endereço da PRÓXIMA música da fila pronto: quando esta acabar, a seguinte começa na hora. */
    private fun preAquecerProxima() {
        // baixa as 2 próximas e a anterior: avançar / voltar abre um arquivo local, na hora
        val alvo = ArrayList<Som>()
        for (n in indice + 1..indice + 2) if (n in fila.indices) alvo.add(fila[n])
        if (indice - 1 in fila.indices) alvo.add(fila[indice - 1])
        Pre.pedir(alvo)
    }

    private fun falhou(f: Som, fl: Fluxo, doCache: Boolean, evitar: Set<String>) {
        if (fl.cliente == "local") { Baixados.apagar(f.id); Pre.apagar(f.id); carregar(f, true, emptySet()); return } // arquivo estragado: baixa de novo
        if (doCache) { carregar(f, true, emptySet()); return }
        val ev = evitar + fl.cliente
        if (fl.cliente != "srv" && fl.cliente !in evitar && ev.size < YT.tentativas(f.id)) { carregar(f, false, ev); return }
        liberar()
        carregando = false; tocando = false
        erro = "Não consegui tocar essa música. Tente outra."
        MusicaService.atualizar()
        val g = geracao
        Thread {
            val m = YT.motivo(f.id)
            if (m.isNotBlank()) Estado.ui { if (g == geracao && !tocando) { erro = "Não toca: " + m; MusicaService.atualizar() } }
        }.start()
    }

    private fun iniciar(f: Som, fl: Fluxo, doCache: Boolean, evitar: Set<String>, g: Int, trocarDe: MediaPlayer?, previa: Boolean) {
        val c = app ?: return
        val agora = System.currentTimeMillis()
        if (!previa) {
            etapa = "abrindo o áudio"
            diagBase = "buscar áudio " + String.format("%.1f", (agora - tInicio) / 1000.0) + "s (" + (if (doCache) "cache" else fl.cliente) + ")"
            diag = diagBase
            tPrep = agora
        }
        try {
            val m = MediaPlayer()
            if (trocarDe == null) mp = m
            if (previa) previaAtiva = true
            val pronto = java.util.concurrent.atomic.AtomicBoolean(false)
            m.setAudioAttributes(atributos())
            m.setWakeMode(c, PowerManager.PARTIAL_WAKE_LOCK)
            if (fl.cliente == "local") m.setDataSource(fl.url)
            else m.setDataSource(c, Uri.parse(fl.url), mapOf("User-Agent" to fl.ua))
            // vigia: se o áudio não abrir a tempo (link travado), desiste e tenta o próximo caminho em vez de ficar em "Carregando…"
            val vigia = Runnable { if (g == geracao && !pronto.get() && !previa) falhou(f, fl, doCache, evitar) }
            if (!previa) main.postDelayed(vigia, if (fl.cliente == "srv") 25_000L else 7_000L)
            m.setOnPreparedListener { p ->
                pronto.set(true)
                main.removeCallbacks(vigia)
                if (g == geracao) {
                    if (pedirFoco()) {
                        val d = p.duration
                        if (d > 0 && !previa) duracaoMs = d.toLong()
                        var deveTocar = true
                        if (trocarDe != null) {
                            // troca a prévia pela música completa, no mesmo ponto
                            val tocavaPrevia = try { trocarDe.isPlaying } catch (e: Exception) { false }
                            val pos = try { trocarDe.currentPosition } catch (e: Exception) { 0 }
                            deveTocar = tocavaPrevia || previaTerminou
                            mp = m
                            previaAtiva = false
                            try { trocarDe.setOnCompletionListener(null); trocarDe.setOnErrorListener(null); trocarDe.setOnPreparedListener(null) } catch (e: Exception) { }
                            try { trocarDe.release() } catch (e: Exception) { }
                            if (pos > 0) { try { p.seekTo(pos) } catch (e: Exception) { } }
                        }
                        if (deveTocar) { p.start(); tocando = true } else tocando = false
                        carregando = false
                        if (!previa) {
                            diag = diagBase + " · abrir " + String.format("%.1f", (System.currentTimeMillis() - tPrep) / 1000.0) + "s"
                            MusicaStore.registrarPlay(f) // conta como "ouvida" só quando a música completa começou
                            if (fl.cliente != "local" && MusicaStore.emAlgumaPlaylist(f.id)) Baixados.agendar(f)
                            preAquecerProxima()
                        }
                    } else {
                        tocando = false; carregando = false
                        erro = "Outro app está usando o áudio (ligação?). Toque em ▶ para tentar de novo."
                    }
                    MusicaService.atualizar()
                }
            }
            m.setOnCompletionListener {
                if (g == geracao) {
                    if (previa) { previaTerminou = true; tocando = false; carregando = true; MusicaService.atualizar() }
                    else proxima(true)
                }
            }
            m.setOnErrorListener { _, _, _ ->
                main.removeCallbacks(vigia)
                if (g == geracao) {
                    if (previa) {
                        if (mp === m) { liberar(); carregando = true; tocando = false; MusicaService.atualizar() }
                    } else falhou(f, fl, doCache, evitar)
                }
                true
            }
            m.prepareAsync()
        } catch (e: Exception) {
            if (g == geracao && !previa) falhou(f, fl, doCache, evitar)
        }
    }
}

/** Serviço em primeiro plano: mantém a música tocando com a tela apagada e mostra o botão na notificação. */
class MusicaService : Service() {

    companion object {
        private const val CANAL = "musica"
        private const val ID_NOTIF = 4107
        private const val ACAO_TOCAR = "com.zeroun.automed.MUSICA_TOCAR"
        private const val ACAO_PROXIMA = "com.zeroun.automed.MUSICA_PROXIMA"
        private const val ACAO_FECHAR = "com.zeroun.automed.MUSICA_FECHAR"

        private var instancia: MusicaService? = null

        fun garantir(c: Context) {
            if (instancia != null) return
            try { ContextCompat.startForegroundService(c, Intent(c, MusicaService::class.java)) } catch (e: Exception) { }
        }

        fun atualizar() { instancia?.renderizar() }
        fun parar() { instancia?.encerrar() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instancia = this
        val canal = NotificationChannel(CANAL, "Música", NotificationManager.IMPORTANCE_LOW)
        canal.description = "Controles da música que está tocando"
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(canal)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACAO_TOCAR -> Tocador.alternar()
            ACAO_PROXIMA -> Tocador.proxima()
            ACAO_FECHAR -> { Tocador.encerrar(); return START_NOT_STICKY }
        }
        renderizar()
        return START_NOT_STICKY
    }

    private fun acao(a: String, codigo: Int): PendingIntent = PendingIntent.getService(
        this, codigo, Intent(this, MusicaService::class.java).setAction(a),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun montar(): Notification {
        val f = Tocador.atual
        val abrir = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val linha2 = when {
            Tocador.carregando -> "Procurando o áudio…"
            Tocador.erro.isNotBlank() -> Tocador.erro
            else -> f?.artista ?: ""
        }
        return NotificationCompat.Builder(this, CANAL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(f?.titulo ?: "Música")
            .setContentText(linha2)
            .setContentIntent(abrir)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(
                if (Tocador.tocando) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                if (Tocador.tocando) "Pausar" else "Tocar", acao(ACAO_TOCAR, 1)
            )
            .addAction(android.R.drawable.ic_media_next, "Próxima", acao(ACAO_PROXIMA, 2))
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Fechar", acao(ACAO_FECHAR, 3))
            .build()
    }

    fun renderizar() {
        try {
            ServiceCompat.startForeground(
                this, ID_NOTIF, montar(),
                if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
            )
        } catch (e: Exception) { }
    }

    fun encerrar() {
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Exception) { }
        stopSelf()
    }

    override fun onDestroy() {
        if (instancia === this) instancia = null
        super.onDestroy()
    }
}
