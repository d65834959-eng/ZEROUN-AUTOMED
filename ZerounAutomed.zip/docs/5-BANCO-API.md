# 🏦 Aba Banco (conta AutoPay) — endpoints do servidor

A aba **Banco** do app mostra o saldo, o extrato (estilo Nubank) e faz Pix.
Ela conversa com o bot por 2 endpoints. **Enquanto eles não existirem no `index.js`**, o app não quebra:
mostra um aviso laranja, o saldo fica em `R$ —` e o extrato lista os Pix lidos pelo app.

Todas as chamadas são `POST` JSON com `key` + `deviceId` (igual aos outros endpoints).
Resposta: `{ ok:true, ... }` ou `{ ok:false, msg }`.

## 1) `/api/banco` — saldo + extrato
Resposta:
```json
{
  "ok": true,
  "saldo": 1234.56,
  "titular": "Nome do titular",
  "conta": "AutoPay 0001-2",
  "extrato": [
    { "id": "E123", "tipo": "entrada", "valor": 50.0, "nome": "Maria", "descricao": "sala", "chave": "", "ts": 1763330000000, "status": "concluido" },
    { "id": "S456", "tipo": "saida",   "valor": 20.0, "nome": "João",  "descricao": "",     "chave": "joao@email.com", "ts": 1763320000000, "status": "concluido" }
  ]
}
```
- `tipo`: `"entrada"` ou `"saida"`. `ts` em milissegundos. Só `ok` é obrigatório; o resto é opcional.
- `chave` das saídas alimenta os "Recentes" da tela de Pix.

## 2) `/api/pix_enviar` — faz o Pix
Recebe: `{ chave, valor, descricao }` (além de `key`/`deviceId`).
Resposta de sucesso: `{ "ok": true, "msg": "Pix enviado!", "id": "comprovante", "nome": "Quem recebeu", "saldo": 1214.56 }`
Erro: `{ "ok": false, "msg": "Saldo insuficiente" }` (o app mostra a mensagem do jeito que vier).

### Esqueleto no `index.js`
```js
// dentro do seu roteador de /api (mesmo lugar do /api/lucros):
if (rota === '/api/banco') {
  const conta = await autopay.consultar(usuario);          // <- ligue na API do AutoPay
  return res({ ok: true, saldo: conta.saldo, titular: conta.nome, conta: conta.numero, extrato: conta.movimentos });
}
if (rota === '/api/pix_enviar') {
  const { chave, valor, descricao } = body;
  if (!chave || !(valor > 0)) return res({ ok: false, msg: 'Chave ou valor inválido' });
  const r = await autopay.enviarPix(usuario, { chave, valor, descricao });   // <- ligue na API do AutoPay
  return res({ ok: true, msg: 'Pix enviado!', id: r.id, nome: r.nome, saldo: r.saldoNovo });
}
```
> ⚠️ O Pix envia dinheiro de verdade. Valide a `key`/`deviceId` como nos outros endpoints, confira o saldo no servidor
> (não confie só no app) e registre cada envio em log.


---

## 3) `/api/pix_gerar` — o bot gera um Pix para você RECEBER
Recebe: `{ valor }` (além de `key`/`deviceId`). Cria a mesma cobrança do `/gerarpix` do Discord.
Sucesso: `{ "ok": true, "id": "dp_...", "copiaCola": "000201...", "valor": 25.0, "credito": 24.25 }`
Erro: `{ "ok": false, "msg": "..." }`. O saldo é creditado sozinho quando o Pix for pago.

## 4) `/api/pix_status` — o Pix gerado já foi pago?
Recebe: `{ id }`. Resposta: `{ "ok": true, "status": "pendente" | "pago" | "expirado" | "cancelado", "valor": 25.0, "credito": 24.25 }`.
O app confere a cada 4 segundos enquanto a tela Receber estiver aberta.

## Pagar por Copia e Cola / QR
O app lê a chave Pix dentro do código (QR estático). Códigos dinâmicos (cobrança) não trazem a chave e são recusados no app.
