package com.zeroun.automed

import android.content.Context
import android.content.SharedPreferences
import java.util.UUID

/** Mesmo arquivo/chaves do app anterior ("zeroun"), então atualizar por cima mantém key, endereço e deviceId. */
object Prefs {
    private var sp: SharedPreferences? = null

    fun init(c: Context) {
        if (sp == null) sp = c.applicationContext.getSharedPreferences("zeroun", Context.MODE_PRIVATE)
    }

    private fun p(): SharedPreferences = sp ?: error("Prefs.init() não foi chamado")

    var url: String
        get() = p().getString("url", "") ?: ""
        set(v) { p().edit().putString("url", v).apply() }

    var key: String
        get() = p().getString("key", "") ?: ""
        set(v) { p().edit().putString("key", v).apply() }

    var gmail: Boolean
        get() = p().getBoolean("gmail", true)
        set(v) { p().edit().putBoolean("gmail", v).apply() }

    var apps: Set<String>
        get() = p().getStringSet("apps", emptySet()) ?: emptySet()
        set(v) { p().edit().putStringSet("apps", HashSet(v)).apply() }

    var conectado: Boolean
        get() = p().getBoolean("conectado", false)
        set(v) { p().edit().putBoolean("conectado", v).apply() }

    var pixJson: String
        get() = p().getString("pixJson", "[]") ?: "[]"
        set(v) { p().edit().putString("pixJson", v).apply() }

    val deviceId: String
        get() {
            val atual = p().getString("deviceId", null)
            if (!atual.isNullOrBlank()) return atual
            val novo = UUID.randomUUID().toString()
            p().edit().putString("deviceId", novo).apply()
            return novo
        }
}
