package com.zeroun.automed

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccountBalance
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Error
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.QrCode2
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ───────────────────────── paleta (visual Inter: escuro + laranja) ─────────────────────────

private object BI {
    val Fundo = Color(0xFF151515)
    val Cartao = Color(0xFF222224)
    val Campo = Color(0xFF282829)
    val Borda = Color(0xFF3A3A3D)
    val Laranja = Color(0xFFEA7500)
    val LaranjaTexto = Color(0xFFFF8A1A)
    val Marrom = Color(0xFF4B2610)
    val Texto = Color.White
    val Muted = Color(0xFFA0A0A6)
    val Verde = Color(0xFF34D17A)
    val Vermelho = Color(0xFFFF6B6B)
    val Amarelo = Color(0xFFFFC107)
}

// ───────────────────────── dados ─────────────────────────

/** Uma linha do extrato. [entrada] = dinheiro que entrou • false = saiu. */
data class Mov(
    val id: String, val entrada: Boolean, val valor: Double, val nome: String,
    val descricao: String, val chave: String, val ts: Long, val status: String
)

data class ResultadoPix(val ok: Boolean, val msg: String, val id: String, val valor: Double, val nome: String)

/** O que veio num Pix Copia e Cola / QR Code de pagamento. */
data class PixLido(val chave: String, val valor: Double?, val nome: String)

enum class TelaBanco { HOME, EXTRATO, PIX, PAGAR, VALOR, RECEBER }

/**
 * Banco do app (conta AutoPay). Fala com o bot por estes endpoints:
 *   /api/banco       -> saldo + extrato
 *   /api/pix_enviar  -> faz um Pix (pagar)
 *   /api/pix_gerar   -> o bot gera um Pix para você receber (QR + copia e cola)
 *   /api/pix_status  -> diz se o Pix gerado já foi pago
 */
object Banco {
    var tela by mutableStateOf(TelaBanco.HOME)
    var saldo by mutableStateOf<Double?>(null)
    var titular by mutableStateOf("")
    var conta by mutableStateOf("")
    val extrato = mutableStateListOf<Mov>()
    var carregando by mutableStateOf(false)
    var carregou by mutableStateOf(false)
    /** false = o servidor ainda não tem /api/banco (aí usamos só os Pix lidos). */
    var servidorOk by mutableStateOf(true)
    var erro by mutableStateOf("")
    var enviando by mutableStateOf(false)
    var resultado by mutableStateOf<ResultadoPix?>(null)
    var ocultar by mutableStateOf(false)

    // ----- pagar -----
    var pagChave by mutableStateOf("")
    var pagNome by mutableStateOf("")
    var pagValor by mutableStateOf("")
    var pagDesc by mutableStateOf("")

    // ----- receber -----
    var recValor by mutableStateOf("")
    var recGerando by mutableStateOf(false)
    var recErro by mutableStateOf("")
    var recCopia by mutableStateOf("")
    var recId by mutableStateOf("")
    var recStatus by mutableStateOf("")
    var recValorGerado by mutableStateOf(0.0)
    var recCredito by mutableStateOf(0.0)

    fun alternarOcultar() { ocultar = !ocultar; Prefs.ocultarSaldo = ocultar }

    fun voltar() {
        tela = when (tela) {
            TelaBanco.VALOR -> TelaBanco.PAGAR
            TelaBanco.PAGAR, TelaBanco.RECEBER -> TelaBanco.PIX
            else -> TelaBanco.HOME
        }
    }

    fun limparPagamento() { pagChave = ""; pagNome = ""; pagValor = ""; pagDesc = "" }

    fun limparRecebimento() {
        recValor = ""; recErro = ""; recCopia = ""; recId = ""; recStatus = ""; recValorGerado = 0.0; recCredito = 0.0
    }

    private fun lerMov(o: org.json.JSONObject): Mov {
        val tipo = o.optString("tipo", "entrada").lowercase()
        return Mov(
            id = o.optString("id", ""),
            entrada = !(tipo.startsWith("sa") || tipo == "debito" || tipo == "out"),
            valor = Math.abs(o.optDouble("valor", 0.0)),
            nome = o.optString("nome", ""),
            descricao = o.optString("descricao", ""),
            chave = o.optString("chave", ""),
            ts = o.optLong("ts", System.currentTimeMillis()),
            status = o.optString("status", "concluido")
        )
    }

    fun carregar() {
        if (carregando) return
        carregando = true
        Thread {
            val r = Net.post("/api/banco", Net.corpo())
            Estado.ui {
                carregando = false
                if (r == null) {
                    erro = "Sem resposta do bot. Confira a internet."
                } else if (!r.optBoolean("ok", false)) {
                    val m = r.optString("msg", "")
                    if (m.contains("desconhecido", true) || m.contains("not found", true)) { servidorOk = false; erro = "" }
                    else erro = m.ifBlank { "Erro ao consultar o banco." }
                } else {
                    servidorOk = true; erro = ""; carregou = true
                    saldo = if (r.has("saldo") && !r.isNull("saldo")) r.optDouble("saldo") else null
                    titular = r.optString("titular", titular)
                    conta = r.optString("conta", conta)
                    val arr = r.optJSONArray("extrato")
                    if (arr != null) {
                        val l = ArrayList<Mov>()
                        for (i in 0 until arr.length()) l.add(lerMov(arr.getJSONObject(i)))
                        extrato.clear(); extrato.addAll(l.sortedByDescending { it.ts })
                    }
                }
            }
        }.start()
    }

    fun enviarPix(chave: String, valor: Double, descricao: String, nome: String) {
        if (enviando) return
        enviando = true
        Thread {
            val r = Net.post(
                "/api/pix_enviar",
                Net.corpo().put("chave", chave).put("valor", valor).put("descricao", descricao)
            )
            Estado.ui {
                enviando = false
                if (r == null) {
                    resultado = ResultadoPix(false, "Sem resposta do bot. O Pix pode ou não ter sido enviado: confira o extrato antes de tentar de novo.", "", valor, nome)
                } else if (r.optBoolean("ok", false)) {
                    if (r.has("saldo") && !r.isNull("saldo")) saldo = r.optDouble("saldo")
                    resultado = ResultadoPix(true, r.optString("msg", "Pix enviado!"), r.optString("id", ""), valor, r.optString("nome", nome))
                    carregar()
                } else {
                    val m = r.optString("msg", "Não foi possível enviar o Pix.")
                    val amigavel = if (m.contains("desconhecido", true))
                        "O servidor do bot ainda não tem o envio de Pix ligado. Troque o index.js do bot e reinicie." else m
                    resultado = ResultadoPix(false, amigavel, "", valor, nome)
                }
            }
        }.start()
    }

    /** Pede ao bot para gerar um Pix de [valor] (QR + copia e cola). */
    fun gerarPix(valor: Double) {
        if (recGerando) return
        recGerando = true; recErro = ""
        Thread {
            val r = Net.post("/api/pix_gerar", Net.corpo().put("valor", valor))
            Estado.ui {
                recGerando = false
                if (r == null) {
                    recErro = "Sem resposta do bot. Confira a internet e tente de novo."
                } else if (!r.optBoolean("ok", false)) {
                    val m = r.optString("msg", "Não foi possível gerar o Pix.")
                    recErro = if (m.contains("desconhecido", true)) "O servidor do bot ainda não tem a geração de Pix. Troque o index.js do bot e reinicie." else m
                } else {
                    recCopia = r.optString("copiaCola", "")
                    recId = r.optString("id", "")
                    recValorGerado = r.optDouble("valor", valor)
                    recCredito = r.optDouble("credito", 0.0)
                    recStatus = "pendente"
                }
            }
        }.start()
    }

    /** Pergunta ao bot se o Pix gerado já foi pago. */
    fun conferirRecebimento() {
        val id = recId
        if (id.isBlank() || recStatus != "pendente") return
        Thread {
            val r = Net.post("/api/pix_status", Net.corpo().put("id", id))
            Estado.ui {
                if (r != null && r.optBoolean("ok", false) && id == recId) {
                    val st = r.optString("status", "pendente")
                    if (st != recStatus) {
                        recStatus = st
                        if (st == "pago") carregar()
                    }
                }
            }
        }.start()
    }

    /**
     * Lê o que a pessoa digitou/colou/escaneou: chave Pix OU Pix Copia e Cola.
     * Devolve o texto do erro, ou "" se deu certo (e já abre a tela do valor).
     */
    fun usarEntrada(bruto: String): String {
        val t = bruto.trim()
        if (t.isBlank()) return "Digite ou cole a chave Pix."
        val ini = t.indexOf("000201")
        if (ini >= 0) {
            val lido = lerBrCode(t.substring(ini).replace(Regex("\\s"), ""))
            if (lido == null || lido.chave.isBlank()) {
                return "Esse código é uma cobrança (QR dinâmico) e não traz a chave Pix. Peça a chave de quem vai receber."
            }
            pagChave = lido.chave
            pagNome = lido.nome
            pagValor = lido.valor?.let { String.format(Locale("pt", "BR"), "%.2f", it) } ?: ""
        } else {
            pagChave = t
            pagNome = ""
            pagValor = ""
        }
        pagDesc = ""
        tela = TelaBanco.VALOR
        return ""
    }

    /** Extrato que a tela mostra: o do banco; se o servidor ainda não tem, os Pix lidos pelo app. */
    fun movimentos(): List<Mov> =
        if (servidorOk) extrato.toList()
        else Estado.pix.map { Mov("", true, it.valor, it.nome.ifBlank { "Pix recebido" }, it.fonte, "", it.ts, "concluido") }
}

// ───────────────────────── Pix Copia e Cola (BR Code) e QR ─────────────────────────

private fun tlv(s: String): List<Pair<String, String>> {
    val out = ArrayList<Pair<String, String>>()
    var i = 0
    while (i + 4 <= s.length) {
        val id = s.substring(i, i + 2)
        val len = s.substring(i + 2, i + 4).toIntOrNull() ?: break
        if (i + 4 + len > s.length) break
        out.add(Pair(id, s.substring(i + 4, i + 4 + len)))
        i += 4 + len
    }
    return out
}

/** Tira a chave, o valor e o nome de um BR Code estático. Dinâmico (sem chave) volta com chave vazia. */
private fun lerBrCode(s: String): PixLido? {
    if (!s.startsWith("000201")) return null
    val campos = tlv(s)
    var chave = ""
    for (c in campos) {
        val n = c.first.toIntOrNull() ?: continue
        if (n in 26..51) {
            val sub = tlv(c.second)
            val gui = (sub.firstOrNull { it.first == "00" }?.second ?: "").lowercase()
            if (gui.contains("br.gov.bcb.pix")) {
                chave = sub.firstOrNull { it.first == "01" }?.second ?: ""
            }
        }
    }
    val valor = campos.firstOrNull { it.first == "54" }?.second?.toDoubleOrNull()
    val nome = campos.firstOrNull { it.first == "59" }?.second ?: ""
    return PixLido(chave, valor, nome)
}

private fun qrMatriz(texto: String): List<BooleanArray>? = try {
    val dicas = mapOf(EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M, EncodeHintType.MARGIN to 0)
    val m = QRCodeWriter().encode(texto, BarcodeFormat.QR_CODE, 0, 0, dicas)
    List(m.height) { y -> BooleanArray(m.width) { x -> m.get(x, y) } }
} catch (e: Exception) {
    null
}

@Composable
private fun QrCodeView(texto: String, tamanho: Dp) {
    val grade = remember(texto) { qrMatriz(texto) }
    Box(Modifier.size(tamanho).clip(RoundedCornerShape(14.dp)).background(Color.White).padding(14.dp)) {
        if (grade != null && grade.isNotEmpty()) {
            Canvas(Modifier.fillMaxSize()) {
                val n = grade.size
                val celula = size.minDimension / n
                for (y in 0 until n) {
                    for (x in 0 until n) {
                        if (grade[y][x]) drawRect(Color.Black, Offset(x * celula, y * celula), Size(celula + 0.6f, celula + 0.6f))
                    }
                }
            }
        }
    }
}

private fun escanearQr(ctx: Context, aoLer: (String) -> Unit, aoErro: (String) -> Unit) {
    try {
        val op = GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
        GmsBarcodeScanning.getClient(ctx, op).startScan()
            .addOnSuccessListener { b -> aoLer(b.rawValue ?: "") }
            .addOnFailureListener { e -> aoErro(e.message ?: "Não consegui abrir a câmera.") }
    } catch (e: Exception) {
        aoErro(e.message ?: "Não consegui abrir a câmera.")
    }
}

// ───────────────────────── formatação ─────────────────────────

private val PT = Locale("pt", "BR")
private fun horaMin(ts: Long): String = SimpleDateFormat("HH:mm", PT).format(Date(ts))
private fun dataCompleta(ts: Long): String = SimpleDateFormat("dd/MM/yyyy 'às' HH:mm", PT).format(Date(ts))
private fun chaveDia(ts: Long): String = SimpleDateFormat("yyyyMMdd", PT).format(Date(ts))

private fun rotuloDia(ts: Long): String {
    val hoje = Calendar.getInstance()
    val ontem = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
    return when (chaveDia(ts)) {
        chaveDia(hoje.timeInMillis) -> "Hoje"
        chaveDia(ontem.timeInMillis) -> "Ontem"
        else -> SimpleDateFormat("d 'de' MMMM", PT).format(Date(ts))
    }
}

private fun valorSinal(m: Mov): String = (if (m.entrada) "+ " else "− ") + brl(m.valor)

/** "TURBOFY TECNOLOGIAS LTDA." -> "Turbofy Tecnologias Ltda." */
private fun nomeBonito(n: String): String {
    val t = n.trim()
    if (t.isEmpty() || t != t.uppercase()) return t
    return t.lowercase().split(" ").joinToString(" ") { w ->
        if (w in listOf("de", "da", "do", "das", "dos", "e")) w else w.replaceFirstChar { it.uppercase() }
    }
}

// ───────────────────────── peças do visual ─────────────────────────

@Composable
private fun Cabecalho(titulo: String, aoVoltar: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).clip(CircleShape).clickable(onClick = aoVoltar), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.ArrowBack, "Voltar", tint = BI.LaranjaTexto)
        }
        Text(titulo, color = BI.Texto, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
        Spacer(Modifier.size(44.dp))
    }
}

@Composable
private fun BotaoBI(texto: String, preenchido: Boolean, enabled: Boolean = true, icone: ImageVector? = null, onClick: () -> Unit) {
    val forma = RoundedCornerShape(14.dp)
    var m = Modifier.fillMaxWidth().height(56.dp).clip(forma)
    m = if (preenchido) m.background(if (enabled) BI.Laranja else BI.Laranja.copy(alpha = 0.35f))
    else m.border(1.5.dp, if (enabled) BI.Laranja else BI.Laranja.copy(alpha = 0.35f), forma)
    val cor = if (preenchido) Color.White else if (enabled) BI.LaranjaTexto else BI.LaranjaTexto.copy(alpha = 0.4f)
    Row(m.clickable(enabled = enabled, onClick = onClick), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        if (icone != null) { Icon(icone, null, tint = cor, modifier = Modifier.size(22.dp)); Spacer(Modifier.width(8.dp)) }
        Text(texto, color = cor, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun CampoBI(
    valor: String, aoMudar: (String) -> Unit, dica: String, modifier: Modifier = Modifier,
    teclado: KeyboardType = KeyboardType.Text, tamanhoFonte: Int = 16, aoConfirmar: (() -> Unit)? = null
) {
    BasicTextField(
        value = valor, onValueChange = aoMudar, singleLine = true,
        textStyle = TextStyle(color = BI.Texto, fontSize = tamanhoFonte.sp),
        cursorBrush = SolidColor(BI.LaranjaTexto),
        keyboardOptions = KeyboardOptions(keyboardType = teclado, imeAction = if (aoConfirmar != null) ImeAction.Done else ImeAction.Default),
        keyboardActions = KeyboardActions(onDone = { aoConfirmar?.invoke() }),
        modifier = modifier.fillMaxWidth(),
        decorationBox = { campo ->
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(BI.Campo).padding(horizontal = 18.dp, vertical = 18.dp)
            ) {
                if (valor.isEmpty()) Text(dica, color = BI.Muted, fontSize = tamanhoFonte.sp, maxLines = 1)
                campo()
            }
        }
    )
}

@Composable
private fun IconeTopo(icone: ImageVector, descricao: String, onClick: () -> Unit) {
    Box(Modifier.size(44.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icone, descricao, tint = BI.Texto, modifier = Modifier.size(26.dp))
    }
}

@Composable
private fun LinhaOpcao(titulo: String, onClick: () -> Unit) {
    val forma = RoundedCornerShape(14.dp)
    Row(
        Modifier.fillMaxWidth().clip(forma).border(1.dp, BI.Borda, forma).clickable(onClick = onClick).padding(horizontal = 22.dp, vertical = 34.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(titulo, color = BI.Texto, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        Icon(Icons.Rounded.ChevronRight, null, tint = BI.LaranjaTexto, modifier = Modifier.size(30.dp))
    }
}

// ───────────────────────── tela principal da aba ─────────────────────────

@Composable
fun BancoAba() {
    LaunchedEffect(Unit) {
        Banco.ocultar = Prefs.ocultarSaldo
        while (true) {
            if (Prefs.conectado) Banco.carregar()
            delay(15_000)
        }
    }
    BackHandler(enabled = Banco.tela != TelaBanco.HOME) { Banco.voltar() }
    Box(Modifier.fillMaxSize().background(BI.Fundo)) {
        when (Banco.tela) {
            TelaBanco.HOME -> BancoHome()
            TelaBanco.EXTRATO -> BancoExtrato()
            TelaBanco.PIX -> BancoPix()
            TelaBanco.PAGAR -> BancoPagar()
            TelaBanco.VALOR -> BancoValor()
            TelaBanco.RECEBER -> BancoReceber()
        }
    }
    DialogoResultado()
}

// ───────────────────────── HOME: saldo + botão Pix + movimentações ─────────────────────────

@Composable
private fun BancoHome() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).clip(CircleShape).background(BI.Cartao), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Person, null, tint = BI.Texto)
            }
            Spacer(Modifier.weight(1f))
            IconeTopo(Icons.Rounded.Refresh, "Atualizar") { Banco.carregar(); Estado.atualizar() }
            IconeTopo(if (Banco.ocultar) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, "Mostrar ou ocultar saldo") { Banco.alternarOcultar() }
        }

        Spacer(Modifier.height(28.dp))
        Text("Saldo", color = BI.Muted, fontSize = 16.sp)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth().clickable { Banco.tela = TelaBanco.EXTRATO }, verticalAlignment = Alignment.CenterVertically) {
            val s = Banco.saldo
            Text(
                if (Banco.ocultar) "R$ ••••••" else if (s != null) brl(s) else "R$ —",
                color = BI.Texto, fontSize = 38.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1
            )
            Icon(Icons.Rounded.ChevronRight, "Ver extrato", tint = BI.Texto, modifier = Modifier.size(30.dp))
        }

        if (Banco.titular.isNotBlank() || Banco.conta.isNotBlank()) {
            Text(
                listOf(Banco.titular, Banco.conta).filter { it.isNotBlank() }.joinToString(" • "),
                color = BI.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(Modifier.height(20.dp))
        Row(
            Modifier.clip(RoundedCornerShape(50)).background(BI.Marrom).clickable { Banco.tela = TelaBanco.PIX }
                .padding(horizontal = 24.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.Bolt, null, tint = BI.LaranjaTexto, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(8.dp))
            Text("Pix", color = BI.LaranjaTexto, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }

        if (Banco.erro.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Text("⚠️ " + Banco.erro, color = BI.Vermelho, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.height(30.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Movimentações", color = BI.Texto, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("Ver extrato", color = BI.LaranjaTexto, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable { Banco.tela = TelaBanco.EXTRATO })
        }
        Spacer(Modifier.height(12.dp))
        val lista = Banco.movimentos()
        if (lista.isEmpty()) {
            CartaoVazio("Nenhuma movimentação ainda", "Quando entrar ou sair dinheiro, aparece aqui.")
        } else {
            ListaMov(lista.take(6))
        }
        NotaServidor()
        Spacer(Modifier.height(28.dp))
    }
}

@Composable
private fun CartaoVazio(titulo: String, sub: String) {
    val forma = RoundedCornerShape(20.dp)
    Column(Modifier.fillMaxWidth().clip(forma).background(BI.Cartao).padding(22.dp)) {
        Text(titulo, color = BI.Texto, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(4.dp))
        Text(sub, color = BI.Muted, fontSize = 14.sp)
    }
}

/** Aviso discreto de que saldo e envio ainda dependem do servidor. */
@Composable
private fun NotaServidor() {
    if (Banco.servidorOk) return
    Spacer(Modifier.height(10.dp))
    Text(
        "Mostrando os Pix recebidos lidos pelo app. O saldo e o envio de Pix aparecem aqui quando a conta AutoPay for conectada ao bot.",
        color = BI.Muted, fontSize = 12.sp
    )
}

// ───────────────────────── lista de movimentações ─────────────────────────

@Composable
private fun ListaMov(lista: List<Mov>) {
    var aberto by remember { mutableStateOf<Mov?>(null) }
    val forma = RoundedCornerShape(20.dp)
    Column(Modifier.fillMaxWidth().clip(forma).background(BI.Cartao).padding(vertical = 4.dp)) {
        lista.forEachIndexed { i, m ->
            LinhaMov(m) { aberto = m }
            if (i < lista.size - 1) Box(Modifier.fillMaxWidth().padding(horizontal = 18.dp).height(1.dp).background(BI.Borda))
        }
    }
    aberto?.let { DetalheMov(it) { aberto = null } }
}

@Composable
private fun LinhaMov(m: Mov, onClick: () -> Unit) {
    val cor = if (m.entrada) BI.Verde else BI.LaranjaTexto
    val nome = nomeBonito(m.nome).ifBlank { if (m.entrada) "Pix recebido" else "Pix enviado" }
    val situacao = when (m.status.lowercase()) {
        "processando", "pendente" -> " • Processando"
        "falhou" -> " • Não enviado"
        else -> ""
    }
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(cor.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
            Icon(if (m.entrada) Icons.Rounded.ArrowDownward else Icons.Rounded.ArrowUpward, null, tint = cor, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(nome, color = BI.Texto, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                (if (m.entrada) "Pix recebido" else "Pix enviado") + " • " + horaMin(m.ts) + situacao,
                color = BI.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(8.dp))
        Text(
            if (Banco.ocultar) "R$ ••••" else valorSinal(m),
            color = if (m.entrada) BI.Verde else BI.Texto, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1
        )
    }
}

@Composable
private fun DetalheMov(m: Mov, fechar: () -> Unit) {
    val clip = LocalClipboardManager.current
    AlertDialog(
        onDismissRequest = fechar,
        containerColor = BI.Cartao, titleContentColor = BI.Texto, textContentColor = BI.Muted,
        title = { Text(if (m.entrada) "Pix recebido" else "Pix enviado", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(valorSinal(m), color = if (m.entrada) BI.Verde else BI.Texto, fontSize = 28.sp, fontWeight = FontWeight.Black)
                if (m.nome.isNotBlank()) Text((if (m.entrada) "De: " else "Para: ") + nomeBonito(m.nome), color = BI.Texto)
                if (m.chave.isNotBlank()) Text("Chave: " + m.chave, color = BI.Muted, fontSize = 13.sp)
                if (m.descricao.isNotBlank()) Text((if (m.entrada) "Recebido via: " else "Descrição: ") + m.descricao, color = BI.Muted, fontSize = 13.sp)
                Text("Data: " + dataCompleta(m.ts), color = BI.Muted, fontSize = 13.sp)
                Text("Status: " + m.status.replaceFirstChar { it.uppercase() }, color = BI.Muted, fontSize = 13.sp)
                if (m.id.isNotBlank()) Text("ID: " + m.id, color = BI.Muted, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton(onClick = fechar) { Text("Fechar", color = BI.LaranjaTexto, fontWeight = FontWeight.Bold) } },
        dismissButton = {
            if (m.id.isNotBlank()) TextButton(onClick = { clip.setText(AnnotatedString(m.id)) }) { Text("Copiar ID", color = BI.Muted) }
        }
    )
}

// ───────────────────────── EXTRATO ─────────────────────────

@Composable
private fun ChipBI(texto: String, marcado: Boolean, onClick: () -> Unit) {
    val forma = RoundedCornerShape(50)
    Text(
        texto, color = if (marcado) Color.White else BI.Muted, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
        modifier = Modifier.clip(forma).background(if (marcado) BI.Laranja else BI.Cartao).clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp)
    )
}

@Composable
private fun BancoExtrato() {
    var filtro by remember { mutableStateOf(0) } // 0 tudo • 1 entradas • 2 saídas
    Column(Modifier.fillMaxSize()) {
        Cabecalho("Extrato") { Banco.voltar() }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            Text("Saldo", color = BI.Muted, fontSize = 15.sp)
            val s = Banco.saldo
            Text(
                if (Banco.ocultar) "R$ ••••••" else if (s != null) brl(s) else "R$ —",
                color = BI.Texto, fontSize = 32.sp, fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(16.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChipBI("Tudo", filtro == 0) { filtro = 0 }
                ChipBI("Entradas", filtro == 1) { filtro = 1 }
                ChipBI("Saídas", filtro == 2) { filtro = 2 }
            }
            NotaServidor()
            Spacer(Modifier.height(16.dp))

            val todos = Banco.movimentos()
            val lista = when (filtro) { 1 -> todos.filter { it.entrada }; 2 -> todos.filter { !it.entrada }; else -> todos }
            if (lista.isEmpty()) {
                CartaoVazio("Nada por aqui.", "Nenhuma movimentação neste filtro.")
            } else {
                lista.groupBy { chaveDia(it.ts) }.forEach { entrada ->
                    val doDia = entrada.value
                    Text(rotuloDia(doDia.first().ts), color = BI.Texto, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.padding(top = 6.dp, bottom = 8.dp))
                    ListaMov(doDia)
                    Spacer(Modifier.height(10.dp))
                }
            }
            Spacer(Modifier.height(28.dp))
        }
    }
}

// ───────────────────────── PIX: só Pagar / Receber ─────────────────────────

@Composable
private fun BancoPix() {
    Column(Modifier.fillMaxSize()) {
        Cabecalho("Pix") { Banco.voltar() }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Spacer(Modifier.height(8.dp))
            LinhaOpcao("Pagar") { Banco.tela = TelaBanco.PAGAR }
            LinhaOpcao("Receber") { Banco.tela = TelaBanco.RECEBER }
        }
    }
}

// ───────────────────────── PAGAR COM PIX ─────────────────────────

@Composable
private fun TileOutro(icone: ImageVector, rotulo: String, novo: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val forma = RoundedCornerShape(14.dp)
    Box(modifier.height(112.dp).clip(forma).border(1.dp, BI.Borda, forma).clickable(onClick = onClick)) {
        Column(Modifier.fillMaxSize().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(icone, null, tint = BI.LaranjaTexto, modifier = Modifier.size(34.dp))
            Spacer(Modifier.height(12.dp))
            Text(rotulo, color = BI.Texto, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        }
        if (novo) {
            Text(
                "Novo", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFFEDEDED)).padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
private fun BancoPagar() {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    var texto by remember { mutableStateOf("") }
    var erro by remember { mutableStateOf("") }
    var dialogoCopiaCola by remember { mutableStateOf(false) }
    var dialogoConta by remember { mutableStateOf(false) }
    var codigoColado by remember { mutableStateOf("") }

    val recentes = Banco.movimentos().filter { !it.entrada && it.chave.isNotBlank() }.distinctBy { it.chave }.take(6)

    Column(Modifier.fillMaxSize()) {
        Cabecalho("Pagar com Pix") { Banco.voltar() }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Para quem você quer pagar?", color = BI.Texto, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text(
                    "Colar", color = BI.LaranjaTexto, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable {
                        val colado = clip.getText()?.text ?: ""
                        if (colado.isBlank()) { erro = "Não há nada copiado para colar." }
                        else { texto = colado.take(600); erro = Banco.usarEntrada(colado) }
                    }.padding(6.dp)
                )
            }
            Spacer(Modifier.height(14.dp))
            CampoBI(
                valor = texto, aoMudar = { texto = it.take(600); erro = "" },
                dica = "Chave Pix ou Copia e Cola", aoConfirmar = { erro = Banco.usarEntrada(texto) }
            )
            if (erro.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text("⚠️ $erro", color = BI.Vermelho, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(14.dp))
            BotaoBI("Continuar", preenchido = true, enabled = texto.isNotBlank()) { erro = Banco.usarEntrada(texto) }

            Spacer(Modifier.height(30.dp))
            Text("Outros pagamentos", color = BI.Texto, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TileOutro(Icons.Rounded.QrCodeScanner, "Escanear", true, Modifier.weight(1f)) {
                    escanearQr(
                        ctx,
                        { lido ->
                            if (lido.isBlank()) { erro = "Não consegui ler esse QR Code." }
                            else { texto = lido.take(600); erro = Banco.usarEntrada(lido) }
                        },
                        { m -> erro = m }
                    )
                }
                TileOutro(Icons.Rounded.ContentCopy, "Pix Copia\ne Cola", false, Modifier.weight(1f)) { codigoColado = ""; dialogoCopiaCola = true }
                TileOutro(Icons.Rounded.AccountBalance, "Agência\ne conta", false, Modifier.weight(1f)) { dialogoConta = true }
            }

            Spacer(Modifier.height(30.dp))
            Text("Favoritos", color = BI.Texto, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(14.dp))
            if (recentes.isEmpty()) {
                Column(Modifier.fillMaxWidth().padding(vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Rounded.Error, null, tint = BI.Amarelo, modifier = Modifier.size(52.dp))
                    Spacer(Modifier.height(14.dp))
                    Text("Nenhum favorito adicionado", color = BI.Texto, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(8.dp))
                    Text("As chaves que você já pagou aparecerão aqui.", color = BI.Muted, fontSize = 15.sp, textAlign = TextAlign.Center)
                }
            } else {
                val forma = RoundedCornerShape(20.dp)
                Column(Modifier.fillMaxWidth().clip(forma).background(BI.Cartao).padding(vertical = 4.dp)) {
                    recentes.forEachIndexed { i, m ->
                        Row(
                            Modifier.fillMaxWidth().clickable { texto = m.chave; erro = Banco.usarEntrada(m.chave) }.padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(44.dp).clip(CircleShape).background(BI.Marrom), contentAlignment = Alignment.Center) {
                                Text(nomeBonito(m.nome).ifBlank { m.chave }.take(1).uppercase(), color = BI.LaranjaTexto, fontWeight = FontWeight.Black, fontSize = 18.sp)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(nomeBonito(m.nome).ifBlank { "Chave Pix" }, color = BI.Texto, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(m.chave, color = BI.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Icon(Icons.Rounded.ChevronRight, null, tint = BI.LaranjaTexto)
                        }
                        if (i < recentes.size - 1) Box(Modifier.fillMaxWidth().padding(horizontal = 18.dp).height(1.dp).background(BI.Borda))
                    }
                }
            }
            Spacer(Modifier.height(30.dp))
        }
    }

    if (dialogoCopiaCola) {
        AlertDialog(
            onDismissRequest = { dialogoCopiaCola = false },
            containerColor = BI.Cartao, titleContentColor = BI.Texto, textContentColor = BI.Muted,
            title = { Text("Pix Copia e Cola", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Cole o código Pix Copia e Cola de quem vai receber.", fontSize = 14.sp)
                    CampoBI(valor = codigoColado, aoMudar = { codigoColado = it.take(900) }, dica = "Cole o código aqui")
                    Text(
                        "Colar do que está copiado",
                        color = BI.LaranjaTexto, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                        modifier = Modifier.clickable { codigoColado = (clip.getText()?.text ?: "").take(900) }
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val e = Banco.usarEntrada(codigoColado)
                    erro = e
                    dialogoCopiaCola = false
                }) { Text("Continuar", color = BI.LaranjaTexto, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { dialogoCopiaCola = false }) { Text("Cancelar", color = BI.Muted) } }
        )
    }

    if (dialogoConta) {
        AlertDialog(
            onDismissRequest = { dialogoConta = false },
            containerColor = BI.Cartao, titleContentColor = BI.Texto, textContentColor = BI.Muted,
            title = { Text("Agência e conta", fontWeight = FontWeight.Bold) },
            text = { Text("Ainda não disponível. Por enquanto o bot envia Pix por chave (CPF, e-mail, celular ou aleatória).") },
            confirmButton = { TextButton(onClick = { dialogoConta = false }) { Text("Entendi", color = BI.LaranjaTexto, fontWeight = FontWeight.Bold) } }
        )
    }
}

// ───────────────────────── VALOR + CONFIRMAR ─────────────────────────

@Composable
private fun BancoValor() {
    var erro by remember { mutableStateOf("") }
    var confirmar by remember { mutableStateOf(false) }
    val v = lerValor(Banco.pagValor)

    Column(Modifier.fillMaxSize()) {
        Cabecalho("Valor do Pix") { Banco.voltar() }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            val forma = RoundedCornerShape(16.dp)
            Column(Modifier.fillMaxWidth().clip(forma).background(BI.Cartao).padding(18.dp)) {
                Text("Para", color = BI.Muted, fontSize = 13.sp)
                if (Banco.pagNome.isNotBlank()) Text(nomeBonito(Banco.pagNome), color = BI.Texto, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text(Banco.pagChave, color = if (Banco.pagNome.isBlank()) BI.Texto else BI.Muted, fontSize = if (Banco.pagNome.isBlank()) 17.sp else 14.sp, fontWeight = if (Banco.pagNome.isBlank()) FontWeight.Bold else FontWeight.Normal, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }

            Spacer(Modifier.height(26.dp))
            Text("Quanto você quer enviar?", color = BI.Texto, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))
            CampoBI(
                valor = Banco.pagValor, aoMudar = { Banco.pagValor = it.take(12); erro = "" },
                dica = "R$ 0,00", teclado = KeyboardType.Decimal, tamanhoFonte = 26
            )
            val s = Banco.saldo
            if (s != null) {
                Spacer(Modifier.height(8.dp))
                Text("Saldo disponível: " + (if (Banco.ocultar) "R$ ••••" else brl(s)), color = BI.Muted, fontSize = 14.sp)
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(10, 20, 50, 100, 200).forEach { q -> ChipBI("R$ $q", false) { Banco.pagValor = "$q"; erro = "" } }
            }

            Spacer(Modifier.height(22.dp))
            Text("Mensagem (opcional)", color = BI.Muted, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            CampoBI(valor = Banco.pagDesc, aoMudar = { Banco.pagDesc = it.take(60) }, dica = "Escreva uma mensagem")

            if (erro.isNotBlank()) {
                Spacer(Modifier.height(12.dp))
                Text("⚠️ $erro", color = BI.Vermelho, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }
            NotaServidor()
            Spacer(Modifier.height(22.dp))
            BotaoBI(if (Banco.enviando) "Enviando…" else "Continuar", preenchido = true, enabled = !Banco.enviando) {
                when {
                    Banco.pagChave.isBlank() -> { erro = "Volte e informe a chave Pix." }
                    v == null || v <= 0.0 -> { erro = "Digite um valor maior que zero (ex.: 25,50)." }
                    s != null && v > s -> { erro = "Saldo insuficiente. Você tem ${brl(s)}." }
                    else -> { erro = ""; confirmar = true }
                }
            }
            Spacer(Modifier.height(28.dp))
        }
    }

    if (confirmar && v != null) {
        AlertDialog(
            onDismissRequest = { confirmar = false },
            containerColor = BI.Cartao, titleContentColor = BI.Texto, textContentColor = BI.Muted,
            title = { Text("Confirmar Pix", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(brl(v), color = BI.Texto, fontSize = 30.sp, fontWeight = FontWeight.Black)
                    Text("Para a chave:", color = BI.Muted, fontSize = 13.sp)
                    Text(Banco.pagChave.trim(), color = BI.Texto, fontWeight = FontWeight.Bold)
                    if (Banco.pagDesc.isNotBlank()) Text("Mensagem: " + Banco.pagDesc, color = BI.Muted, fontSize = 13.sp)
                    Text("Confira com atenção: o Pix não pode ser desfeito.", color = BI.LaranjaTexto, fontSize = 12.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmar = false
                    Banco.enviarPix(Banco.pagChave.trim(), v, Banco.pagDesc.trim(), Banco.pagNome.ifBlank { Banco.pagChave.trim() })
                }) { Text("Enviar agora", color = BI.LaranjaTexto, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { confirmar = false }) { Text("Cancelar", color = BI.Muted) } }
        )
    }
}

/** Resultado do envio (aparece em qualquer tela da aba). */
@Composable
private fun DialogoResultado() {
    val res = Banco.resultado ?: return
    val cor = if (res.ok) BI.Verde else BI.Vermelho
    AlertDialog(
        onDismissRequest = { Banco.resultado = null },
        containerColor = BI.Cartao, titleContentColor = BI.Texto, textContentColor = BI.Muted,
        icon = { Icon(if (res.ok) Icons.Rounded.CheckCircle else Icons.Rounded.Error, null, tint = cor, modifier = Modifier.size(48.dp)) },
        title = { Text(if (res.ok) "Pix enviado!" else "Pix não enviado", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (res.ok) Text(brl(res.valor), color = BI.Texto, fontSize = 26.sp, fontWeight = FontWeight.Black)
                Text(res.msg, color = BI.Muted, fontSize = 13.sp)
                if (res.id.isNotBlank()) Text("Comprovante: " + res.id, color = BI.Muted, fontSize = 11.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val ok = res.ok
                Banco.resultado = null
                if (ok) { Banco.limparPagamento(); Banco.tela = TelaBanco.EXTRATO }
            }) { Text(if (res.ok) "Ver extrato" else "Fechar", color = cor, fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            if (res.ok) TextButton(onClick = { Banco.resultado = null; Banco.limparPagamento(); Banco.tela = TelaBanco.HOME }) { Text("Fechar", color = BI.Muted) }
        }
    )
}

// ───────────────────────── RECEBER PIX ─────────────────────────

@Composable
private fun BancoReceber() {
    val clip = LocalClipboardManager.current
    var dialogoValor by remember { mutableStateOf(false) }
    var rascunho by remember { mutableStateOf("") }
    var copiado by remember { mutableStateOf(false) }
    val gerado = Banco.recCopia.isNotBlank()
    val pago = Banco.recStatus == "pago"
    val v = lerValor(Banco.recValor)

    // enquanto o Pix gerado está pendente, pergunta ao bot se já foi pago
    LaunchedEffect(Banco.recId, Banco.recStatus) {
        while (Banco.recId.isNotBlank() && Banco.recStatus == "pendente") {
            delay(4_000)
            Banco.conferirRecebimento()
        }
    }
    LaunchedEffect(copiado) {
        if (copiado) { delay(2_000); copiado = false }
    }

    Column(Modifier.fillMaxSize()) {
        Cabecalho("Receber Pix") { Banco.voltar() }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(10.dp))
            if (gerado) {
                QrCodeView(Banco.recCopia, 270.dp)
            } else {
                Column(
                    Modifier.size(270.dp).clip(RoundedCornerShape(14.dp)).background(Color.White).padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Rounded.QrCode2, null, tint = Color(0xFFBDBDBD), modifier = Modifier.size(110.dp))
                    Spacer(Modifier.height(8.dp))
                    Text("O QR Code aparece aqui", color = Color(0xFF7A7A7A), fontSize = 14.sp, textAlign = TextAlign.Center)
                }
            }

            Spacer(Modifier.height(18.dp))
            if (gerado) {
                Text(
                    if (pago) "Pagamento recebido!" else "Aguardando pagamento…",
                    color = if (pago) BI.Verde else BI.Texto, fontSize = 18.sp, fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Valor " + brl(Banco.recValorGerado) + if (Banco.recCredito > 0.0) " • você recebe " + brl(Banco.recCredito) else "",
                    color = BI.Muted, fontSize = 14.sp, textAlign = TextAlign.Center
                )
                if (Banco.recStatus == "expirado" || Banco.recStatus == "cancelado") {
                    Spacer(Modifier.height(4.dp))
                    Text("Esse Pix não vale mais. Gere outro.", color = BI.Vermelho, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }
            } else {
                Text(
                    if (v != null && v > 0.0) "Valor " + brl(v) else "Escolha um valor para gerar o Pix",
                    color = if (v != null && v > 0.0) BI.Texto else BI.Muted, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center
                )
            }

            Spacer(Modifier.height(18.dp))
            Box(Modifier.width(34.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(BI.Laranja))
            Spacer(Modifier.height(18.dp))

            val forma = RoundedCornerShape(14.dp)
            Row(
                Modifier.fillMaxWidth().clip(forma).border(1.dp, BI.Borda, forma)
                    .clickable { rascunho = Banco.recValor; dialogoValor = true }.padding(horizontal = 20.dp, vertical = 22.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.Edit, null, tint = BI.LaranjaTexto, modifier = Modifier.size(26.dp))
                Spacer(Modifier.width(14.dp))
                Text("Personalizar valor", color = BI.Texto, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Icon(Icons.Rounded.ChevronRight, null, tint = BI.LaranjaTexto, modifier = Modifier.size(28.dp))
            }

            if (Banco.recErro.isNotBlank()) {
                Spacer(Modifier.height(12.dp))
                Text("⚠️ " + Banco.recErro, color = BI.Vermelho, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(16.dp))
        }

        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            BotaoBI(if (copiado) "Copiado!" else "Copiar Pix Copia e Cola", preenchido = true, enabled = gerado, icone = Icons.Rounded.ContentCopy) {
                clip.setText(AnnotatedString(Banco.recCopia)); copiado = true
            }
            BotaoBI(
                if (Banco.recGerando) "Gerando…" else if (gerado) "Gerar outro Pix" else "Gerar Pix",
                preenchido = false, enabled = !Banco.recGerando
            ) {
                if (v == null || v <= 0.0) { rascunho = Banco.recValor; dialogoValor = true }
                else {
                    Banco.recCopia = ""; Banco.recId = ""; Banco.recStatus = ""
                    Banco.gerarPix(v)
                }
            }
        }
    }

    if (dialogoValor) {
        val vr = lerValor(rascunho)
        AlertDialog(
            onDismissRequest = { dialogoValor = false },
            containerColor = BI.Cartao, titleContentColor = BI.Texto, textContentColor = BI.Muted,
            title = { Text("Personalizar valor", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Quanto você quer receber?", fontSize = 14.sp)
                    CampoBI(valor = rascunho, aoMudar = { rascunho = it.take(12) }, dica = "R$ 0,00", teclado = KeyboardType.Decimal, tamanhoFonte = 22)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(10, 20, 50, 100, 200).forEach { q -> ChipBI("R$ $q", false) { rascunho = "$q" } }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = vr != null && vr > 0.0,
                    onClick = {
                        if (vr != null && vr > 0.0) {
                            Banco.recValor = rascunho
                            dialogoValor = false
                            Banco.recCopia = ""; Banco.recId = ""; Banco.recStatus = ""
                            Banco.gerarPix(vr)
                        }
                    }
                ) { Text("Gerar Pix", color = if (vr != null && vr > 0.0) BI.LaranjaTexto else BI.Muted, fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { dialogoValor = false }) { Text("Cancelar", color = BI.Muted) } }
        )
    }
}
