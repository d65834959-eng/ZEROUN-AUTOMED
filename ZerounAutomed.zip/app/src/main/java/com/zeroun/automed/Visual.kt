package com.zeroun.automed

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ───────────────────────── componentes visuais compartilhados ─────────────────────────

/** Título de grupo com barrinha colorida: "CONFIGURAR O BOT". */
@Composable
fun TituloGrupo(texto: String, cor: Color) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(4.dp).height(16.dp).clip(RoundedCornerShape(2.dp)).background(cor))
        Spacer(Modifier.width(8.dp))
        Text(texto, color = Cor.Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
    }
}

/** Selinho pequeno: "personalizada", "Antiban"… */
@Composable
fun Selo(texto: String, cor: Color) {
    Text(
        texto, color = cor, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(cor.copy(alpha = 0.18f))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    )
}

/** Botão-pílula de escolha (abas, escopo). */
@Composable
fun Chip(texto: String, cor: Color, marcado: Boolean, onClick: () -> Unit) {
    val forma = RoundedCornerShape(50)
    Text(
        texto, color = if (marcado) Color.White else Cor.Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1,
        modifier = Modifier.clip(forma)
            .background(if (marcado) cor.copy(alpha = 0.55f) else Cor.Card2)
            .border(1.dp, if (marcado) cor else Color.White.copy(alpha = 0.08f), forma)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp)
    )
}

/** Botão pequeno (editar, excluir…). */
@Composable
fun BotaoMini(texto: String, cor: Color, onClick: () -> Unit) {
    val forma = RoundedCornerShape(12.dp)
    Text(
        texto, color = cor, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1,
        modifier = Modifier.clip(forma).background(cor.copy(alpha = 0.16f))
            .border(1.dp, cor.copy(alpha = 0.4f), forma)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    )
}

@Composable
fun Avatar(letra: String, cor: Color, tamanho: Int = 44) {
    Box(
        Modifier.size(tamanho.dp).clip(CircleShape).background(cor.copy(alpha = 0.22f)),
        contentAlignment = Alignment.Center
    ) {
        Text(letra.trim().take(1).uppercase().ifBlank { "?" }, color = cor, fontWeight = FontWeight.Black, fontSize = (tamanho * 0.4).sp)
    }
}

@Composable
fun Estatistica(valor: String, rotulo: String, cor: Color, modifier: Modifier) {
    val forma = RoundedCornerShape(18.dp)
    Column(
        modifier.clip(forma).background(cor.copy(alpha = 0.14f)).border(1.dp, cor.copy(alpha = 0.35f), forma).padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(valor, color = cor, fontSize = 24.sp, fontWeight = FontWeight.Black)
        Text(rotulo, color = Cor.Muted, fontSize = 11.sp)
    }
}

/** Cartão clicável com ícone, título, descrição, selo e (opcional) um "código" em destaque. */
@Composable
fun CartaoAcao(
    emoji: String, titulo: String, sub: String, cor: Color,
    selo: String?, seloCor: Color, destaque: String?, onClick: () -> Unit
) {
    val forma = RoundedCornerShape(20.dp)
    Row(
        Modifier.fillMaxWidth().clip(forma)
            .background(Brush.linearGradient(listOf(cor.copy(alpha = 0.22f), Cor.Card)))
            .border(1.dp, cor.copy(alpha = 0.35f), forma)
            .clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(46.dp).clip(CircleShape).background(cor.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) {
            Text(emoji, fontSize = 22.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(titulo, color = Cor.Texto, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                if (selo != null) { Spacer(Modifier.width(8.dp)); Selo(selo, seloCor) }
            }
            Text(sub, color = Cor.Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (destaque != null) {
                Spacer(Modifier.height(6.dp))
                Text(
                    destaque, color = cor, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, maxLines = 1,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(Cor.Fundo).padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }
        Spacer(Modifier.width(8.dp))
        Text("›", color = cor, fontSize = 24.sp, fontWeight = FontWeight.Black)
    }
}

/** Faixa de aviso (resultado da última ação). */
@Composable
fun AvisoBarra() {
    if (Painel.aviso.isNotBlank()) {
        val cor = if (Painel.avisoOk) Cor.Verde else Cor.Vermelho
        val forma = RoundedCornerShape(14.dp)
        Text(
            (if (Painel.avisoOk) "✅  " else "⚠️  ") + Painel.aviso,
            color = cor, fontSize = 13.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth().clip(forma).background(cor.copy(alpha = 0.14f))
                .border(1.dp, cor.copy(alpha = 0.45f), forma).padding(12.dp)
        )
    }
}

/** Mostra "não conectado", erro do bot ou "atualizando". Devolve true se pode mostrar o conteúdo. */
@Composable
fun EstadoDoPainel(): Boolean {
    if (!Prefs.conectado) {
        Cartao {
            Text("🔗 Conecte o app primeiro", color = Cor.Laranja, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("Abra \"Conexão\" no início, coloque o endereço do bot e a key. Depois essa tela carrega sozinha.", color = Cor.Muted, fontSize = 12.sp)
        }
        return false
    }
    if (Painel.erro.isNotBlank()) {
        Cartao {
            Text("⚠️ " + Painel.erro, color = Cor.Vermelho, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            Botao("Tentar de novo", Cor.Card2) { Painel.carregar() }
        }
        return false
    }
    if (!Painel.carregado) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) { Pill("Carregando…", Cor.Ciano) }
        return false
    }
    return true
}

/** Grade de 2 colunas de botões de categoria. */
@Composable
fun GradeCategorias(itens: List<Triple<Tela, Color, String>>, ir: (Tela) -> Unit) {
    itens.chunked(2).forEach { par ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            par.forEach { (t, c, sub) ->
                BotaoCategoria(t.emoji, t.titulo, sub, c, Modifier.weight(1f)) { ir(t) }
            }
            if (par.size == 1) Spacer(Modifier.weight(1f))
        }
    }
}

// ───────────────────────── prévia de mensagem (estilo Discord) ─────────────────────────

fun previaMensagem(t: String): String {
    return t.replace("{nome}", "João Silva")
        .replace("{valor_real}", "R\$ 5,00")
        .replace("{valor}", "5,00")
        .replace("{restante}", "2,00")
        .replace("**", "").replace("__", "").replace("`", "")
        .replace(Regex("(?m)^#{1,3}\\s*"), "")
        .replace(Regex("(?m)^>\\s?"), "")
        .replace(Regex("(?m)^-#\\s*"), "")
}

@Composable
fun PreviaDiscord(texto: String) {
    val forma = RoundedCornerShape(14.dp)
    Column(Modifier.fillMaxWidth().clip(forma).background(Cor.Fundo).border(1.dp, Color.White.copy(alpha = 0.06f), forma).padding(12.dp)) {
        Text("PRÉVIA", color = Cor.Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(6.dp))
        Text(if (texto.isBlank()) "(vazio)" else previaMensagem(texto), color = Cor.Texto, fontSize = 13.sp)
    }
}
