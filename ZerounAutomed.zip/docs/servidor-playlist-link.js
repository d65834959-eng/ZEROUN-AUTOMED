// ZEROUN — link curto de playlist (servidor). Salve ao lado do index.js como playlist-link.js
// Guarda as playlists em app_playlists.json e devolve um código curto (ex.: k7Qx2mP).
// O app abre zeroun://playlist/<código> e busca o conteúdo aqui.
const fs = require('fs');
const crypto = require('crypto');

const ARQ = require('path').join(__dirname, 'app_playlists.json');
const MAX_FAIXAS = 300;        // igual ao app
const MAX_POR_KEY = 50;        // playlists publicadas por key
const ABC = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789'; // sem letras que confundem (0 O 1 l I)

let db = {};   // codigo -> { dono, pid, nome, faixas, criada, atualizada }
let idx = {};  // "DONO|pid" -> codigo
try { db = JSON.parse(fs.readFileSync(ARQ, 'utf8')); } catch (e) { db = {}; }
for (const c of Object.keys(db)) idx[db[c].dono + '|' + db[c].pid] = c;

let timer = null;
function gravar() {
  clearTimeout(timer);
  timer = setTimeout(() => {
    fs.writeFile(ARQ + '.tmp', JSON.stringify(db), (e) => { if (!e) fs.rename(ARQ + '.tmp', ARQ, () => {}); });
  }, 500);
}

function novoCodigo() {
  for (;;) {
    let c = '';
    for (const b of crypto.randomBytes(7)) c += ABC[b % ABC.length];
    if (!db[c]) return c;
  }
}

const txt = (v, n) => String(v == null ? '' : v).trim().slice(0, n);

/** body = { key, deviceId, pid, nome, faixas:[[id,titulo,artista,duracao],...] }. Valide a key ANTES de chamar. */
function salvar(body) {
  const dono = txt(body.key, 80).toUpperCase();
  const pid = txt(body.pid, 60);
  if (!dono || !pid) return { ok: false, msg: 'Pedido inválido.' };
  if (!Array.isArray(body.faixas) || !body.faixas.length) return { ok: false, msg: 'Playlist vazia.' };

  const faixas = [];
  const vistos = new Set();
  for (const f of body.faixas.slice(0, MAX_FAIXAS)) {
    if (!Array.isArray(f)) continue;
    const id = txt(f[0], 40);
    const titulo = txt(f[1], 200);
    if (!/^[A-Za-z0-9_-]{1,40}$/.test(id) || !titulo || vistos.has(id)) continue;
    vistos.add(id);
    faixas.push([id, titulo, txt(f[2], 120), Math.max(0, Math.min(86400, parseInt(f[3]) || 0))]);
  }
  if (!faixas.length) return { ok: false, msg: 'Nenhuma música válida.' };

  const chave = dono + '|' + pid;
  let codigo = idx[chave];                      // mesma playlist → MESMO link (só atualiza o conteúdo)
  if (!codigo) {
    const meus = Object.values(db).filter((p) => p.dono === dono).length;
    if (meus >= MAX_POR_KEY) return { ok: false, msg: 'Limite de ' + MAX_POR_KEY + ' playlists compartilhadas.' };
    codigo = novoCodigo();
    idx[chave] = codigo;
    db[codigo] = { dono, pid, criada: Date.now() };
  }
  Object.assign(db[codigo], { nome: txt(body.nome, 60) || 'Playlist', faixas, atualizada: Date.now() });
  gravar();
  return { ok: true, codigo };
}

/** body = { codigo }. Não precisa de key: o código já é o "segredo" do link. */
function ler(body) {
  const p = db[txt(body.codigo, 40)];
  if (!p) return { ok: false, msg: 'Playlist não encontrada. O link pode estar errado.' };
  return { ok: true, nome: p.nome, faixas: p.faixas };
}

module.exports = { salvar, ler };
