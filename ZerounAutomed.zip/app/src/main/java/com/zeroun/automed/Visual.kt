package com.zeroun.automed

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ───────────────────────── tema claro / escuro ─────────────────────────

object Tema {
    /** false = claro (padrão) • true = escuro. Mudar aqui recompõe o app inteiro. */
    var escuro by mutableStateOf(false)

    fun alternar() { escuro = !escuro; Prefs.escuro = escuro }
}

/** Paleta: branco (claro) ou grafite (escuro). Sem roxo. Cada cor é lida na hora, então troca de tema é instantânea. */
object Cor {
    private fun c(claro: Long, escuro: Long) = Color(if (Tema.escuro) escuro else claro)

    val Fundo get() = c(0xFFF2F7FF, 0xFF000000)
    val Fundo2 get() = c(0xFFE4EEFF, 0xFF050506)
    val Card get() = c(0xFFFFFFFF, 0xFF0B0B0D)
    val Card2 get() = c(0xFFE8EFFB, 0xFF1B1B1E)
    val Borda get() = c(0x2E2563EB, 0xFF2A2A2E)

    /** Destaque: azul no claro, branco no escuro (como na foto). Nos botões vira degradê. */
    val Marca get() = c(0xFF2563EB, 0xFFFFFFFF)
    val SobreMarca get() = if (Tema.escuro) Color.Black else Color.White
    val Gradiente get() = Brush.horizontalGradient(
        if (Tema.escuro) listOf(Color(0xFFFFFFFF), Color(0xFFD4D4D8))
        else listOf(Color(0xFF2563EB), Color(0xFF06B6D4))
    )

    val Ciano get() = c(0xFF0891B2, 0xFF22D3EE)
    val Verde get() = c(0xFF059669, 0xFF22D47B)
    val Rosa get() = c(0xFFDB2777, 0xFFF472B6)
    val Roxo get() = c(0xFF7C3AED, 0xFFA78BFA)
    val Laranja get() = c(0xFFD97706, 0xFFFBBF24)
    val Vermelho get() = c(0xFFDC2626, 0xFFF87171)
    val Azul get() = c(0xFF2563EB, 0xFF60A5FA)

    val Texto get() = c(0xFF0B1220, 0xFFFFFFFF)
    val Muted get() = c(0xFF5B6B86, 0xFFA1A1AA)
}

/** Cor do texto/ícone que fica legível em cima de [c]. */
fun sobre(c: Color): Color = if (c.luminance() > 0.5f) Color(0xFF0A0C11) else Color.White

/** Sombra suave só no tema claro (no escuro o contorno já separa os cartões). */
fun Modifier.suave(forma: androidx.compose.ui.graphics.Shape): Modifier =
    if (Tema.escuro) this
    else this.shadow(6.dp, forma, ambientColor = Color(0x1A0F172A), spotColor = Color(0x290F172A))

/** Fundo do app. Escuro = preto puro com um brilho diagonal bem leve no topo (como na foto). Claro = degradê azulado. */
fun Modifier.decoracao(): Modifier =
    if (Tema.escuro) this
        .background(Color.Black)
        .drawBehind {
            val w = size.width
            val h = size.height
            drawRect(
                Brush.linearGradient(
                    listOf(Color(0x1FFFFFFF), Color.Transparent),
                    start = Offset(w * 0.95f, 0f), end = Offset(w * 0.35f, h * 0.30f)
                )
            )
        }
    else this
        .background(Brush.verticalGradient(listOf(Cor.Fundo, Cor.Fundo2, Cor.Fundo)))
        .drawBehind {
            val w = size.width
            val h = size.height
            val forte = 0.22f
            val r1 = w * 1.0f
            drawCircle(
                brush = Brush.radialGradient(listOf(Cor.Azul.copy(alpha = forte), Color.Transparent), center = Offset(w, 0f), radius = r1),
                radius = r1, center = Offset(w, 0f)
            )
            val r2 = w * 0.9f
            drawCircle(
                brush = Brush.radialGradient(listOf(Cor.Ciano.copy(alpha = forte * 0.8f), Color.Transparent), center = Offset(0f, h * 0.88f), radius = r2),
                radius = r2, center = Offset(0f, h * 0.88f)
            )
        }

// ───────────────────────── botão sol / lua ─────────────────────────

@Composable
fun BotaoTema() {
    val giro by animateFloatAsState(if (Tema.escuro) 360f else 0f, label = "giro")
    Box(
        Modifier.size(44.dp).suave(CircleShape).clip(CircleShape)
            .background(Cor.Card).border(1.dp, Cor.Borda, CircleShape)
            .clickable { Tema.alternar() },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            if (Tema.escuro) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
            contentDescription = "Trocar tema",
            tint = if (Tema.escuro) Cor.Laranja else Cor.Azul,
            modifier = Modifier.size(24.dp).rotate(giro)
        )
    }
}

// ───────────────────────── componentes básicos ─────────────────────────

@Composable
fun Pill(texto: String, cor: Color) {
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(cor.copy(alpha = 0.14f))
            .border(1.dp, cor.copy(alpha = 0.45f), RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(cor))
        Spacer(Modifier.width(7.dp))
        Text(texto, color = cor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

/** Pílula cheia (ex.: ONLINE), sem bolinha. */
@Composable
fun PillSolida(texto: String, cor: Color) {
    Text(
        texto, color = cor, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(cor.copy(alpha = 0.16f))
            .border(1.dp, cor.copy(alpha = 0.35f), RoundedCornerShape(50))
            .padding(horizontal = 16.dp, vertical = 8.dp)
    )
}

@Composable
fun Cartao(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val forma = RoundedCornerShape(30.dp)
    Column(
        modifier.fillMaxWidth().suave(forma).clip(forma).background(Cor.Card)
            .border(1.dp, Cor.Borda, forma).padding(20.dp)
    ) { content() }
}

@Composable
fun Botao(
    texto: String, cor: Color = Cor.Marca, modifier: Modifier = Modifier.fillMaxWidth(),
    icone: ImageVector? = null, enabled: Boolean = true, onClick: () -> Unit
) {
    val forma = RoundedCornerShape(50)
    val principal = cor == Cor.Marca
    val fundo: Brush = if (!enabled) Brush.linearGradient(listOf(Cor.Card2, Cor.Card2))
        else if (principal) Cor.Gradiente else Brush.linearGradient(listOf(cor, cor))
    val letra = if (!enabled) Cor.Muted else if (principal) Cor.SobreMarca else sobre(cor)
    var m = modifier.height(58.dp)
    if (enabled && principal && !Tema.escuro) m = m.shadow(12.dp, forma, ambientColor = Cor.Marca.copy(alpha = 0.5f), spotColor = Cor.Marca.copy(alpha = 0.6f))
    Row(
        m.clip(forma).background(fundo).clickable(enabled = enabled, onClick = onClick).padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
    ) {
        if (icone != null) { Icon(icone, null, tint = letra, modifier = Modifier.size(22.dp)); Spacer(Modifier.width(10.dp)) }
        Text(texto, color = letra, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, maxLines = 1)
    }
}

/** Título de grupo com barrinha colorida. */
@Composable
fun TituloGrupo(texto: String, cor: Color) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(4.dp).height(16.dp).clip(RoundedCornerShape(2.dp)).background(cor))
        Spacer(Modifier.width(8.dp))
        Text(texto, color = Cor.Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
    }
}

@Composable
fun Selo(texto: String, cor: Color) {
    Text(
        texto, color = cor, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(cor.copy(alpha = 0.14f))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    )
}

/** Botão-pílula de escolha (abas, escopo). */
@Composable
fun Chip(texto: String, cor: Color, marcado: Boolean, onClick: () -> Unit) {
    val forma = RoundedCornerShape(50)
    Text(
        texto, color = if (marcado) sobre(cor) else Cor.Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1,
        modifier = Modifier.clip(forma)
            .background(if (marcado) cor else Cor.Card)
            .border(1.dp, if (marcado) cor else Cor.Borda, forma)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    )
}

@Composable
fun BotaoMini(texto: String, cor: Color, onClick: () -> Unit) {
    val forma = RoundedCornerShape(12.dp)
    Text(
        texto, color = cor, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1,
        modifier = Modifier.clip(forma).background(cor.copy(alpha = 0.12f))
            .border(1.dp, cor.copy(alpha = 0.4f), forma)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    )
}

@Composable
fun Avatar(letra: String, cor: Color, tamanho: Int = 44) {
    Box(
        Modifier.size(tamanho.dp).clip(CircleShape).background(cor.copy(alpha = 0.16f)),
        contentAlignment = Alignment.Center
    ) {
        Text(letra.trim().take(1).uppercase().ifBlank { "?" }, color = cor, fontWeight = FontWeight.Black, fontSize = (tamanho * 0.4).sp)
    }
}

@Composable
fun Estatistica(valor: String, rotulo: String, cor: Color, modifier: Modifier) {
    val forma = RoundedCornerShape(18.dp)
    Column(
        modifier.clip(forma).background(cor.copy(alpha = 0.10f)).border(1.dp, cor.copy(alpha = 0.3f), forma).padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(valor, color = cor, fontSize = 24.sp, fontWeight = FontWeight.Black)
        Text(rotulo, color = Cor.Muted, fontSize = 11.sp)
    }
}

/** Ícone dentro de um quadradinho colorido. */
@Composable
fun IconeCaixa(icone: ImageVector, cor: Color, tamanho: Int = 46) {
    Box(
        Modifier.size(tamanho.dp).clip(RoundedCornerShape((tamanho * 0.32).dp)).background(cor.copy(alpha = 0.14f)),
        contentAlignment = Alignment.Center
    ) { Icon(icone, null, tint = cor, modifier = Modifier.size((tamanho * 0.5).dp)) }
}

/** Linha de menu clicável: ícone, título, descrição e seta. */
@Composable
fun LinhaMenu(icone: ImageVector, titulo: String, sub: String, cor: Color, onClick: () -> Unit) {
    val forma = RoundedCornerShape(20.dp)
    Row(
        Modifier.fillMaxWidth().suave(forma).clip(forma).background(Cor.Card)
            .border(1.dp, Cor.Borda, forma).clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconeCaixa(icone, cor)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(titulo, color = Cor.Texto, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, color = Cor.Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Rounded.ChevronRight, null, tint = Cor.Muted)
    }
}

/** Cartão clicável com emoji, título, descrição, selo e (opcional) um "código" em destaque. */
@Composable
fun CartaoAcao(
    emoji: String, titulo: String, sub: String, cor: Color,
    selo: String?, seloCor: Color, destaque: String?, onClick: () -> Unit
) {
    val forma = RoundedCornerShape(22.dp)
    Row(
        Modifier.fillMaxWidth().suave(forma).clip(forma)
            .background(Brush.linearGradient(listOf(cor.copy(alpha = 0.12f), Cor.Card)))
            .border(1.dp, cor.copy(alpha = 0.3f), forma)
            .clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(46.dp).clip(CircleShape).background(cor.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
            Text(emoji, fontSize = 22.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(titulo, color = Cor.Texto, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                if (selo != null) { Spacer(Modifier.width(8.dp)); Selo(selo, seloCor) }
            }
            Text(sub, color = Cor.Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (destaque != null) {
                Spacer(Modifier.height(6.dp))
                Text(
                    destaque, color = cor, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, maxLines = 1,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(Cor.Card2).padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }
        Spacer(Modifier.width(8.dp))
        Icon(Icons.Rounded.ChevronRight, null, tint = cor)
    }
}

/** Faixa de aviso (resultado da última ação). */
@Composable
fun AvisoBarra() {
    if (Painel.aviso.isNotBlank()) {
        val cor = if (Painel.avisoOk) Cor.Verde else Cor.Vermelho
        val forma = RoundedCornerShape(14.dp)
        Text(
            (if (Painel.avisoOk) "✅  " else "⚠️  ") + Painel.aviso,
            color = cor, fontSize = 13.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth().clip(forma).background(cor.copy(alpha = 0.12f))
                .border(1.dp, cor.copy(alpha = 0.45f), forma).padding(12.dp)
        )
    }
}

/** Mostra erro do bot ou "carregando". Devolve true se pode mostrar o conteúdo. */
@Composable
fun EstadoDoPainel(): Boolean {
    if (!Prefs.conectado) {
        Cartao {
            Text("🔗 Entre com a sua key primeiro", color = Cor.Laranja, fontWeight = FontWeight.Bold)
        }
        return false
    }
    if (Painel.erro.isNotBlank()) {
        Cartao {
            Text("⚠️ " + Painel.erro, color = Cor.Vermelho, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            Botao("Tentar de novo", Cor.Card2) { Painel.carregar() }
        }
        return false
    }
    if (!Painel.carregado) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) { Pill("Carregando…", Cor.Azul) }
        return false
    }
    return true
}

// ───────────────────────── prévia de mensagem (estilo Discord) ─────────────────────────

fun previaMensagem(t: String): String {
    return t.replace("{nome}", "João Silva")
        .replace("{valor_real}", "R\$ 5,00")
        .replace("{valor}", "5,00")
        .replace("{restante}", "2,00")
        .replace("**", "").replace("__", "").replace("`", "")
        .replace(Regex("(?m)^#{1,3}\\s*"), "")
        .replace(Regex("(?m)^>\\s?"), "")
        .replace(Regex("(?m)^-#\\s*"), "")
}

@Composable
fun PreviaDiscord(texto: String) {
    val forma = RoundedCornerShape(14.dp)
    Column(Modifier.fillMaxWidth().clip(forma).background(Cor.Card2).border(1.dp, Cor.Borda, forma).padding(12.dp)) {
        Text("PRÉVIA", color = Cor.Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(6.dp))
        Text(if (texto.isBlank()) "(vazio)" else previaMensagem(texto), color = Cor.Texto, fontSize = 13.sp)
    }
}
