package com.zeroun.automed

import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/*
 * MÚSICA — "Mediação com música"
 *
 * Como funciona (igual ao index.js do bot de call):
 *   1) PROCURAR  = o index.js usa  yt-dlp ytsearch1:<busca>  → só título + link (rápido, sem baixar nada).
 *                  Aqui o celular faz a mesma busca direto no YouTube (YT.buscar).
 *   2) TOCAR     = o index.js usa  yt-dlp -f bestaudio  → pega o melhor áudio.
 *                  Aqui o celular pede o melhor áudio (YT.resolver) e toca no próprio aparelho (Tocador).
 *   3) CACHE     = o index.js guarda busca → resultado num Map. Aqui tudo fica num JSON no celular
 *                  (files/musica.json): buscas, músicas tocadas, endereço do áudio e histórico de cada usuário.
 *
 * Nada disso usa a key nem o servidor, então continua funcionando (e salvo) mesmo se a key acabar.
 */

/** Uma música do YouTube. */
data class Som(val id: String, val titulo: String, val artista: String, val duracao: Int)

/** Quantas vezes UM usuário ouviu a música e quando foi a última vez. */
data class Uso(val plays: Int, val ultimo: Long)

/** Música + uso (para as listas "Mais ouvidas" e "Recentes"). */
data class ItemUso(val faixa: Som, val uso: Uso)

/** Endereço direto do áudio (vale umas 6 horas) + de qual "cliente" do YouTube ele veio. */
data class Fluxo(
    val url: String, val ua: String, val cliente: String, val expira: Long,
    val titulo: String, val artista: String, val duracao: Int
)

// ───────────────────────── YouTube (o "yt-dlp" do celular) ─────────────────────────

object YT {
    private class Cliente(
        val chave: String, val nome: String, val numero: String, val versao: String,
        val ua: String, val extra: JSONObject
    )

    /**
     * Clientes do YouTube que entregam o link do áudio sem login. Tenta um por um.
     * Se o YouTube mudar algo e a música parar de tocar, atualize as versões aqui (como se atualiza o yt-dlp).
     */
    private val clientes = listOf(
        Cliente(
            "vr", "ANDROID_VR", "28", "1.65.10",
            "com.google.android.apps.youtube.vr.oculus/1.65.10 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip",
            JSONObject().put("deviceMake", "Oculus").put("deviceModel", "Quest 3")
                .put("androidSdkVersion", 32).put("osName", "Android").put("osVersion", "12L")
        ),
        Cliente(
            "ios", "IOS", "5", "20.10.4",
            "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
            JSONObject().put("deviceMake", "Apple").put("deviceModel", "iPhone16,2")
                .put("osName", "iPhone").put("osVersion", "18.3.2.22D82")
        ),
        Cliente(
            "and", "ANDROID", "3", "20.10.38",
            "com.google.android.youtube/20.10.38 (Linux; U; Android 11) gzip",
            JSONObject().put("androidSdkVersion", 30).put("osName", "Android").put("osVersion", "11")
        )
    )

    val total: Int get() = 1

    private const val VERSAO_WEB = "2.20241126.01.00"
    private const val UA_WEB =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"

    private val reLink = Regex(
        "(?:youtu\\.be/|youtube\\.com/(?:watch\\?(?:.*&)?v=|shorts/|embed/|live/))([A-Za-z0-9_-]{11})"
    )
    private val reExpira = Regex("[?&]expire=(\\d+)")

    private fun postar(url: String, corpo: JSONObject, cab: Map<String, String>): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            for ((k, v) in cab) c.setRequestProperty(k, v)
            c.outputStream.use { it.write(corpo.toString().toByteArray(Charsets.UTF_8)) }
            val ok = c.responseCode in 200..299
            val txt = (if (ok) c.inputStream else c.errorStream)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (!ok) {
                // mostra o motivo que o YouTube deu (ex.: "Precondition check failed" = versão do cliente velha demais)
                val motivo = try { JSONObject(txt).optJSONObject("error")?.optString("message").orEmpty() } catch (e: Exception) { "" }
                throw IOException("HTTP " + c.responseCode + (if (motivo.isNotBlank()) " - " + motivo else ""))
            }
            return JSONObject(txt)
        } finally {
            c.disconnect()
        }
    }

    /** Se o texto for um link do YouTube, devolve o id do vídeo (o index.js também aceita link). */
    fun idDoLink(texto: String): String? {
        val t = texto.trim()
        if (!t.startsWith("http", ignoreCase = true)) return null
        return reLink.find(t)?.groupValues?.get(1)
    }

    // ── 1) PROCURAR (igual ao ytsearch1 do index.js, só que trazendo vários resultados) ──

    fun buscar(consulta: String): List<Som> {
        val j = servidor("/musica/buscar?q=" + java.net.URLEncoder.encode(consulta.trim(), "UTF-8") + "&" + auth(), 60_000)
        val arr = j.optJSONArray("itens") ?: JSONArray()
        val lista = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Som(o.getString("id"), o.optString("titulo"), o.optString("artista"), o.optInt("duracao"))
        }
        if (lista.isEmpty()) throw Exception("Não achei nenhuma música com essa busca.")
        return lista
    }

    private fun auth(): String =
        "k=" + java.net.URLEncoder.encode(Prefs.key.trim().uppercase(), "UTF-8") +
            "&d=" + java.net.URLEncoder.encode(Prefs.deviceId, "UTF-8")

    /** GET no bot (o yt-dlp roda lá). Devolve o JSON ou joga o motivo real. */
    private fun servidor(caminho: String, leitura: Int): JSONObject {
        val c = URL(Net.base() + caminho).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = leitura
            val ok = c.responseCode in 200..299
            val txt = (if (ok) c.inputStream else c.errorStream)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            val j = try { JSONObject(txt) } catch (e: Exception) { throw IOException("Servidor respondeu HTTP " + c.responseCode) }
            if (!j.optBoolean("ok")) throw IOException(j.optString("msg").ifBlank { "HTTP " + c.responseCode })
            return j
        } finally {
            c.disconnect()
        }
    }

    fun detalhe(e: Exception): String = e.javaClass.simpleName + (if (e.message.isNullOrBlank()) "" else ": " + e.message)

    private fun buscarApi(consulta: String): JSONObject {
        val cliente = JSONObject().put("clientName", "WEB").put("clientVersion", VERSAO_WEB)
            .put("hl", "pt").put("gl", "BR")
        val corpo = JSONObject().put("context", JSONObject().put("client", cliente))
            .put("query", consulta).put("params", "EgIQAQ==") // EgIQAQ== = só vídeos
        return postar(
            "https://www.youtube.com/youtubei/v1/search?prettyPrint=false", corpo,
            mapOf(
                "User-Agent" to UA_WEB, "X-YouTube-Client-Name" to "1", "X-YouTube-Client-Version" to VERSAO_WEB,
                "Accept-Language" to "pt-BR,pt;q=0.9", "Origin" to "https://www.youtube.com", "Cookie" to "SOCS=CAI"
            )
        )
    }

    /** Plano B: abre a página de resultados como o navegador e lê o JSON embutido (ytInitialData). */
    private fun buscarHtml(consulta: String): JSONObject {
        val q = java.net.URLEncoder.encode(consulta, "UTF-8")
        val c = URL("https://www.youtube.com/results?hl=pt&gl=BR&sp=EgIQAQ%253D%253D&search_query=" + q).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.setRequestProperty("User-Agent", UA_WEB)
            c.setRequestProperty("Accept-Language", "pt-BR,pt;q=0.9")
            c.setRequestProperty("Cookie", "SOCS=CAI; CONSENT=YES+1")
            if (c.responseCode !in 200..299) throw IOException("HTTP " + c.responseCode)
            val html = c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val i = html.indexOf("ytInitialData = ")
            if (i < 0) throw IOException("página sem resultados")
            val ini = i + "ytInitialData = ".length
            val fim = html.indexOf(";</script>", ini)
            if (fim < 0) throw IOException("página em formato novo")
            return JSONObject(html.substring(ini, fim))
        } finally {
            c.disconnect()
        }
    }

    private fun lerResultados(r: JSONObject): List<Som> {
        val brutos = ArrayList<JSONObject>()
        coletar(r, brutos)
        val lista = ArrayList<Som>()
        for (v in brutos) {
            val vid = v.optString("videoId")
            if (vid.isBlank() || lista.any { it.id == vid }) continue
            val seg = segundos(texto(v.optJSONObject("lengthText")))
            if (seg <= 0) continue // ao vivo / sem duração
            val titulo = texto(v.optJSONObject("title")).trim()
            if (titulo.isBlank()) continue
            var artista = texto(v.optJSONObject("ownerText")).trim()
            if (artista.isBlank()) artista = texto(v.optJSONObject("longBylineText")).trim()
            artista = artista.removeSuffix(" - Topic").ifBlank { "YouTube" }
            lista.add(Som(vid, titulo, artista, seg))
            if (lista.size >= 12) break
        }
        return lista
    }

    /** Percorre o JSON do YouTube e junta todos os "videoRenderer" (os vídeos do resultado). */
    private fun coletar(n: Any?, out: MutableList<JSONObject>) {
        if (out.size >= 20) return
        if (n is JSONObject) {
            val v = n.optJSONObject("videoRenderer")
            if (v != null) out.add(v)
            val ks = n.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                if (k != "videoRenderer") coletar(n.opt(k), out)
            }
        } else if (n is JSONArray) {
            for (i in 0 until n.length()) coletar(n.opt(i), out)
        }
    }

    private fun texto(o: JSONObject?): String {
        if (o == null) return ""
        val simples = o.optString("simpleText")
        if (simples.isNotBlank()) return simples
        val runs = o.optJSONArray("runs") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until runs.length()) sb.append(runs.optJSONObject(i)?.optString("text") ?: "")
        return sb.toString()
    }

    private fun segundos(t: String): Int {
        if (t.isBlank()) return 0
        var s = 0
        for (p in t.split(":")) {
            val n = p.trim().toIntOrNull() ?: return 0
            s = s * 60 + n
        }
        return s
    }

    // ── 2) PEGAR O ÁUDIO (igual ao "-f bestaudio" do index.js) ──

    /** O bot baixa o áudio com yt-dlp (igual ao index.js) e o app toca esse endereço. */
    fun resolver(id: String, evitar: Set<String>): Fluxo {
        servidor("/musica/preparar?id=" + id + "&" + auth(), 120_000)
        return Fluxo(
            url = Net.base() + "/musica/audio?id=" + id + "&" + auth(),
            ua = "ZerounAutomed", cliente = "srv",
            expira = System.currentTimeMillis() + 3 * 3600_000L,
            titulo = MusicaStore.faixa(id)?.titulo ?: "Música",
            artista = MusicaStore.faixa(id)?.artista ?: "YouTube",
            duracao = MusicaStore.faixa(id)?.duracao ?: 0
        )
    }

    /** Escolhe o melhor áudio: m4a (AAC) de maior qualidade; se não tiver, qualquer áudio; por último o vídeo completo. */
    private fun melhorAudio(sd: JSONObject?): String? {
        if (sd == null) return null
        val ad = sd.optJSONArray("adaptiveFormats")
        var melhor: String? = null
        var nota = -1L
        if (ad != null) {
            for (i in 0 until ad.length()) {
                val f = ad.optJSONObject(i) ?: continue
                val mime = f.optString("mimeType")
                val u = f.optString("url")
                if (!mime.startsWith("audio/") || u.isBlank()) continue
                val n = f.optLong("bitrate", 0L) + (if (mime.contains("mp4")) 1_000_000_000L else 0L)
                if (n > nota) { nota = n; melhor = u }
            }
        }
        if (melhor != null) return melhor
        val fm = sd.optJSONArray("formats")
        if (fm != null) {
            for (i in 0 until fm.length()) {
                val u = fm.optJSONObject(i)?.optString("url").orEmpty()
                if (u.isNotBlank()) return u
            }
        }
        return null
    }
}

// ───────────────────────── JSON no celular ─────────────────────────

/**
 * Tudo num arquivo só: files/musica.json
 *   "faixas"   → músicas que o usuário clicou (não precisa pesquisar de novo)
 *   "streams"  → endereço do áudio já descoberto (toca na hora enquanto não vence)
 *   "buscas"   → resultados de cada pesquisa (repetir a busca não vai ao YouTube)
 *   "usuarios" → por usuário: quantas vezes ouviu e quando (Mais ouvidas / Recentes)
 * Fica no celular: continua aí quando a key acaba e quando se compra outra.
 */
object MusicaStore {
    private const val MAX_BUSCAS = 200
    private const val MAX_FAIXAS = 2000
    private val lock = Any()
    private val gravador = Executors.newSingleThreadExecutor()
    private var arquivo: File? = null
    private var iniciado = false

    private val faixas = LinkedHashMap<String, Som>()
    private val streams = HashMap<String, Fluxo>()
    private val buscas = LinkedHashMap<String, Pair<Long, List<Som>>>()
    private val usuarios = HashMap<String, HashMap<String, Uso>>()

    /** Sobe a cada mudança: as telas usam isso pra se atualizar. */
    var versao by mutableIntStateOf(0)
        private set

    fun init(c: Context) {
        if (iniciado) return
        iniciado = true
        val app = c.applicationContext
        Capas.init(app)
        Tocador.init(app)
        arquivo = File(app.filesDir, "musica.json")
        carregar()
    }

    private fun usuario(): String = Prefs.deviceId

    private fun faixaJson(f: Som): JSONObject = JSONObject()
        .put("id", f.id).put("titulo", f.titulo).put("artista", f.artista).put("duracao", f.duracao)

    private fun faixaDe(o: JSONObject): Som = Som(
        o.optString("id"), o.optString("titulo"), o.optString("artista"), o.optInt("duracao", 0)
    )

    private fun carregar() {
        try {
            val f = arquivo ?: return
            if (!f.exists()) return
            val raiz = JSONObject(f.readText(Charsets.UTF_8))
            synchronized(lock) {
                val fa = raiz.optJSONObject("faixas")
                if (fa != null) {
                    val ks = fa.keys()
                    while (ks.hasNext()) {
                        val k = ks.next()
                        val x = faixaDe(fa.getJSONObject(k))
                        if (x.id.isNotBlank()) faixas[k] = x
                    }
                }
                val st = raiz.optJSONObject("streams")
                if (st != null) {
                    val ks = st.keys()
                    while (ks.hasNext()) {
                        val k = ks.next()
                        val o = st.getJSONObject(k)
                        streams[k] = Fluxo(
                            o.optString("url"), o.optString("ua"), o.optString("cliente"), o.optLong("expira"),
                            o.optString("titulo"), o.optString("artista"), o.optInt("duracao")
                        )
                    }
                }
                val bu = raiz.optJSONObject("buscas")
                if (bu != null) {
                    val ks = bu.keys()
                    while (ks.hasNext()) {
                        val k = ks.next()
                        val o = bu.getJSONObject(k)
                        val arr = o.optJSONArray("itens") ?: JSONArray()
                        val lista = ArrayList<Som>()
                        for (i in 0 until arr.length()) lista.add(faixaDe(arr.getJSONObject(i)))
                        buscas[k] = Pair(o.optLong("ts"), lista)
                    }
                }
                val us = raiz.optJSONObject("usuarios")
                if (us != null) {
                    val ks = us.keys()
                    while (ks.hasNext()) {
                        val u = ks.next()
                        val m = HashMap<String, Uso>()
                        val o = us.getJSONObject(u)
                        val ids = o.keys()
                        while (ids.hasNext()) {
                            val id = ids.next()
                            val x = o.getJSONObject(id)
                            m[id] = Uso(x.optInt("plays"), x.optLong("ultimo"))
                        }
                        usuarios[u] = m
                    }
                }
            }
            versao = versao + 1
        } catch (e: Exception) {
            // arquivo estragado: começa do zero (o antigo é sobrescrito no próximo salvar)
        }
    }

    /** Monta o JSON agora (dentro do lock) e grava em segundo plano, sem travar a tela. */
    private fun salvar() {
        val alvo = arquivo ?: return
        val txt: String
        synchronized(lock) {
            val raiz = JSONObject()
            val fa = JSONObject(); faixas.forEach { (k, v) -> fa.put(k, faixaJson(v)) }
            val st = JSONObject()
            streams.forEach { (k, v) ->
                st.put(k, JSONObject().put("url", v.url).put("ua", v.ua).put("cliente", v.cliente)
                    .put("expira", v.expira).put("titulo", v.titulo).put("artista", v.artista).put("duracao", v.duracao))
            }
            val bu = JSONObject()
            buscas.forEach { (k, v) ->
                val arr = JSONArray(); v.second.forEach { arr.put(faixaJson(it)) }
                bu.put(k, JSONObject().put("ts", v.first).put("itens", arr))
            }
            val us = JSONObject()
            usuarios.forEach { (u, m) ->
                val o = JSONObject()
                m.forEach { (id, x) -> o.put(id, JSONObject().put("plays", x.plays).put("ultimo", x.ultimo)) }
                us.put(u, o)
            }
            raiz.put("versao", 1).put("faixas", fa).put("streams", st).put("buscas", bu).put("usuarios", us)
            txt = raiz.toString()
        }
        gravador.execute {
            try {
                val tmp = File(alvo.parentFile, "musica.json.tmp")
                tmp.writeText(txt, Charsets.UTF_8)
                if (!tmp.renameTo(alvo)) { alvo.writeText(txt, Charsets.UTF_8); tmp.delete() }
            } catch (e: Exception) { }
        }
    }

    private fun mudou() { Estado.ui { versao = versao + 1 } }

    // ── buscas ──

    private fun chave(q: String) = q.trim().lowercase().replace(Regex("\\s+"), " ")

    fun buscaCache(q: String): List<Som>? = synchronized(lock) { buscas[chave(q)]?.second }

    fun guardarBusca(q: String, lista: List<Som>) {
        synchronized(lock) {
            val k = chave(q)
            buscas.remove(k)
            buscas[k] = Pair(System.currentTimeMillis(), lista)
            while (buscas.size > MAX_BUSCAS) buscas.remove(buscas.keys.first())
        }
        salvar(); mudou()
    }

    // ── músicas clicadas ──

    fun guardarFaixa(f: Som) {
        synchronized(lock) {
            faixas.remove(f.id)
            faixas[f.id] = f
            while (faixas.size > MAX_FAIXAS) {
                val velho = faixas.keys.first()
                faixas.remove(velho); streams.remove(velho)
            }
        }
        salvar()
    }

    fun faixa(id: String): Som? = synchronized(lock) { faixas[id] }

    // ── endereço do áudio ──

    /** Só devolve se ainda vale por mais de 10 minutos. */
    fun stream(id: String): Fluxo? = synchronized(lock) {
        val s = streams[id]
        if (s != null && s.url.isNotBlank() && s.expira - System.currentTimeMillis() > 10 * 60_000L) s else null
    }

    fun guardarStream(id: String, fl: Fluxo) {
        synchronized(lock) { streams[id] = fl }
        salvar()
    }

    // ── histórico do usuário ──

    fun registrarPlay(f: Som) {
        synchronized(lock) {
            val m = usuarios.getOrPut(usuario()) { HashMap() }
            val antes = m[f.id]
            m[f.id] = Uso((antes?.plays ?: 0) + 1, System.currentTimeMillis())
        }
        salvar(); mudou()
    }

    fun recentes(n: Int): List<ItemUso> = synchronized(lock) {
        val m = usuarios[usuario()] ?: return emptyList()
        m.entries.sortedByDescending { it.value.ultimo }
            .mapNotNull { e -> faixas[e.key]?.let { ItemUso(it, e.value) } }
            .take(n)
    }

    fun maisOuvidas(n: Int): List<ItemUso> = synchronized(lock) {
        val m = usuarios[usuario()] ?: return emptyList()
        m.entries.filter { it.value.plays > 0 }
            .sortedWith(compareByDescending<Map.Entry<String, Uso>> { it.value.plays }.thenByDescending { it.value.ultimo })
            .mapNotNull { e -> faixas[e.key]?.let { ItemUso(it, e.value) } }
            .take(n)
    }

    fun limparHistorico() {
        synchronized(lock) { usuarios.remove(usuario()) }
        salvar(); mudou()
    }

    fun totalFaixas(): Int = synchronized(lock) { faixas.size }
    fun totalBuscas(): Int = synchronized(lock) { buscas.size }
}

// ───────────────────────── capas (miniaturas) ─────────────────────────

/** Baixa a capa uma vez e guarda no celular (files/capas) — da próxima vez abre na hora, até sem internet. */
object Capas {
    private var dir: File? = null
    private val mem = object : android.util.LruCache<String, ImageBitmap>(80) {}

    fun init(c: Context) { dir = File(c.filesDir, "capas").apply { mkdirs() } }

    fun memoria(id: String): ImageBitmap? = mem.get(id)

    fun carregar(id: String): ImageBitmap? {
        val cacheado = mem.get(id)
        if (cacheado != null) return cacheado
        val d = dir ?: return null
        val f = File(d, "$id.jpg")
        if (!f.exists() || f.length() < 100L) {
            try {
                val c = URL("https://i.ytimg.com/vi/$id/mqdefault.jpg").openConnection() as HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 10000
                if (c.responseCode == 200) {
                    val tmp = File(d, "$id.tmp")
                    c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                    tmp.renameTo(f)
                }
                c.disconnect()
            } catch (e: Exception) { }
        }
        val bmp = try { BitmapFactory.decodeFile(f.absolutePath) } catch (e: Exception) { null }
        if (bmp == null) return null
        val img = bmp.asImageBitmap()
        mem.put(id, img)
        return img
    }
}

// ───────────────────────── busca (estado da tela) ─────────────────────────

object MusicaBusca {
    var texto by mutableStateOf("")
    var resultados by mutableStateOf<List<Som>?>(null)
    var doCache by mutableStateOf(false)
    var buscando by mutableStateOf(false)
    var erro by mutableStateOf("")

    fun limpar() { texto = ""; resultados = null; erro = ""; doCache = false }

    /** [forcar] = ignora o que está salvo e pesquisa de novo no YouTube. */
    fun pesquisar(forcar: Boolean = false) {
        val q = texto.trim()
        if (q.isEmpty() || buscando) return
        erro = ""
        if (!forcar) {
            val salvo = MusicaStore.buscaCache(q)
            if (salvo != null) { resultados = salvo; doCache = true; return }
        }
        buscando = true
        Thread {
            try {
                val lista = YT.buscar(q)
                MusicaStore.guardarBusca(q, lista)
                Estado.ui { resultados = lista; doCache = false; buscando = false }
            } catch (e: Exception) {
                val msg = e.message ?: YT.detalhe(e)
                Estado.ui { buscando = false; erro = msg }
            }
        }.start()
    }
}
