package com.zeroun.automed

import android.media.MediaPlayer
import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.LoudnessEnhancer
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * VOLUME DA MÚSICA (só do player do app; não mexe no volume do celular).
 *
 * nivel 0..100:
 *  • 0        = OFF (mudo)
 *  • 1..70    = volume REAL do player (MediaPlayer.setVolume) — de bem baixinho (1) até o normal (70).
 *               Isso funciona em qualquer aparelho, na hora, sem depender de efeito nenhum.
 *  • 71..100  = REFORÇO acima do normal (LoudnessEnhancer; se o aparelho não tiver, DynamicsProcessing).
 *
 * Assim o controle SEMPRE faz diferença audível: abaixa, desliga e (quando o aparelho deixa) aumenta.
 * [status] mostra no player o que pegou.
 */
object Reforco {
    private const val PONTO_NORMAL = 70  // daqui para baixo: só volume do player • daqui para cima: reforço
    private const val PISO_DB = 30.0     // nível 1 = −30 dB (bem baixo, mas dá para ouvir)
    private const val MAX_MB = 1000      // LoudnessEnhancer: +10 dB no máximo
    private const val MAX_DB_DP = 8f     // DynamicsProcessing (plano B): +8 dB no máximo

    var nivel by mutableIntStateOf(100)
        private set

    /** Texto de diagnóstico mostrado no player. */
    var status by mutableStateOf("")
        private set

    private var player: MediaPlayer? = null
    private var le: LoudnessEnhancer? = null
    private var dp: DynamicsProcessing? = null
    private var carregado = false
    private var abafado = false          // outro app pediu para baixar o volume (ex.: aviso do GPS)
    private var diagEfeito = ""

    fun init() {
        if (carregado) return
        try { nivel = Prefs.volume; carregado = true } catch (e: Exception) { }
    }

    fun definir(n: Int, salvar: Boolean) {
        nivel = n.coerceIn(0, 100)
        aplicar()
        if (salvar) { try { Prefs.volume = nivel } catch (e: Exception) { } }
    }

    /** Foco de áudio: true = baixa para 25% (outro som por cima) • false = volta ao que o controle mandar. */
    fun abafar(b: Boolean) {
        abafado = b
        aplicarVolumePlayer()
    }

    fun ligar(p: MediaPlayer) {
        init()
        soltar()
        player = p
        abafado = false
        val sessao = try { p.audioSessionId } catch (e: Exception) { 0 }
        val msg = StringBuilder()

        if (sessao > 0) {
            try {
                le = LoudnessEnhancer(sessao)
                msg.append("reforço LE ok")
            } catch (e: Throwable) {
                le = null
                msg.append("LE falhou: ").append(e.javaClass.simpleName)
            }
            // plano B só se o LE não existir (os dois juntos distorcem)
            if (le == null && Build.VERSION.SDK_INT >= 28) {
                try {
                    dp = criarDp(sessao)
                    msg.append(" · DP ok")
                } catch (e: Throwable) {
                    dp = null
                    msg.append(" · DP falhou: ").append(e.javaClass.simpleName)
                }
            }
        } else {
            msg.append("sem sessão de áudio")
        }
        if (le == null && dp == null) msg.append(" — acima de 70 não aumenta neste aparelho; de 0 a 70 funciona normal")
        diagEfeito = msg.toString()
        aplicar()
    }

    fun soltar() {
        val a = le; le = null
        if (a != null) { try { a.release() } catch (x: Throwable) { } }
        val b = dp; dp = null
        if (b != null) { try { b.release() } catch (x: Throwable) { } }
        player = null
    }

    @Suppress("NewApi")
    private fun criarDp(sessao: Int): DynamicsProcessing {
        val cfg = DynamicsProcessing.Config.Builder(
            DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
            2, false, 0, false, 0, false, 0, true
        ).build()
        val d = DynamicsProcessing(0, sessao, cfg)
        val lim = DynamicsProcessing.Limiter(true, true, 0, 1f, 60f, 10f, -2f, 0f)
        d.setLimiterAllChannelsTo(lim)
        return d
    }

    /** 0 = mudo • 1..70 = −30 dB … 0 dB (curva em dB: soa uniforme) • acima de 70 = 1 (normal; o resto é reforço). */
    private fun ganhoPlayer(): Float {
        if (nivel <= 0) return 0f
        val t = minOf(nivel, PONTO_NORMAL) / PONTO_NORMAL.toDouble()
        return Math.pow(10.0, (-PISO_DB / 20.0) * (1.0 - t)).toFloat()
    }

    /** 0..1 = quanto do reforço está ligado (0 em 70 ou menos • 1 em 100). */
    private fun fracaoReforco(): Float =
        if (nivel <= PONTO_NORMAL) 0f else (nivel - PONTO_NORMAL) / (100f - PONTO_NORMAL)

    private fun aplicarVolumePlayer() {
        val v = ganhoPlayer() * (if (abafado) 0.25f else 1f)
        try { player?.setVolume(v, v) } catch (x: Throwable) { }
    }

    @Suppress("NewApi")
    private fun aplicar() {
        aplicarVolumePlayer()
        val f = fracaoReforco()
        val ligado = f > 0f
        try {
            le?.let {
                it.setTargetGain((f * MAX_MB).toInt())
                it.setEnabled(ligado)
            }
        } catch (x: Throwable) { }
        try {
            dp?.let {
                it.setInputGainAllChannelsTo(f * MAX_DB_DP)
                it.setEnabled(ligado)
            }
        } catch (x: Throwable) { }
        status = diagEfeito
    }
}
