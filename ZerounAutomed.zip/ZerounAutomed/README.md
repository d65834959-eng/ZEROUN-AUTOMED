# ZEROUN AUTOMED (Android)
1. Instale o Android Studio e abra a pasta ZerounAutomed (ele baixa o Gradle sozinho).
2. Build > Build APK(s). O arquivo sai em app/build/outputs/apk/debug/app-debug.apk
3. No celular: instale o APK, abra o app, toque em "Permitir acesso às notificações" e ative ZEROUN AUTOMED.
4. Digite o endereço do bot (IP:porta do servidor OAuth) e a sua key (a mesma ativada no Discord) e toque em Conectar.
5. Escolha até 5 apps e ligue Gmail / Pagamentos.
Dica: no Xiaomi/Samsung, tire a economia de bateria do app para ele não ser fechado.

## Sem PC (pelo GitHub)
Suba esta pasta inteira (com .github) num repositório do GitHub. Aba Actions > Build APK > Run workflow.
Quando terminar, baixe o artefato "ZEROUN-AUTOMED-apk" (é um .zip com o app-debug.apk dentro).
