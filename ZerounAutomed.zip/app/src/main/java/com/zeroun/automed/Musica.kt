package com.zeroun.automed

import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/*
 * MÚSICA — SOMENTE DEEZER (busca + capa + áudio completo autenticado pelo cookie ARL).
 */

/** Uma música do Deezer. */
data class Som(val id: String, val titulo: String, val artista: String, val duracao: Int)

/** Quantas vezes UM usuário ouviu a música e quando foi a última vez. */
data class Uso(val plays: Int, val ultimo: Long)

/** Música + uso (para as listas "Mais ouvidas" e "Recentes"). */
data class ItemUso(val faixa: Som, val uso: Uso)

/** Playlist do usuário (a "favoritas" é fixa e criada sozinha). */
data class Playlist(val id: String, val nome: String, val faixas: List<String>, val criada: Long)

const val ID_FAV = "favoritas"

/** Arquivo local já descriptografado e pronto para tocar no MediaPlayer. */
data class Fluxo(
    val url: String,
    val ua: String,
    val cliente: String,
    val expira: Long,
    val titulo: String,
    val artista: String,
    val duracao: Int
)

// ───────────────────────── Deezer (busca + streaming completo via ARL) ─────────────────────────

object YT {
    private const val UA_WEB =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    private const val BF_SECRET = "g4el58wc0zvf9na1"
    private val BF_IV = byteArrayOf(0, 1, 2, 3, 4, 5, 6, 7)

    private val reLinkDeezer = Regex("deezer\\.com/(?:[a-z]{2}/)?track/(\\d+)", RegexOption.IGNORE_CASE)

    private val dzInfo = ConcurrentHashMap<String, Som>()
    private val dzCapa = ConcurrentHashMap<String, String>()
    private val dzToken = ConcurrentHashMap<String, String>()

    @Volatile private var sessaoApiToken = ""
    @Volatile private var sessaoLicenseToken = ""
    @Volatile private var sessaoSid = ""
    @Volatile private var sessaoExpira = 0L
    private val lockSessao = Any()

    fun tentativas(@Suppress("UNUSED_PARAMETER") id: String): Int = 2

    fun idDoLink(texto: String): String? {
        val t = texto.trim()
        if (!t.startsWith("http", ignoreCase = true)) return null
        val m = reLinkDeezer.find(t)?.groupValues?.get(1) ?: return null
        return "dz_$m"
    }

    private fun normalizarId(id: String): String =
        if (id.startsWith("dz_")) id.removePrefix("dz_") else id

    private fun pegarJson(url: String, ms: Int = 8_000): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = ms
            c.readTimeout = ms
            c.setRequestProperty("User-Agent", UA_WEB)
            c.setRequestProperty("Accept", "application/json")
            if (c.responseCode !in 200..299) throw IOException("Deezer HTTP " + c.responseCode)
            val txt = c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            return JSONObject(txt)
        } finally {
            c.disconnect()
        }
    }

    private fun postarDeezer(url: String, corpo: JSONObject, arl: String, sid: String = "", ms: Int = 10_000): Pair<JSONObject, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = ms
            c.readTimeout = ms
            c.doOutput = true
            c.setRequestProperty("User-Agent", UA_WEB)
            c.setRequestProperty("Accept", "application/json")
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("Origin", "https://www.deezer.com")
            c.setRequestProperty("Referer", "https://www.deezer.com/")
            val cookie = buildString {
                append("arl=").append(arl)
                if (sid.isNotBlank()) append("; sid=").append(sid)
            }
            c.setRequestProperty("Cookie", cookie)
            c.outputStream.use { it.write(corpo.toString().toByteArray(Charsets.UTF_8)) }

            var novoSid = sid
            val setCookies = c.headerFields["Set-Cookie"].orEmpty()
            for (sc in setCookies) {
                if (sc.startsWith("sid=")) {
                    novoSid = sc.substringAfter("sid=").substringBefore(";").trim()
                }
            }

            val ok = c.responseCode in 200..299
            val txt = (if (ok) c.inputStream else c.errorStream)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (!ok) throw IOException("Deezer HTTP " + c.responseCode)
            return Pair(JSONObject(txt), novoSid)
        } finally {
            c.disconnect()
        }
    }

    fun buscar(consulta: String): List<Som> = buscarProgressivo(consulta) { _, _ -> }

    fun buscarProgressivo(consulta: String, aoMudar: (List<Som>, Boolean) -> Unit): List<Som> {
        val q = consulta.trim()
        val dzId = idDoLink(q)
        if (dzId != null) {
            val r = listOf(infoTrack(dzId))
            aoMudar(r, true)
            return r
        }
        if (q.startsWith("http", ignoreCase = true)) {
            throw IOException("Cole apenas um link de música do Deezer ou digite o nome da música.")
        }
        val r = buscarDeezer(q)
        aoMudar(r, true)
        return r
    }

    private fun infoTrack(id: String): Som {
        val raw = normalizarId(id)
        val o = pegarJson("https://api.deezer.com/track/$raw", 8_000)
        if (o.has("error")) {
            throw IOException("Deezer: " + o.optJSONObject("error")?.optString("message").orEmpty())
        }
        val dzKey = "dz_$raw"
        val titulo = o.optString("title").ifBlank { "Música" }
        val artista = o.optJSONObject("artist")?.optString("name").orEmpty().ifBlank { "Artista" }
        val dur = o.optInt("duration", 0)
        val som = Som(dzKey, titulo, artista, dur)
        dzInfo[dzKey] = som
        val capa = o.optJSONObject("album")?.optString("cover_big").orEmpty()
        if (capa.startsWith("http")) dzCapa[dzKey] = capa
        val tok = o.optString("track_token")
        if (tok.isNotBlank()) dzToken[dzKey] = tok
        return som
    }

    private fun buscarDeezer(q: String): List<Som> {
        val j = pegarJson("https://api.deezer.com/search/track?limit=20&q=" + java.net.URLEncoder.encode(q, "UTF-8"), 8_000)
        val arr = j.optJSONArray("data") ?: throw IOException("Deezer: " + j.optJSONObject("error")?.optString("message").orEmpty())
        val out = ArrayList<Som>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val rawId = o.optLong("id", 0L)
            if (rawId <= 0L) continue
            val id = "dz_$rawId"
            val dur = o.optInt("duration", 0)
            val titulo = o.optString("title")
            if (titulo.isBlank() || dur <= 0) continue
            val som = Som(id, titulo, o.optJSONObject("artist")?.optString("name").orEmpty().ifBlank { "Artista" }, dur)
            dzInfo[id] = som
            val capa = o.optJSONObject("album")?.optString("cover_big").orEmpty()
            if (capa.startsWith("http")) dzCapa[id] = capa
            val tok = o.optString("track_token")
            if (tok.isNotBlank()) dzToken[id] = tok
            if (out.none { it.id == id }) out.add(som)
        }
        if (out.isEmpty()) throw IOException("Não achei nenhuma música no Deezer com essa busca.")
        return out
    }

    fun capaDeezer(id: String): String {
        val dzKey = "dz_" + normalizarId(id)
        dzCapa[dzKey]?.let { return it }
        return try {
            val u = pegarJson("https://api.deezer.com/track/" + normalizarId(id), 8_000)
                .optJSONObject("album")?.optString("cover_big").orEmpty()
            if (u.startsWith("http")) dzCapa[dzKey] = u
            u
        } catch (e: Exception) { "" }
    }

    private fun garantirSessaoDeezer(forcar: Boolean = false): Triple<String, String, String> {
        val arl = Prefs.deezerArl
        if (arl.isBlank()) throw IOException("ARL do Deezer não configurado.")
        synchronized(lockSessao) {
            if (!forcar && sessaoApiToken.isNotBlank() && sessaoLicenseToken.isNotBlank() && System.currentTimeMillis() < sessaoExpira) {
                return Triple(sessaoApiToken, sessaoLicenseToken, sessaoSid)
            }
            val (j, sid) = postarDeezer(
                "https://www.deezer.com/ajax/gw-light.php?method=deezer.getUserData&input=3&api_version=1.0&api_token=",
                JSONObject(),
                arl
            )
            val res = j.optJSONObject("results") ?: throw IOException("Falha ao autenticar conta Deezer.")
            val user = res.optJSONObject("USER")
            val userId = user?.optLong("USER_ID", 0L) ?: 0L
            if (userId <= 0L) throw IOException("Conta Deezer inválida ou ARL expirado.")
            val apiToken = res.optString("checkForm")
            val licenseToken = user?.optJSONObject("OPTIONS")?.optString("license_token").orEmpty()
            if (apiToken.isBlank() || licenseToken.isBlank()) {
                throw IOException("Não foi possível obter o token de reprodução da conta Deezer.")
            }
            sessaoApiToken = apiToken
            sessaoLicenseToken = licenseToken
            sessaoSid = sid
            sessaoExpira = System.currentTimeMillis() + 20 * 60_000L
            return Triple(apiToken, licenseToken, sid)
        }
    }

    private fun obterTrackToken(rawTrackId: String, apiToken: String, sid: String): String {
        val dzKey = "dz_$rawTrackId"
        dzToken[dzKey]?.let { if (it.isNotBlank()) return it }

        val arl = Prefs.deezerArl
        val (j, _) = postarDeezer(
            "https://www.deezer.com/ajax/gw-light.php?method=song.getData&input=3&api_version=1.0&api_token=$apiToken",
            JSONObject().put("sng_id", rawTrackId),
            arl,
            sid
        )
        val res = j.optJSONObject("results") ?: throw IOException("Faixa não encontrada no Deezer.")
        val tok = res.optString("TRACK_TOKEN")
        if (tok.isBlank()) throw IOException("Deezer não liberou TRACK_TOKEN para esta faixa.")
        dzToken[dzKey] = tok
        return tok
    }

    private fun obterUrlCriptografadaDeezer(rawTrackId: String, forcarSessao: Boolean = false): String {
        val (apiToken, licenseToken, sid) = garantirSessaoDeezer(forcarSessao)
        val trackToken = obterTrackToken(rawTrackId, apiToken, sid)

        val formatos = JSONArray()
            .put(JSONObject().put("cipher", "BF_CBC_STRIPE").put("format", "MP3_320"))
            .put(JSONObject().put("cipher", "BF_CBC_STRIPE").put("format", "MP3_128"))
            .put(JSONObject().put("cipher", "BF_CBC_STRIPE").put("format", "MP3_MISC"))

        val mediaObj = JSONObject()
            .put("type", "FULL")
            .put("formats", formatos)

        val body = JSONObject()
            .put("license_token", licenseToken)
            .put("media", JSONArray().put(mediaObj))
            .put("track_tokens", JSONArray().put(trackToken))

        val c = URL("https://media.deezer.com/v1/get_url").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 10_000
            c.readTimeout = 12_000
            c.doOutput = true
            c.setRequestProperty("User-Agent", UA_WEB)
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("Accept", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val ok = c.responseCode in 200..299
            val txt = (if (ok) c.inputStream else c.errorStream)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (!ok) {
                if (!forcarSessao) return obterUrlCriptografadaDeezer(rawTrackId, true)
                throw IOException("Deezer media HTTP " + c.responseCode)
            }
            val resp = JSONObject(txt)
            val dataArr = resp.optJSONArray("data") ?: throw IOException("Sem mídia retornada pelo Deezer.")
            val first = dataArr.optJSONObject(0) ?: throw IOException("Resposta vazia do Deezer.")
            val mediaArr = first.optJSONArray("media")
            if (mediaArr == null || mediaArr.length() == 0) {
                val errs = first.optJSONArray("errors")
                val msg = errs?.optJSONObject(0)?.optString("message").orEmpty()
                throw IOException(if (msg.isNotBlank()) "Deezer: $msg" else "Faixa indisponível nessa conta Deezer.")
            }
            val sources = mediaArr.optJSONObject(0)?.optJSONArray("sources")
            val streamUrl = sources?.optJSONObject(0)?.optString("url").orEmpty()
            if (!streamUrl.startsWith("http")) throw IOException("URL de áudio inválida do Deezer.")
            return streamUrl
        } finally {
            c.disconnect()
        }
    }

    private fun chaveBlowfishDeezer(rawTrackId: String): ByteArray {
        val md5 = MessageDigest.getInstance("MD5").digest(rawTrackId.toByteArray(Charsets.UTF_8))
        val hex = md5.joinToString("") { "%02x".format(it) }
        val key = ByteArray(16)
        for (i in 0 until 16) {
            val b = hex[i].code xor hex[i + 16].code xor BF_SECRET[i].code
            key[i] = b.toByte()
        }
        return key
    }

    /**
     * Baixa o stream criptografado do Deezer e grava o MP3 completo já descriptografado no [destino].
     */
    fun baixarEConstruirMp3Deezer(id: String, destino: File) {
        val rawTrackId = normalizarId(id)
        if (!rawTrackId.all { it.isDigit() }) {
            throw IOException("Esta música não é do Deezer.")
        }
        val streamUrl = obterUrlCriptografadaDeezer(rawTrackId, false)
        val bfKey = chaveBlowfishDeezer(rawTrackId)
        val keySpec = SecretKeySpec(bfKey, "Blowfish")
        val ivSpec = IvParameterSpec(BF_IV)

        val tmp = File(destino.parentFile, destino.name + ".tmp")
        val c = URL(streamUrl).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 12_000
            c.readTimeout = 30_000
            c.setRequestProperty("User-Agent", UA_WEB)
            if (c.responseCode !in 200..299) throw IOException("CDN Deezer HTTP " + c.responseCode)

            c.inputStream.use { input ->
                FileOutputStream(tmp).use { out ->
                    val chunk = ByteArray(2048)
                    var chunkIndex = 0
                    while (true) {
                        val read = lerExato(input, chunk)
                        if (read <= 0) break
                        if (read == 2048 && chunkIndex % 3 == 0) {
                            val cipher = Cipher.getInstance("Blowfish/CBC/NoPadding")
                            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec)
                            out.write(cipher.doFinal(chunk))
                        } else {
                            out.write(chunk, 0, read)
                        }
                        chunkIndex++
                    }
                }
            }
        } catch (e: Exception) {
            tmp.delete()
            throw e
        } finally {
            c.disconnect()
        }

        if (tmp.length() < 20_000L || !tmp.renameTo(destino)) {
            tmp.delete()
            throw IOException("Falha ao salvar áudio completo do Deezer.")
        }
    }

    private fun lerExato(input: InputStream, buf: ByteArray): Int {
        var total = 0
        while (total < buf.size) {
            val n = input.read(buf, total, buf.size - total)
            if (n < 0) break
            total += n
        }
        return total
    }

    /**
     * Resolve o áudio completo exclusivamente pela conta Deezer e entrega um arquivo local pronto para tocar.
     */
    fun resolver(id: String, @Suppress("UNUSED_PARAMETER") evitar: Set<String>, @Suppress("UNUSED_PARAMETER") soDireto: Boolean = false): Fluxo {
        val rawId = normalizarId(id)
        if (!rawId.all { it.isDigit() }) {
            throw IOException("Somente músicas do Deezer são suportadas.")
        }
        val dzId = "dz_$rawId"
        val f0 = MusicaStore.faixa(dzId) ?: dzInfo[dzId] ?: infoTrack(dzId)

        Baixados.arquivo(dzId)?.let { arq ->
            return Fluxo(arq.absolutePath, "", "deezer_local", Long.MAX_VALUE, f0.titulo, f0.artista, f0.duracao)
        }
        Pre.arquivo(dzId)?.let { arq ->
            return Fluxo(arq.absolutePath, "", "deezer_cache", Long.MAX_VALUE, f0.titulo, f0.artista, f0.duracao)
        }

        val destino = Pre.arquivoDestino(dzId)
            ?: throw IOException("Armazenamento de áudio não inicializado.")
        baixarEConstruirMp3Deezer(dzId, destino)
        Pre.limparCache()
        return Fluxo(destino.absolutePath, "", "deezer_arl", Long.MAX_VALUE, f0.titulo, f0.artista, f0.duracao)
    }

    fun motivo(@Suppress("UNUSED_PARAMETER") id: String): String =
        if (Prefs.deezerArl.isBlank()) "ARL do Deezer não configurado." else "Não foi possível obter a faixa completa pela conta Deezer."

    fun auth(): String =
        "k=" + java.net.URLEncoder.encode(Prefs.key.trim().uppercase(), "UTF-8") +
            "&d=" + java.net.URLEncoder.encode(Prefs.deviceId, "UTF-8")

    fun semRede(e: Exception): Boolean =
        e is java.net.UnknownHostException || e is java.net.ConnectException || e is java.net.SocketTimeoutException

    fun detalhe(e: Exception): String = e.javaClass.simpleName + (if (e.message.isNullOrBlank()) "" else ": " + e.message)
}

// ───────────────────────── JSON no celular ─────────────────────────

object MusicaStore {
    private const val MAX_BUSCAS = 200
    private const val MAX_FAIXAS = 2000
    private val lock = Any()
    private val gravador = Executors.newSingleThreadScheduledExecutor()
    private val salvarPendente = AtomicBoolean(false)
    private var arquivo: File? = null
    private var iniciado = false

    private val faixas = LinkedHashMap<String, Som>()
    private val streams = HashMap<String, Fluxo>()
    private val buscas = LinkedHashMap<String, Pair<Long, List<Som>>>()
    private val usuarios = HashMap<String, HashMap<String, Uso>>()
    private val playlists = LinkedHashMap<String, Playlist>()
    private val dicas = HashMap<String, Pair<String, String>>()

    var versao by mutableIntStateOf(0)
        private set

    fun init(c: Context) {
        if (iniciado) return
        iniciado = true
        val app = c.applicationContext
        Capas.init(app)
        Baixados.init(app)
        Pre.init(app)
        Tocador.init(app)
        arquivo = File(app.filesDir, "musica.json")
        carregar()
        synchronized(lock) { garantirFavoritas() }
        versao = versao + 1
    }

    private fun usuario(): String = Prefs.deviceId

    private fun faixaJson(f: Som): JSONObject = JSONObject()
        .put("id", f.id).put("titulo", f.titulo).put("artista", f.artista).put("duracao", f.duracao)

    private fun faixaDe(o: JSONObject): Som = Som(
        o.optString("id"), o.optString("titulo"), o.optString("artista"), o.optInt("duracao", 0)
    )

    private fun carregar() {
        try {
            val f = arquivo ?: return
            if (!f.exists()) return
            val raiz = JSONObject(f.readText(Charsets.UTF_8))
            synchronized(lock) {
                val fa = raiz.optJSONObject("faixas")
                if (fa != null) {
                    val ks = fa.keys()
                    while (ks.hasNext()) {
                        val k = ks.next()
                        val x = faixaDe(fa.getJSONObject(k))
                        if (x.id.startsWith("dz_")) faixas[k] = x
                    }
                }
                val bu = raiz.optJSONObject("buscas")
                if (bu != null) {
                    val ks = bu.keys()
                    while (ks.hasNext()) {
                        val k = ks.next()
                        val o = bu.getJSONObject(k)
                        val arr = o.optJSONArray("itens") ?: JSONArray()
                        val lista = ArrayList<Som>()
                        for (i in 0 until arr.length()) {
                            val s = faixaDe(arr.getJSONObject(i))
                            if (s.id.startsWith("dz_")) lista.add(s)
                        }
                        if (lista.isNotEmpty()) buscas[k] = Pair(o.optLong("ts"), lista)
                    }
                }
                val us = raiz.optJSONObject("usuarios")
                if (us != null) {
                    val ks = us.keys()
                    while (ks.hasNext()) {
                        val u = ks.next()
                        val m = HashMap<String, Uso>()
                        val o = us.getJSONObject(u)
                        val ids = o.keys()
                        while (ids.hasNext()) {
                            val id = ids.next()
                            if (!id.startsWith("dz_")) continue
                            val x = o.getJSONObject(id)
                            m[id] = Uso(x.optInt("plays"), x.optLong("ultimo"))
                        }
                        usuarios[u] = m
                    }
                }
                val pls = raiz.optJSONArray("playlists")
                if (pls != null) {
                    for (i in 0 until pls.length()) {
                        val o = pls.optJSONObject(i) ?: continue
                        val id = o.optString("id")
                        if (id.isBlank()) continue
                        val ids = ArrayList<String>()
                        val arr = o.optJSONArray("faixas") ?: JSONArray()
                        for (k in 0 until arr.length()) {
                            val fid = arr.optString(k)
                            if (fid.startsWith("dz_")) ids.add(fid)
                        }
                        playlists[id] = Playlist(id, o.optString("nome", "Playlist"), ids, o.optLong("criada"))
                    }
                }
            }
            versao = versao + 1
        } catch (e: Exception) { }
    }

    private fun salvar(urgente: Boolean = false) {
        if (arquivo == null) return
        if (urgente) { gravador.execute { salvarPendente.set(false); gravarAgora() }; return }
        if (!salvarPendente.compareAndSet(false, true)) return
        gravador.schedule({ salvarPendente.set(false); gravarAgora() }, 700L, TimeUnit.MILLISECONDS)
    }

    private fun gravarAgora() {
        val alvo = arquivo ?: return
        val txt: String
        synchronized(lock) {
            val raiz = JSONObject()
            val fa = JSONObject(); faixas.forEach { (k, v) -> fa.put(k, faixaJson(v)) }
            val st = JSONObject()
            streams.forEach { (k, v) ->
                st.put(k, JSONObject().put("url", v.url).put("ua", v.ua).put("cliente", v.cliente)
                    .put("expira", v.expira).put("titulo", v.titulo).put("artista", v.artista).put("duracao", v.duracao))
            }
            val bu = JSONObject()
            buscas.forEach { (k, v) ->
                val arr = JSONArray(); v.second.forEach { arr.put(faixaJson(it)) }
                bu.put(k, JSONObject().put("ts", v.first).put("itens", arr))
            }
            val us = JSONObject()
            usuarios.forEach { (u, m) ->
                val o = JSONObject()
                m.forEach { (id, x) -> o.put(id, JSONObject().put("plays", x.plays).put("ultimo", x.ultimo)) }
                us.put(u, o)
            }
            val pl = JSONArray()
            playlists.values.forEach { p ->
                val ids = JSONArray(); p.faixas.forEach { ids.put(it) }
                pl.put(JSONObject().put("id", p.id).put("nome", p.nome).put("criada", p.criada).put("faixas", ids))
            }
            raiz.put("playlists", pl)
            val di = JSONObject()
            dicas.forEach { (k, v) -> di.put(k, JSONObject().put("p", v.first).put("a", v.second)) }
            raiz.put("dicas", di)
            raiz.put("versao", 1).put("faixas", fa).put("streams", st).put("buscas", bu).put("usuarios", us)
            txt = raiz.toString()
        }
        try {
            val tmp = File(alvo.parentFile, "musica.json.tmp")
            tmp.writeText(txt, Charsets.UTF_8)
            if (!tmp.renameTo(alvo)) { alvo.writeText(txt, Charsets.UTF_8); tmp.delete() }
        } catch (e: Exception) { }
    }

    fun mudou() { Estado.ui { versao = versao + 1 } }

    private fun chave(q: String) = q.trim().lowercase().replace(Regex("\\s+"), " ")

    fun buscaCache(q: String): List<Som>? = synchronized(lock) { buscas[chave(q)]?.second }

    fun buscasRecentes(n: Int): List<String> = synchronized(lock) {
        buscas.keys.toList().asReversed().filter { !it.startsWith("http") }.take(n)
    }

    fun apagarBusca(q: String) {
        synchronized(lock) { buscas.remove(chave(q)) }
        salvar(); mudou()
    }

    fun guardarBusca(q: String, lista: List<Som>) {
        synchronized(lock) {
            val k = chave(q)
            buscas.remove(k)
            buscas[k] = Pair(System.currentTimeMillis(), lista)
            while (buscas.size > MAX_BUSCAS) buscas.remove(buscas.keys.first())
        }
        salvar(); mudou()
    }

    fun guardarFaixa(f: Som) {
        if (!f.id.startsWith("dz_")) return
        synchronized(lock) {
            faixas.remove(f.id)
            faixas[f.id] = f
            while (faixas.size > MAX_FAIXAS) {
                val emUso = playlists.values.flatMap { it.faixas }.toSet()
                val velho = faixas.keys.firstOrNull { it !in emUso } ?: break
                faixas.remove(velho); streams.remove(velho)
            }
        }
        salvar()
    }

    fun faixa(id: String): Som? = synchronized(lock) { faixas[id] }

    fun todasFaixas(): List<Som> = synchronized(lock) { faixas.values.toList() }

    private fun garantirFavoritas() {
        if (playlists.containsKey(ID_FAV)) return
        val resto = LinkedHashMap(playlists)
        playlists.clear()
        playlists[ID_FAV] = Playlist(ID_FAV, "Músicas Favoritas", emptyList(), System.currentTimeMillis())
        playlists.putAll(resto)
    }

    fun listaPlaylists(): List<Playlist> = synchronized(lock) { playlists.values.toList() }

    fun playlist(id: String): Playlist? = synchronized(lock) { playlists[id] }

    fun faixasDaPlaylist(id: String): List<Som> = synchronized(lock) {
        val ids = playlists[id]?.faixas ?: return emptyList()
        val lista = ids.mapNotNull { faixas[it] }
        if (id == ID_FAV) lista.reversed() else lista
    }

    fun criarPlaylist(nome: String): String {
        val n = nome.trim().ifBlank { "Minha playlist" }.take(60)
        val id = "pl_" + System.currentTimeMillis().toString(36) + (100..999).random()
        synchronized(lock) { playlists[id] = Playlist(id, n, emptyList(), System.currentTimeMillis()) }
        salvar(true); mudou()
        return id
    }

    fun importarPlaylist(nome: String, lista: List<Som>): String {
        val n = nome.trim().ifBlank { "Playlist importada" }.take(60)
        val id = "pl_" + System.currentTimeMillis().toString(36) + (100..999).random()
        val apenasDz = lista.filter { it.id.startsWith("dz_") }
        synchronized(lock) {
            apenasDz.forEach { if (!faixas.containsKey(it.id)) faixas[it.id] = it }
            playlists[id] = Playlist(id, n, apenasDz.map { it.id }.distinct(), System.currentTimeMillis())
        }
        salvar(true); mudou()
        return id
    }

    fun renomearPlaylist(id: String, nome: String) {
        if (id == ID_FAV) return
        synchronized(lock) {
            val p = playlists[id] ?: return
            playlists[id] = p.copy(nome = nome.trim().ifBlank { p.nome }.take(60))
        }
        salvar(true); mudou()
    }

    fun excluirPlaylist(id: String) {
        if (id == ID_FAV) return
        synchronized(lock) { playlists.remove(id) }
        salvar(true); mudou()
    }

    fun naPlaylist(plId: String, faixaId: String): Boolean = synchronized(lock) { playlists[plId]?.faixas?.contains(faixaId) == true }

    fun emAlgumaPlaylist(id: String): Boolean = synchronized(lock) { playlists.values.any { it.faixas.contains(id) } }

    fun ehFavorita(faixaId: String): Boolean = naPlaylist(ID_FAV, faixaId)

    fun alternarNaPlaylist(plId: String, f: Som): Boolean {
        var dentro = false
        synchronized(lock) {
            val p = playlists[plId] ?: return false
            if (!faixas.containsKey(f.id)) faixas[f.id] = f
            if (p.faixas.contains(f.id)) {
                playlists[plId] = p.copy(faixas = p.faixas.filter { it != f.id })
            } else {
                playlists[plId] = p.copy(faixas = p.faixas + f.id)
                dentro = true
            }
        }
        salvar(true); mudou()
        if (dentro) Baixados.agendar(f)
        return dentro
    }

    fun alternarFavorita(f: Som): Boolean = alternarNaPlaylist(ID_FAV, f)

    fun removerDaPlaylist(plId: String, faixaId: String) {
        synchronized(lock) {
            val p = playlists[plId] ?: return
            playlists[plId] = p.copy(faixas = p.faixas.filter { it != faixaId })
        }
        salvar(true); mudou()
    }

    fun stream(id: String): Fluxo? = synchronized(lock) {
        val s = streams[id]
        if (s != null && s.url.isNotBlank() && File(s.url).exists()) s else null
    }

    fun guardarStream(id: String, fl: Fluxo) {
        synchronized(lock) { streams[id] = fl }
        salvar()
    }

    fun registrarPlay(f: Som) {
        synchronized(lock) {
            val m = usuarios.getOrPut(usuario()) { HashMap() }
            val antes = m[f.id]
            m[f.id] = Uso((antes?.plays ?: 0) + 1, System.currentTimeMillis())
        }
        salvar(); mudou()
    }

    fun recentes(n: Int): List<ItemUso> = synchronized(lock) {
        val m = usuarios[usuario()] ?: return emptyList()
        m.entries.sortedByDescending { it.value.ultimo }
            .mapNotNull { e -> faixas[e.key]?.let { ItemUso(it, e.value) } }
            .take(n)
    }

    fun maisOuvidas(n: Int): List<ItemUso> = synchronized(lock) {
        val m = usuarios[usuario()] ?: return emptyList()
        m.entries.filter { it.value.plays > 0 }
            .sortedWith(compareByDescending> { it.value.plays }.thenByDescending { it.value.ultimo })
            .mapNotNull { e -> faixas[e.key]?.let { ItemUso(it, e.value) } }
            .take(n)
    }

    fun limparHistorico() {
        synchronized(lock) { usuarios.remove(usuario()) }
        salvar(); mudou()
    }

    fun totalFaixas(): Int = synchronized(lock) { faixas.size }
    fun totalBuscas(): Int = synchronized(lock) { buscas.size }
}

// ───────────────────────── músicas baixadas (tocam SEM internet) ─────────────────────────

object Baixados {
    private var dir: File? = null
    private val andando = java.util.Collections.synchronizedSet(HashSet<String>())
    private val fila = Executors.newFixedThreadPool(3)

    private var app: Context? = null
    private val pend = java.util.Collections.synchronizedSet(HashSet<String>())
    private val falhas = ConcurrentHashMap<String, Long>()
    private const val MIN_LIVRE = 1_000_000_000L

    fun init(c: Context) {
        app = c.applicationContext
        dir = File(c.filesDir, "audio").apply { mkdirs() }
        val t = Thread {
            try { Thread.sleep(8_000L) } catch (e: Exception) { }
            while (true) {
                try { automatico() } catch (e: Exception) { }
                try { Thread.sleep(5 * 60_000L) } catch (e: Exception) { }
            }
        }
        t.isDaemon = true
        t.start()
    }

    private fun redeLivre(): Boolean {
        val cm = app?.getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager ?: return false
        val n = cm.activeNetwork ?: return false
        val cap = cm.getNetworkCapabilities(n) ?: return false
        return cap.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            cap.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
    }

    private fun automatico() {
        if (Prefs.key.isBlank() || !redeLivre()) return
        val d = dir ?: return
        if (d.usableSpace < MIN_LIVRE) return
        MusicaStore.todasFaixas().forEach { agendar(it) }
    }

    fun faltam(): Int = MusicaStore.todasFaixas().count { !tem(it.id) }

    fun arquivo(id: String): File? {
        val d = dir ?: return null
        val f = File(d, "$id.mp3")
        return if (f.exists() && f.length() > 20_000L) f else null
    }

    fun tem(id: String): Boolean = arquivo(id) != null

    fun baixando(id: String): Boolean = andando.contains(id)

    fun emAndamento(): Int = andando.size

    fun total(): Int = dir?.listFiles()?.count { it.name.endsWith(".mp3") } ?: 0

    fun apagar(id: String) {
        try { File(dir ?: return, "$id.mp3").delete() } catch (e: Exception) { }
        MusicaStore.mudou()
    }

    fun agendar(f: Som) {
        if (!f.id.startsWith("dz_") || tem(f.id) || andando.contains(f.id)) return
        val ultima = falhas[f.id]
        if (ultima != null && System.currentTimeMillis() - ultima < 3600_000L) return
        if (!pend.add(f.id)) return
        fila.execute {
            try { garantir(f) } finally { pend.remove(f.id) }
        }
    }

    fun baixarLista(lista: List<Som>) { lista.forEach { agendar(it) } }

    private fun garantir(f: Som) {
        if (tem(f.id) || !andando.add(f.id)) return
        MusicaStore.mudou()
        try {
            val d = dir ?: return
            val destino = File(d, "${f.id}.mp3")
            val pre = Pre.arquivo(f.id)
            if (pre != null && pre.copyTo(destino, overwrite = true).length() > 20_000L) {
                MusicaStore.guardarStream(f.id, Fluxo(destino.absolutePath, "", "deezer_local", Long.MAX_VALUE, f.titulo, f.artista, f.duracao))
            } else {
                YT.baixarEConstruirMp3Deezer(f.id, destino)
                MusicaStore.guardarStream(f.id, Fluxo(destino.absolutePath, "", "deezer_local", Long.MAX_VALUE, f.titulo, f.artista, f.duracao))
            }
            try { Capas.carregar(f.id) } catch (e: Exception) { }
        } catch (e: Exception) {
            falhas[f.id] = System.currentTimeMillis()
        } finally {
            andando.remove(f.id)
            MusicaStore.mudou()
        }
    }
}

// ───────────────────────── pré-carga (áudio completo do Deezer) ─────────────────────────

object Pre {
    private var dir: File? = null
    private val andando = java.util.Collections.synchronizedSet(HashSet<String>())
    private val pool = Executors.newFixedThreadPool(3)
    private const val MAX_MB = 400L

    fun init(c: Context) {
        dir = File(c.cacheDir, "pre").apply { mkdirs() }
        pool.execute { limparCache() }
    }

    fun arquivoDestino(id: String): File? {
        val d = dir ?: return null
        return File(d, "$id.mp3")
    }

    fun arquivo(id: String): File? {
        val d = dir ?: return null
        val f = File(d, "$id.mp3")
        return if (f.exists() && f.length() > 20_000L) {
            f.setLastModified(System.currentTimeMillis())
            f
        } else null
    }

    fun apagar(id: String) {
        try { File(dir ?: return, "$id.mp3").delete() } catch (e: Exception) { }
    }

    fun pedir(lista: List<Som>) { lista.forEach { pedir(it) } }

    fun pedir(f: Som) {
        if (!f.id.startsWith("dz_") || dir == null || Baixados.tem(f.id) || arquivo(f.id) != null || !andando.add(f.id)) return
        pool.execute {
            try {
                val dest = arquivoDestino(f.id) ?: return@execute
                YT.baixarEConstruirMp3Deezer(f.id, dest)
                MusicaStore.guardarStream(f.id, Fluxo(dest.absolutePath, "", "deezer_cache", Long.MAX_VALUE, f.titulo, f.artista, f.duracao))
                limparCache()
            } catch (e: Exception) {
            } finally {
                andando.remove(f.id)
            }
        }
    }

    fun emAndamento(id: String): Boolean = andando.contains(id)

    fun aquecerBusca(lista: List<Som>) {
        pedir(lista.take(3))
    }

    fun aquecerPrimeira(lista: List<Som>) {
        pedir(lista.take(1))
    }

    fun limparCache() {
        try {
            val arqs = (dir?.listFiles() ?: return).filter { it.isFile }
            var total = arqs.sumOf { it.length() }
            for (a in arqs.sortedBy { it.lastModified() }) {
                if (total <= MAX_MB * 1048576L) break
                if (andando.contains(a.name.substringBefore('.'))) continue
                total -= a.length()
                a.delete()
            }
        } catch (e: Exception) { }
    }
}

// ───────────────────────── capas (miniaturas do Deezer) ─────────────────────────

object Capas {
    private var dir: File? = null
    private val mem = object : android.util.LruCache<String, ImageBitmap>(80) {}

    fun init(c: Context) { dir = File(c.filesDir, "capas").apply { mkdirs() } }

    fun memoria(id: String): ImageBitmap? = mem.get(id)

    fun carregar(id: String): ImageBitmap? {
        val cacheado = mem.get(id)
        if (cacheado != null) return cacheado
        val d = dir ?: return null
        val f = File(d, "$id.jpg")
        if (!f.exists() || f.length() < 100L) {
            try {
                val urlCapa = YT.capaDeezer(id)
                if (urlCapa.startsWith("http")) {
                    val c = URL(urlCapa).openConnection() as HttpURLConnection
                    c.connectTimeout = 8000
                    c.readTimeout = 10000
                    if (c.responseCode == 200) {
                        val tmp = File(d, "$id.tmp")
                        c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                        tmp.renameTo(f)
                    }
                    c.disconnect()
                }
            } catch (e: Exception) { }
        }
        val bmp = try { BitmapFactory.decodeFile(f.absolutePath) } catch (e: Exception) { null }
        if (bmp == null) return null
        val img = bmp.asImageBitmap()
        mem.put(id, img)
        return img
    }
}

// ───────────────────────── busca (estado da tela) ─────────────────────────

object MusicaBusca {
    var texto by mutableStateOf("")
    var resultados by mutableStateOf<List<Som>?>(null)
    var doCache by mutableStateOf(false)
    var buscando by mutableStateOf(false)
    var erro by mutableStateOf("")
    private var geracao = 0

    fun limpar() { geracao++; texto = ""; resultados = null; erro = ""; doCache = false; buscando = false }

    fun pesquisar(forcar: Boolean = false) {
        val q = texto.trim()
        if (q.isEmpty()) return
        val g = ++geracao
        erro = ""
        if (!forcar) {
            val salvo = MusicaStore.buscaCache(q)
            if (salvo != null) { resultados = salvo; doCache = true; buscando = false; Pre.aquecerBusca(salvo); return }
        }
        buscando = true
        Thread {
            var primeira = true
            try {
                val lista = YT.buscarProgressivo(q) { parcial, fim ->
                    if (primeira) { primeira = false; Pre.aquecerPrimeira(parcial) }
                    if (fim) { MusicaStore.guardarBusca(q, parcial); Pre.aquecerBusca(parcial) }
                    Estado.ui { if (g == geracao) { resultados = parcial; doCache = false; buscando = false } }
                }
                if (lista.isEmpty()) Estado.ui { if (g == geracao) buscando = false }
            } catch (e: Exception) {
                val msg = if (YT.semRede(e)) "Sem internet. Você ainda pode tocar as músicas baixadas (aba Playlists)."
                else (e.message ?: YT.detalhe(e))
                Estado.ui { if (g == geracao) { buscando = false; erro = msg } }
            }
        }.start()
    }
}

// ───────────────────────── link de playlist (compartilhar / importar) ─────────────────────────

object LinkPlaylist {
    private const val PREFIXO = "zeroun://playlist/"
    private val re = Regex("zeroun://playlist/([A-Za-z0-9_\\-]+)")
    private val reId = Regex("^[A-Za-z0-9_\\-]{1,40}$")
    const val MAX = 300
    private const val FLAGS = android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING

    class Lida(val nome: String, val faixas: List<Som>)

    fun ehLink(texto: String): Boolean = re.containsMatchIn(texto)

    fun gerar(nome: String, lista: List<Som>): String {
        val arr = JSONArray()
        lista.take(MAX).forEach { arr.put(JSONArray().put(it.id).put(it.titulo).put(it.artista).put(it.duracao)) }
        val j = JSONObject().put("v", 1).put("n", nome).put("f", arr)
        val saida = java.io.ByteArrayOutputStream()
        java.util.zip.GZIPOutputStream(saida).use { it.write(j.toString().toByteArray(Charsets.UTF_8)) }
        return PREFIXO + android.util.Base64.encodeToString(saida.toByteArray(), FLAGS)
    }

    fun ler(texto: String): Lida {
        val token = re.find(texto)?.groupValues?.get(1) ?: throw Exception("Isso não parece um link de playlist da ZEROUN.")
        val txt = try {
            val bruto = android.util.Base64.decode(token, FLAGS)
            java.util.zip.GZIPInputStream(bruto.inputStream()).use { gz ->
                val buf = ByteArray(8192)
                val out = java.io.ByteArrayOutputStream()
                while (true) {
                    val n = gz.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    if (out.size() > 2_000_000) throw Exception("grande demais")
                }
                out.toString("UTF-8")
            }
        } catch (e: Exception) { throw Exception("Link incompleto ou estragado. Copie o link inteiro de novo.") }
        val j = try { JSONObject(txt) } catch (e: Exception) { throw Exception("Link incompleto ou estragado. Copie o link inteiro de novo.") }
        val arr = j.optJSONArray("f") ?: throw Exception("Esse link não tem músicas.")
        val lista = ArrayList<Som>()
        for (i in 0 until minOf(arr.length(), 500)) {
            val o = arr.optJSONArray(i) ?: continue
            val id = o.optString(0)
            if (!reId.matches(id) || !id.startsWith("dz_") || lista.any { it.id == id }) continue
            val titulo = o.optString(1).trim().take(200)
            if (titulo.isBlank()) continue
            lista.add(Som(id, titulo, o.optString(2).trim().take(120).ifBlank { "Deezer" }, o.optInt(3).coerceIn(0, 86_400)))
        }
        if (lista.isEmpty()) throw Exception("Esse link não tem músicas do Deezer.")
        return Lida(j.optString("n").trim().take(60).ifBlank { "Playlist importada" }, lista)
    }

    fun mensagem(nome: String, qtd: Int, link: String): String =
        "🎵 Playlist \"" + nome + "\" · " + qtd + (if (qtd == 1) " música" else " músicas") +
            "\nZEROUN MÚSICA → aba Playlists → \"Colar link\" e cole isto:\n" + link
}
