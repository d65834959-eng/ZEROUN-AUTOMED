# 🎵 Aba Música — "Mediação com música"

Botão **Música** na barra de baixo (entre *Salas* e *Controle*).

## O que tem na tela
| Parte | O que faz |
|---|---|
| 🔎 Barra de pesquisa | Digite o nome da música ou cole um link do YouTube (igual ao `!play` do `index.js`) |
| Resultados | Toque numa música para tocar. Ficam salvos: repetir a mesma busca **não vai ao YouTube** (botão *Atualizar* força uma busca nova) |
| 🔥 Mais ouvidas | As músicas que **o usuário** mais tocou (conta como ouvida quando o áudio realmente começa) |
| 🕘 Recentes | As últimas músicas **do usuário** (cada usuário só vê as suas) |
| ▶ Player (embaixo) | Play/pausa, anterior, próxima, barra de tempo e fechar. Continua tocando com a tela apagada (notificação com botões) |

## Como procura e toca (igual ao index.js)
| index.js (bot de call) | App (no celular) |
|---|---|
| `yt-dlp ytsearch1:<busca>` → título + link | `YT.buscar()` → busca no YouTube, devolve título, canal, duração e capa |
| `yt-dlp -f bestaudio` | `YT.resolver()` → pega o melhor áudio (m4a) |
| `cache` (busca → resultado) | `MusicaStore` → `files/musica.json` |
| `ffmpeg` → Discord | `MediaPlayer` toca no próprio celular |

## O que fica salvo no celular (`files/musica.json` + `files/capas/`)
- `faixas`: músicas em que o usuário clicou · `buscas`: resultado de cada pesquisa · `streams`: endereço do áudio (reaproveitado enquanto vale, ~6 h) · `usuarios`: plays e última vez de cada usuário.
- **Não usa a key nem o servidor.** Se a key acabar, tudo continua salvo; ao comprar outra, as músicas e buscas já estão lá (Sair/trocar de key não apaga nada).
- Entra no backup do Google (`allowBackup`), então reinstalar o app restaura.

## Se a música parar de tocar um dia
O YouTube muda de vez em quando (o mesmo acontece com o yt-dlp). A lista de "clientes" fica no topo de `Musica.kt` (`YT.clientes`): atualize as versões lá e lance o app de novo. A busca e o histórico não são afetados.

## Arquivos
`Musica.kt` (YouTube + JSON + capas + estado da busca) · `Tocador.kt` (player e serviço da notificação) · `MusicaUI.kt` (tela).

## Playlists e Favoritas (versão estilo Spotify)
- **Início / Buscar / Playlists** (botões no topo da aba). Cada música tem ❤ (guarda nas **Músicas Favoritas**) e ＋ (salvar em qualquer playlist ou criar uma nova na hora).
- A tela da playlist tem capa (mosaico 2x2), nome, ▶ tocar, 🔀 aleatório e ⋮ (renomear / excluir).
- Tocar na mini barra abre o **player grande** (capa, ❤, barra de tempo, anterior/próxima).
- Tudo fica em `files/musica.json` (chave `playlists`), junto com o resto da música.

## Por que a música demorava ~4 s (e o que mudou)
Antes: o app chamava `/musica/preparar` e depois `/musica/audio` (que ainda redirecionava para o CDN) → 2 idas ao servidor + redirecionamento.
Agora: `/musica/preparar` já devolve o endereço direto do CDN (`url`), o app toca direto de lá, o servidor pré-aquece as 3 primeiras músicas da busca, e o app pré-carrega a próxima música da fila.

## Sem internet (músicas baixadas)
- Música que está em **qualquer playlist (inclusive Favoritas)** é baixada sozinha para o celular (`files/audio/`). No topo da playlist, o botão ⬇ baixa todas; o ✓ verde na linha mostra as que já estão salvas.
- Música baixada toca **sem internet e sem servidor**. A lista, as playlists, as buscas já feitas e as capas também ficam salvas.
- Para baixar a primeira vez precisa de internet. Se o arquivo estragar, o app apaga e baixa de novo.

## Baixar tudo automático
Ao abrir o app (e a cada 5 min) ele baixa **todas as músicas que conhece** (tocadas, favoritas e de playlists) quando o celular está no **Wi-Fi**, e para se sobrar menos de ~1 GB de espaço. Quem falhou espera 1 h para tentar de novo. Roda enquanto o app está aberto.

## Visual ZEROUN (preto e branco)
A aba Música deixou o estilo Spotify e usa a identidade da Zeroun (avatar + banner do bot):
- Paleta só preto/branco/cinza, e **segue o tema claro/escuro do app** (antes era sempre escura). Destaque = preto no claro, branco no escuro (sem verde).
- Imagens em `res/drawable-nodpi/`: `zeroun_avatar.webp` (robô no cabeçalho, estados vazios e "carregando" piscando) e `zeroun_banner.webp` (topo do Início).
- Cabeçalho "ZEROUN / MÚSICA" com linha fina, abas em cantos quadrados, títulos de seção em caixa alta com barrinha, marca d'água "ZEROUN" ao fundo e selo GG/ZEROUN no fim do Início.
- Cantos mais arredondados nas capas, mini player com contorno, botão de tocar quadrado e player grande com "ZEROUN · TOCANDO".
- Música tocando: barrinha lateral + título em negrito (em vez de texto verde).
- Todas as cores ficam no objeto `Sp` do topo de `MusicaUI.kt`; a estrutura e a lógica não mudaram.

## Velocidade (busca e tocar) — o que mudou
- **Busca**: YouTube (celular) e SoundCloud (servidor) rodam ao mesmo tempo e a lista aparece assim que a primeira responde (~1 s). Se o servidor demorar, os resultados dele entram no FIM da lista depois, sem embaralhar. O servidor não trava mais a busca por até 60 s (agora no máximo 15 s).
- **Tocar (YouTube)**: os 4 clientes do celular não são mais tentados um por um — começa pelo que funcionou da última vez e dispara o próximo se demorar mais de 0,7 s. Se o celular não entregar em 1,5 s, o servidor é chamado em paralelo (o primeiro que responder toca).
- **Pré-carga**: os primeiros resultados da busca já deixam o endereço do áudio pronto, então tocar é quase instantâneo.
- **Salvar**: `musica.json` agora grava em segundo plano 0,7 s depois (antes montava o arquivo na hora do clique e travava a tela). Playlists gravam na hora.
- Se a busca ainda ficar lenta em alguma música, o gargalo é o `/musica/buscar` do servidor (SoundCloud): o app já não espera por ele.

## Compartilhar e importar playlist
- Na playlist, botão **Compartilhar** → mostra o link, **Copiar** ou **Enviar** (WhatsApp, Discord…). Também tem o botão na lista de playlists.
- Quem recebe: Playlists → **Colar link de playlist** (ou o cartão no Início, ou colar na busca). O app mostra o nome e as músicas e **Importar** cria uma playlist NOVA na biblioteca dela (não mexe nas suas).
- O link é `zeroun://playlist/…` e leva a playlist inteira dentro (nome + músicas, comprimido) — não usa servidor. Máximo de 300 músicas por link.

## Mais recursos estilo Spotify
- Player: **Aleatório** e **Repetir** (fila toda / só a música) — `Tocador.alternarAleatorio()` e `alternarRepetir()`.
- Buscar: **Buscas recentes** (toque para repetir na hora, X para apagar).

## Correção do "Carregando…" eterno (até 120 s ou nunca tocava)
- **Causa 1:** se o YouTube falhasse no celular uma vez, o app passava 10 min mandando TODAS as músicas ao servidor (cujo IP o YouTube barra) e esperava até 120 s. Agora a pausa é de 15 s e a espera pelo servidor é de no máximo 12 s (YouTube) / 40 s (SoundCloud).
- **Causa 2:** o `MediaPlayer` não tinha limite de tempo para abrir o link. Agora há um vigia (7 s; 25 s pelo servidor): se não abrir, o app troca sozinho para o próximo cliente do YouTube em vez de travar.
- Clientes do YouTube agora disparam a cada 0,45 s (antes 0,7 s) e cada um tem limite de 4–5 s.

## Quase instantâneo (pré-baixar como o Spotify)
- Ao aparecer a busca, as **5 primeiras** músicas (YouTube e SoundCloud) já são baixadas inteiras no celular (cache/pre, até 400 MB, 5 downloads ao mesmo tempo, em pedaços de 2 MB com Range). Tocar uma delas abre o arquivo local na hora, sem rede. As próximas 5 só têm o endereço pronto.
- Se o usuário toca uma música cuja pré-carga está quase pronta, o app espera até 3 s por ela em vez de começar um streaming do zero.
- O servidor não é mais chamado para "aquecer" músicas do YouTube (o IP dele é barrado).

## Diagnóstico e plano B
- Sob o "Carregando…" aparece a etapa e os segundos (ex.: "procurando o link · 4s", "abrindo o áudio · 2s"). Se passar de 30 s, para e mostra em qual etapa travou.
- Se não achar o link da música (ex.: faixa do SoundCloud), o app procura a mesma música no YouTube (duração parecida) e toca por lá (`YT.equivalenteYt`).

## Fontes alternativas (Piped / Invidious)
Se o YouTube direto no celular falhar (ou demorar 1,5 s), o app pergunta AO MESMO TEMPO a 8 instâncias Piped e 6 Invidious (listas `pipeds` e `invs` no topo do bloco "fontes ALTERNATIVAS" em `Musica.kt`) além do servidor do bot; a primeira que devolver o áudio toca. A busca também cai para o Piped se o YouTube direto falhar. Instâncias públicas saem do ar com frequência: se uma parar, troque/adicione outras nessas listas (https://docs.invidious.io/instances/ e a lista de instâncias do Piped).

## Busca SOMENTE pelo Deezer
- Texto digitado na busca → `api.deezer.com/search/track` (título, artista, duração e capa certos; ids `dz_<número>`). Link do YouTube/SoundCloud colado continua funcionando como antes.
- O Deezer só entrega prévia de 30 s, então para TOCAR o app acha o vídeo equivalente no YouTube por "artista + título" (duração até 6 s de diferença; evita karaokê/cover/ao vivo) e usa o mesmo caminho de antes (clientes do celular → Piped/Invidious → servidor). O vídeo escolhido fica salvo (`dicas`, prefixo `yt:`).
- Capas vêm do Deezer. Funções: `buscarDeezer`, `ytIdDe`, `capaDeezer` em `Musica.kt`.

## Prévia do Deezer enquanto acha a música completa
Ao tocar uma música `dz_…` que ainda não está no celular, o app toca NA HORA a prévia de 30 s do Deezer (`YT.previa`) e, quando o áudio completo é achado (YouTube/Piped/servidor), troca para ele no mesmo ponto (`Tocador.iniciar(trocarDe=…)`). Se a pessoa pausou na prévia, a troca não retoma sozinha. Se a prévia acabar antes, mostra "Carregando…" até a completa chegar. A música só conta como ouvida quando a completa começa.
- **Prévias pré-baixadas:** quando a busca aparece, as 10 primeiras prévias (~0,5 MB cada) já são salvas em `cache/prev` (`Pre.pedirPrevias`). Ao clicar, a prévia abre do próprio celular (quase 0 s). A prévia agora começa ANTES de qualquer espera (antes ela esperava até 3 s pelo download da música inteira).
