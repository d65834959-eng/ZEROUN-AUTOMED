package com.zeroun.automed

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

// ───────────────────────── utilidades ─────────────────────────

fun duracaoTxt(s: Int): String {
    val h = s / 3600
    val m = (s % 3600) / 60
    val x = s % 60
    return if (h > 0) String.format("%d:%02d:%02d", h, m, x) else String.format("%d:%02d", m, x)
}

fun tempoRel(ts: Long): String {
    val d = (System.currentTimeMillis() - ts) / 1000
    return when {
        d < 60 -> "agora"
        d < 3600 -> "há ${d / 60} min"
        d < 86400 -> "há ${d / 3600} h"
        d < 7 * 86400 -> "há ${d / 86400} d"
        else -> hora(ts)
    }
}

// ───────────────────────── visual "Spotify" (a aba Música é sempre escura) ─────────────────────────

private object Sp {
    val Fundo = Color(0xFF121212)
    val Card = Color(0xFF181818)
    val Card2 = Color(0xFF2A2A2A)
    val Verde = Color(0xFF1DB954)
    val Texto = Color.White
    val Muted = Color(0xFFB3B3B3)
    val Linha = Color(0xFF535353)
    val Vermelho = Color(0xFFF87171)
    val CorFav = Color(0xFF4529D6)

    private val cores = listOf(
        Color(0xFF1E6B52), Color(0xFF7A3B69), Color(0xFF1F4E79), Color(0xFF8A4B1F), Color(0xFF5B3FA0), Color(0xFF9C2F3F)
    )

    /** Cada playlist tem sua cor (sempre a mesma) no degradê do topo. */
    fun corDe(id: String): Color = if (id == ID_FAV) CorFav else cores[(id.hashCode() and 0x7fffffff) % cores.size]
}

/** Para onde o usuário está dentro da aba Música. */
private object NavMusica {
    /** "inicio" • "buscar" • "playlists" • "pl:<id da playlist>" */
    var pagina by mutableStateOf("inicio")
    var playerAberto by mutableStateOf(false)
}

// ───────────────────────── tela principal ─────────────────────────

@Composable
fun MusicaAba() {
    val ctx = LocalContext.current
    val v = MusicaStore.versao // só para a tela se atualizar quando algo mudar
    var dialogoNova by remember { mutableStateOf(false) }
    var faixaParaAdicionar by remember { mutableStateOf<Som?>(null) }
    var novaParaFaixa by remember { mutableStateOf<Som?>(null) }
    var perguntouNotif by remember { mutableStateOf(false) }
    val pedirNotif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun tocar(lista: List<Som>, i: Int) {
        // Android 13+: pede (uma vez) para mostrar os botões da música na notificação
        if (Build.VERSION.SDK_INT >= 33 && !perguntouNotif &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            perguntouNotif = true
            pedirNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        Tocador.tocarLista(ctx, lista, i)
    }

    BackHandler(enabled = NavMusica.playerAberto || NavMusica.pagina.startsWith("pl:")) {
        if (NavMusica.playerAberto) NavMusica.playerAberto = false else NavMusica.pagina = "playlists"
    }

    val pagina = NavMusica.pagina

    Box(Modifier.fillMaxSize().background(Sp.Fundo)) {
        Column(Modifier.fillMaxSize()) {
            if (!pagina.startsWith("pl:")) Cabecalho(pagina)

            Box(Modifier.weight(1f).fillMaxWidth()) {
                when {
                    pagina == "buscar" -> PaginaBuscar(::tocar) { faixaParaAdicionar = it }
                    pagina == "playlists" -> PaginaPlaylists(v) { dialogoNova = true }
                    pagina.startsWith("pl:") -> PaginaPlaylist(pagina.removePrefix("pl:"), v, ::tocar) { faixaParaAdicionar = it }
                    else -> PaginaInicio(v, ::tocar) { faixaParaAdicionar = it }
                }
            }

            if (Tocador.atual != null) MiniPlayer { NavMusica.playerAberto = true }
        }

        if (NavMusica.playerAberto && Tocador.atual != null) {
            PlayerCheio(onFechar = { NavMusica.playerAberto = false }) { faixaParaAdicionar = it }
        }
    }

    if (dialogoNova) {
        DialogoNome("Nova playlist", "", "Criar", onCancelar = { dialogoNova = false }) { nome ->
            dialogoNova = false
            val id = MusicaStore.criarPlaylist(nome)
            NavMusica.pagina = "pl:$id"
        }
    }

    val adicionar = faixaParaAdicionar
    if (adicionar != null) {
        DialogoAdicionar(
            adicionar,
            onNova = { faixaParaAdicionar = null; novaParaFaixa = adicionar },
            onFechar = { faixaParaAdicionar = null }
        )
    }

    val paraNova = novaParaFaixa
    if (paraNova != null) {
        DialogoNome("Nova playlist", "", "Criar e salvar", onCancelar = { novaParaFaixa = null }) { nome ->
            novaParaFaixa = null
            val id = MusicaStore.criarPlaylist(nome)
            MusicaStore.alternarNaPlaylist(id, paraNova)
            Toast.makeText(ctx, "Salva em \"" + (MusicaStore.playlist(id)?.nome ?: "playlist") + "\"", Toast.LENGTH_SHORT).show()
        }
    }
}

// ───────────────────────── cabeçalho + atalhos ─────────────────────────

@Composable
private fun Cabecalho(pagina: String) {
    Column(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(38.dp).clip(CircleShape).background(Sp.Verde),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.MusicNote, null, tint = Color.Black, modifier = Modifier.size(22.dp)) }
            Spacer(Modifier.width(10.dp))
            Text("Música", color = Sp.Texto, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ChipSp("Início", Icons.Rounded.Home, pagina == "inicio") { NavMusica.pagina = "inicio" }
            ChipSp("Buscar", Icons.Rounded.Search, pagina == "buscar") { NavMusica.pagina = "buscar" }
            ChipSp("Playlists", Icons.Rounded.LibraryMusic, pagina == "playlists") { NavMusica.pagina = "playlists" }
        }
    }
}

@Composable
private fun ChipSp(texto: String, icone: ImageVector, marcado: Boolean, onClick: () -> Unit) {
    val fundo = if (marcado) Sp.Verde else Sp.Card2
    val letra = if (marcado) Color.Black else Sp.Texto
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(fundo).clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icone, null, tint = letra, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(texto, color = letra, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

// ───────────────────────── página: INÍCIO ─────────────────────────

@Composable
private fun PaginaInicio(v: Int, tocar: (List<Som>, Int) -> Unit, adicionar: (Som) -> Unit) {
    val recentes = remember(v) { MusicaStore.recentes(15) }
    val mais = remember(v) { MusicaStore.maisOuvidas(10) }
    val playlists = remember(v) { MusicaStore.listaPlaylists() }
    var confirmarLimpar by remember { mutableStateOf(false) }

    val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    val saudacao = if (h < 5) "Boa madrugada" else if (h < 12) "Bom dia" else if (h < 18) "Boa tarde" else "Boa noite"

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(top = 8.dp, bottom = 12.dp)) {
        Text(
            saudacao, color = Sp.Texto, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        Spacer(Modifier.height(12.dp))

        // grade de atalhos (Favoritas + playlists)
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            playlists.take(6).chunked(2).forEach { par ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    par.forEach { p -> AtalhoPlaylist(p, Modifier.weight(1f)) { NavMusica.pagina = "pl:" + p.id } }
                    if (par.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }

        if (mais.isNotEmpty()) {
            TituloSecao("Mais ouvidas", Icons.Rounded.LocalFireDepartment)
            val listaMais = mais.map { it.faixa }
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                mais.forEachIndexed { i, item -> CartaoTop(i + 1, item) { tocar(listaMais, i) } }
            }
        }

        if (recentes.isNotEmpty()) {
            TituloSecao("Tocadas recentemente", Icons.Rounded.History)
            val listaRec = recentes.map { it.faixa }
            recentes.forEachIndexed { i, item ->
                FaixaSp(item.faixa, tempoRel(item.uso.ultimo), { tocar(listaRec, i) }, onAdicionar = { adicionar(item.faixa) })
            }
        }

        if (mais.isEmpty() && recentes.isEmpty()) {
            Column(
                Modifier.fillMaxWidth().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(16.dp))
                Icon(Icons.Rounded.MusicNote, null, tint = Sp.Verde, modifier = Modifier.size(54.dp))
                Spacer(Modifier.height(10.dp))
                Text("Sua música começa aqui", color = Sp.Texto, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Busque uma música, toque no ❤ para guardar nas Favoritas e crie suas playlists.",
                    color = Sp.Muted, fontSize = 14.sp, textAlign = TextAlign.Center, lineHeight = 20.sp
                )
                Spacer(Modifier.height(16.dp))
                BotaoVerde("Buscar música", Icons.Rounded.Search) { NavMusica.pagina = "buscar" }
            }
        } else {
            Spacer(Modifier.height(14.dp))
            TextButton(onClick = { confirmarLimpar = true }, modifier = Modifier.padding(horizontal = 8.dp)) {
                Text("Limpar meu histórico", color = Sp.Muted, fontSize = 13.sp)
            }
        }
    }

    if (confirmarLimpar) {
        AlertDialog(
            onDismissRequest = { confirmarLimpar = false },
            containerColor = Sp.Card2, titleContentColor = Sp.Texto, textContentColor = Sp.Muted,
            title = { Text("Limpar histórico?", fontWeight = FontWeight.Bold) },
            text = { Text("Apaga \"Mais ouvidas\" e \"Recentes\". Suas playlists e favoritas continuam salvas.") },
            confirmButton = {
                TextButton(onClick = { confirmarLimpar = false; MusicaStore.limparHistorico() }) {
                    Text("Limpar", color = Sp.Vermelho, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { confirmarLimpar = false }) { Text("Cancelar", color = Sp.Muted) } }
        )
    }
}

@Composable
private fun TituloSecao(texto: String, icone: ImageVector) {
    Row(
        Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 22.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(texto, color = Sp.Texto, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
        Icon(icone, null, tint = Sp.Muted, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun AtalhoPlaylist(p: Playlist, modifier: Modifier, onClick: () -> Unit) {
    val forma = RoundedCornerShape(6.dp)
    Row(
        modifier.height(56.dp).clip(forma).background(Sp.Card2).clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CapaPlaylist(p, Modifier.size(56.dp), RoundedCornerShape(0.dp))
        Text(
            p.nome, color = Sp.Texto, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 2,
            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(horizontal = 10.dp)
        )
    }
}

@Composable
private fun CartaoTop(pos: Int, item: ItemUso, onClick: () -> Unit) {
    val f = item.faixa
    val ativa = Tocador.atual?.id == f.id
    Column(Modifier.width(140.dp).clickable { if (ativa) Tocador.alternar() else onClick() }) {
        Box {
            Capa(f.id, Modifier.size(140.dp), RoundedCornerShape(8.dp))
            Text(
                "#$pos", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.align(Alignment.TopStart).padding(6.dp).clip(RoundedCornerShape(50))
                    .background(Color(0xCC000000)).padding(horizontal = 8.dp, vertical = 3.dp)
            )
            if (ativa) {
                Icon(
                    Icons.Rounded.GraphicEq, null, tint = Color.Black,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp).size(26.dp).clip(CircleShape)
                        .background(Sp.Verde).padding(4.dp)
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            f.titulo, color = if (ativa) Sp.Verde else Sp.Texto, fontWeight = FontWeight.Bold, fontSize = 13.sp,
            minLines = 2, maxLines = 2, overflow = TextOverflow.Ellipsis
        )
        Text(
            f.artista + " · " + item.uso.plays + "x", color = Sp.Muted, fontSize = 12.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}

// ───────────────────────── página: BUSCAR ─────────────────────────

@Composable
private fun PaginaBuscar(tocar: (List<Som>, Int) -> Unit, adicionar: (Som) -> Unit) {
    val resultados = MusicaBusca.resultados
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 12.dp)) {
        BarraBusca()

        if (MusicaBusca.buscando) {
            Row(
                Modifier.fillMaxWidth().padding(24.dp), horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircularProgressIndicator(Modifier.size(22.dp), color = Sp.Verde, strokeWidth = 2.5.dp)
                Spacer(Modifier.width(10.dp))
                Text("Procurando…", color = Sp.Muted, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        if (MusicaBusca.erro.isNotBlank()) {
            Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("⚠️ " + MusicaBusca.erro, color = Sp.Vermelho, fontWeight = FontWeight.Bold, fontSize = 13.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(8.dp))
                BotaoVerde("Tentar de novo", null) { MusicaBusca.pesquisar(true) }
            }
        }

        if (resultados != null) {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 6.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    if (MusicaBusca.doCache) "Resultados (salvos no celular)" else "Resultados",
                    color = Sp.Texto, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f)
                )
                if (MusicaBusca.doCache) {
                    TextButton(onClick = { MusicaBusca.pesquisar(true) }) {
                        Text("Atualizar", color = Sp.Verde, fontWeight = FontWeight.Bold)
                    }
                }
            }
            if (resultados.isEmpty()) {
                Text("Nada encontrado.", color = Sp.Muted, modifier = Modifier.padding(16.dp))
            }
            resultados.forEachIndexed { i, f -> FaixaSp(f, null, { tocar(resultados, i) }, onAdicionar = { adicionar(f) }) }
        } else if (!MusicaBusca.buscando && MusicaBusca.erro.isBlank()) {
            Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(Modifier.height(20.dp))
                Icon(Icons.Rounded.Search, null, tint = Sp.Muted, modifier = Modifier.size(48.dp))
                Spacer(Modifier.height(8.dp))
                Text("Pesquise músicas e artistas", color = Sp.Texto, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    "Digite o nome ou cole um link.", color = Sp.Muted, fontSize = 14.sp,
                    textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun BarraBusca() {
    val foco = LocalFocusManager.current
    OutlinedTextField(
        value = MusicaBusca.texto, onValueChange = { MusicaBusca.texto = it },
        singleLine = true, shape = RoundedCornerShape(10.dp),
        placeholder = { Text("O que você quer ouvir?", color = Color(0xFF535353), fontWeight = FontWeight.SemiBold) },
        leadingIcon = { Icon(Icons.Rounded.Search, null, tint = Color.Black) },
        trailingIcon = {
            if (MusicaBusca.texto.isNotEmpty()) {
                Icon(
                    Icons.Rounded.Close, "Limpar", tint = Color.Black,
                    modifier = Modifier.padding(end = 6.dp).clip(CircleShape).clickable { MusicaBusca.limpar() }.padding(8.dp)
                )
            }
        },
        textStyle = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color.Black),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Sp.Verde, unfocusedBorderColor = Color.Transparent,
            focusedContainerColor = Color.White, unfocusedContainerColor = Color.White,
            focusedTextColor = Color.Black, unfocusedTextColor = Color.Black, cursorColor = Sp.Verde
        ),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { foco.clearFocus(); MusicaBusca.pesquisar() }),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
    )
}

// ───────────────────────── página: PLAYLISTS (biblioteca) ─────────────────────────

@Composable
private fun PaginaPlaylists(v: Int, criar: () -> Unit) {
    val playlists = remember(v) { MusicaStore.listaPlaylists() }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 12.dp)) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Sua biblioteca", color = Sp.Texto, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                IconeBtn(Icons.Rounded.Add, Sp.Texto, 44.dp, "Nova playlist") { criar() }
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth().clickable { criar() }.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(64.dp).clip(RoundedCornerShape(6.dp)).background(Sp.Card2),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Add, null, tint = Sp.Texto, modifier = Modifier.size(32.dp)) }
                Spacer(Modifier.width(14.dp))
                Text("Criar playlist", color = Sp.Texto, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
        itemsIndexed(playlists) { _, p ->
            Row(
                Modifier.fillMaxWidth().clickable { NavMusica.pagina = "pl:" + p.id }.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CapaPlaylist(p, Modifier.size(64.dp), RoundedCornerShape(6.dp))
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(p.nome, color = Sp.Texto, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        "Playlist · " + p.faixas.size + (if (p.faixas.size == 1) " música" else " músicas"),
                        color = Sp.Muted, fontSize = 13.sp
                    )
                }
            }
        }
    }
}

// ───────────────────────── página: UMA PLAYLIST ─────────────────────────

@Composable
private fun PaginaPlaylist(id: String, v: Int, tocar: (List<Som>, Int) -> Unit, adicionar: (Som) -> Unit) {
    val ctx = LocalContext.current
    val p = remember(v, id) { MusicaStore.playlist(id) }
    val faixas = remember(v, id) { MusicaStore.faixasDaPlaylist(id) }
    var menu by remember { mutableStateOf(false) }
    var renomear by remember { mutableStateOf(false) }
    var excluir by remember { mutableStateOf(false) }

    if (p == null) {
        LaunchedEffect(id) { NavMusica.pagina = "playlists" }
        return
    }

    val cor = Sp.corDe(id)
    val totalSeg = faixas.sumOf { it.duracao }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 12.dp)) {
        item {
            Column(
                Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(cor.copy(alpha = 0.9f), Sp.Fundo)))
                    .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconeBtn(Icons.Rounded.ArrowBack, Sp.Texto, 44.dp, "Voltar") { NavMusica.pagina = "playlists" }
                }
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    CapaPlaylist(p, Modifier.size(190.dp), RoundedCornerShape(6.dp))
                }
                Spacer(Modifier.height(16.dp))
                Text(p.nome, color = Sp.Texto, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(4.dp))
                Text(
                    faixas.size.toString() + (if (faixas.size == 1) " música" else " músicas") +
                        (if (totalSeg > 0) " · " + (totalSeg / 60) + " min" else ""),
                    color = Sp.Muted, fontSize = 14.sp
                )
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconeBtn(Icons.Rounded.Shuffle, Sp.Muted, 44.dp, "Aleatório") {
                        if (faixas.isNotEmpty()) tocar(faixas.shuffled(), 0)
                        else Toast.makeText(ctx, "Esta playlist está vazia.", Toast.LENGTH_SHORT).show()
                    }
                    if (id != ID_FAV) IconeBtn(Icons.Rounded.MoreVert, Sp.Muted, 44.dp, "Opções") { menu = true }
                    Spacer(Modifier.weight(1f))
                    Box(
                        Modifier.size(58.dp).clip(CircleShape).background(Sp.Verde).clickable {
                            if (faixas.isEmpty()) Toast.makeText(ctx, "Adicione músicas primeiro (botão ＋ ao lado de cada música).", Toast.LENGTH_SHORT).show()
                            else tocar(faixas, 0)
                        },
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Rounded.PlayArrow, "Tocar", tint = Color.Black, modifier = Modifier.size(34.dp)) }
                }
            }
        }

        if (faixas.isEmpty()) {
            item {
                Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Nada por aqui ainda", color = Sp.Texto, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (id == ID_FAV) "Toque no ❤ de qualquer música para guardar aqui."
                        else "Busque uma música e toque em ＋ para salvar nesta playlist.",
                        color = Sp.Muted, fontSize = 14.sp, textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(14.dp))
                    BotaoVerde("Buscar música", Icons.Rounded.Search) { NavMusica.pagina = "buscar" }
                }
            }
        }

        itemsIndexed(faixas) { i, f ->
            FaixaSp(
                f, null, { tocar(faixas, i) },
                onAdicionar = if (id == ID_FAV) ({ adicionar(f) }) else null,
                onRemover = if (id != ID_FAV) ({ MusicaStore.removerDaPlaylist(id, f.id) }) else null
            )
        }
    }

    if (menu) {
        AlertDialog(
            onDismissRequest = { menu = false },
            containerColor = Sp.Card2,
            title = { Text(p.nome, color = Sp.Texto, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            text = {
                Column {
                    TextButton(onClick = { menu = false; renomear = true }) { Text("Renomear playlist", color = Sp.Texto, fontSize = 16.sp) }
                    TextButton(onClick = { menu = false; excluir = true }) { Text("Excluir playlist", color = Sp.Vermelho, fontSize = 16.sp) }
                }
            },
            confirmButton = { TextButton(onClick = { menu = false }) { Text("Fechar", color = Sp.Muted) } }
        )
    }
    if (renomear) {
        DialogoNome("Renomear playlist", p.nome, "Salvar", onCancelar = { renomear = false }) { nome ->
            renomear = false
            MusicaStore.renomearPlaylist(id, nome)
        }
    }
    if (excluir) {
        AlertDialog(
            onDismissRequest = { excluir = false },
            containerColor = Sp.Card2, titleContentColor = Sp.Texto, textContentColor = Sp.Muted,
            title = { Text("Excluir playlist?", fontWeight = FontWeight.Bold) },
            text = { Text("\"" + p.nome + "\" será apagada. As músicas continuam salvas no celular.") },
            confirmButton = {
                TextButton(onClick = { excluir = false; NavMusica.pagina = "playlists"; MusicaStore.excluirPlaylist(id) }) {
                    Text("Excluir", color = Sp.Vermelho, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { excluir = false }) { Text("Cancelar", color = Sp.Muted) } }
        )
    }
}

// ───────────────────────── componentes ─────────────────────────

/** Capa da música: baixa uma vez, guarda no celular e abre na hora depois. */
@Composable
fun Capa(id: String, modifier: Modifier, forma: Shape) {
    val img by produceState<ImageBitmap?>(initialValue = Capas.memoria(id), key1 = id) {
        if (value == null) value = withContext(Dispatchers.IO) { Capas.carregar(id) }
    }
    Box(modifier.clip(forma).background(Sp.Card2), contentAlignment = Alignment.Center) {
        val i = img
        if (i != null) {
            Image(bitmap = i, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Icon(Icons.Rounded.MusicNote, null, tint = Sp.Muted, modifier = Modifier.size(24.dp))
        }
    }
}

/** Capa da playlist: Favoritas = coração roxo • com 4+ músicas = mosaico 2x2 • 1 a 3 = capa da primeira. */
@Composable
private fun CapaPlaylist(p: Playlist, modifier: Modifier, forma: Shape) {
    if (p.id == ID_FAV) {
        Box(
            modifier.clip(forma).background(Brush.linearGradient(listOf(Color(0xFF4529D6), Color(0xFF9D8DF1)))),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.Favorite, null, tint = Color.White, modifier = Modifier.fillMaxSize(0.45f)) }
        return
    }
    val ids = p.faixas.takeLast(4).reversed()
    when {
        ids.isEmpty() -> Box(modifier.clip(forma).background(Sp.Card2), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.QueueMusic, null, tint = Sp.Muted, modifier = Modifier.fillMaxSize(0.45f))
        }
        ids.size < 4 -> Capa(ids[0], modifier, forma)
        else -> Column(modifier.clip(forma)) {
            Row(Modifier.weight(1f).fillMaxWidth()) {
                Capa(ids[0], Modifier.weight(1f).fillMaxHeight(), RoundedCornerShape(0.dp))
                Capa(ids[1], Modifier.weight(1f).fillMaxHeight(), RoundedCornerShape(0.dp))
            }
            Row(Modifier.weight(1f).fillMaxWidth()) {
                Capa(ids[2], Modifier.weight(1f).fillMaxHeight(), RoundedCornerShape(0.dp))
                Capa(ids[3], Modifier.weight(1f).fillMaxHeight(), RoundedCornerShape(0.dp))
            }
        }
    }
}

@Composable
private fun IconeBtn(icone: ImageVector, cor: Color, tam: Dp, desc: String?, onClick: () -> Unit) {
    Box(Modifier.size(tam).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icone, desc, tint = cor, modifier = Modifier.size(tam * 0.56f))
    }
}

@Composable
private fun BotaoVerde(texto: String, icone: ImageVector?, onClick: () -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(Sp.Verde).clickable(onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icone != null) {
            Icon(icone, null, tint = Color.Black, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(texto, color = Color.Black, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
    }
}

/** Coração: guarda / tira a música das "Músicas Favoritas" (a playlist fixa). */
@Composable
private fun Coracao(f: Som, tam: Dp) {
    val ctx = LocalContext.current
    val fav = remember(MusicaStore.versao, f.id) { MusicaStore.ehFavorita(f.id) }
    IconeBtn(
        if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
        if (fav) Sp.Verde else Sp.Muted, tam, "Favorita"
    ) {
        val agora = MusicaStore.alternarFavorita(f)
        Toast.makeText(
            ctx, if (agora) "Adicionada às Músicas Favoritas" else "Removida das Músicas Favoritas", Toast.LENGTH_SHORT
        ).show()
    }
}

/** Linha de música estilo Spotify: capa, título, artista, ❤ e ＋ (salvar em playlist). */
@Composable
private fun FaixaSp(
    f: Som, info: String?, onTocar: () -> Unit,
    onAdicionar: (() -> Unit)? = null, onRemover: (() -> Unit)? = null
) {
    val ativa = Tocador.atual?.id == f.id
    Row(
        Modifier.fillMaxWidth().clickable { if (ativa) Tocador.alternar() else onTocar() }
            .padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box {
            Capa(f.id, Modifier.size(52.dp), RoundedCornerShape(6.dp))
            if (ativa) {
                Box(
                    Modifier.size(52.dp).clip(RoundedCornerShape(6.dp)).background(Color(0x99000000)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.GraphicEq, null, tint = Sp.Verde, modifier = Modifier.size(26.dp)) }
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                f.titulo, color = if (ativa) Sp.Verde else Sp.Texto, fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                f.artista + " · " + duracaoTxt(f.duracao) + (if (info != null) " · $info" else ""),
                color = Sp.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        Coracao(f, 40.dp)
        if (onAdicionar != null) IconeBtn(Icons.Rounded.PlaylistAdd, Sp.Muted, 40.dp, "Salvar em playlist") { onAdicionar() }
        if (onRemover != null) IconeBtn(Icons.Rounded.Close, Sp.Muted, 40.dp, "Remover da playlist") { onRemover() }
    }
}

// ───────────────────────── diálogos ─────────────────────────

@Composable
private fun DialogoNome(titulo: String, inicial: String, botao: String, onCancelar: () -> Unit, onOk: (String) -> Unit) {
    var nome by remember { mutableStateOf(inicial) }
    AlertDialog(
        onDismissRequest = onCancelar,
        containerColor = Sp.Card2,
        title = { Text(titulo, color = Sp.Texto, fontWeight = FontWeight.Bold) },
        text = {
            OutlinedTextField(
                value = nome, onValueChange = { nome = it.take(60) }, singleLine = true,
                placeholder = { Text("Nome da playlist", color = Sp.Muted) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Sp.Verde, unfocusedBorderColor = Sp.Linha,
                    focusedTextColor = Sp.Texto, unfocusedTextColor = Sp.Texto, cursorColor = Sp.Verde
                ),
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = { TextButton(onClick = { onOk(nome) }) { Text(botao, color = Sp.Verde, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClick = onCancelar) { Text("Cancelar", color = Sp.Muted) } }
    )
}

/** "Salvar em…": lista as playlists com ✓ nas que já têm a música. Toque para colocar / tirar. */
@Composable
private fun DialogoAdicionar(f: Som, onNova: () -> Unit, onFechar: () -> Unit) {
    val ctx = LocalContext.current
    val v = MusicaStore.versao
    val playlists = remember(v) { MusicaStore.listaPlaylists() }
    AlertDialog(
        onDismissRequest = onFechar,
        containerColor = Sp.Card2,
        title = { Text("Salvar em…", color = Sp.Texto, fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.heightIn(max = 340.dp).verticalScroll(rememberScrollState())) {
                Row(
                    Modifier.fillMaxWidth().clickable { onNova() }.padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(48.dp).clip(RoundedCornerShape(6.dp)).background(Sp.Card),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Rounded.Add, null, tint = Sp.Texto, modifier = Modifier.size(26.dp)) }
                    Spacer(Modifier.width(12.dp))
                    Text("Nova playlist", color = Sp.Texto, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
                playlists.forEach { p ->
                    val dentro = p.faixas.contains(f.id)
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            val agora = MusicaStore.alternarNaPlaylist(p.id, f)
                            Toast.makeText(
                                ctx, if (agora) "Salva em \"" + p.nome + "\"" else "Removida de \"" + p.nome + "\"", Toast.LENGTH_SHORT
                            ).show()
                        }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CapaPlaylist(p, Modifier.size(48.dp), RoundedCornerShape(6.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.nome, color = Sp.Texto, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(p.faixas.size.toString() + " músicas", color = Sp.Muted, fontSize = 12.sp)
                        }
                        if (dentro) {
                            Box(Modifier.size(24.dp).clip(CircleShape).background(Sp.Verde), contentAlignment = Alignment.Center) {
                                Icon(Icons.Rounded.Check, null, tint = Color.Black, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onFechar) { Text("Pronto", color = Sp.Verde, fontWeight = FontWeight.Bold) } }
    )
}

// ───────────────────────── player ─────────────────────────

/** Mini player (fica embaixo, acima da barra do app). Toque nele para abrir o player grande. */
@Composable
private fun MiniPlayer(onAbrir: () -> Unit) {
    val f = Tocador.atual ?: return
    var pos by remember { mutableLongStateOf(0L) }
    LaunchedEffect(f.id) {
        while (true) {
            pos = Tocador.posicaoMs()
            delay(500)
        }
    }
    val dur = Tocador.duracaoMs.coerceAtLeast(1L)
    val fracao = (pos.toFloat() / dur.toFloat()).coerceIn(0f, 1f)
    val forma = RoundedCornerShape(10.dp)

    Column(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp)
            .clip(forma).background(Sp.Card2).clickable(onClick = onAbrir)
    ) {
        Row(Modifier.padding(start = 8.dp, end = 4.dp, top = 8.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Capa(f.id, Modifier.size(44.dp), RoundedCornerShape(6.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(f.titulo, color = Sp.Texto, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                when {
                    Tocador.carregando -> Text("Carregando…", color = Sp.Verde, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Tocador.erro.isNotBlank() -> Text(Tocador.erro, color = Sp.Vermelho, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    else -> Text(f.artista, color = Sp.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Coracao(f, 40.dp)
            Box(Modifier.size(44.dp).clip(CircleShape).clickable { Tocador.alternar() }, contentAlignment = Alignment.Center) {
                if (Tocador.carregando) {
                    CircularProgressIndicator(Modifier.size(22.dp), color = Sp.Texto, strokeWidth = 2.5.dp)
                } else {
                    Icon(
                        if (Tocador.tocando) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null,
                        tint = Sp.Texto, modifier = Modifier.size(30.dp)
                    )
                }
            }
            IconeBtn(Icons.Rounded.Close, Sp.Muted, 36.dp, "Fechar") { Tocador.encerrar() }
        }
        // barrinha de progresso fininha
        Box(Modifier.fillMaxWidth().height(2.dp).background(Sp.Linha)) {
            Box(Modifier.fillMaxWidth(fracao).height(2.dp).background(Sp.Texto))
        }
    }
}

/** Player grande (tela cheia), como o "Tocando agora" do Spotify. */
@Composable
private fun PlayerCheio(onFechar: () -> Unit, onAdicionar: (Som) -> Unit) {
    val f = Tocador.atual ?: return
    var pos by remember { mutableLongStateOf(0L) }
    var arrastando by remember { mutableStateOf(false) }
    var valorArrasto by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(f.id) {
        while (true) {
            if (!arrastando) pos = Tocador.posicaoMs()
            delay(400)
        }
    }

    val dur = Tocador.duracaoMs.coerceAtLeast(1L)
    val fracao = if (arrastando) valorArrasto else (pos.toFloat() / dur.toFloat()).coerceIn(0f, 1f)

    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF3A3A5C), Sp.Fundo, Sp.Fundo)))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
            .padding(horizontal = 24.dp, vertical = 10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconeBtn(Icons.Rounded.KeyboardArrowDown, Sp.Texto, 44.dp, "Minimizar") { onFechar() }
            Text(
                "TOCANDO AGORA", color = Sp.Texto, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp,
                textAlign = TextAlign.Center, modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.size(44.dp))
        }
        Spacer(Modifier.height(18.dp))
        Capa(f.id, Modifier.fillMaxWidth().aspectRatio(1f), RoundedCornerShape(10.dp))
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(f.titulo, color = Sp.Texto, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(f.artista, color = Sp.Muted, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Coracao(f, 48.dp)
        }
        when {
            Tocador.carregando -> Text("Carregando…", color = Sp.Verde, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
            Tocador.erro.isNotBlank() -> Text(Tocador.erro, color = Sp.Vermelho, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        }
        Spacer(Modifier.height(6.dp))
        Slider(
            value = fracao,
            onValueChange = { arrastando = true; valorArrasto = it },
            onValueChangeFinished = {
                val alvo = (valorArrasto * dur).toLong()
                Tocador.ir(alvo)
                pos = alvo
                arrastando = false
            },
            colors = SliderDefaults.colors(thumbColor = Sp.Texto, activeTrackColor = Sp.Texto, inactiveTrackColor = Sp.Linha),
            modifier = Modifier.fillMaxWidth().height(28.dp)
        )
        Row(Modifier.fillMaxWidth()) {
            Text(duracaoTxt((fracao * dur / 1000f).toInt()), color = Sp.Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text(duracaoTxt((dur / 1000L).toInt()), color = Sp.Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconeBtn(Icons.Rounded.PlaylistAdd, Sp.Texto, 48.dp, "Salvar em playlist") { onAdicionar(f) }
            IconeBtn(Icons.Rounded.SkipPrevious, Sp.Texto, 56.dp, "Anterior") { Tocador.anterior() }
            Box(
                Modifier.size(72.dp).clip(CircleShape).background(Sp.Texto).clickable { Tocador.alternar() },
                contentAlignment = Alignment.Center
            ) {
                if (Tocador.carregando) {
                    CircularProgressIndicator(Modifier.size(30.dp), color = Color.Black, strokeWidth = 3.dp)
                } else {
                    Icon(
                        if (Tocador.tocando) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null,
                        tint = Color.Black, modifier = Modifier.size(42.dp)
                    )
                }
            }
            IconeBtn(Icons.Rounded.SkipNext, Sp.Texto, 56.dp, "Próxima") { Tocador.proxima() }
            IconeBtn(Icons.Rounded.Close, Sp.Muted, 48.dp, "Parar") { onFechar(); Tocador.encerrar() }
        }
    }
}
