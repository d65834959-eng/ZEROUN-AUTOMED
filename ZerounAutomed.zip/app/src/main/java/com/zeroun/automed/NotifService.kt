package com.zeroun.automed

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONObject

class NotifService : NotificationListenerService() {

    override fun onCreate() {
        super.onCreate()
        Estado.init(applicationContext)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            Estado.init(applicationContext)
            val pkg = sbn.packageName ?: return
            if (pkg == packageName) return
            if (Prefs.key.isBlank() || Prefs.url.isBlank()) return

            val permitido = if (Prefs.gmail) pkg == "com.google.android.gm" else Prefs.apps.contains(pkg)
            if (!permitido) return

            val ex = sbn.notification.extras
            val titulo = ex.getCharSequence("android.title")?.toString() ?: ""
            val texto = (ex.getCharSequence("android.bigText") ?: ex.getCharSequence("android.text"))?.toString() ?: ""
            if (titulo.isBlank() && texto.isBlank()) return

            val label = try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) { pkg }
            val ts = sbn.postTime

            Thread {
                val corpo = Net.corpo()
                    .put("app", label)
                    .put("pkg", pkg)
                    .put("pacote", pkg)
                    .put("titulo", titulo)
                    .put("texto", texto)
                    .put("ts", ts)
                tratarResposta(label, titulo, texto, ts, Net.post("/api/notificacao", corpo))
            }.start()
        } catch (e: Exception) { /* nunca derruba o serviço */ }
    }

    private fun tratarResposta(app: String, titulo: String, texto: String, ts: Long, r: JSONObject?) {
        val resumo = (titulo + " — " + texto).replace(Regex("\\s+"), " ").trim().take(140)
        var res: String
        var tipo = 0
        if (r == null) {
            res = "Sem resposta do bot"; tipo = 2
        } else if (!r.optBoolean("ok", false)) {
            res = r.optString("msg", "Erro no bot"); tipo = 2
        } else if (r.has("ativo") && !r.optBoolean("ativo", true)) {
            res = "Bot ignorou: \"Ativar notificações app\" está desligado no Discord"; tipo = 2
            Estado.ui { Estado.ativoApp = false }
        } else if (r.optBoolean("pix", false)) {
            val valor = r.optDouble("valor", 0.0)
            val nome = if (r.isNull("nome")) "" else r.optString("nome", "")
            if (r.optBoolean("repetido", false)) {
                res = "Pix já lido antes (repetido)"
            } else {
                res = "Pix lido"
                tipo = 1
                Estado.addPix(PixItem(nome, valor, app, "app", ts))
            }
            Estado.ui { Estado.ativoApp = true; Estado.online = true }
        } else {
            res = "Ignorada (não parece Pix recebido)"
            Estado.ui { Estado.online = true }
        }
        Estado.addEvento(Evento(app, resumo, res, tipo, System.currentTimeMillis()))
    }
}
