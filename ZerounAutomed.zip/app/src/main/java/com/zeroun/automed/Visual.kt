package com.zeroun.automed

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ───────────────────────── tema claro / escuro ─────────────────────────

object Tema {
    /** false = claro (padrão) • true = escuro. Mudar aqui recompõe o app inteiro. */
    var escuro by mutableStateOf(false)

    fun alternar() { escuro = !escuro; Prefs.escuro = escuro }
}

/** Paleta: branco (claro) ou grafite (escuro). Sem roxo. Cada cor é lida na hora, então troca de tema é instantânea. */
object Cor {
    private fun c(claro: Long, escuro: Long) = Color(if (Tema.escuro) escuro else claro)

    val Fundo get() = c(0xFFF3F6FB, 0xFF0A0C11)
    val Fundo2 get() = c(0xFFFFFFFF, 0xFF10141C)
    val Card get() = c(0xFFFFFFFF, 0xFF151922)
    val Card2 get() = c(0xFFEBEFF6, 0xFF1F2430)
    val Borda get() = c(0x1F0F172A, 0x26FFFFFF)

    /** Cor de destaque: tinta (claro) / branco (escuro). */
    val Marca get() = c(0xFF0F172A, 0xFFF8FAFC)
    val SobreMarca get() = c(0xFFFFFFFF, 0xFF0A0C11)

    val Ciano get() = c(0xFF0891B2, 0xFF22D3EE)
    val Verde get() = c(0xFF059669, 0xFF34D399)
    val Rosa get() = c(0xFFDB2777, 0xFFF472B6)
    val Laranja get() = c(0xFFD97706, 0xFFFBBF24)
    val Vermelho get() = c(0xFFDC2626, 0xFFF87171)
    val Azul get() = c(0xFF2563EB, 0xFF60A5FA)

    val Texto get() = c(0xFF0F172A, 0xFFF1F5F9)
    val Muted get() = c(0xFF64748B, 0xFF94A3B8)
}

/** Cor do texto/ícone que fica legível em cima de [c]. */
fun sobre(c: Color): Color = if (c.luminance() > 0.5f) Color(0xFF0A0C11) else Color.White

/** Sombra suave só no tema claro (no escuro o contorno já separa os cartões). */
fun Modifier.suave(forma: androidx.compose.ui.graphics.Shape): Modifier =
    if (Tema.escuro) this
    else this.shadow(6.dp, forma, ambientColor = Color(0x1A0F172A), spotColor = Color(0x290F172A))

/** Fundo decorado: dois brilhos suaves (azul no topo, verde embaixo). */
fun Modifier.decoracao(): Modifier = this.drawBehind {
    val w = size.width
    val h = size.height
    val forte = if (Tema.escuro) 0.22f else 0.17f
    val r1 = w * 0.95f
    drawCircle(
        brush = Brush.radialGradient(listOf(Cor.Azul.copy(alpha = forte), Color.Transparent), center = Offset(w, 0f), radius = r1),
        radius = r1, center = Offset(w, 0f)
    )
    val r2 = w * 0.85f
    drawCircle(
        brush = Brush.radialGradient(listOf(Cor.Verde.copy(alpha = forte), Color.Transparent), center = Offset(0f, h * 0.9f), radius = r2),
        radius = r2, center = Offset(0f, h * 0.9f)
    )
}

// ───────────────────────── botão sol / lua ─────────────────────────

@Composable
fun BotaoTema() {
    val giro by animateFloatAsState(if (Tema.escuro) 360f else 0f, label = "giro")
    Box(
        Modifier.size(44.dp).suave(CircleShape).clip(CircleShape)
            .background(Cor.Card).border(1.dp, Cor.Borda, CircleShape)
            .clickable { Tema.alternar() },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            if (Tema.escuro) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
            contentDescription = "Trocar tema",
            tint = if (Tema.escuro) Cor.Laranja else Cor.Azul,
            modifier = Modifier.size(24.dp).rotate(giro)
        )
    }
}

// ───────────────────────── componentes básicos ─────────────────────────

@Composable
fun Pill(texto: String, cor: Color) {
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(cor.copy(alpha = 0.14f))
            .border(1.dp, cor.copy(alpha = 0.45f), RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(cor))
        Spacer(Modifier.width(7.dp))
        Text(texto, color = cor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Cartao(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val forma = RoundedCornerShape(22.dp)
    Column(
        modifier.fillMaxWidth().suave(forma).clip(forma).background(Cor.Card)
            .border(1.dp, Cor.Borda, forma).padding(16.dp)
    ) { content() }
}

@Composable
fun Botao(
    texto: String, cor: Color = Cor.Marca, modifier: Modifier = Modifier.fillMaxWidth(),
    icone: ImageVector? = null, enabled: Boolean = true, onClick: () -> Unit
) {
    Button(
        onClick = onClick, enabled = enabled,
        modifier = modifier.height(54.dp),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = cor, contentColor = sobre(cor),
            disabledContainerColor = Cor.Card2, disabledContentColor = Cor.Muted
        )
    ) {
        if (icone != null) { Icon(icone, null, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
        Text(texto, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
    }
}

/** Título de grupo com barrinha colorida. */
@Composable
fun TituloGrupo(texto: String, cor: Color) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(4.dp).height(16.dp).clip(RoundedCornerShape(2.dp)).background(cor))
        Spacer(Modifier.width(8.dp))
        Text(texto, color = Cor.Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
    }
}

@Composable
fun Selo(texto: String, cor: Color) {
    Text(
        texto, color = cor, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(cor.copy(alpha = 0.14f))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    )
}

/** Botão-pílula de escolha (abas, escopo). */
@Composable
fun Chip(texto: String, cor: Color, marcado: Boolean, onClick: () -> Unit) {
    val forma = RoundedCornerShape(50)
    Text(
        texto, color = if (marcado) sobre(cor) else Cor.Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1,
        modifier = Modifier.clip(forma)
            .background(if (marcado) cor else Cor.Card)
            .border(1.dp, if (marcado) cor else Cor.Borda, forma)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    )
}

@Composable
fun BotaoMini(texto: String, cor: Color, onClick: () -> Unit) {
    val forma = RoundedCornerShape(12.dp)
    Text(
        texto, color = cor, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1,
        modifier = Modifier.clip(forma).background(cor.copy(alpha = 0.12f))
            .border(1.dp, cor.copy(alpha = 0.4f), forma)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    )
}

@Composable
fun Avatar(letra: String, cor: Color, tamanho: Int = 44) {
    Box(
        Modifier.size(tamanho.dp).clip(CircleShape).background(cor.copy(alpha = 0.16f)),
        contentAlignment = Alignment.Center
    ) {
        Text(letra.trim().take(1).uppercase().ifBlank { "?" }, color = cor, fontWeight = FontWeight.Black, fontSize = (tamanho * 0.4).sp)
    }
}

@Composable
fun Estatistica(valor: String, rotulo: String, cor: Color, modifier: Modifier) {
    val forma = RoundedCornerShape(18.dp)
    Column(
        modifier.clip(forma).background(cor.copy(alpha = 0.10f)).border(1.dp, cor.copy(alpha = 0.3f), forma).padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(valor, color = cor, fontSize = 24.sp, fontWeight = FontWeight.Black)
        Text(rotulo, color = Cor.Muted, fontSize = 11.sp)
    }
}

/** Ícone dentro de um quadradinho colorido. */
@Composable
fun IconeCaixa(icone: ImageVector, cor: Color, tamanho: Int = 46) {
    Box(
        Modifier.size(tamanho.dp).clip(RoundedCornerShape((tamanho * 0.32).dp)).background(cor.copy(alpha = 0.14f)),
        contentAlignment = Alignment.Center
    ) { Icon(icone, null, tint = cor, modifier = Modifier.size((tamanho * 0.5).dp)) }
}

/** Linha de menu clicável: ícone, título, descrição e seta. */
@Composable
fun LinhaMenu(icone: ImageVector, titulo: String, sub: String, cor: Color, onClick: () -> Unit) {
    val forma = RoundedCornerShape(20.dp)
    Row(
        Modifier.fillMaxWidth().suave(forma).clip(forma).background(Cor.Card)
            .border(1.dp, Cor.Borda, forma).clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconeCaixa(icone, cor)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(titulo, color = Cor.Texto, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, color = Cor.Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Rounded.ChevronRight, null, tint = Cor.Muted)
    }
}

/** Cartão clicável com emoji, título, descrição, selo e (opcional) um "código" em destaque. */
@Composable
fun CartaoAcao(
    emoji: String, titulo: String, sub: String, cor: Color,
    selo: String?, seloCor: Color, destaque: String?, onClick: () -> Unit
) {
    val forma = RoundedCornerShape(22.dp)
    Row(
        Modifier.fillMaxWidth().suave(forma).clip(forma)
            .background(Brush.linearGradient(listOf(cor.copy(alpha = 0.12f), Cor.Card)))
            .border(1.dp, cor.copy(alpha = 0.3f), forma)
            .clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(46.dp).clip(CircleShape).background(cor.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
            Text(emoji, fontSize = 22.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(titulo, color = Cor.Texto, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                if (selo != null) { Spacer(Modifier.width(8.dp)); Selo(selo, seloCor) }
            }
            Text(sub, color = Cor.Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (destaque != null) {
                Spacer(Modifier.height(6.dp))
                Text(
                    destaque, color = cor, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, maxLines = 1,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(Cor.Card2).padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }
        Spacer(Modifier.width(8.dp))
        Icon(Icons.Rounded.ChevronRight, null, tint = cor)
    }
}

/** Faixa de aviso (resultado da última ação). */
@Composable
fun AvisoBarra() {
    if (Painel.aviso.isNotBlank()) {
        val cor = if (Painel.avisoOk) Cor.Verde else Cor.Vermelho
        val forma = RoundedCornerShape(14.dp)
        Text(
            (if (Painel.avisoOk) "✅  " else "⚠️  ") + Painel.aviso,
            color = cor, fontSize = 13.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth().clip(forma).background(cor.copy(alpha = 0.12f))
                .border(1.dp, cor.copy(alpha = 0.45f), forma).padding(12.dp)
        )
    }
}

/** Mostra erro do bot ou "carregando". Devolve true se pode mostrar o conteúdo. */
@Composable
fun EstadoDoPainel(): Boolean {
    if (!Prefs.conectado) {
        Cartao {
            Text("🔗 Entre com a sua key primeiro", color = Cor.Laranja, fontWeight = FontWeight.Bold)
        }
        return false
    }
    if (Painel.erro.isNotBlank()) {
        Cartao {
            Text("⚠️ " + Painel.erro, color = Cor.Vermelho, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            Botao("Tentar de novo", Cor.Card2) { Painel.carregar() }
        }
        return false
    }
    if (!Painel.carregado) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) { Pill("Carregando…", Cor.Azul) }
        return false
    }
    return true
}

// ───────────────────────── prévia de mensagem (estilo Discord) ─────────────────────────

fun previaMensagem(t: String): String {
    return t.replace("{nome}", "João Silva")
        .replace("{valor_real}", "R\$ 5,00")
        .replace("{valor}", "5,00")
        .replace("{restante}", "2,00")
        .replace("**", "").replace("__", "").replace("`", "")
        .replace(Regex("(?m)^#{1,3}\\s*"), "")
        .replace(Regex("(?m)^>\\s?"), "")
        .replace(Regex("(?m)^-#\\s*"), "")
}

@Composable
fun PreviaDiscord(texto: String) {
    val forma = RoundedCornerShape(14.dp)
    Column(Modifier.fillMaxWidth().clip(forma).background(Cor.Card2).border(1.dp, Cor.Borda, forma).padding(12.dp)) {
        Text("PRÉVIA", color = Cor.Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(6.dp))
        Text(if (texto.isBlank()) "(vazio)" else previaMensagem(texto), color = Cor.Texto, fontSize = 13.sp)
    }
}
