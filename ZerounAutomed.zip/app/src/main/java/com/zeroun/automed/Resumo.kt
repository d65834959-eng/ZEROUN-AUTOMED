package com.zeroun.automed

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

data class AtividadeItem(val tipo: String, val titulo: String, val sub: String, val ts: Long)

/** Dados do Início vindos do bot: salas ativas (filas sendo mediadas), recebido hoje e atividade recente. */
object Resumo {
    var carregado by mutableStateOf(false)
    var salasAtivas by mutableStateOf(0)
    var jogadores by mutableStateOf(0)
    var recebidoHoje by mutableStateOf(0.0)
    var pixHoje by mutableStateOf(0)
    var atividade by mutableStateOf<List<AtividadeItem>>(emptyList())
    private var buscando = false

    fun carregar() {
        if (buscando) return
        buscando = true
        Thread {
            val r = Net.post("/api/home", Net.corpo())
            Estado.ui {
                buscando = false
                if (r != null && r.optBoolean("ok", false)) {
                    salasAtivas = r.optInt("salasAtivas", 0)
                    jogadores = r.optInt("jogadores", 0)
                    recebidoHoje = r.optDouble("recebidoHoje", 0.0)
                    pixHoje = r.optInt("pixHoje", 0)
                    val arr = r.optJSONArray("atividade")
                    val l = ArrayList<AtividadeItem>()
                    if (arr != null) for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        l.add(AtividadeItem(o.optString("tipo"), o.optString("titulo"), o.optString("sub"), o.optLong("ts")))
                    }
                    atividade = l
                    carregado = true
                }
            }
        }.start()
    }
}

fun tempoRelativo(ts: Long): String {
    val s = (System.currentTimeMillis() - ts) / 1000
    return when {
        s < 60 -> "Agora"
        s < 3600 -> "Há ${s / 60} min"
        s < 86400 -> "Há ${s / 3600} h"
        else -> "Há ${s / 86400} d"
    }
}
