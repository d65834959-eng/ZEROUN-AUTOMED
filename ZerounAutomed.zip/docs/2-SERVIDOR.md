# Mudanças no index.js (servidor) — versão do app 3.2

Só foram acrescentadas linhas; 3 linhas antigas foram trocadas (marcadas abaixo). Troque o index.js e reinicie o bot.

1. **app_dispositivos.json** (novo, salvo igual ao keys.json): por key guarda os celulares que usaram o app
   (modelo, versão do app, primeiro e último acesso) e as trocas de celular.
2. **Reinstalou o app / ID mudou?** (linha trocada em `/api/key`) Se o modelo do celular for o MESMO do que estava
   vinculado, o bot troca o vínculo sozinho (limite: 3 trocas em 7 dias). Outro modelo continua dando
   "Key já está vinculada a outro celular". `.env`: `APP_TROCA_AUTO=0` desliga; `APP_TROCA_MAX=5` muda o limite.
   Para destravar uma key à mão: abra keys.json e apague a linha `"appDevice"` dela.
3. **Ligar pelo app** (`sistema_ativar`, linhas trocadas): agora o bot confere se de fato ligou e devolve o MOTIVO
   (key não resgatada no Discord, key congelada, antiban sem servidor, erro do módulo...). Antes devolvia
   "Sistema ativado" mesmo quando recusava em silêncio.
4. `/api/sistema` agora informa se a key foi resgatada e, no modo antiban, quantos servidores estão ativos
   (o app mostra um aviso laranja explicando).
