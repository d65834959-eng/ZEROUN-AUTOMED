package com.zeroun.automed

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import kotlin.concurrent.thread

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = Prefs(this)
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val todos = packageManager.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
            .filter { it.first != packageName }.distinctBy { it.first }.sortedBy { it.second.lowercase() }
        setContent {
            var dark by remember { mutableStateOf(prefs.dark) }
            val cs = if (dark) darkColorScheme(background = Color(0xFF0B0D10), surface = Color(0xFF15181D), primary = Color(0xFFF3F4F6), onPrimary = Color(0xFF111827))
            else lightColorScheme(background = Color(0xFFF6F7F9), surface = Color.White, primary = Color(0xFF111827), onPrimary = Color.White)
            MaterialTheme(colorScheme = cs) { Tela(prefs, todos, dark) { dark = it; prefs.dark = it } }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Tela(prefs: Prefs, todos: List<Pair<String, String>>, dark: Boolean, onDark: (Boolean) -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var url by remember { mutableStateOf(prefs.url) }
    var key by remember { mutableStateOf(prefs.key) }
    var conectado by remember { mutableStateOf(prefs.connected) }
    var msg by remember { mutableStateOf("") }
    var gmail by remember { mutableStateOf(prefs.gmail) }
    var pag by remember { mutableStateOf(prefs.pag) }
    var sel by remember { mutableStateOf(prefs.apps) }
    var aberto by remember { mutableStateOf(false) }
    val nomeDe = { pkg: String -> todos.firstOrNull { it.first == pkg }?.second ?: pkg }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("ZEROUN AUTOMED", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(if (conectado) "Online" else "Desconectado", fontSize = 12.sp)
                }
                TextButton(onClick = { onDark(!dark) }) { Text(if (dark) "☀️" else "🌙", fontSize = 22.sp) }
            }
            Card(url, key, conectado, msg, { url = it }, { key = it }) {
                prefs.url = url; prefs.key = key; msg = "Conectando…"
                thread {
                    val r = Net.post(prefs.url, "/api/key", JSONObject().put("key", prefs.key).put("deviceId", prefs.deviceId))
                    val ok = r?.optBoolean("ok") == true
                    prefs.connected = ok
                    android.os.Handler(android.os.Looper.getMainLooper()).post { conectado = ok; msg = r?.optString("msg") ?: "Sem resposta do bot. Confira o endereço." }
                }
            }
            Box(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface, RoundedCornerShape(18.dp)).padding(16.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(Estado.status.value, fontWeight = FontWeight.SemiBold)
                    Text("R$ %.2f".format(Estado.total.value).replace('.', ','), fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                    Text("${Estado.qtd.value} Pix lidos hoje", fontSize = 12.sp)
                }
            }
            Box(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface, RoundedCornerShape(18.dp)).padding(16.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Apps monitorados (até 5)", fontWeight = FontWeight.SemiBold)
                    ExposedDropdownMenuBox(expanded = aberto, onExpandedChange = { aberto = it }) {
                        OutlinedTextField(value = "Selecionar app… (${sel.size}/5)", onValueChange = {}, readOnly = true, modifier = Modifier.menuAnchor().fillMaxWidth())
                        ExposedDropdownMenu(expanded = aberto, onDismissRequest = { aberto = false }) {
                            todos.forEach { (pkg, nome) ->
                                DropdownMenuItem(text = { Text((if (pkg in sel) "✓ " else "") + nome) }, onClick = {
                                    sel = if (pkg in sel) sel - pkg else if (sel.size < 5) sel + pkg else sel
                                    prefs.apps = sel
                                })
                            }
                        }
                    }
                    sel.forEach { pkg ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(nomeDe(pkg), Modifier.weight(1f))
                            TextButton(onClick = { sel = sel - pkg; prefs.apps = sel }) { Text("✕") }
                        }
                    }
                }
            }
            Box(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface, RoundedCornerShape(18.dp)).padding(16.dp)) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("Gmail", fontWeight = FontWeight.SemiBold); Text("Ler notificações do Gmail", fontSize = 12.sp) }
                        Switch(checked = gmail, onCheckedChange = { gmail = it; prefs.gmail = it })
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("Pagamentos", fontWeight = FontWeight.SemiBold); Text("Ler notificações dos apps escolhidos", fontSize = 12.sp) }
                        Switch(checked = pag, onCheckedChange = { pag = it; prefs.pag = it })
                    }
                }
            }
            OutlinedButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) { Text("Permitir acesso às notificações") }
            Box(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface, RoundedCornerShape(18.dp)).padding(16.dp)) {
                Column {
                    Text("Pix recentes", fontWeight = FontWeight.SemiBold)
                    if (Estado.recentes.isEmpty()) Text("Nenhum Pix lido ainda.", fontSize = 13.sp)
                    Estado.recentes.take(20).forEach { Text("✅ $it", fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
                }
            }
        }
    }
}

@Composable
fun Card(url: String, key: String, conectado: Boolean, msg: String, onUrl: (String) -> Unit, onKey: (String) -> Unit, onConectar: () -> Unit) {
    Box(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface, RoundedCornerShape(18.dp)).padding(16.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Conexão com o bot", fontWeight = FontWeight.SemiBold)
            OutlinedTextField(url, onUrl, label = { Text("Endereço do bot (ex.: http://192.168.0.10:3000)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(key, onKey, label = { Text("Key ZEROUN-AUTOMED-…") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Button(onClick = onConectar, modifier = Modifier.fillMaxWidth()) { Text(if (conectado) "Reconectar" else "Conectar") }
            if (msg.isNotBlank()) Text(msg, fontSize = 12.sp)
        }
    }
}
