package com.zeroun.automed

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.Icon
import android.media.MediaMetadata
import android.media.MediaPlayer
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.io.IOException

/**
 * Toca a música no próprio celular.
 * Fluxo: acha o áudio (cache JSON ou YT.resolver) → MediaPlayer → ao começar, conta +1 no histórico do usuário.
 * Se o endereço salvo já venceu / mudou de rede, pede um novo sozinho e tenta de novo.
 */
object Tocador {
    private var app: Context? = null
    private val main = Handler(Looper.getMainLooper())
    private var mp: MediaPlayer? = null
    private var geracao = 0
    private var focoTemporario = false
    private var foco: AudioFocusRequest? = null

    var fila by mutableStateOf<List<Som>>(emptyList())
        private set
    var indice by mutableIntStateOf(0)
        private set
    var atual by mutableStateOf<Som?>(null)
        private set
    var tocando by mutableStateOf(false)
        private set
    var carregando by mutableStateOf(false)
        private set
    var erro by mutableStateOf("")
        private set
    var duracaoMs by mutableLongStateOf(0L)
        private set
    /** Aleatório (como no Spotify): embaralha o que falta tocar; desligar volta à ordem original. */
    var aleatorio by mutableStateOf(false)
        private set
    /** Repetir: 0 = desligado • 1 = repete a fila toda • 2 = repete a música atual. */
    var repetir by mutableIntStateOf(0)
        private set
    private var filaOriginal: List<Som> = emptyList()
    /** Medidor: quanto tempo levou cada etapa da última música (para achar o que está lento). */
    var diag by mutableStateOf("")
        private set
    private var tInicio = 0L
    private var tPrep = 0L
    private var diagBase = ""
    @Volatile private var etapa = "começando"
    private var previaAtiva = false
    private var previaTerminou = false

    fun init(c: Context) { app = c.applicationContext }

    // ── foco de áudio (pausa quando entra ligação ou outro app de música) ──

    private val ouvinteFoco = AudioManager.OnAudioFocusChangeListener { mudanca ->
        when (mudanca) {
            AudioManager.AUDIOFOCUS_LOSS -> { focoTemporario = false; pausarPorFoco() }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> { focoTemporario = true; pausarPorFoco() }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> { mp?.setVolume(0.25f, 0.25f) }
            AudioManager.AUDIOFOCUS_GAIN -> {
                mp?.setVolume(1f, 1f)
                if (focoTemporario) {
                    focoTemporario = false
                    try { mp?.start(); tocando = mp != null } catch (e: Exception) { }
                    MusicaService.atualizar()
                }
            }
        }
    }

    private fun pausarPorFoco() {
        try { if (mp?.isPlaying == true) mp?.pause() } catch (e: Exception) { }
        tocando = false
        MusicaService.atualizar()
    }

    private fun pedirFoco(): Boolean {
        val am = app?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return true
        val req = foco ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(atributos())
            .setAcceptsDelayedFocusGain(true)
            .setOnAudioFocusChangeListener(ouvinteFoco, main)
            .build().also { foco = it }
        // Em ligação o Android recusa (FAILED) ou adia (DELAYED) o foco. Isso NÃO deve impedir a música:
        // tocamos mesmo assim; o foco é só "boa educação" com outros apps.
        try { am.requestAudioFocus(req) } catch (e: Exception) { }
        return true
    }

    private fun soltarFoco() {
        val am = app?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        foco?.let { am.abandonAudioFocusRequest(it) }
    }

    private fun atributos() = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    // ── comandos ──

    /** Toca [lista] a partir da posição [i]; ao acabar uma música segue para a próxima da lista. */
    fun tocarLista(c: Context, lista: List<Som>, i: Int) {
        app = c.applicationContext
        if (lista.isEmpty() || i !in lista.indices) return
        filaOriginal = lista
        if (aleatorio) {
            fila = listOf(lista[i]) + lista.filterIndexed { k, _ -> k != i }.shuffled()
            indice = 0
        } else {
            fila = lista
            indice = i
        }
        MusicaService.garantir(c.applicationContext)
        carregar(lista[i], false, emptySet())
    }

    fun alternarAleatorio() {
        val musica = atual
        if (!aleatorio) {
            aleatorio = true
            if (fila.isNotEmpty() && musica != null) {
                filaOriginal = fila
                fila = listOf(musica) + fila.filter { it.id != musica.id }.shuffled()
                indice = 0
            }
        } else {
            aleatorio = false
            if (filaOriginal.isNotEmpty() && musica != null) {
                fila = filaOriginal
                indice = fila.indexOfFirst { it.id == musica.id }.coerceAtLeast(0)
            }
        }
        MusicaService.atualizar()
    }

    fun alternarRepetir() { repetir = (repetir + 1) % 3 }

    fun alternar() {
        val m = mp
        if (m == null) {
            val f = atual
            if (f != null && !carregando) carregar(f, false, emptySet())
            return
        }
        try {
            if (m.isPlaying) {
                m.pause(); tocando = false; focoTemporario = false
            } else if (!carregando && pedirFoco()) {
                m.start(); tocando = true
            }
        } catch (e: Exception) { }
        MusicaService.atualizar()
    }

    fun proxima(auto: Boolean = false) {
        if (auto && repetir == 2) { // repetir a música: volta ao começo sem buscar o áudio de novo
            val m = mp
            if (m != null) {
                try { m.seekTo(0); m.start(); tocando = true; MusicaService.atualizar(); return } catch (e: Exception) { }
            }
            atual?.let { carregar(it, false, emptySet()) }
            return
        }
        val n = indice + 1
        if (n < fila.size) {
            indice = n
            carregar(fila[n], false, emptySet())
        } else if (repetir == 1 && fila.isNotEmpty()) { // repetir a fila: recomeça do início
            indice = 0
            carregar(fila[0], false, emptySet())
        } else if (auto) {
            liberar()
            tocando = false
            MusicaService.atualizar()
        }
    }

    fun anterior() {
        if (posicaoMs() > 3000L || indice <= 0) { ir(0L); return }
        indice -= 1
        carregar(fila[indice], false, emptySet())
    }

    fun ir(ms: Long) {
        try { mp?.seekTo(ms.toInt()) } catch (e: Exception) { }
        MusicaService.atualizar() // a barrinha da notificação acompanha o pulo
    }

    fun posicaoMs(): Long = try { (mp?.currentPosition ?: 0).toLong() } catch (e: Exception) { 0L }

    /** Para tudo e some com o player e a notificação. */
    fun encerrar() {
        geracao++
        liberar()
        atual = null; tocando = false; carregando = false; erro = ""
        fila = emptyList(); indice = 0
        MusicaService.parar()
    }

    // ── interno ──

    private fun liberar() {
        val m = mp
        mp = null
        previaAtiva = false
        if (m != null) {
            try { m.setOnCompletionListener(null); m.setOnErrorListener(null); m.setOnPreparedListener(null) } catch (e: Exception) { }
            try { m.release() } catch (e: Exception) { }
        }
        soltarFoco()
    }

    /** [forcarNovo] = ignora o endereço salvo • [evitar] = clientes do YouTube que já falharam. */
    private fun carregar(f: Som, forcarNovo: Boolean, evitar: Set<String>, manterPrevia: Boolean = false) {
        val g = ++geracao
        tInicio = System.currentTimeMillis()
        diag = ""
        // nova tentativa do áudio completo: a prévia que já está tocando NÃO é derrubada
        val manter = manterPrevia && previaAtiva && mp != null
        if (!manter) { liberar(); previaTerminou = false }
        atual = f; erro = ""
        if (!manter) { carregando = true; tocando = false }
        duracaoMs = f.duracao * 1000L
        focoTemporario = false
        etapa = "procurando o link"
        // relógio na tela (mostra a etapa e os segundos) + limite de 30 s: nunca mais fica "Carregando…" para sempre
        val relogio = object : Runnable {
            override fun run() {
                if (g != geracao || !carregando) return
                val seg = (System.currentTimeMillis() - tInicio) / 1000
                if (seg >= 30) {
                    geracao++
                    liberar()
                    carregando = false; tocando = false
                    erro = "Demorou demais (" + etapa + "). Toque em ▶ para tentar de novo."
                    MusicaService.atualizar()
                    return
                }
                diag = etapa + " · " + seg + "s"
                main.postDelayed(this, 1000L)
            }
        }
        main.postDelayed(relogio, 1000L)
        MusicaStore.guardarFaixa(f) // clicou → fica salva no JSON, não precisa pesquisar de novo
        MusicaService.atualizar()
        Thread {
            try {
                if (!forcarNovo && evitar.isEmpty() && f.id.startsWith("dz_") && Baixados.arquivo(f.id) == null && Pre.arquivo(f.id) == null) {
                    // PRÉVIA de 30 s (Deezer): toca já (do celular se estiver salva, senão pela rede); a música completa troca por cima
                    val pf = Pre.previaArquivo(f.id)
                    val fp = if (pf != null) Fluxo(pf.absolutePath, "", "local", Long.MAX_VALUE, f.titulo, f.artista, 30)
                        else YT.previa(f.id).let { u -> if (u.isBlank()) null else Fluxo(u, "ZerounAutomed", "prev", Long.MAX_VALUE, f.titulo, f.artista, 30) }
                    if (fp != null) Estado.ui { if (g == geracao && mp == null) iniciar(f, fp, false, evitar, g, null, true) }
                }
                var local = if (forcarNovo) null else (Baixados.arquivo(f.id) ?: Pre.arquivo(f.id))
                // pré-carga quase pronta: espera até 3 s por ela (abre na hora, sem streaming)
                if (local == null && !forcarNovo && Pre.emAndamento(f.id)) {
                    var k = 0
                    while (k < 30 && local == null && Pre.emAndamento(f.id)) { Thread.sleep(100); local = Pre.arquivo(f.id); k++ }
                    if (local == null) local = Pre.arquivo(f.id)
                }
                if (local != null) {
                    // música baixada: toca do próprio celular, sem internet
                    val fl = Fluxo(local.absolutePath, "", "local", Long.MAX_VALUE, f.titulo, f.artista, f.duracao)
                    Estado.ui { if (g == geracao) iniciar(f, fl, false, evitar, g, if (previaAtiva) mp else null, false) }
                } else {
                    val salvo = if (forcarNovo || evitar.isNotEmpty()) null else MusicaStore.stream(f.id)
                    var fl: Fluxo? = salvo
                    if (fl == null) {
                        try {
                            fl = resolverComRecuperacao(f, evitar).also { MusicaStore.guardarStream(f.id, it) }
                        } catch (e: Exception) {
                            if (YT.semRede(e)) throw e
                            // plano B: toca a mesma música pelo YouTube
                            etapa = "plano B (YouTube)"
                            val alt = YT.equivalenteYt(f) ?: throw e
                            fl = alt.second
                        }
                    }
                    val flf: Fluxo = fl!!
                    Estado.ui { if (g == geracao) iniciar(f, flf, salvo != null, evitar, g, if (previaAtiva) mp else null, false) }
                }
            } catch (e: Exception) {
                val msg = if (YT.semRede(e)) "Sem internet. Essa música ainda não foi baixada."
                    else (e.message ?: YT.detalhe(e))
                Estado.ui {
                    if (g == geracao) { carregando = false; erro = msg; MusicaService.atualizar() }
                }
            }
        }.start()
    }

    /** Se o bot esqueceu a música (reiniciou), pesquisa de novo em silêncio e tenta outra vez. */
    private fun resolverComRecuperacao(f: Som, evitar: Set<String>): Fluxo {
        try {
            return YT.resolver(f.id, evitar)
        } catch (e: Exception) {
            if ((e.message ?: "").contains("Busque a música")) {
                try { YT.buscar(f.titulo + " " + f.artista) } catch (x: Exception) { }
                return YT.resolver(f.id, evitar)
            }
            throw e
        }
    }

    /** Deixa o endereço da PRÓXIMA música da fila pronto: quando esta acabar, a seguinte começa na hora. */
    private fun preAquecerProxima() {
        // baixa as 2 próximas e a anterior: avançar / voltar abre um arquivo local, na hora
        val alvo = ArrayList<Som>()
        for (n in indice + 1..indice + 2) if (n in fila.indices) alvo.add(fila[n])
        if (indice - 1 in fila.indices) alvo.add(fila[indice - 1])
        Pre.pedir(alvo)
    }

    private fun falhou(f: Som, fl: Fluxo, doCache: Boolean, evitar: Set<String>) {
        if (fl.cliente == "local") { Baixados.apagar(f.id); Pre.apagar(f.id); carregar(f, true, emptySet(), previaAtiva); return } // arquivo estragado: baixa de novo
        if (doCache) { carregar(f, true, emptySet(), previaAtiva); return }
        val ev = evitar + fl.cliente
        if (fl.cliente != "srv" && fl.cliente !in evitar && ev.size < YT.tentativas(f.id)) { carregar(f, false, ev, previaAtiva); return }
        if (!previaAtiva) { liberar(); tocando = false }
        carregando = false
        erro = if (previaAtiva) "Só consegui a prévia de 30 s dessa música." else "Não consegui tocar essa música. Tente outra."
        MusicaService.atualizar()
        val g = geracao
        Thread {
            val m = YT.motivo(f.id)
            if (m.isNotBlank()) Estado.ui { if (g == geracao && !tocando && !previaAtiva) { erro = "Não toca: " + m; MusicaService.atualizar() } }
        }.start()
    }

    private fun iniciar(f: Som, fl: Fluxo, doCache: Boolean, evitar: Set<String>, g: Int, trocarDe: MediaPlayer?, previa: Boolean) {
        val c = app ?: return
        val agora = System.currentTimeMillis()
        if (!previa) {
            etapa = "abrindo o áudio"
            diagBase = "buscar áudio " + String.format("%.1f", (agora - tInicio) / 1000.0) + "s (" + (if (doCache) "cache" else fl.cliente) + ")"
            diag = diagBase
            tPrep = agora
        }
        try {
            val m = MediaPlayer()
            if (trocarDe == null) mp = m
            if (previa) previaAtiva = true
            val pronto = java.util.concurrent.atomic.AtomicBoolean(false)
            m.setAudioAttributes(atributos())
            m.setWakeMode(c, PowerManager.PARTIAL_WAKE_LOCK)
            if (fl.cliente == "local") m.setDataSource(fl.url)
            else m.setDataSource(c, Uri.parse(fl.url), mapOf("User-Agent" to fl.ua))
            // vigia: se o áudio não abrir a tempo (link travado), desiste e tenta o próximo caminho em vez de ficar em "Carregando…"
            val soltar = { if (trocarDe != null) { try { m.setOnPreparedListener(null); m.setOnErrorListener(null); m.release() } catch (e: Exception) { } } }
            val vigia = Runnable { if (g == geracao && !pronto.get() && !previa) { soltar(); falhou(f, fl, doCache, evitar) } }
            if (!previa) main.postDelayed(vigia, if (fl.cliente == "srv") 25_000L else 7_000L)
            m.setOnPreparedListener { p ->
                pronto.set(true)
                main.removeCallbacks(vigia)
                if (if (previa) mp === m else g == geracao) {
                    if (pedirFoco()) {
                        val d = p.duration
                        if (d > 0 && !previa) duracaoMs = d.toLong()
                        var deveTocar = true
                        if (trocarDe != null) {
                            // troca a prévia pela música completa, no mesmo ponto
                            val tocavaPrevia = try { trocarDe.isPlaying } catch (e: Exception) { false }
                            val pos = try { trocarDe.currentPosition } catch (e: Exception) { 0 }
                            deveTocar = tocavaPrevia || previaTerminou
                            mp = m
                            previaAtiva = false
                            try { trocarDe.setOnCompletionListener(null); trocarDe.setOnErrorListener(null); trocarDe.setOnPreparedListener(null) } catch (e: Exception) { }
                            try { trocarDe.release() } catch (e: Exception) { }
                            if (pos > 0) { try { p.seekTo(pos) } catch (e: Exception) { } }
                        }
                        if (deveTocar) { p.start(); tocando = true } else tocando = false
                        carregando = false
                        if (!previa) {
                            diag = diagBase + " · abrir " + String.format("%.1f", (System.currentTimeMillis() - tPrep) / 1000.0) + "s"
                            MusicaStore.registrarPlay(f) // conta como "ouvida" só quando a música completa começou
                            if (fl.cliente != "local" && MusicaStore.emAlgumaPlaylist(f.id)) Baixados.agendar(f)
                            preAquecerProxima()
                        }
                    } else {
                        tocando = false; carregando = false
                        erro = "Outro app está usando o áudio (ligação?). Toque em ▶ para tentar de novo."
                    }
                    MusicaService.atualizar()
                }
            }
            m.setOnCompletionListener {
                if (previa) {
                    if (mp === m) { previaTerminou = true; tocando = false; carregando = erro.isBlank(); MusicaService.atualizar() }
                } else if (g == geracao) proxima(true)
            }
            m.setOnErrorListener { _, _, _ ->
                main.removeCallbacks(vigia)
                if (previa) {
                    if (mp === m) { liberar(); carregando = true; tocando = false; MusicaService.atualizar() }
                } else if (g == geracao) { soltar(); falhou(f, fl, doCache, evitar) }
                true
            }
            m.prepareAsync()
        } catch (e: Exception) {
            if (g == geracao && !previa) falhou(f, fl, doCache, evitar)
        }
    }
}

/**
 * Serviço em primeiro plano: mantém a música tocando com a tela apagada e mostra o PLAYER na notificação,
 * no estilo do Spotify: capa grande, título/artista, botões anterior • play/pause • próxima • fechar
 * e barra de progresso que dá para arrastar (Android 13+; no 11/12 aparece no player rápido).
 * Usa MediaSession → também funciona na tela de bloqueio, fone de ouvido e Bluetooth do carro.
 */
class MusicaService : Service() {

    companion object {
        private const val CANAL = "musica_player"
        private const val ID_NOTIF = 4107
        private const val ACAO_TOCAR = "com.zeroun.automed.MUSICA_TOCAR"
        private const val ACAO_ANTERIOR = "com.zeroun.automed.MUSICA_ANTERIOR"
        private const val ACAO_PROXIMA = "com.zeroun.automed.MUSICA_PROXIMA"
        private const val ACAO_FECHAR = "com.zeroun.automed.MUSICA_FECHAR"
        private const val COR_PADRAO = 0xFF1B1B1E.toInt()

        private var instancia: MusicaService? = null

        fun garantir(c: Context) {
            if (instancia != null) return
            try { ContextCompat.startForegroundService(c, Intent(c, MusicaService::class.java)) } catch (e: Exception) { }
        }

        fun atualizar() { instancia?.renderizar() }
        fun parar() { instancia?.encerrar() }
    }

    private val main = Handler(Looper.getMainLooper())
    private var sessao: MediaSession? = null
    private var capaId: String? = null
    private var capaBmp: Bitmap? = null
    private var capaCor: Int = COR_PADRAO
    private var avatarBmp: Bitmap? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instancia = this
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        try { nm.deleteNotificationChannel("musica") } catch (e: Exception) { } // canal antigo (sem visual de player)
        val canal = NotificationChannel(CANAL, "Player de música", NotificationManager.IMPORTANCE_LOW)
        canal.description = "Capa, botões e barra de progresso da música que está tocando"
        canal.setShowBadge(false)
        canal.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        nm.createNotificationChannel(canal)

        try {
            val s = MediaSession(this, "ZerounMusica")
            s.setCallback(object : MediaSession.Callback() {
                override fun onPlay() { if (!Tocador.tocando) Tocador.alternar() }
                override fun onPause() { if (Tocador.tocando) Tocador.alternar() }
                override fun onSkipToNext() { Tocador.proxima() }
                override fun onSkipToPrevious() { Tocador.anterior() }
                override fun onSeekTo(pos: Long) { Tocador.ir(pos) }
                override fun onStop() { Tocador.encerrar() }
            })
            s.isActive = true
            sessao = s
        } catch (e: Exception) { }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACAO_TOCAR -> Tocador.alternar()
            ACAO_ANTERIOR -> Tocador.anterior()
            ACAO_PROXIMA -> Tocador.proxima()
            ACAO_FECHAR -> { Tocador.encerrar(); return START_NOT_STICKY }
        }
        renderizar()
        return START_NOT_STICKY
    }

    private fun intentAcao(a: String, codigo: Int): PendingIntent = PendingIntent.getService(
        this, codigo, Intent(this, MusicaService::class.java).setAction(a),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun botao(icone: Int, titulo: String, a: String, codigo: Int): Notification.Action =
        Notification.Action.Builder(Icon.createWithResource(this, icone), titulo, intentAcao(a, codigo)).build()

    /** Robô da Zeroun: aparece no lugar da capa enquanto ela não chega (ou se não existir). */
    private fun avatar(): Bitmap? {
        avatarBmp?.let { return it }
        return try { BitmapFactory.decodeResource(resources, R.drawable.zeroun_avatar).also { avatarBmp = it } } catch (e: Exception) { null }
    }

    /** Cor média da capa, escurecida (para o texto branco da notificação ler bem) — como o Spotify faz. */
    private fun corMedia(b: Bitmap): Int = try {
        val px = Bitmap.createScaledBitmap(b, 1, 1, true).getPixel(0, 0)
        val hsv = FloatArray(3)
        Color.colorToHSV(px, hsv)
        hsv[1] = hsv[1].coerceAtMost(0.85f)
        hsv[2] = hsv[2].coerceIn(0.18f, 0.38f)
        Color.HSVToColor(hsv)
    } catch (e: Exception) { COR_PADRAO }

    /** Baixa/abre a capa da música atual em segundo plano e refaz a notificação quando ela chegar. */
    private fun buscarCapa(f: Som?) {
        if (f == null || f.id == capaId) return
        val id = f.id
        capaId = id; capaBmp = null; capaCor = COR_PADRAO
        Thread {
            val bmp = try { Capas.carregar(id)?.asAndroidBitmap() } catch (e: Exception) { null }
            if (bmp != null) {
                val cor = corMedia(bmp)
                main.post { if (capaId == id && instancia === this) { capaBmp = bmp; capaCor = cor; renderizar() } }
            }
        }.start()
    }

    /** Diz ao Android o que está tocando e em que ponto (é daqui que vem a barra de progresso da notificação). */
    private fun atualizarSessao(f: Som?) {
        val s = sessao ?: return
        try {
            val dur = if (Tocador.duracaoMs > 0L) Tocador.duracaoMs else (f?.duracao ?: 0) * 1000L
            val md = MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, f?.titulo ?: "ZEROUN")
                .putString(MediaMetadata.METADATA_KEY_ARTIST, f?.artista ?: "")
                .putString(MediaMetadata.METADATA_KEY_ALBUM, "ZEROUN MÚSICA")
                .putLong(MediaMetadata.METADATA_KEY_DURATION, dur)
            val arte = capaBmp ?: avatar()
            if (arte != null) {
                md.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, arte)
                md.putBitmap(MediaMetadata.METADATA_KEY_ART, arte)
            }
            s.setMetadata(md.build())

            val estado = when {
                Tocador.carregando -> PlaybackState.STATE_BUFFERING
                Tocador.tocando -> PlaybackState.STATE_PLAYING
                else -> PlaybackState.STATE_PAUSED
            }
            val acoes = PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE or
                PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or
                PlaybackState.ACTION_SEEK_TO or PlaybackState.ACTION_STOP
            s.setPlaybackState(
                PlaybackState.Builder()
                    .setActions(acoes)
                    .setState(estado, Tocador.posicaoMs(), if (estado == PlaybackState.STATE_PLAYING) 1f else 0f)
                    .build()
            )
        } catch (e: Exception) { }
    }

    private fun montar(): Notification {
        val f = Tocador.atual
        val abrir = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val linha2 = when {
            Tocador.carregando -> "Procurando o áudio…"
            Tocador.erro.isNotBlank() -> Tocador.erro
            else -> f?.artista ?: ""
        }
        val estilo = Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2)
        val token = sessao?.sessionToken
        if (token != null) estilo.setMediaSession(token)

        return Notification.Builder(this, CANAL)
            .setSmallIcon(R.drawable.ic_stat_musica)
            .setContentTitle(f?.titulo ?: "Música")
            .setContentText(linha2)
            .setSubText("ZEROUN")
            .setLargeIcon(capaBmp ?: avatar())
            .setContentIntent(abrir)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(Notification.CATEGORY_TRANSPORT)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setColor(capaCor)
            .setColorized(true)
            .addAction(botao(R.drawable.ic_media_anterior, "Anterior", ACAO_ANTERIOR, 1))
            .addAction(
                if (Tocador.tocando) botao(R.drawable.ic_media_pausar, "Pausar", ACAO_TOCAR, 2)
                else botao(R.drawable.ic_media_tocar, "Tocar", ACAO_TOCAR, 2)
            )
            .addAction(botao(R.drawable.ic_media_proxima, "Próxima", ACAO_PROXIMA, 3))
            .addAction(botao(R.drawable.ic_media_fechar, "Fechar", ACAO_FECHAR, 4))
            .setStyle(estilo)
            .build()
    }

    fun renderizar() {
        try {
            buscarCapa(Tocador.atual)
            atualizarSessao(Tocador.atual)
            ServiceCompat.startForeground(
                this, ID_NOTIF, montar(),
                if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
            )
        } catch (e: Exception) { }
    }

    fun encerrar() {
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Exception) { }
        soltarSessao()
        stopSelf()
    }

    private fun soltarSessao() {
        val s = sessao
        sessao = null
        if (s != null) {
            try { s.isActive = false } catch (e: Exception) { }
            try { s.release() } catch (e: Exception) { }
        }
    }

    override fun onDestroy() {
        if (instancia === this) instancia = null
        soltarSessao()
        super.onDestroy()
    }
}
