# Atualização automática (via GitHub)

## Configurar UMA vez
1. Repositório PÚBLICO no GitHub.
2. Em `Atualizador.kt` troque `GITHUB_REPO = "SEU-USUARIO/SEU-REPOSITORIO"` pelo seu.
3. Instale o app. Na tela que aparece depois da key, toque em **Permitir atualizações** (passo "Atualizar sozinho").

## Para lançar uma versão
1. `app/build.gradle.kts`: mude só `nomeDaVersao` (ex.: "3.3.0").
2. Build > Build APK(s) -> app/build/outputs/apk/debug/app-debug.apk
3. GitHub > Releases > novo release, tag `v3.3.0` (mesmo número), anexe o APK, Publish.

## O que acontece no celular
- O app checa o GitHub de hora em hora (também quando está só rodando em segundo plano, lendo Pix).
- Achou versão nova + "Atualizar sozinho" ligado + permissão dada: baixa e instala sozinho.
- Android 12+: a 1ª atualização pede uma confirmação (regra do Android). As seguintes costumam entrar sem perguntar,
  porque o próprio app passa a ser o "instalador" dele. Alguns celulares (Xiaomi/MIUI/HyperOS, por ex.) ainda pedem
  confirmação: nesse caso aparece o aviso laranja no Início e é só tocar em "Instalar agora".
- Dá para desligar em Gerenciar > Atualização do app > Atualizar sozinho.
- A assinatura é fixa (`app/zeroun.jks`): guarde uma cópia. Sempre use o MESMO arquivo, senão o Android recusa instalar por cima.

## Celulares e keys no servidor
Ficam em JSON no servidor (keys.json e app_dispositivos.json), NUNCA dentro do zip/app. Veja SERVIDOR.md.
