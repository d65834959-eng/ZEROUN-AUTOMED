package com.zeroun.automed

import android.media.MediaPlayer
import android.media.audiofx.LoudnessEnhancer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

/**
 * Reforço de volume SÓ da música (não mexe no volume do celular).
 *
 * Usa o LoudnessEnhancer do Android: soma um ganho (em dB) ao áudio do player ANTES do volume do sistema.
 * Resultado: com o volume do celular baixo, a música continua alta. Ele já traz um limitador,
 * então estoura bem menos do que só "multiplicar" o som.
 *
 * nivel: 0 = desligado • 100 = máximo (+MAX_MB milibéis). Padrão: 100 (o mais alto possível).
 */
object Reforco {
    /** Ganho máximo em milibéis (3000 mB = +30 dB). Se distorcer no seu aparelho, baixe o nível no player. */
    private const val MAX_MB = 3000

    /** 0..100 — mostrado no player. */
    var nivel by mutableIntStateOf(100)
        private set

    private var efeito: LoudnessEnhancer? = null
    private var carregado = false

    /** Lê o nível salvo (chamado quando o Tocador inicia). */
    fun init() {
        if (carregado) return
        try { nivel = Prefs.reforco; carregado = true } catch (e: Exception) { }
    }

    /** Muda o nível ao vivo (a música que está tocando já muda na hora) e guarda para as próximas. */
    fun definir(n: Int, salvar: Boolean) {
        nivel = n.coerceIn(0, 100)
        aplicar()
        if (salvar) { try { Prefs.reforco = nivel } catch (e: Exception) { } }
    }

    /** Liga o reforço no player [p] (troca o efeito do player anterior). */
    fun ligar(p: MediaPlayer) {
        init()
        soltar()
        try {
            val e = LoudnessEnhancer(p.audioSessionId)
            efeito = e
            aplicar()
        } catch (e: Exception) {
            // aparelho sem suporte ao efeito: a música toca normal, só sem o reforço
            efeito = null
        }
    }

    fun soltar() {
        val e = efeito
        efeito = null
        if (e != null) { try { e.release() } catch (x: Exception) { } }
    }

    private fun aplicar() {
        val e = efeito ?: return
        try {
            if (nivel <= 0) {
                e.setEnabled(false)
            } else {
                e.setTargetGain(nivel * MAX_MB / 100)
                e.setEnabled(true)
            }
        } catch (x: Exception) { }
    }
}
