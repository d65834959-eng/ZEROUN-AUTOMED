package com.zeroun.automed

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * Toca a música completa obtida exclusivamente pelo Deezer (via ARL).
 */
object Tocador {
    private var app: Context? = null
    private val main = Handler(Looper.getMainLooper())
    private var mp: MediaPlayer? = null
    private var geracao = 0
    private var focoTemporario = false
    private var foco: AudioFocusRequest? = null

    var fila by mutableStateOf<List<Som>>(emptyList())
        private set
    var indice by mutableIntStateOf(0)
        private set
    var atual by mutableStateOf<Som?>(null)
        private set
    var tocando by mutableStateOf(false)
        private set
    var carregando by mutableStateOf(false)
        private set
    var erro by mutableStateOf("")
        private set
    var duracaoMs by mutableLongStateOf(0L)
        private set
    var aleatorio by mutableStateOf(false)
        private set
    var repetir by mutableIntStateOf(0)
        private set
    private var filaOriginal: List<Som> = emptyList()
    var diag by mutableStateOf("")
        private set
    private var tInicio = 0L
    private var tPrep = 0L
    private var diagBase = ""
    @Volatile private var etapa = "começando"

    fun init(c: Context) { app = c.applicationContext }

    private val ouvinteFoco = AudioManager.OnAudioFocusChangeListener { mudanca ->
        when (mudanca) {
            AudioManager.AUDIOFOCUS_LOSS -> { focoTemporario = false; pausarPorFoco() }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> { focoTemporario = true; pausarPorFoco() }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> { mp?.setVolume(0.25f, 0.25f) }
            AudioManager.AUDIOFOCUS_GAIN -> {
                mp?.setVolume(1f, 1f)
                if (focoTemporario) {
                    focoTemporario = false
                    try { mp?.start(); tocando = mp != null } catch (e: Exception) { }
                    MusicaService.atualizar()
                }
            }
        }
    }

    private fun pausarPorFoco() {
        try { if (mp?.isPlaying == true) mp?.pause() } catch (e: Exception) { }
        tocando = false
        MusicaService.atualizar()
    }

    private fun pedirFoco(): Boolean {
        val am = app?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return true
        val req = foco ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(atributos())
            .setOnAudioFocusChangeListener(ouvinteFoco, main)
            .build().also { foco = it }
        return am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun soltarFoco() {
        val am = app?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        foco?.let { am.abandonAudioFocusRequest(it) }
    }

    private fun atributos() = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    fun tocarLista(c: Context, lista: List<Som>, i: Int) {
        app = c.applicationContext
        if (lista.isEmpty() || i !in lista.indices) return
        filaOriginal = lista
        if (aleatorio) {
            fila = listOf(lista[i]) + lista.filterIndexed { k, _ -> k != i }.shuffled()
            indice = 0
        } else {
            fila = lista
            indice = i
        }
        MusicaService.garantir(c.applicationContext)
        carregar(lista[i], false)
    }

    fun alternarAleatorio() {
        val musica = atual
        if (!aleatorio) {
            aleatorio = true
            if (fila.isNotEmpty() && musica != null) {
                filaOriginal = fila
                fila = listOf(musica) + fila.filter { it.id != musica.id }.shuffled()
                indice = 0
            }
        } else {
            aleatorio = false
            if (filaOriginal.isNotEmpty() && musica != null) {
                fila = filaOriginal
                indice = fila.indexOfFirst { it.id == musica.id }.coerceAtLeast(0)
            }
        }
        MusicaService.atualizar()
    }

    fun alternarRepetir() { repetir = (repetir + 1) % 3 }

    fun alternar() {
        val m = mp
        if (m == null) {
            val f = atual
            if (f != null && !carregando) carregar(f, false)
            return
        }
        try {
            if (m.isPlaying) {
                m.pause(); tocando = false; focoTemporario = false
            } else if (!carregando && pedirFoco()) {
                m.start(); tocando = true
            }
        } catch (e: Exception) { }
        MusicaService.atualizar()
    }

    fun proxima(auto: Boolean = false) {
        if (auto && repetir == 2) {
            val m = mp
            if (m != null) {
                try { m.seekTo(0); m.start(); tocando = true; MusicaService.atualizar(); return } catch (e: Exception) { }
            }
            atual?.let { carregar(it, false) }
            return
        }
        val n = indice + 1
        if (n < fila.size) {
            indice = n
            carregar(fila[n], false)
        } else if (repetir == 1 && fila.isNotEmpty()) {
            indice = 0
            carregar(fila[0], false)
        } else if (auto) {
            liberar()
            tocando = false
            MusicaService.atualizar()
        }
    }

    fun anterior() {
        if (posicaoMs() > 3000L || indice <= 0) { ir(0L); return }
        indice -= 1
        carregar(fila[indice], false)
    }

    fun ir(ms: Long) {
        try { mp?.seekTo(ms.toInt()) } catch (e: Exception) { }
    }

    fun posicaoMs(): Long = try { (mp?.currentPosition ?: 0).toLong() } catch (e: Exception) { 0L }

    fun encerrar() {
        geracao++
        liberar()
        atual = null; tocando = false; carregando = false; erro = ""
        fila = emptyList(); indice = 0
        MusicaService.parar()
    }

    private fun liberar() {
        val m = mp
        mp = null
        if (m != null) {
            try { m.setOnCompletionListener(null); m.setOnErrorListener(null); m.setOnPreparedListener(null) } catch (e: Exception) { }
            try { m.release() } catch (e: Exception) { }
        }
        soltarFoco()
    }

    private fun carregar(f: Som, forcarNovo: Boolean) {
        val g = ++geracao
        tInicio = System.currentTimeMillis()
        diag = ""
        liberar()
        atual = f
        erro = ""
        carregando = true
        tocando = false
        duracaoMs = f.duracao * 1000L
        focoTemporario = false
        etapa = "autenticando no Deezer"

        val relogio = object : Runnable {
            override fun run() {
                if (g != geracao || !carregando) return
                val seg = (System.currentTimeMillis() - tInicio) / 1000
                if (seg >= 30) {
                    geracao++
                    liberar()
                    carregando = false; tocando = false
                    erro = "Demorou demais (" + etapa + "). Toque em ▶ para tentar de novo."
                    MusicaService.atualizar()
                    return
                }
                diag = etapa + " · " + seg + "s"
                main.postDelayed(this, 1000L)
            }
        }
        main.postDelayed(relogio, 1000L)
        MusicaStore.guardarFaixa(f)
        MusicaService.atualizar()

        Thread {
            try {
                if (forcarNovo) {
                    Baixados.apagar(f.id)
                    Pre.apagar(f.id)
                }

                var local = if (forcarNovo) null else (Baixados.arquivo(f.id) ?: Pre.arquivo(f.id))
                if (local == null && !forcarNovo && Pre.emAndamento(f.id)) {
                    var k = 0
                    while (k < 40 && local == null && Pre.emAndamento(f.id)) {
                        Thread.sleep(100)
                        local = Pre.arquivo(f.id)
                        k++
                    }
                    if (local == null) local = Pre.arquivo(f.id)
                }

                val fl = if (local != null) {
                    Fluxo(local.absolutePath, "", "deezer_local", Long.MAX_VALUE, f.titulo, f.artista, f.duracao)
                } else {
                    etapa = "baixando áudio completo (Deezer)"
                    YT.resolver(f.id, emptySet(), false).also { MusicaStore.guardarStream(f.id, it) }
                }

                Estado.ui { if (g == geracao) iniciar(f, fl, local != null, g) }
            } catch (e: Exception) {
                val msg = if (YT.semRede(e)) "Sem internet. Essa música ainda não foi baixada."
                else (e.message ?: YT.detalhe(e))
                Estado.ui {
                    if (g == geracao) {
                        carregando = false
                        erro = msg
                        MusicaService.atualizar()
                    }
                }
            }
        }.start()
    }

    private fun preAquecerProxima() {
        val alvo = ArrayList<Som>()
        for (n in indice + 1..indice + 2) if (n in fila.indices) alvo.add(fila[n])
        if (indice - 1 in fila.indices) alvo.add(fila[indice - 1])
        Pre.pedir(alvo)
    }

    private fun falhou(f: Som, jaForcou: Boolean) {
        Baixados.apagar(f.id)
        Pre.apagar(f.id)
        if (!jaForcou) {
            carregar(f, true)
            return
        }
        liberar()
        tocando = false
        carregando = false
        erro = "Não consegui tocar essa música pelo Deezer. Tente outra."
        MusicaService.atualizar()
    }

    private fun iniciar(f: Som, fl: Fluxo, doCache: Boolean, g: Int) {
        val c = app ?: return
        val agora = System.currentTimeMillis()
        etapa = "abrindo o áudio"
        diagBase = "Deezer " + String.format("%.1f", (agora - tInicio) / 1000.0) + "s (" + (if (doCache) "local" else fl.cliente) + ")"
        diag = diagBase
        tPrep = agora

        try {
            val m = MediaPlayer()
            mp = m
            val pronto = java.util.concurrent.atomic.AtomicBoolean(false)
            m.setAudioAttributes(atributos())
            m.setWakeMode(c, PowerManager.PARTIAL_WAKE_LOCK)
            m.setDataSource(fl.url)

            val vigia = Runnable {
                if (g == geracao && !pronto.get()) {
                    falhou(f, !doCache)
                }
            }
            main.postDelayed(vigia, 8_000L)

            m.setOnPreparedListener { p ->
                pronto.set(true)
                main.removeCallbacks(vigia)
                if (g == geracao) {
                    if (pedirFoco()) {
                        val d = p.duration
                        if (d > 0) duracaoMs = d.toLong()
                        p.start()
                        tocando = true
                        carregando = false
                        diag = diagBase + " · abrir " + String.format("%.1f", (System.currentTimeMillis() - tPrep) / 1000.0) + "s"
                        MusicaStore.registrarPlay(f)
                        if (MusicaStore.emAlgumaPlaylist(f.id)) Baixados.agendar(f)
                        preAquecerProxima()
                    } else {
                        tocando = false
                        carregando = false
                        erro = "Outro app está usando o áudio (ligação?). Toque em ▶ para tentar de novo."
                    }
                    MusicaService.atualizar()
                }
            }
            m.setOnCompletionListener {
                if (g == geracao) proxima(true)
            }
            m.setOnErrorListener { _, _, _ ->
                main.removeCallbacks(vigia)
                if (g == geracao) falhou(f, !doCache)
                true
            }
            m.prepareAsync()
        } catch (e: Exception) {
            if (g == geracao) falhou(f, !doCache)
        }
    }
}

/** Serviço em primeiro plano: mantém a música tocando com a tela apagada e mostra o botão na notificação. */
class MusicaService : Service() {

    companion object {
        private const val CANAL = "musica"
        private const val ID_NOTIF = 4107
        private const val ACAO_TOCAR = "com.zeroun.automed.MUSICA_TOCAR"
        private const val ACAO_PROXIMA = "com.zeroun.automed.MUSICA_PROXIMA"
        private const val ACAO_FECHAR = "com.zeroun.automed.MUSICA_FECHAR"

        private var instancia: MusicaService? = null

        fun garantir(c: Context) {
            if (instancia != null) return
            try { ContextCompat.startForegroundService(c, Intent(c, MusicaService::class.java)) } catch (e: Exception) { }
        }

        fun atualizar() { instancia?.renderizar() }
        fun parar() { instancia?.encerrar() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instancia = this
        val canal = NotificationChannel(CANAL, "Música", NotificationManager.IMPORTANCE_LOW)
        canal.description = "Controles da música que está tocando"
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(canal)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACAO_TOCAR -> Tocador.alternar()
            ACAO_PROXIMA -> Tocador.proxima()
            ACAO_FECHAR -> { Tocador.encerrar(); return START_NOT_STICKY }
        }
        renderizar()
        return START_NOT_STICKY
    }

    private fun acao(a: String, codigo: Int): PendingIntent = PendingIntent.getService(
        this, codigo, Intent(this, MusicaService::class.java).setAction(a),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun montar(): Notification {
        val f = Tocador.atual
        val abrir = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val linha2 = when {
            Tocador.carregando -> "Baixando faixa do Deezer…"
            Tocador.erro.isNotBlank() -> Tocador.erro
            else -> f?.artista ?: ""
        }
        return NotificationCompat.Builder(this, CANAL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(f?.titulo ?: "Música")
            .setContentText(linha2)
            .setContentIntent(abrir)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(
                if (Tocador.tocando) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                if (Tocador.tocando) "Pausar" else "Tocar", acao(ACAO_TOCAR, 1)
            )
            .addAction(android.R.drawable.ic_media_next, "Próxima", acao(ACAO_PROXIMA, 2))
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Fechar", acao(ACAO_FECHAR, 3))
            .build()
    }

    fun renderizar() {
        try {
            ServiceCompat.startForeground(
                this, ID_NOTIF, montar(),
                if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
            )
        } catch (e: Exception) { }
    }

    fun encerrar() {
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Exception) { }
        stopSelf()
    }

    override fun onDestroy() {
        if (instancia === this) instancia = null
        super.onDestroy()
    }
}
ltar = { if (trocarDe != null) { try { m.setOnPreparedListener(null); m.setOnErrorListener(null); m.release() } catch (e: Exception) { } } }
            val vigia = Runnable { if (g == geracao && !pronto.get() && !previa) { soltar(); falhou(f, fl, doCache, evitar) } }
            if (!previa) main.postDelayed(vigia, if (fl.cliente == "srv") 25_000L else 7_000L)
            m.setOnPreparedListener { p ->
                pronto.set(true)
                main.removeCallbacks(vigia)
                if (if (previa) mp === m else g == geracao) {
                    if (pedirFoco()) {
                        val d = p.duration
                        if (d > 0 && !previa) duracaoMs = d.toLong()
                        var deveTocar = true
                        if (trocarDe != null) {
                            // troca a prévia pela música completa, no mesmo ponto
                            val tocavaPrevia = try { trocarDe.isPlaying } catch (e: Exception) { false }
                            val pos = try { trocarDe.currentPosition } catch (e: Exception) { 0 }
                            deveTocar = tocavaPrevia || previaTerminou
                            mp = m
                            previaAtiva = false
                            try { trocarDe.setOnCompletionListener(null); trocarDe.setOnErrorListener(null); trocarDe.setOnPreparedListener(null) } catch (e: Exception) { }
                            try { trocarDe.release() } catch (e: Exception) { }
                            if (pos > 0) { try { p.seekTo(pos) } catch (e: Exception) { } }
                        }
                        if (deveTocar) { p.start(); tocando = true } else tocando = false
                        carregando = false
                        if (!previa) {
                            diag = diagBase + " · abrir " + String.format("%.1f", (System.currentTimeMillis() - tPrep) / 1000.0) + "s"
                            MusicaStore.registrarPlay(f) // conta como "ouvida" só quando a música completa começou
                            if (fl.cliente != "local" && MusicaStore.emAlgumaPlaylist(f.id)) Baixados.agendar(f)
                            preAquecerProxima()
                        }
                    } else {
                        tocando = false; carregando = false
                        erro = "Outro app está usando o áudio (ligação?). Toque em ▶ para tentar de novo."
                    }
                    MusicaService.atualizar()
                }
            }
            m.setOnCompletionListener {
                if (previa) {
                    if (mp === m) { previaTerminou = true; tocando = false; carregando = erro.isBlank(); MusicaService.atualizar() }
                } else if (g == geracao) proxima(true)
            }
            m.setOnErrorListener { _, _, _ ->
                main.removeCallbacks(vigia)
                if (previa) {
                    if (mp === m) { liberar(); carregando = true; tocando = false; MusicaService.atualizar() }
                } else if (g == geracao) { soltar(); falhou(f, fl, doCache, evitar) }
                true
            }
            m.prepareAsync()
        } catch (e: Exception) {
            if (g == geracao && !previa) falhou(f, fl, doCache, evitar)
        }
    }
}

/** Serviço em primeiro plano: mantém a música tocando com a tela apagada e mostra o botão na notificação. */
class MusicaService : Service() {

    companion object {
        private const val CANAL = "musica"
        private const val ID_NOTIF = 4107
        private const val ACAO_TOCAR = "com.zeroun.automed.MUSICA_TOCAR"
        private const val ACAO_PROXIMA = "com.zeroun.automed.MUSICA_PROXIMA"
        private const val ACAO_FECHAR = "com.zeroun.automed.MUSICA_FECHAR"

        private var instancia: MusicaService? = null

        fun garantir(c: Context) {
            if (instancia != null) return
            try { ContextCompat.startForegroundService(c, Intent(c, MusicaService::class.java)) } catch (e: Exception) { }
        }

        fun atualizar() { instancia?.renderizar() }
        fun parar() { instancia?.encerrar() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instancia = this
        val canal = NotificationChannel(CANAL, "Música", NotificationManager.IMPORTANCE_LOW)
        canal.description = "Controles da música que está tocando"
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(canal)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACAO_TOCAR -> Tocador.alternar()
            ACAO_PROXIMA -> Tocador.proxima()
            ACAO_FECHAR -> { Tocador.encerrar(); return START_NOT_STICKY }
        }
        renderizar()
        return START_NOT_STICKY
    }

    private fun acao(a: String, codigo: Int): PendingIntent = PendingIntent.getService(
        this, codigo, Intent(this, MusicaService::class.java).setAction(a),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun montar(): Notification {
        val f = Tocador.atual
        val abrir = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val linha2 = when {
            Tocador.carregando -> "Procurando o áudio…"
            Tocador.erro.isNotBlank() -> Tocador.erro
            else -> f?.artista ?: ""
        }
        return NotificationCompat.Builder(this, CANAL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(f?.titulo ?: "Música")
            .setContentText(linha2)
            .setContentIntent(abrir)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(
                if (Tocador.tocando) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                if (Tocador.tocando) "Pausar" else "Tocar", acao(ACAO_TOCAR, 1)
            )
            .addAction(android.R.drawable.ic_media_next, "Próxima", acao(ACAO_PROXIMA, 2))
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Fechar", acao(ACAO_FECHAR, 3))
            .build()
    }

    fun renderizar() {
        try {
            ServiceCompat.startForeground(
                this, ID_NOTIF, montar(),
                if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
            )
        } catch (e: Exception) { }
    }

    fun encerrar() {
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Exception) { }
        stopSelf()
    }

    override fun onDestroy() {
        if (instancia === this) instancia = null
        super.onDestroy()
    }
}
