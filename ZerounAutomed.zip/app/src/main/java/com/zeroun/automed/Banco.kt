package com.zeroun.automed

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Error
import androidx.compose.material.icons.rounded.Receipt
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ───────────────────────── dados ─────────────────────────

/** Uma linha do extrato. [entrada] = dinheiro que entrou • false = saiu. */
data class Mov(
    val id: String, val entrada: Boolean, val valor: Double, val nome: String,
    val descricao: String, val chave: String, val ts: Long, val status: String
)

data class ResultadoPix(val ok: Boolean, val msg: String, val id: String, val valor: Double, val nome: String)

enum class TelaBanco { HOME, EXTRATO, PIX }

/**
 * Banco do app (conta AutoPay). Fala com o bot por 2 endpoints (veja docs/5-BANCO-API.md):
 *   /api/banco       -> saldo + extrato
 *   /api/pix_enviar  -> faz um Pix
 * Enquanto o servidor não tiver esses endpoints, o extrato mostra os Pix lidos pelo app e o saldo fica em "—".
 */
object Banco {
    var tela by mutableStateOf(TelaBanco.HOME)
    var saldo by mutableStateOf<Double?>(null)
    var titular by mutableStateOf("")
    var conta by mutableStateOf("")
    val extrato = mutableStateListOf<Mov>()
    var carregando by mutableStateOf(false)
    var carregou by mutableStateOf(false)
    /** false = o servidor ainda não tem /api/banco (aí usamos só os Pix lidos). */
    var servidorOk by mutableStateOf(true)
    var erro by mutableStateOf("")
    var enviando by mutableStateOf(false)
    var resultado by mutableStateOf<ResultadoPix?>(null)

    var ocultar by mutableStateOf(false)
    fun alternarOcultar() { ocultar = !ocultar; Prefs.ocultarSaldo = ocultar }

    private fun lerMov(o: org.json.JSONObject): Mov {
        val tipo = o.optString("tipo", "entrada").lowercase()
        return Mov(
            id = o.optString("id", ""),
            entrada = !(tipo.startsWith("sa") || tipo == "debito" || tipo == "out"),
            valor = Math.abs(o.optDouble("valor", 0.0)),
            nome = o.optString("nome", ""),
            descricao = o.optString("descricao", ""),
            chave = o.optString("chave", ""),
            ts = o.optLong("ts", System.currentTimeMillis()),
            status = o.optString("status", "concluido")
        )
    }

    fun carregar() {
        if (carregando) return
        carregando = true
        Thread {
            val r = Net.post("/api/banco", Net.corpo())
            Estado.ui {
                carregando = false
                if (r == null) {
                    erro = "Sem resposta do bot. Confira a internet."
                } else if (!r.optBoolean("ok", false)) {
                    val m = r.optString("msg", "")
                    if (m.contains("desconhecido", true) || m.contains("not found", true)) { servidorOk = false; erro = "" }
                    else erro = m.ifBlank { "Erro ao consultar o banco." }
                } else {
                    servidorOk = true; erro = ""; carregou = true
                    saldo = if (r.has("saldo") && !r.isNull("saldo")) r.optDouble("saldo") else null
                    titular = r.optString("titular", titular)
                    conta = r.optString("conta", conta)
                    val arr = r.optJSONArray("extrato")
                    if (arr != null) {
                        val l = ArrayList<Mov>()
                        for (i in 0 until arr.length()) l.add(lerMov(arr.getJSONObject(i)))
                        extrato.clear(); extrato.addAll(l.sortedByDescending { it.ts })
                    }
                }
            }
        }.start()
    }

    fun enviarPix(chave: String, valor: Double, descricao: String, nome: String) {
        if (enviando) return
        enviando = true
        Thread {
            val r = Net.post(
                "/api/pix_enviar",
                Net.corpo().put("chave", chave).put("valor", valor).put("descricao", descricao)
            )
            Estado.ui {
                enviando = false
                if (r == null) {
                    resultado = ResultadoPix(false, "Sem resposta do bot. O Pix pode ou não ter sido enviado: confira o extrato antes de tentar de novo.", "", valor, nome)
                } else if (r.optBoolean("ok", false)) {
                    if (r.has("saldo") && !r.isNull("saldo")) saldo = r.optDouble("saldo")
                    resultado = ResultadoPix(true, r.optString("msg", "Pix enviado!"), r.optString("id", ""), valor, r.optString("nome", nome))
                    carregar()
                } else {
                    val m = r.optString("msg", "Não foi possível enviar o Pix.")
                    val amigavel = if (m.contains("desconhecido", true))
                        "O servidor do bot ainda não tem o envio de Pix ligado. Veja docs/5-BANCO-API.md." else m
                    resultado = ResultadoPix(false, amigavel, "", valor, nome)
                }
            }
        }.start()
    }

    /** Extrato que a tela mostra: o do banco; se o servidor ainda não tem, os Pix lidos pelo app. */
    fun movimentos(): List<Mov> =
        if (servidorOk) extrato.toList()
        else Estado.pix.map { Mov("", true, it.valor, it.nome.ifBlank { "Pix recebido" }, it.fonte, "", it.ts, "concluido") }
}

// ───────────────────────── formatação ─────────────────────────

private val PT = Locale("pt", "BR")
private fun horaMin(ts: Long): String = SimpleDateFormat("HH:mm", PT).format(Date(ts))
private fun dataCompleta(ts: Long): String = SimpleDateFormat("dd/MM/yyyy 'às' HH:mm", PT).format(Date(ts))
private fun chaveDia(ts: Long): String = SimpleDateFormat("yyyyMMdd", PT).format(Date(ts))

private fun rotuloDia(ts: Long): String {
    val hoje = Calendar.getInstance()
    val ontem = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
    val k = chaveDia(ts)
    return when (k) {
        chaveDia(hoje.timeInMillis) -> "Hoje"
        chaveDia(ontem.timeInMillis) -> "Ontem"
        else -> SimpleDateFormat("d 'de' MMMM", PT).format(Date(ts))
    }
}

private fun valorSinal(m: Mov): String = (if (m.entrada) "+ " else "− ") + brl(m.valor)

private val RoxoBanco = Color(0xFF8A05BE)

// ───────────────────────── tela principal da aba ─────────────────────────

@Composable
fun BancoAba() {
    LaunchedEffect(Unit) {
        Banco.ocultar = Prefs.ocultarSaldo
        while (true) {
            if (Prefs.conectado) Banco.carregar()
            delay(15_000)
        }
    }
    BackHandler(enabled = Banco.tela != TelaBanco.HOME) { Banco.tela = TelaBanco.HOME }
    when (Banco.tela) {
        TelaBanco.HOME -> BancoHome()
        TelaBanco.EXTRATO -> BancoExtrato()
        TelaBanco.PIX -> BancoPix()
    }
}

// ───────────────────────── HOME: saldo + atalhos ─────────────────────────

@Composable
private fun BancoHome() {
    Pagina("Banco", "Sua conta AutoPay") {
        CartaoSaldo(grande = true) { Banco.tela = TelaBanco.EXTRATO }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AcaoTile(Icons.Rounded.Send, "Pix", Cor.Verde, Modifier.weight(1f)) { Banco.tela = TelaBanco.PIX }
            AcaoTile(Icons.Rounded.Receipt, "Extrato", Cor.Roxo, Modifier.weight(1f)) { Banco.tela = TelaBanco.EXTRATO }
            AcaoTile(Icons.Rounded.Refresh, if (Banco.carregando) "Atualizando" else "Atualizar", Cor.Azul, Modifier.weight(1f)) { Banco.carregar(); Estado.atualizar() }
        }

        if (Banco.erro.isNotBlank()) Text("⚠️ " + Banco.erro, color = Cor.Vermelho, fontSize = 12.sp, fontWeight = FontWeight.Bold)

        TituloGrupo("MOVIMENTAÇÕES", Cor.Roxo)
        val lista = Banco.movimentos()
        if (lista.isEmpty()) {
            Cartao {
                Text("Nenhuma movimentação ainda", color = Cor.Texto, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text("Quando entrar ou sair dinheiro, aparece aqui.", color = Cor.Muted, fontSize = 13.sp)
            }
        } else {
            ListaMov(lista.take(5))
            Botao("Ver extrato completo", Cor.Card2, icone = Icons.Rounded.Receipt) { Banco.tela = TelaBanco.EXTRATO }
        }
        NotaServidor()
    }
}

/** Aviso discreto (sem texto técnico) de que saldo e envio ainda dependem do servidor. */
@Composable
private fun NotaServidor() {
    if (Banco.servidorOk) return
    Text(
        "Mostrando os Pix recebidos lidos pelo app. O saldo e o envio de Pix aparecem aqui quando a conta AutoPay for conectada ao bot.",
        color = Cor.Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 6.dp)
    )
}

/** Cartão principal: roxo profundo com brilho suave. Mostra o saldo (ou o recebido hoje, se o servidor ainda não manda o saldo). */
@Composable
private fun CartaoSaldo(grande: Boolean, onClick: (() -> Unit)?) {
    val forma = RoundedCornerShape(28.dp)
    val fundo = Brush.linearGradient(listOf(Color(0xFF8A05BE), Color(0xFF5A0B96), Color(0xFF2E0A5C)))
    var m = Modifier.fillMaxWidth().clip(forma).background(fundo)
        .drawBehind {
            drawCircle(Color.White.copy(alpha = 0.07f), radius = size.width * 0.55f, center = Offset(size.width * 1.02f, -size.height * 0.10f))
            drawCircle(Color.White.copy(alpha = 0.05f), radius = size.width * 0.35f, center = Offset(size.width * 0.05f, size.height * 1.05f))
        }
    if (onClick != null) m = m.clickable(onClick = onClick)
    val saldo = Banco.saldo
    val temSaldo = saldo != null
    Column(m.padding(horizontal = 22.dp, vertical = if (grande) 22.dp else 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(30.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Bolt, null, tint = Color.White, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.width(10.dp))
            Text("AutoPay", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, modifier = Modifier.weight(1f))
            Icon(
                if (Banco.ocultar) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, "Mostrar ou ocultar saldo",
                tint = Color.White, modifier = Modifier.size(34.dp).clip(CircleShape).clickable { Banco.alternarOcultar() }.padding(5.dp)
            )
        }
        Spacer(Modifier.height(if (grande) 22.dp else 10.dp))
        Text(
            if (temSaldo) "Saldo em conta" else "Recebido hoje",
            color = Color.White.copy(alpha = 0.78f), fontSize = 13.sp, fontWeight = FontWeight.Medium
        )
        Spacer(Modifier.height(2.dp))
        Text(
            if (Banco.ocultar) "R$ ••••••" else brl(if (temSaldo) saldo!! else Estado.totalHoje),
            color = Color.White, fontSize = if (grande) 38.sp else 28.sp, fontWeight = FontWeight.Black
        )
        if (!temSaldo) {
            Text("${Estado.hoje} Pix lido(s) hoje", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
        } else if (Banco.titular.isNotBlank() || Banco.conta.isNotBlank()) {
            Text(
                listOf(Banco.titular, Banco.conta).filter { it.isNotBlank() }.joinToString(" • "),
                color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        if (onClick != null) {
            Spacer(Modifier.height(16.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.18f)))
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Ver extrato", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Icon(Icons.Rounded.ChevronRight, null, tint = Color.White)
            }
        }
    }
}

/** Atalho em cartão (ícone em cima, nome embaixo). */
@Composable
private fun AcaoTile(icone: androidx.compose.ui.graphics.vector.ImageVector, rotulo: String, cor: Color, modifier: Modifier, onClick: () -> Unit) {
    val forma = RoundedCornerShape(20.dp)
    Column(
        modifier.suave(forma).clip(forma).background(Cor.Card).border(1.dp, Cor.Borda, forma)
            .clickable(onClick = onClick).padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        IconeCaixa(icone, cor, 44)
        Spacer(Modifier.height(8.dp))
        Text(rotulo, color = Cor.Texto, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
    }
}

// ───────────────────────── lista de movimentações ─────────────────────────

@Composable
private fun ListaMov(lista: List<Mov>) {
    var aberto by remember { mutableStateOf<Mov?>(null) }
    val forma = RoundedCornerShape(26.dp)
    Column(Modifier.fillMaxWidth().suave(forma).clip(forma).background(Cor.Card).border(1.dp, Cor.Borda, forma).padding(vertical = 6.dp)) {
        lista.forEachIndexed { i, m ->
            LinhaMov(m) { aberto = m }
            if (i < lista.size - 1) Box(Modifier.fillMaxWidth().padding(horizontal = 18.dp).height(1.dp).background(Cor.Borda))
        }
    }
    aberto?.let { DetalheMov(it) { aberto = null } }
}

/** "TURBOFY TECNOLOGIAS LTDA." -> "Turbofy Tecnologias Ltda." (nomes em CAIXA ALTA ficam legíveis). */
private fun nomeBonito(n: String): String {
    val t = n.trim()
    if (t.isEmpty() || t != t.uppercase()) return t
    return t.lowercase().split(" ").joinToString(" ") { w ->
        if (w in listOf("de", "da", "do", "das", "dos", "e")) w else w.replaceFirstChar { it.uppercase() }
    }
}

@Composable
private fun LinhaMov(m: Mov, onClick: () -> Unit) {
    val cor = if (m.entrada) Cor.Verde else Cor.Vermelho
    val nome = nomeBonito(m.nome).ifBlank { if (m.entrada) "Pix recebido" else "Pix enviado" }
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(46.dp).clip(CircleShape).background(cor.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
            Text(nome.take(1).uppercase(), color = cor, fontWeight = FontWeight.Black, fontSize = 18.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(nome, color = Cor.Texto, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                (if (m.entrada) "Pix recebido" else "Pix enviado") + " • " + horaMin(m.ts),
                color = Cor.Muted, fontSize = 12.sp, maxLines = 1
            )
        }
        Spacer(Modifier.width(8.dp))
        Text(
            if (Banco.ocultar) "R$ ••••" else valorSinal(m),
            color = if (m.entrada) Cor.Verde else Cor.Texto, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, maxLines = 1
        )
    }
}

@Composable
private fun DetalheMov(m: Mov, fechar: () -> Unit) {
    val clip = LocalClipboardManager.current
    AlertDialog(
        onDismissRequest = fechar,
        containerColor = Cor.Card, titleContentColor = Cor.Texto, textContentColor = Cor.Muted,
        title = { Text(if (m.entrada) "Pix recebido" else "Pix enviado", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(valorSinal(m), color = if (m.entrada) Cor.Verde else Cor.Texto, fontSize = 28.sp, fontWeight = FontWeight.Black)
                if (m.nome.isNotBlank()) Text((if (m.entrada) "De: " else "Para: ") + nomeBonito(m.nome), color = Cor.Texto)
                if (m.chave.isNotBlank()) Text("Chave: " + m.chave, color = Cor.Muted, fontSize = 13.sp)
                if (m.descricao.isNotBlank()) Text((if (m.entrada) "Recebido via: " else "Descrição: ") + m.descricao, color = Cor.Muted, fontSize = 13.sp)
                Text("Data: " + dataCompleta(m.ts), color = Cor.Muted, fontSize = 13.sp)
                Text("Status: " + m.status.replaceFirstChar { it.uppercase() }, color = Cor.Muted, fontSize = 13.sp)
                if (m.id.isNotBlank()) Text("ID: " + m.id, color = Cor.Muted, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton(onClick = fechar) { Text("Fechar", color = Cor.Texto, fontWeight = FontWeight.Bold) } },
        dismissButton = {
            if (m.id.isNotBlank()) TextButton(onClick = { clip.setText(AnnotatedString(m.id)) }) { Text("Copiar ID", color = Cor.Azul) }
        }
    )
}

// ───────────────────────── EXTRATO ─────────────────────────

/** Página com seta de voltar (igual às telas internas de um banco). */
@Composable
private fun PaginaVoltar(titulo: String, sub: String, conteudo: @Composable () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 20.dp, top = 16.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(Cor.Card).border(1.dp, Cor.Borda, CircleShape)
                    .clickable { Banco.tela = TelaBanco.HOME },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.ArrowBack, "Voltar", tint = Cor.Texto) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(titulo, color = Cor.Texto, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                Text(sub, color = Cor.Muted, fontSize = 14.sp)
            }
        }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            conteudo()
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun BancoExtrato() {
    var filtro by remember { mutableStateOf(0) } // 0 tudo • 1 entradas • 2 saídas
    PaginaVoltar("Extrato", "Tudo que entrou e saiu") {
        CartaoSaldo(grande = false, onClick = null)

        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("Tudo", RoxoBanco, filtro == 0) { filtro = 0 }
            Chip("Entradas", Cor.Verde, filtro == 1) { filtro = 1 }
            Chip("Saídas", Cor.Vermelho, filtro == 2) { filtro = 2 }
        }

        NotaServidor()

        val todos = Banco.movimentos()
        val lista = when (filtro) { 1 -> todos.filter { it.entrada }; 2 -> todos.filter { !it.entrada }; else -> todos }
        if (lista.isEmpty()) {
            Cartao {
                Text("Nada por aqui.", color = Cor.Texto, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text("Nenhuma movimentação neste filtro.", color = Cor.Muted, fontSize = 12.sp)
            }
        } else {
            val totalEntradas = lista.filter { it.entrada }.sumOf { it.valor }
            val totalSaidas = lista.filter { !it.entrada }.sumOf { it.valor }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Estatistica(if (Banco.ocultar) "••••" else brl(totalEntradas), "Entrou", Cor.Verde, Modifier.weight(1f))
                Estatistica(if (Banco.ocultar) "••••" else brl(totalSaidas), "Saiu", Cor.Vermelho, Modifier.weight(1f))
            }
            lista.groupBy { chaveDia(it.ts) }.forEach { (_, doDia) ->
                Text(rotuloDia(doDia.first().ts), color = Cor.Texto, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, modifier = Modifier.padding(top = 6.dp))
                ListaMov(doDia)
            }
        }
    }
}

// ───────────────────────── PIX ─────────────────────────

@Composable
private fun BancoPix() {
    var chave by remember { mutableStateOf("") }
    var valor by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var erro by remember { mutableStateOf("") }
    var confirmar by remember { mutableStateOf(false) }

    val v = lerValor(valor)
    val recentes = Banco.movimentos().filter { !it.entrada && it.chave.isNotBlank() }.distinctBy { it.chave }.take(6)

    PaginaVoltar("Pix", "Transferir pela AutoPay") {
        CartaoSaldo(grande = false, onClick = null)

        Cartao {
            Text("Para quem?", color = Cor.Texto, fontWeight = FontWeight.Black, fontSize = 17.sp)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = chave, onValueChange = { chave = it.take(80); erro = "" }, singleLine = true,
                label = { Text("Chave Pix") }, placeholder = { Text("CPF, e-mail, celular ou aleatória") },
                modifier = Modifier.fillMaxWidth()
            )
            if (recentes.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Text("RECENTES", color = Cor.Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Spacer(Modifier.height(6.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    recentes.forEach { Chip(it.nome.ifBlank { it.chave }.take(16), Cor.Azul, chave == it.chave) { chave = it.chave; erro = "" } }
                }
            }
        }

        Cartao {
            Text("Quanto?", color = Cor.Texto, fontWeight = FontWeight.Black, fontSize = 17.sp)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = valor, onValueChange = { valor = it.take(12); erro = "" }, singleLine = true,
                label = { Text("Valor (R$)") }, placeholder = { Text("0,00") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(10, 20, 50, 100, 200).forEach { q -> Chip("R$ $q", Cor.Verde, false) { valor = "$q"; erro = "" } }
            }
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = desc, onValueChange = { desc = it.take(60) }, singleLine = true,
                label = { Text("Mensagem (opcional)") }, modifier = Modifier.fillMaxWidth()
            )
        }

        if (erro.isNotBlank()) Text("⚠️ $erro", color = Cor.Vermelho, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        NotaServidor()

        Botao(
            if (Banco.enviando) "Enviando…" else "Continuar", Cor.Verde, icone = Icons.Rounded.Send,
            enabled = !Banco.enviando
        ) {
            val s = Banco.saldo
            when {
                chave.isBlank() -> { erro = "Digite a chave Pix de quem vai receber." }
                v == null || v <= 0.0 -> { erro = "Digite um valor maior que zero (ex.: 25,50)." }
                s != null && v > s -> { erro = "Saldo insuficiente. Você tem ${brl(s)}." }
                else -> { erro = ""; confirmar = true }
            }
        }
    }

    if (confirmar && v != null) {
        AlertDialog(
            onDismissRequest = { confirmar = false },
            containerColor = Cor.Card, titleContentColor = Cor.Texto, textContentColor = Cor.Muted,
            title = { Text("Confirmar Pix", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(brl(v), color = Cor.Texto, fontSize = 30.sp, fontWeight = FontWeight.Black)
                    Text("Para a chave:", color = Cor.Muted, fontSize = 13.sp)
                    Text(chave.trim(), color = Cor.Texto, fontWeight = FontWeight.Bold)
                    if (desc.isNotBlank()) Text("Mensagem: $desc", color = Cor.Muted, fontSize = 13.sp)
                    Text("Confira com atenção: o Pix não pode ser desfeito.", color = Cor.Laranja, fontSize = 12.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { confirmar = false; Banco.enviarPix(chave.trim(), v, desc.trim(), chave.trim()) }) {
                    Text("Enviar agora", color = Cor.Verde, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { confirmar = false }) { Text("Cancelar", color = Cor.Muted) } }
        )
    }

    val res = Banco.resultado
    if (res != null) {
        val cor = if (res.ok) Cor.Verde else Cor.Vermelho
        AlertDialog(
            onDismissRequest = { Banco.resultado = null },
            containerColor = Cor.Card, titleContentColor = Cor.Texto, textContentColor = Cor.Muted,
            icon = { Icon(if (res.ok) Icons.Rounded.CheckCircle else Icons.Rounded.Error, null, tint = cor, modifier = Modifier.size(48.dp)) },
            title = { Text(if (res.ok) "Pix enviado!" else "Pix não enviado", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (res.ok) Text(brl(res.valor), color = Cor.Texto, fontSize = 26.sp, fontWeight = FontWeight.Black)
                    Text(res.msg, color = Cor.Muted, fontSize = 13.sp)
                    if (res.id.isNotBlank()) Text("Comprovante: " + res.id, color = Cor.Muted, fontSize = 11.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val ok = res.ok
                    Banco.resultado = null
                    if (ok) { chave = ""; valor = ""; desc = ""; Banco.tela = TelaBanco.EXTRATO }
                }) { Text(if (res.ok) "Ver extrato" else "Fechar", color = cor, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                if (res.ok) TextButton(onClick = { Banco.resultado = null; chave = ""; valor = ""; desc = "" }) { Text("Fechar", color = Cor.Muted) }
            }
        )
    }
}
