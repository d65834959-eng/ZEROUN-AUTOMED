package com.zeroun.automed

import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONObject

data class MsgTipo(val k: String, val rotulo: String, val descricao: String, val placeholders: String, val padrao: String)
data class SalaTipo(val k: String, val rotulo: String, val descricao: String, val padrao: String)
data class Servidor(val id: String, val nome: String, val antiban: Boolean, val salasAutomed: Boolean)
data class Variavel(val id: String, val gatilho: String, val mensagem: String)
data class Comando(val custom: String, val efetivo: String)
data class DetalheServidor(
    val id: String,
    val nome: String,
    val antiban: Boolean,
    val msgs: Map<String, String>,
    val imagem: String,
    val comandos: Map<String, Comando>
)

/** Tudo que o app mostra/edita do bot: conta, servidores, antiban, mensagens, variáveis, modo fantasma e comandos de sala. */
object Painel {
    private val main = Handler(Looper.getMainLooper())

    var carregado by mutableStateOf(false)
    var carregando by mutableStateOf(false)
    var erro by mutableStateOf("")
    var aviso by mutableStateOf("")
    var avisoOk by mutableStateOf(true)

    // conta
    var userId by mutableStateOf("")
    var nome by mutableStateOf("")
    var contaOnline by mutableStateOf(false)
    var automed by mutableStateOf(true)
    var email by mutableStateOf("")
    var semToken by mutableStateOf(false)
    var antibanLivre by mutableStateOf(false)
    var expira by mutableStateOf("")
    var fantasma by mutableStateOf(false)

    // servidores / antiban
    var servidores by mutableStateOf<List<Servidor>>(emptyList())
    var antibanTotal by mutableStateOf(0)

    // mensagens
    var msgTipos by mutableStateOf<List<MsgTipo>>(emptyList())
    var globalAtivo by mutableStateOf(false)
    var globalMsgs by mutableStateOf<Map<String, String>>(emptyMap())
    var globalImagem by mutableStateOf("")
    var win by mutableStateOf("")
    var variaveis by mutableStateOf<List<Variavel>>(emptyList())

    // salas
    var salaTipos by mutableStateOf<List<SalaTipo>>(emptyList())
    var meet by mutableStateOf("")

    // seleção atual (compartilhada entre Mensagens e Comandos de sala)
    var escopoGlobal by mutableStateOf(true)
    var servidorSel by mutableStateOf<String?>(null)
    var detalhe by mutableStateOf<DetalheServidor?>(null)

    fun corpoAcao(acao: String): JSONObject = Net.corpo().put("acao", acao)

    private fun mostrar(msg: String, ok: Boolean) {
        Estado.ui {
            aviso = msg
            avisoOk = ok
            main.postDelayed({ if (aviso == msg) aviso = "" }, 4500)
        }
    }

    private fun aplicarPainel(r: JSONObject) {
        val c = r.optJSONObject("conta")
        if (c != null) {
            userId = c.optString("userId", "")
            nome = c.optString("nome", "")
            contaOnline = c.optBoolean("online", false)
            automed = c.optBoolean("automed", true)
            email = c.optString("email", "")
            semToken = c.optBoolean("semToken", false)
            antibanLivre = c.optBoolean("antibanLivre", false)
            expira = c.optString("expira", "")
            fantasma = c.optBoolean("fantasma", false)
        }

        val sv = ArrayList<Servidor>()
        val arrS = r.optJSONArray("servidores")
        if (arrS != null) {
            for (i in 0 until arrS.length()) {
                val o = arrS.getJSONObject(i)
                sv.add(Servidor(o.optString("id", ""), o.optString("nome", ""), o.optBoolean("antiban", false), o.optBoolean("salasAutomed", false)))
            }
        }
        servidores = sv
        antibanTotal = r.optInt("antibanTotal", 0)

        val mt = ArrayList<MsgTipo>()
        val arrM = r.optJSONArray("msgTipos")
        if (arrM != null) {
            for (i in 0 until arrM.length()) {
                val o = arrM.getJSONObject(i)
                mt.add(MsgTipo(o.optString("k", ""), o.optString("rotulo", ""), o.optString("descricao", ""), o.optString("placeholders", ""), o.optString("padrao", "")))
            }
        }
        msgTipos = mt

        val st = ArrayList<SalaTipo>()
        val arrT = r.optJSONArray("salaTipos")
        if (arrT != null) {
            for (i in 0 until arrT.length()) {
                val o = arrT.getJSONObject(i)
                st.add(SalaTipo(o.optString("k", ""), o.optString("rotulo", ""), o.optString("descricao", ""), o.optString("padrao", "")))
            }
        }
        salaTipos = st

        val g = r.optJSONObject("global")
        if (g != null) {
            globalAtivo = g.optBoolean("ativo", false)
            globalImagem = g.optString("imagem", "")
            val m = HashMap<String, String>()
            val go = g.optJSONObject("msgs")
            if (go != null) {
                val ks = go.keys()
                while (ks.hasNext()) { val k = ks.next(); m[k] = go.optString(k, "") }
            }
            globalMsgs = m
        }
        win = r.optString("win", "")
        meet = r.optString("meet", "")

        val vs = ArrayList<Variavel>()
        val arrV = r.optJSONArray("variaveis")
        if (arrV != null) {
            for (i in 0 until arrV.length()) {
                val o = arrV.getJSONObject(i)
                vs.add(Variavel(o.optString("id", ""), o.optString("gatilho", ""), o.optString("mensagem", "")))
            }
        }
        variaveis = vs
        carregado = true
    }

    private fun aplicarServidor(r: JSONObject) {
        val ms = HashMap<String, String>()
        val mo = r.optJSONObject("msgs")
        if (mo != null) {
            val ks = mo.keys()
            while (ks.hasNext()) { val k = ks.next(); ms[k] = mo.optString(k, "") }
        }
        val cs = HashMap<String, Comando>()
        val co = r.optJSONObject("comandos")
        if (co != null) {
            val ks = co.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                val o = co.optJSONObject(k)
                if (o != null) cs[k] = Comando(o.optString("custom", ""), o.optString("efetivo", ""))
            }
        }
        detalhe = DetalheServidor(
            r.optString("id", ""), r.optString("nome", ""), r.optBoolean("antiban", false),
            ms, r.optString("imagem", ""), cs
        )
    }

    /** Busca no bot (já numa thread). */
    private fun buscarServidor(id: String) {
        val r = Net.post("/api/servidor", Net.corpo().put("guildId", id))
        if (r != null && r.optBoolean("ok", false)) {
            Estado.ui { aplicarServidor(r) }
        } else if (r != null) {
            mostrar(r.optString("msg", "Erro ao carregar o servidor."), false)
        }
    }

    /** Atualiza conta, mensagens, variáveis, comandos e servidores. */
    fun carregar() {
        if (carregando) return
        carregando = true
        Thread {
            val r = Net.post("/api/painel", Net.corpo())
            val ok = r != null && r.optBoolean("ok", false)
            Estado.ui {
                carregando = false
                if (r == null) erro = "Sem resposta do bot. Confira a internet."
                else if (!ok) erro = r.optString("msg", "Erro ao falar com o bot.")
                else { erro = ""; aplicarPainel(r) }
            }
            val sel = servidorSel
            if (ok && sel != null) buscarServidor(sel)
        }.start()
    }

    fun escolherServidor(id: String) {
        servidorSel = id
        detalhe = null
        Thread { buscarServidor(id) }.start()
    }

    /** Envia uma ação (salvar mensagem, variável, comando…) e recarrega tudo. */
    fun acao(corpo: JSONObject) {
        Thread {
            val r = Net.post("/api/acao", corpo)
            val ok = r != null && r.optBoolean("ok", false)
            val msg = if (r == null) "Sem resposta do bot." else r.optString("msg", if (ok) "Salvo." else "Erro.")
            mostrar(msg, ok)
            if (ok) {
                val rp = Net.post("/api/painel", Net.corpo())
                if (rp != null && rp.optBoolean("ok", false)) Estado.ui { aplicarPainel(rp) }
                val sel = servidorSel
                if (sel != null) buscarServidor(sel)
            }
        }.start()
    }
}
