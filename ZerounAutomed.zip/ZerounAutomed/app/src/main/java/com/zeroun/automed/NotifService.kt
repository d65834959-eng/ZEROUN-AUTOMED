package com.zeroun.automed

import android.app.Notification
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONObject
import kotlin.concurrent.thread

object Estado {
    val recentes = androidx.compose.runtime.mutableStateListOf<String>()
    val status = androidx.compose.runtime.mutableStateOf("Aguardando o próximo Pix…")
    val total = androidx.compose.runtime.mutableStateOf(0.0)
    val qtd = androidx.compose.runtime.mutableStateOf(0)
}

class NotifService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val p = Prefs(this)
        val pkg = sbn.packageName
        if (pkg == packageName || !p.connected || p.url.isBlank()) return
        val permitido = if (pkg == "com.google.android.gm") p.gmail else (p.pag && pkg in p.apps)
        if (!permitido) return
        val e = sbn.notification.extras
        val titulo = e.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val texto = (e.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: e.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
        if (titulo.isBlank() && texto.isBlank()) return
        val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (x: Exception) { pkg }
        thread {
            val body = JSONObject().put("key", p.key).put("deviceId", p.deviceId).put("app", label)
                .put("pacote", pkg).put("titulo", titulo).put("texto", texto).put("ts", sbn.postTime)
            val r = Net.post(p.url, "/api/notificacao", body)
            if (r != null && r.optBoolean("pix") && !r.optBoolean("repetido")) {
                val v = r.optDouble("valor", 0.0); val n = r.optString("nome", "").ifBlank { "sem nome" }
                Handler(Looper.getMainLooper()).post {
                    Estado.total.value += v; Estado.qtd.value += 1
                    Estado.recentes.add(0, "$n — R$ %.2f (%s)".format(v, label).replace('.', ','))
                    Estado.status.value = "Último Pix lido: $n"
                }
            }
        }
    }
}
