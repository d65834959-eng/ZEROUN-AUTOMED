package com.zeroun.automed

import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings
import java.util.UUID

/** Mesmo arquivo/chaves do app anterior ("zeroun"), então atualizar por cima mantém key, endereço e deviceId. */
object Prefs {
    private var sp: SharedPreferences? = null
    private var ctx: Context? = null

    /** Versão do app (ex.: "3.1.0"), enviada ao bot junto com o modelo do celular. */
    var versaoApp: String = ""

    fun init(c: Context) {
        if (sp == null) {
            ctx = c.applicationContext
            versaoApp = try { c.packageManager.getPackageInfo(c.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
            sp = c.applicationContext.getSharedPreferences("zeroun", Context.MODE_PRIVATE)
        }
    }

    private fun p(): SharedPreferences = sp ?: error("Prefs.init() não foi chamado")

    /** Sempre o endereço fixo do bot. */
    var url: String
        get() = Net.URL_FIXA
        set(@Suppress("UNUSED_PARAMETER") v) { }

    var key: String
        get() = p().getString("key", "") ?: ""
        set(v) { p().edit().putString("key", v).apply() }

    var gmail: Boolean
        get() = p().getBoolean("gmail", true)
        set(v) { p().edit().putBoolean("gmail", v).apply() }

    var apps: Set<String>
        get() = p().getStringSet("apps", emptySet()) ?: emptySet()
        set(v) { p().edit().putStringSet("apps", HashSet(v)).apply() }

    /** Tema: true = escuro (padrão, igual à foto), false = claro. Chave nova para todo mundo começar no escuro. */
    var escuro: Boolean
        get() = p().getBoolean("tema_v4", true)
        set(v) { p().edit().putBoolean("tema_v4", v).apply() }

    /** IDs dos avisos do sino que a pessoa já viu (pra bolinha vermelha só aparecer no que é novo). */
    var avisosVistos: Set<String>
        get() = p().getStringSet("avisosVistos", emptySet()) ?: emptySet()
        set(v) { p().edit().putStringSet("avisosVistos", HashSet(v)).apply() }

    /** true depois que a pessoa terminou a configuração inicial (permissão + bancos). */
    var setupOk: Boolean
        get() = p().getBoolean("setupOk", false)
        set(v) { p().edit().putBoolean("setupOk", v).apply() }

    /** Atualizar sozinho (baixa e instala quando sai versão nova no GitHub). */
    var autoUpdate: Boolean
        get() = true // obrigatório: não dá pra desligar
        set(v) { p().edit().putBoolean("autoUpdate", true).apply() }

    /** Última versão que o app já tentou instalar sozinho (evita tentar em loop). */
    var tentouAuto: Long
        get() = p().getLong("tentouAuto", 0L)
        set(v) { p().edit().putLong("tentouAuto", v).apply() }

    /** Volume só da música: 0 = OFF (mudo) • 1..70 = volume do player (70 = normal) • 71..100 = reforço acima do normal. */
    var volume: Int
        get() = p().getInt("volume_v2", 100)
        set(v) { p().edit().putInt("volume_v2", v.coerceIn(0, 100)).apply() }

    /** Banco: esconder o saldo (••••). */
    var ocultarSaldo: Boolean
        get() = p().getBoolean("ocultarSaldo", false)
        set(v) { p().edit().putBoolean("ocultarSaldo", v).apply() }

    /** true = key só de música: o app mostra apenas Atualização, Música e Banco. */
    var soMusica: Boolean
        get() = p().getBoolean("soMusica", false)
        set(v) { p().edit().putBoolean("soMusica", v).apply() }

    /** Descobre se a key é de música (resposta do bot em /api/key ou /api/sistema, ou prefixo da key). */
    fun ehKeyMusica(r: org.json.JSONObject?, k: String): Boolean {
        if (k.trim().uppercase().startsWith("MUSIC")) return true
        if (r == null) return false
        fun tem(t: String) = t.lowercase().let { it.contains("music") || it.contains("músic") }
        // olha TODOS os campos da resposta do bot: nome do campo ligado (true) ou texto que cita "música"
        val it = r.keys()
        while (it.hasNext()) {
            val nome = it.next()
            if (nome == "msg") continue
            val v = r.opt(nome)
            if (v is Boolean && v && tem(nome)) return true
            if (v is String && tem(v)) return true
        }
        return false
    }

    var conectado: Boolean
        get() = p().getBoolean("conectado", false)
        set(v) { p().edit().putBoolean("conectado", v).apply() }

    var pixJson: String
        get() = p().getString("pixJson", "[]") ?: "[]"
        set(v) { p().edit().putString("pixJson", v).apply() }

    /**
     * ID do celular: se já existe, mantém (quem já está vinculado não muda).
     * Se for instalação nova, usa o ANDROID_ID do aparelho, que é o MESMO depois de desinstalar e instalar de novo
     * (enquanto o app for assinado com a mesma chave, ou seja, gerado no mesmo computador/Android Studio).
     */
    val deviceId: String
        get() {
            val atual = p().getString("deviceId", null)
            if (!atual.isNullOrBlank()) return atual
            val aid = try { Settings.Secure.getString(ctx?.contentResolver, Settings.Secure.ANDROID_ID) } catch (e: Exception) { null }
            val novo = if (!aid.isNullOrBlank() && aid != "9774d56d682e549c") "and-$aid" else UUID.randomUUID().toString()
            p().edit().putString("deviceId", novo).apply()
            return novo
        }
}
