# Endpoints do app 2.2 (JÁ IMPLEMENTADOS no index.js novo)

Este arquivo só documenta o que o `index.js` entregue junto já faz. Não precisa codar nada.
Todas as chamadas são POST JSON com `key` + `deviceId`. Resposta: `{ ok:true, ... }` ou `{ ok:false, msg }`.

| Tela do app | Endpoint | Ações em `/api/acao` |
|---|---|---|
| ⚙️ Gerenciar sistema | `/api/sistema` → `estado` (sem/parado/conectando/online), `ativo`, `congelada`, `expiraTs`, `expira`, `plano` | `sistema_ativar {valor:true/false}`, `sistema_reiniciar` |
| 💰 Lucros | `/api/lucros` → `valorPorSala`, `acumulado`, `hoje/semana/mes/total {salas,valor}`, `historico[{ts,valor}]` | `lucro_valor {valor}` |
| 🤖 IA e canais de regras | `/api/ia` (+ `guildId` opcional) → `configurada`, `modelo`, `max`, `online`, `servidores[{id,nome,canais}]`; com `guildId`: `canais[{id,nome,cat}]`, `selecionados[]` | `ia_canais {guildId, canais:[ids]}`, `ia_limpar` |

Como cada coisa se liga ao bot (mesmas funções do painel do Discord):
- **Ativar / Parar / Reiniciar** = botões de `/central → Gerenciar sistema` (`iniciarSelfbot`, `desligarUsuario`, `pararSelfbot`).
- **Valor por sala** = o `ganhoFila` de `/central → Pagamentos`. Lucros = `salas_log.jsonl`, o mesmo do `.lucro` (semana começa na segunda, fuso UTC-3).
- **Canais da IA** = `iaCanais` de `/central → Configurar IA` (máximo de 5 por servidor, só canais de texto).
