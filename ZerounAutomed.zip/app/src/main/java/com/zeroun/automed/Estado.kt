package com.zeroun.automed

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** origem: "app" = notificação do celular • "gmail" = e-mail lido pelo bot */
data class PixItem(val nome: String, val valor: Double, val fonte: String, val origem: String, val ts: Long)

/** tipo: 0 = neutro • 1 = Pix lido • 2 = aviso/erro */
data class Evento(val app: String, val texto: String, val resultado: String, val tipo: Int, val ts: Long)

object Estado {
    private const val MAX_PIX = 60
    private const val MAX_EVENTOS = 30
    private var iniciado = false
    private val main = Handler(Looper.getMainLooper())

    val pix = mutableStateListOf<PixItem>()
    val eventos = mutableStateListOf<Evento>()

    var online by mutableStateOf(false)
    var gmail by mutableStateOf(true)
    var apps by mutableStateOf<Set<String>>(emptySet())
    var hoje by mutableIntStateOf(0)
    var totalHoje by mutableStateOf(0.0)
    /** null = ainda não sei • false = "Ativar notificações app" está DESLIGADO no bot */
    var ativoApp by mutableStateOf<Boolean?>(null)
    var msgServidor by mutableStateOf("")
    var atualizando by mutableStateOf(false)
    var tick by mutableIntStateOf(0)

    fun ui(block: () -> Unit) { main.post(block) }

    fun init(c: Context) {
        Prefs.init(c)
        if (iniciado) return
        iniciado = true
        gmail = Prefs.gmail
        apps = Prefs.apps
        online = Prefs.conectado
        try {
            val arr = JSONArray(Prefs.pixJson)
            val lista = ArrayList<PixItem>()
            for (i in 0 until arr.length()) lista.add(lerItem(arr.getJSONObject(i)))
            pix.clear(); pix.addAll(lista)
        } catch (e: Exception) { /* ignora */ }
        recalcular()
    }

    private fun lerItem(o: JSONObject): PixItem = PixItem(
        nome = if (o.isNull("nome")) "" else o.optString("nome", ""),
        valor = o.optDouble("valor", 0.0),
        fonte = if (o.isNull("fonte")) "" else o.optString("fonte", ""),
        origem = if (o.isNull("origem")) "app" else o.optString("origem", "app"),
        ts = o.optLong("ts", System.currentTimeMillis())
    )

    private fun salvar() {
        try {
            val arr = JSONArray()
            pix.forEach {
                arr.put(JSONObject().put("nome", it.nome).put("valor", it.valor)
                    .put("fonte", it.fonte).put("origem", it.origem).put("ts", it.ts))
            }
            Prefs.pixJson = arr.toString()
        } catch (e: Exception) { /* ignora */ }
    }

    private fun recalcular() {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        val inicio = c.timeInMillis
        val doDia = pix.filter { it.ts >= inicio }
        hoje = doDia.size
        totalHoje = doDia.sumOf { it.valor }
    }

    private fun parecido(a: PixItem, b: PixItem) =
        Math.abs(a.valor - b.valor) < 0.005 && Math.abs(a.ts - b.ts) < 120_000

    fun addPix(item: PixItem) = ui {
        if (pix.none { parecido(it, item) }) {
            pix.add(0, item)
            while (pix.size > MAX_PIX) pix.removeAt(pix.size - 1)
            salvar(); recalcular()
        }
    }

    fun addEvento(e: Evento) = ui {
        eventos.add(0, e)
        while (eventos.size > MAX_EVENTOS) eventos.removeAt(eventos.size - 1)
    }

    fun limparEventos() = ui { eventos.clear() }

    fun salvarApps(novo: Set<String>) { Prefs.apps = novo; apps = novo }

    fun definirFonte(g: Boolean) {
        Prefs.gmail = g; gmail = g
        if (Prefs.conectado) Thread {
            Net.post("/api/modo", Net.corpo().put("modo", if (g) "gmail" else "apps"))
        }.start()
    }

    /** Busca no bot a lista oficial de Pix lidos (inclui os do Gmail/e-mail) e mescla com a local. */
    fun atualizar() {
        if (atualizando) return
        atualizando = true
        Thread {
            val r = Net.post("/api/pix", Net.corpo())
            ui {
                atualizando = false
                if (r == null) {
                    msgServidor = "Sem resposta do bot. Confira a internet."
                } else if (!r.optBoolean("ok", false)) {
                    msgServidor = r.optString("msg", "Erro ao falar com o bot.")
                } else {
                    msgServidor = ""
                    online = true
                    ativoApp = if (r.has("ativoApp")) r.optBoolean("ativoApp") else null
                    val arr = r.optJSONArray("itens") ?: JSONArray()
                    val doServidor = ArrayList<PixItem>()
                    for (i in 0 until arr.length()) doServidor.add(lerItem(arr.getJSONObject(i)))
                    val locais = pix.filter { l -> doServidor.none { parecido(it, l) } }
                    val tudo = (doServidor + locais).sortedByDescending { it.ts }.take(MAX_PIX)
                    pix.clear(); pix.addAll(tudo)
                    salvar(); recalcular()
                }
            }
        }.start()
    }
}
