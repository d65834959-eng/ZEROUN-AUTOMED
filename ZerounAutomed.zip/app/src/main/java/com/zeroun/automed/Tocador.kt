package com.zeroun.automed

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.io.IOException

/**
 * Toca a música no próprio celular.
 * Fluxo: acha o áudio (cache JSON ou YT.resolver) → MediaPlayer → ao começar, conta +1 no histórico do usuário.
 * Se o endereço salvo já venceu / mudou de rede, pede um novo sozinho e tenta de novo.
 */
object Tocador {
    private var app: Context? = null
    private val main = Handler(Looper.getMainLooper())
    private var mp: MediaPlayer? = null
    private var geracao = 0
    private var focoTemporario = false
    private var foco: AudioFocusRequest? = null

    var fila by mutableStateOf<List<Som>>(emptyList())
        private set
    var indice by mutableIntStateOf(0)
        private set
    var atual by mutableStateOf<Som?>(null)
        private set
    var tocando by mutableStateOf(false)
        private set
    var carregando by mutableStateOf(false)
        private set
    var erro by mutableStateOf("")
        private set
    var duracaoMs by mutableLongStateOf(0L)
        private set

    fun init(c: Context) { app = c.applicationContext }

    // ── foco de áudio (pausa quando entra ligação ou outro app de música) ──

    private val ouvinteFoco = AudioManager.OnAudioFocusChangeListener { mudanca ->
        when (mudanca) {
            AudioManager.AUDIOFOCUS_LOSS -> { focoTemporario = false; pausarPorFoco() }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> { focoTemporario = true; pausarPorFoco() }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> { mp?.setVolume(0.25f, 0.25f) }
            AudioManager.AUDIOFOCUS_GAIN -> {
                mp?.setVolume(1f, 1f)
                if (focoTemporario) {
                    focoTemporario = false
                    try { mp?.start(); tocando = mp != null } catch (e: Exception) { }
                    MusicaService.atualizar()
                }
            }
        }
    }

    private fun pausarPorFoco() {
        try { if (mp?.isPlaying == true) mp?.pause() } catch (e: Exception) { }
        tocando = false
        MusicaService.atualizar()
    }

    private fun pedirFoco(): Boolean {
        val am = app?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return true
        val req = foco ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(atributos())
            .setOnAudioFocusChangeListener(ouvinteFoco, main)
            .build().also { foco = it }
        return am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun soltarFoco() {
        val am = app?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        foco?.let { am.abandonAudioFocusRequest(it) }
    }

    private fun atributos() = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    // ── comandos ──

    /** Toca [lista] a partir da posição [i]; ao acabar uma música segue para a próxima da lista. */
    fun tocarLista(c: Context, lista: List<Som>, i: Int) {
        app = c.applicationContext
        if (lista.isEmpty() || i !in lista.indices) return
        fila = lista
        indice = i
        MusicaService.garantir(c.applicationContext)
        carregar(lista[i], false, emptySet())
    }

    fun alternar() {
        val m = mp
        if (m == null) {
            val f = atual
            if (f != null && !carregando) carregar(f, false, emptySet())
            return
        }
        try {
            if (m.isPlaying) {
                m.pause(); tocando = false; focoTemporario = false
            } else if (!carregando && pedirFoco()) {
                m.start(); tocando = true
            }
        } catch (e: Exception) { }
        MusicaService.atualizar()
    }

    fun proxima(auto: Boolean = false) {
        val n = indice + 1
        if (n < fila.size) {
            indice = n
            carregar(fila[n], false, emptySet())
        } else if (auto) {
            liberar()
            tocando = false
            MusicaService.atualizar()
        }
    }

    fun anterior() {
        if (posicaoMs() > 3000L || indice <= 0) { ir(0L); return }
        indice -= 1
        carregar(fila[indice], false, emptySet())
    }

    fun ir(ms: Long) {
        try { mp?.seekTo(ms.toInt()) } catch (e: Exception) { }
    }

    fun posicaoMs(): Long = try { (mp?.currentPosition ?: 0).toLong() } catch (e: Exception) { 0L }

    /** Para tudo e some com o player e a notificação. */
    fun encerrar() {
        geracao++
        liberar()
        atual = null; tocando = false; carregando = false; erro = ""
        fila = emptyList(); indice = 0
        MusicaService.parar()
    }

    // ── interno ──

    private fun liberar() {
        val m = mp
        mp = null
        if (m != null) {
            try { m.setOnCompletionListener(null); m.setOnErrorListener(null); m.setOnPreparedListener(null) } catch (e: Exception) { }
            try { m.release() } catch (e: Exception) { }
        }
        soltarFoco()
    }

    /** [forcarNovo] = ignora o endereço salvo • [evitar] = clientes do YouTube que já falharam. */
    private fun carregar(f: Som, forcarNovo: Boolean, evitar: Set<String>) {
        val g = ++geracao
        liberar()
        atual = f; carregando = true; tocando = false; erro = ""
        duracaoMs = f.duracao * 1000L
        focoTemporario = false
        MusicaStore.guardarFaixa(f) // clicou → fica salva no JSON, não precisa pesquisar de novo
        MusicaService.atualizar()
        Thread {
            try {
                val salvo = if (forcarNovo || evitar.isNotEmpty()) null else MusicaStore.stream(f.id)
                val fl = salvo ?: YT.resolver(f.id, evitar).also { MusicaStore.guardarStream(f.id, it) }
                Estado.ui { if (g == geracao) iniciar(f, fl, salvo != null, evitar, g) }
            } catch (e: Exception) {
                val msg = if (e is IOException) "Sem internet ou o YouTube não respondeu." else (e.message ?: "Não consegui achar o áudio.")
                Estado.ui {
                    if (g == geracao) { carregando = false; erro = msg; MusicaService.atualizar() }
                }
            }
        }.start()
    }

    private fun falhou(f: Som, fl: Fluxo, doCache: Boolean, evitar: Set<String>) {
        if (doCache) { carregar(f, true, emptySet()); return }
        val ev = evitar + fl.cliente
        if (ev.size < YT.total) { carregar(f, false, ev); return }
        liberar()
        carregando = false; tocando = false
        erro = "O YouTube recusou o áudio dessa música. Tente outra."
        MusicaService.atualizar()
    }

    private fun iniciar(f: Som, fl: Fluxo, doCache: Boolean, evitar: Set<String>, g: Int) {
        val c = app ?: return
        try {
            val m = MediaPlayer()
            mp = m
            m.setAudioAttributes(atributos())
            m.setWakeMode(c, PowerManager.PARTIAL_WAKE_LOCK)
            m.setDataSource(c, Uri.parse(fl.url), mapOf("User-Agent" to fl.ua))
            m.setOnPreparedListener { p ->
                if (g == geracao) {
                    if (pedirFoco()) {
                        val d = p.duration
                        if (d > 0) duracaoMs = d.toLong()
                        p.start()
                        tocando = true; carregando = false
                        MusicaStore.registrarPlay(f) // conta como "ouvida" só quando realmente começou
                    } else {
                        tocando = false; carregando = false
                        erro = "Outro app está usando o áudio (ligação?). Toque em ▶ para tentar de novo."
                    }
                    MusicaService.atualizar()
                }
            }
            m.setOnCompletionListener { if (g == geracao) proxima(true) }
            m.setOnErrorListener { _, _, _ ->
                if (g == geracao) falhou(f, fl, doCache, evitar)
                true
            }
            m.prepareAsync()
        } catch (e: Exception) {
            if (g == geracao) falhou(f, fl, doCache, evitar)
        }
    }
}

/** Serviço em primeiro plano: mantém a música tocando com a tela apagada e mostra o botão na notificação. */
class MusicaService : Service() {

    companion object {
        private const val CANAL = "musica"
        private const val ID_NOTIF = 4107
        private const val ACAO_TOCAR = "com.zeroun.automed.MUSICA_TOCAR"
        private const val ACAO_PROXIMA = "com.zeroun.automed.MUSICA_PROXIMA"
        private const val ACAO_FECHAR = "com.zeroun.automed.MUSICA_FECHAR"

        private var instancia: MusicaService? = null

        fun garantir(c: Context) {
            if (instancia != null) return
            try { ContextCompat.startForegroundService(c, Intent(c, MusicaService::class.java)) } catch (e: Exception) { }
        }

        fun atualizar() { instancia?.renderizar() }
        fun parar() { instancia?.encerrar() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instancia = this
        val canal = NotificationChannel(CANAL, "Música", NotificationManager.IMPORTANCE_LOW)
        canal.description = "Controles da música que está tocando"
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(canal)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACAO_TOCAR -> Tocador.alternar()
            ACAO_PROXIMA -> Tocador.proxima()
            ACAO_FECHAR -> { Tocador.encerrar(); return START_NOT_STICKY }
        }
        renderizar()
        return START_NOT_STICKY
    }

    private fun acao(a: String, codigo: Int): PendingIntent = PendingIntent.getService(
        this, codigo, Intent(this, MusicaService::class.java).setAction(a),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun montar(): Notification {
        val f = Tocador.atual
        val abrir = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val linha2 = when {
            Tocador.carregando -> "Procurando o áudio…"
            Tocador.erro.isNotBlank() -> Tocador.erro
            else -> f?.artista ?: ""
        }
        return NotificationCompat.Builder(this, CANAL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(f?.titulo ?: "Música")
            .setContentText(linha2)
            .setContentIntent(abrir)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(
                if (Tocador.tocando) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                if (Tocador.tocando) "Pausar" else "Tocar", acao(ACAO_TOCAR, 1)
            )
            .addAction(android.R.drawable.ic_media_next, "Próxima", acao(ACAO_PROXIMA, 2))
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Fechar", acao(ACAO_FECHAR, 3))
            .build()
    }

    fun renderizar() {
        try {
            ServiceCompat.startForeground(
                this, ID_NOTIF, montar(),
                if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0
            )
        } catch (e: Exception) { }
    }

    fun encerrar() {
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Exception) { }
        stopSelf()
    }

    override fun onDestroy() {
        if (instancia === this) instancia = null
        super.onDestroy()
    }
}
