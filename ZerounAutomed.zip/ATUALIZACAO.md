# Atualização automática do app (via GitHub Actions)

## Como lançar uma versão nova
1. Suba as mudanças para o repositório (branch `main`), principalmente a pasta `app/`.
2. Pronto. Em ~5 min o GitHub compila o APK, define a versão (1 acima da última Release) e publica a Release.
3. Os celulares com o app instalado detectam e se atualizam sozinhos.

Acompanhe na aba **Actions** do repositório (✅ verde = publicou, ❌ vermelho = erro de compilação; abra o item para ver o log).

## Importante
- Mudou só o `index.js` (bot)? NÃO precisa lançar app. Troque o arquivo no servidor e reinicie.
- O arquivo `.github/workflows/lancar.yml` precisa estar no repositório.
- A assinatura é fixa (`app/zeroun.jks`): não troque, senão o Android recusa instalar por cima.
- Repositório deve ser PÚBLICO.
- Para pular de versão (ex.: 3.4.0), mude `versaoBase` em `app/build.gradle.kts`.
