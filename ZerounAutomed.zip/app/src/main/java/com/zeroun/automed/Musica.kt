package com.zeroun.automed

import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.ExecutorCompletionService
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/*
 * MÚSICA — "Mediação com música"
 *
 * Como funciona (igual ao index.js do bot de call):
 *   1) PROCURAR  = o index.js usa  yt-dlp ytsearch1:<busca>  → só título + link (rápido, sem baixar nada).
 *                  Aqui o celular faz a mesma busca direto no YouTube (YT.buscar).
 *   2) TOCAR     = o index.js usa  yt-dlp -f bestaudio  → pega o melhor áudio.
 *                  Aqui o celular pede o melhor áudio (YT.resolver) e toca no próprio aparelho (Tocador).
 *   3) CACHE     = o index.js guarda busca → resultado num Map. Aqui tudo fica num JSON no celular
 *                  (files/musica.json): buscas, músicas tocadas, endereço do áudio e histórico de cada usuário.
 *
 * Nada disso usa a key nem o servidor, então continua funcionando (e salvo) mesmo se a key acabar.
 */

/** Uma música do YouTube. */
data class Som(val id: String, val titulo: String, val artista: String, val duracao: Int)

/** Quantas vezes UM usuário ouviu a música e quando foi a última vez. */
data class Uso(val plays: Int, val ultimo: Long)

/** Música + uso (para as listas "Mais ouvidas" e "Recentes"). */
data class ItemUso(val faixa: Som, val uso: Uso)

/** Playlist do usuário (a "favoritas" é fixa e criada sozinha). [faixas] = ids das músicas, na ordem em que foram adicionadas. */
data class Playlist(val id: String, val nome: String, val faixas: List<String>, val criada: Long)

const val ID_FAV = "favoritas"

/** Endereço direto do áudio (vale umas 6 horas) + de qual "cliente" do YouTube ele veio. */
data class Fluxo(
    val url: String, val ua: String, val cliente: String, val expira: Long,
    val titulo: String, val artista: String, val duracao: Int
)

// ───────────────────────── YouTube (o "yt-dlp" do celular) ─────────────────────────

object YT {
    private const val UA_WEB_CLIENTE =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    private class Cliente(
        val chave: String, val nome: String, val numero: String, val versao: String,
        val ua: String, val extra: JSONObject
    )

    /**
     * Clientes do YouTube que entregam o link do áudio sem login. Tenta um por um.
     * Se o YouTube mudar algo e a música parar de tocar, atualize as versões aqui (como se atualiza o yt-dlp).
     */
    private val clientes = listOf(
        Cliente(
            "vr", "ANDROID_VR", "28", "1.71.26",
            "com.google.android.apps.youtube.vr.oculus/1.71.26 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip",
            JSONObject().put("deviceMake", "Oculus").put("deviceModel", "Quest 3")
                .put("androidSdkVersion", 32).put("osName", "Android").put("osVersion", "12L")
        ),
        Cliente(
            "emb", "WEB_EMBEDDED_PLAYER", "56", "1.20260115.01.00",
            UA_WEB_CLIENTE,
            JSONObject().put("clientScreen", "EMBED")
        ),
        Cliente(
            "ios", "IOS", "5", "20.10.4",
            "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
            JSONObject().put("deviceMake", "Apple").put("deviceModel", "iPhone16,2")
                .put("osName", "iPhone").put("osVersion", "18.3.2.22D82")
        ),
        Cliente(
            "and", "ANDROID", "3", "20.10.38",
            "com.google.android.youtube/20.10.38 (Linux; U; Android 11) gzip",
            JSONObject().put("androidSdkVersion", 30).put("osName", "Android").put("osVersion", "11")
        )
    )

    /** Quantas tentativas por música: SoundCloud = link direto + servidor; YouTube = 3 clientes do celular + servidor. */
    fun tentativas(id: String): Int = if (id.startsWith("sc_")) 2 else clientes.size + 2

    @Volatile var motivoYt = ""
    private const val VERSAO_WEB = "2.20241126.01.00"
    private const val UA_WEB =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"

    private val reLink = Regex(
        "(?:youtu\\.be/|youtube\\.com/(?:watch\\?(?:.*&)?v=|shorts/|embed/|live/))([A-Za-z0-9_-]{11})"
    )
    private val reExpira = Regex("[?&]expire=(\\d+)")

    private fun postar(url: String, corpo: JSONObject, cab: Map<String, String>, conexao: Int = 10_000, leitura: Int = 15_000): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = conexao
            c.readTimeout = leitura
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            for ((k, v) in cab) c.setRequestProperty(k, v)
            c.outputStream.use { it.write(corpo.toString().toByteArray(Charsets.UTF_8)) }
            val ok = c.responseCode in 200..299
            val txt = (if (ok) c.inputStream else c.errorStream)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (!ok) {
                // mostra o motivo que o YouTube deu (ex.: "Precondition check failed" = versão do cliente velha demais)
                val motivo = try { JSONObject(txt).optJSONObject("error")?.optString("message").orEmpty() } catch (e: Exception) { "" }
                throw IOException("HTTP " + c.responseCode + (if (motivo.isNotBlank()) " - " + motivo else ""))
            }
            return JSONObject(txt)
        } finally {
            c.disconnect()
        }
    }

    /** Se o texto for um link do YouTube, devolve o id do vídeo (o index.js também aceita link). */
    fun idDoLink(texto: String): String? {
        val t = texto.trim()
        if (!t.startsWith("http", ignoreCase = true)) return null
        return reLink.find(t)?.groupValues?.get(1)
    }

    // ── 1) PROCURAR (igual ao ytsearch1 do index.js, só que trazendo vários resultados) ──

    /** Busca completa (espera tudo terminar). Usada nos bastidores. */
    fun buscar(consulta: String): List<Som> = buscarProgressivo(consulta) { _, _ -> }

    /**
     * Busca RÁPIDA: YouTube (celular, ~1 s) e SoundCloud (servidor, às vezes lento) correm ao mesmo tempo.
     * O resultado aparece assim que a primeira fonte responde (espera só 0,6 s pela outra para misturar);
     * se a outra chegar depois, os resultados dela entram no FIM da lista, sem embaralhar o que já está na tela.
     * [aoMudar] recebe (lista, terminou).
     */
    fun buscarProgressivo(consulta: String, aoMudar: (List<Som>, Boolean) -> Unit): List<Som> {
        val q = consulta.trim()
        val ytId = idDoLink(q)
        if (ytId != null) { val r = listOf(infoYt(ytId)); aoMudar(r, true); return r } // link do YouTube: o celular lê direto
        if (q.startsWith("http", ignoreCase = true)) { val r = buscarServidor(q); aoMudar(r, true); return r }

        val ytRes = AtomicReference<List<Som>?>(null)
        val scRes = AtomicReference<List<Som>?>(null)
        val erroYt = AtomicReference<Exception?>(null)
        val erroSc = AtomicReference<Exception?>(null)
        val aviso = Object()
        fun acordar() { synchronized(aviso) { aviso.notifyAll() } }
        Thread {
            try { ytRes.set(buscarYt(q)) } catch (e: Exception) { erroYt.set(e); ytRes.set(emptyList()) }
            acordar()
        }.apply { isDaemon = true }.start()
        Thread {
            try { scRes.set(buscarServidor(q)) } catch (e: Exception) { erroSc.set(e); scRes.set(emptyList()) }
            acordar()
        }.apply { isDaemon = true }.start()

        val limite = System.currentTimeMillis() + 20_000L
        var primeiroEm = 0L
        var lista: List<Som> = emptyList()
        var mostrou = false
        while (true) {
            val yt = ytRes.get()
            val sc = scRes.get()
            val fim = yt != null && sc != null
            val agora = System.currentTimeMillis()
            val temAlgo = !yt.isNullOrEmpty() || !sc.isNullOrEmpty()
            if (temAlgo && primeiroEm == 0L) primeiroEm = agora
            if (temAlgo && (fim || agora - primeiroEm >= 600L)) {
                val novo = if (!mostrou) mesclar(sc.orEmpty(), yt.orEmpty()) else acrescentar(lista, sc.orEmpty(), yt.orEmpty())
                if (!mostrou || novo.size != lista.size) {
                    lista = novo; mostrou = true
                    aoMudar(lista, fim)
                } else if (fim) aoMudar(lista, true)
            }
            if (fim || agora > limite) break
            synchronized(aviso) { aviso.wait(150) }
        }
        if (lista.isEmpty()) throw (erroSc.get() ?: erroYt.get() ?: Exception("Não achei nenhuma música com essa busca."))
        return lista
    }

    private fun mesclar(sc: List<Som>, yt: List<Som>): List<Som> {
        val out = ArrayList<Som>()
        fun add(l: List<Som>) { for (x in l) if (out.none { it.id == x.id }) out.add(x) }
        add(sc.take(4)); add(yt.take(4)); add(sc.drop(4)); add(yt.drop(4))
        return out.take(14)
    }

    /** Resultado que chegou atrasado: entra no fim da lista (o que já está na tela não muda de lugar). */
    private fun acrescentar(atual: List<Som>, sc: List<Som>, yt: List<Som>): List<Som> {
        val out = ArrayList(atual)
        for (x in sc + yt) { if (out.size >= 16) break; if (out.none { it.id == x.id }) out.add(x) }
        return out
    }

    /** Plano B: acha a mesma música no YouTube (duração parecida) e já devolve um Fluxo tocável pelo celular. */
    fun equivalenteYt(f: Som): Pair<Som, Fluxo>? {
        val lista = try { buscarYt((f.titulo + " " + f.artista).trim()) } catch (e: Exception) { return null }
        for (c in lista.filter { !it.id.startsWith("sc_") }.take(4)) {
            if (f.duracao > 0 && c.duracao > 0 && Math.abs(c.duracao - f.duracao) > 10) continue
            try { val fl = resolverYt(c.id, emptySet()); if (fl != null) return Pair(c, fl) } catch (e: Exception) { }
        }
        return null
    }

    private fun buscarYt(q: String): List<Som> =
        try { lerResultados(buscarApi(q)) } catch (e: Exception) { try { lerResultados(buscarHtml(q)) } catch (e2: Exception) { buscarProxy(q) } }

    /** Título/artista/duração de um vídeo do YouTube (link colado), lidos direto pelo celular. */
    private fun infoYt(id: String): Som {
        var ultimo: Exception? = null
        for (c in clientes) {
            try {
                val r = playerYt(id, c)
                val d = r.optJSONObject("videoDetails")
                val dur = d?.optString("lengthSeconds")?.toIntOrNull() ?: 0
                if (d != null && dur > 0) return Som(id, d.optString("title"), d.optString("author").removeSuffix(" - Topic").ifBlank { "YouTube" }, dur)
            } catch (e: Exception) { ultimo = e }
        }
        throw ultimo ?: Exception("Não consegui ler esse link do YouTube.")
    }

    private fun playerYt(id: String, c: Cliente): JSONObject {
        val cli = JSONObject().put("clientName", c.nome).put("clientVersion", c.versao).put("hl", "pt").put("gl", "BR")
        val ks = c.extra.keys()
        while (ks.hasNext()) { val k = ks.next(); cli.put(k, c.extra.get(k)) }
        val ctx = JSONObject().put("client", cli)
        if (c.chave == "emb") ctx.put("thirdParty", JSONObject().put("embedUrl", "https://www.youtube.com/"))
        val corpo = JSONObject().put("context", ctx).put("videoId", id)
            .put("contentCheckOk", true).put("racyCheckOk", true)
        return postar(
            "https://www.youtube.com/youtubei/v1/player?prettyPrint=false", corpo,
            mapOf("User-Agent" to c.ua, "X-YouTube-Client-Name" to c.numero, "X-YouTube-Client-Version" to c.versao,
                "Origin" to "https://www.youtube.com", "Accept-Language" to "pt-BR,pt;q=0.9"),
            4_000, 5_000
        )
    }

    /** Áudio do YouTube pedido pelo próprio celular (o IP do servidor é barrado). Pula os clientes que já falharam. */
    @Volatile private var ytCelularFalhouEm = 0L
    @Volatile private var clienteBom = "" // o último cliente que funcionou vai primeiro na próxima vez

    private fun celularEmPausa(): Boolean = System.currentTimeMillis() - ytCelularFalhouEm < 15_000L

    private fun tentarCliente(id: String, c: Cliente, f0: Som?, motivos: MutableList<String>): Fluxo? {
        try {
            val r = playerYt(id, c)
            val ps = r.optJSONObject("playabilityStatus")
            if (ps?.optString("status") != "OK") { motivos.add(c.chave + ": " + ps?.optString("status") + " " + ps?.optString("reason")); return null }
            val u = melhorAudio(r.optJSONObject("streamingData"))
            if (u == null) { motivos.add(c.chave + ": sem áudio"); return null }
            val exp = reExpira.find(u)?.groupValues?.get(1)?.toLongOrNull()?.times(1000L) ?: (System.currentTimeMillis() + 5 * 3600_000L)
            val d = r.optJSONObject("videoDetails")
            clienteBom = c.chave
            return Fluxo(u, c.ua, c.chave, exp,
                f0?.titulo ?: d?.optString("title").orEmpty().ifBlank { "Música" },
                f0?.artista ?: d?.optString("author").orEmpty().ifBlank { "YouTube" },
                f0?.duracao ?: d?.optString("lengthSeconds")?.toIntOrNull() ?: 0)
        } catch (e: Exception) {
            motivos.add(c.chave + ": " + (e.message ?: e.javaClass.simpleName))
            return null
        }
    }

    /**
     * Antes: tentava os 4 clientes UM POR UM (cada falha custava ~1 s).
     * Agora: começa pelo que funcionou da última vez e, se ele demorar mais de 0,7 s ou falhar,
     * já dispara o próximo sem esperar — o primeiro que entregar o áudio ganha.
     */
    private fun resolverYt(id: String, evitar: Set<String>): Fluxo? {
        if (evitar.isEmpty() && celularEmPausa()) return null // falharam há pouco: vai direto ao servidor
        val f0 = MusicaStore.faixa(id)
        val ordem = clientes.filter { it.chave !in evitar }.sortedByDescending { it.chave == clienteBom }
        if (ordem.isEmpty()) return null
        val motivos = java.util.Collections.synchronizedList(ArrayList<String>())
        val pool = Executors.newFixedThreadPool(ordem.size)
        val fila = ExecutorCompletionService<Fluxo?>(pool)
        try {
            var enviados = 0
            var recebidos = 0
            fila.submit { tentarCliente(id, ordem[0], f0, motivos) }; enviados++
            while (recebidos < enviados) {
                val pronto = fila.poll(if (enviados < ordem.size) 450L else 8_000L, TimeUnit.MILLISECONDS)
                if (pronto == null) {
                    if (enviados < ordem.size) { val c = ordem[enviados]; fila.submit { tentarCliente(id, c, f0, motivos) }; enviados++; continue }
                    break
                }
                recebidos++
                val r = try { pronto.get() } catch (e: Exception) { null }
                if (r != null) return r
                if (enviados < ordem.size) { val c = ordem[enviados]; fila.submit { tentarCliente(id, c, f0, motivos) }; enviados++ }
            }
        } finally {
            pool.shutdownNow()
        }
        if (motivos.isNotEmpty()) { motivoYt = motivos.joinToString(" | "); ytCelularFalhouEm = System.currentTimeMillis() }
        return null
    }

    // ───── fontes ALTERNATIVAS (Piped / Invidious): repassam o áudio do YouTube por outros servidores ─────
    private val pipeds = listOf(
        "https://pipedapi.kavin.rocks", "https://pipedapi.leptons.xyz", "https://pipedapi.nosebs.ru",
        "https://pipedapi.adminforge.de", "https://api.piped.private.coffee", "https://pipedapi.orangenet.cc",
        "https://pipedapi.reallyaweso.me", "https://pipedapi.ducks.party"
    )
    private val invs = listOf(
        "https://inv.nadeko.net", "https://invidious.nerdvpn.de", "https://yt.chocolatemoo53.com",
        "https://invidious.tiekoetter.com", "https://invidious.f5.si", "https://inv.zoomerville.com"
    )

    private fun pegar(url: String, ms: Int): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = ms
            c.readTimeout = ms
            c.setRequestProperty("User-Agent", UA_WEB)
            c.setRequestProperty("Accept", "application/json")
            if (c.responseCode !in 200..299) throw IOException("HTTP " + c.responseCode)
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun melhorDaLista(arr: JSONArray?, campoMime: String): String? {
        if (arr == null) return null
        var melhor: String? = null
        var nota = -1L
        for (i in 0 until arr.length()) {
            val f = arr.optJSONObject(i) ?: continue
            val mime = f.optString(campoMime)
            val u = f.optString("url")
            if (!mime.startsWith("audio/") || !u.startsWith("http")) continue
            val n = f.optLong("bitrate", 0L) + (if (mime.contains("mp4")) 1_000_000_000L else 0L)
            if (n > nota) { nota = n; melhor = u }
        }
        return melhor
    }

    /** Pergunta a VÁRIAS instâncias ao mesmo tempo; a primeira que devolver o áudio ganha. null = nenhuma deu. */
    private fun viaProxies(id: String): Fluxo? {
        val f0 = MusicaStore.faixa(id)
        val fila = LinkedBlockingQueue<String>()
        var total = 0
        for (b in pipeds) {
            total++
            Thread {
                try {
                    val j = JSONObject(pegar(b + "/streams/" + id, 7_000))
                    val u = melhorDaLista(j.optJSONArray("audioStreams"), "mimeType")
                    fila.put(u ?: "")
                } catch (e: Exception) { fila.put("") }
            }.apply { isDaemon = true }.start()
        }
        for (b in invs) {
            total++
            Thread {
                try {
                    val j = JSONObject(pegar(b + "/api/v1/videos/" + id + "?local=true&fields=adaptiveFormats", 7_000))
                    val u = melhorDaLista(j.optJSONArray("adaptiveFormats"), "type")
                    fila.put(u ?: "")
                } catch (e: Exception) { fila.put("") }
            }.apply { isDaemon = true }.start()
        }
        val limite = System.currentTimeMillis() + 9_000L
        var recebidos = 0
        while (recebidos < total) {
            val r = fila.poll((limite - System.currentTimeMillis()).coerceAtLeast(1L), TimeUnit.MILLISECONDS) ?: break
            recebidos++
            if (r.startsWith("http")) {
                return Fluxo(r, UA_WEB, "px", System.currentTimeMillis() + 30 * 60_000L,
                    f0?.titulo ?: "Música", f0?.artista ?: "YouTube", f0?.duracao ?: 0)
            }
        }
        return null
    }

    /** Busca pelas instâncias Piped quando o YouTube direto falha. */
    private fun buscarProxy(q: String): List<Som> {
        val fila = LinkedBlockingQueue<List<Som>>()
        val qs = java.net.URLEncoder.encode(q, "UTF-8")
        val bases = pipeds.take(5)
        for (b in bases) {
            Thread {
                try {
                    val arr = JSONObject(pegar(b + "/search?q=" + qs + "&filter=videos", 7_000)).optJSONArray("items")
                    val out = ArrayList<Som>()
                    if (arr != null) for (i in 0 until arr.length()) {
                        val o = arr.optJSONObject(i) ?: continue
                        val id = o.optString("url").substringAfter("v=", "")
                        val dur = o.optInt("duration", 0)
                        if (id.length == 11 && dur > 0) out.add(Som(id, o.optString("title"), o.optString("uploaderName").removeSuffix(" - Topic").ifBlank { "YouTube" }, dur))
                    }
                    fila.put(out)
                } catch (e: Exception) { fila.put(emptyList()) }
            }.apply { isDaemon = true }.start()
        }
        val limite = System.currentTimeMillis() + 9_000L
        var n = 0
        while (n < bases.size) {
            val r = fila.poll((limite - System.currentTimeMillis()).coerceAtLeast(1L), TimeUnit.MILLISECONDS) ?: break
            n++
            if (r.isNotEmpty()) return r.take(12)
        }
        throw IOException("Não achei nenhuma música com essa busca.")
    }

    private fun buscarServidor(consulta: String): List<Som> {
        val j = servidor("/musica/buscar?q=" + java.net.URLEncoder.encode(consulta.trim(), "UTF-8") + "&" + auth(), 15_000)
        val arr = j.optJSONArray("itens") ?: JSONArray()
        val lista = (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            val id = o.getString("id")
            val prog = o.optString("prog")
            if (prog.startsWith("http")) MusicaStore.guardarDica(id, prog, o.optString("auth"))
            Som(id, o.optString("titulo"), o.optString("artista"), o.optInt("duracao"))
        }
        if (cidSc.isBlank()) Thread { try { clienteSc() } catch (e: Exception) { } }.start()
        if (lista.isEmpty()) throw Exception("Não achei nenhuma música com essa busca.")
        return lista
    }

    fun auth(): String =
        "k=" + java.net.URLEncoder.encode(Prefs.key.trim().uppercase(), "UTF-8") +
            "&d=" + java.net.URLEncoder.encode(Prefs.deviceId, "UTF-8")

    /** GET no bot (o yt-dlp roda lá). Devolve o JSON ou joga o motivo real. */
    private fun servidor(caminho: String, leitura: Int): JSONObject {
        val c = URL(Net.base() + caminho).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = leitura
            val ok = c.responseCode in 200..299
            val txt = (if (ok) c.inputStream else c.errorStream)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            val j = try { JSONObject(txt) } catch (e: Exception) { throw IOException("Servidor respondeu HTTP " + c.responseCode) }
            if (!j.optBoolean("ok")) throw IOException(j.optString("msg").ifBlank { "HTTP " + c.responseCode })
            return j
        } finally {
            c.disconnect()
        }
    }

    fun semRede(e: Exception): Boolean =
        e is java.net.UnknownHostException || e is java.net.ConnectException || e is java.net.SocketTimeoutException

    fun detalhe(e: Exception): String = e.javaClass.simpleName + (if (e.message.isNullOrBlank()) "" else ": " + e.message)

    private fun buscarApi(consulta: String): JSONObject {
        val cliente = JSONObject().put("clientName", "WEB").put("clientVersion", VERSAO_WEB)
            .put("hl", "pt").put("gl", "BR")
        val corpo = JSONObject().put("context", JSONObject().put("client", cliente))
            .put("query", consulta).put("params", "EgIQAQ==") // EgIQAQ== = só vídeos
        return postar(
            "https://www.youtube.com/youtubei/v1/search?prettyPrint=false", corpo,
            mapOf(
                "User-Agent" to UA_WEB, "X-YouTube-Client-Name" to "1", "X-YouTube-Client-Version" to VERSAO_WEB,
                "Accept-Language" to "pt-BR,pt;q=0.9", "Origin" to "https://www.youtube.com", "Cookie" to "SOCS=CAI"
            ),
            5_000, 8_000
        )
    }

    /** Plano B: abre a página de resultados como o navegador e lê o JSON embutido (ytInitialData). */
    private fun buscarHtml(consulta: String): JSONObject {
        val q = java.net.URLEncoder.encode(consulta, "UTF-8")
        val c = URL("https://www.youtube.com/results?hl=pt&gl=BR&sp=EgIQAQ%253D%253D&search_query=" + q).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 5_000
            c.readTimeout = 8_000
            c.setRequestProperty("User-Agent", UA_WEB)
            c.setRequestProperty("Accept-Language", "pt-BR,pt;q=0.9")
            c.setRequestProperty("Cookie", "SOCS=CAI; CONSENT=YES+1")
            if (c.responseCode !in 200..299) throw IOException("HTTP " + c.responseCode)
            val html = c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val i = html.indexOf("ytInitialData = ")
            if (i < 0) throw IOException("página sem resultados")
            val ini = i + "ytInitialData = ".length
            val fim = html.indexOf(";</script>", ini)
            if (fim < 0) throw IOException("página em formato novo")
            return JSONObject(html.substring(ini, fim))
        } finally {
            c.disconnect()
        }
    }

    private fun lerResultados(r: JSONObject): List<Som> {
        val brutos = ArrayList<JSONObject>()
        coletar(r, brutos)
        val lista = ArrayList<Som>()
        for (v in brutos) {
            val vid = v.optString("videoId")
            if (vid.isBlank() || lista.any { it.id == vid }) continue
            val seg = segundos(texto(v.optJSONObject("lengthText")))
            if (seg <= 0) continue // ao vivo / sem duração
            val titulo = texto(v.optJSONObject("title")).trim()
            if (titulo.isBlank()) continue
            var artista = texto(v.optJSONObject("ownerText")).trim()
            if (artista.isBlank()) artista = texto(v.optJSONObject("longBylineText")).trim()
            artista = artista.removeSuffix(" - Topic").ifBlank { "YouTube" }
            lista.add(Som(vid, titulo, artista, seg))
            if (lista.size >= 12) break
        }
        return lista
    }

    /** Percorre o JSON do YouTube e junta todos os "videoRenderer" (os vídeos do resultado). */
    private fun coletar(n: Any?, out: MutableList<JSONObject>) {
        if (out.size >= 20) return
        if (n is JSONObject) {
            val v = n.optJSONObject("videoRenderer")
            if (v != null) out.add(v)
            val ks = n.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                if (k != "videoRenderer") coletar(n.opt(k), out)
            }
        } else if (n is JSONArray) {
            for (i in 0 until n.length()) coletar(n.opt(i), out)
        }
    }

    private fun texto(o: JSONObject?): String {
        if (o == null) return ""
        val simples = o.optString("simpleText")
        if (simples.isNotBlank()) return simples
        val runs = o.optJSONArray("runs") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until runs.length()) sb.append(runs.optJSONObject(i)?.optString("text") ?: "")
        return sb.toString()
    }

    private fun segundos(t: String): Int {
        if (t.isBlank()) return 0
        var s = 0
        for (p in t.split(":")) {
            val n = p.trim().toIntOrNull() ?: return 0
            s = s * 60 + n
        }
        return s
    }

    // ── 2) PEGAR O ÁUDIO (igual ao "-f bestaudio" do index.js) ──

    /**
     * Pega o endereço do áudio.
     *  • SoundCloud: pergunta direto ao CDN (~0,3 s) e, se não der, ao bot.
     *  • YouTube: celular e servidor correm JUNTOS — o servidor só é chamado se o celular não entregar em 1,5 s
     *    (ou se falhar), então quase nunca se espera por um e só depois pelo outro.
     */
    fun resolver(id: String, evitar: Set<String>, soDireto: Boolean = false): Fluxo {
        val f0 = MusicaStore.faixa(id)
        val dica = MusicaStore.dica(id)
        val forcarSrv = "cdn" in evitar // o link direto já falhou nesta música: usa o servidor
        if (!id.startsWith("sc_")) {
            if (soDireto || evitar.isNotEmpty() || celularEmPausa()) {
                val y = resolverYt(id, evitar)
                if (y != null) return y
                if ("px" !in evitar) { val p = viaProxies(id); if (p != null) return p }
                if (soDireto) throw IOException("YouTube indisponível")
            } else {
                return corridaYoutube(id, forcarSrv)
            }
        }
        if (dica != null && !forcarSrv) {
            // caminho rápido: o celular pergunta direto ao SoundCloud (sem passar pelo bot)
            try {
                val u = diretoSc(dica.first, dica.second)
                if (u != null) return Fluxo(u, UA_WEB, "cdn", System.currentTimeMillis() + 8 * 60_000L,
                    f0?.titulo ?: "Música", f0?.artista ?: "Artista", f0?.duracao ?: 0)
            } catch (e: Exception) { }
        }
        if (soDireto) throw IOException("sem caminho rápido") // downloads/pré-carga em segundo plano NÃO ocupam a fila do bot
        return viaServidor(id, forcarSrv)
    }

    /** Pede ao bot (/musica/preparar). Se ele devolver o endereço do CDN, toca direto de lá; senão usa o /musica/audio do bot. */
    private fun viaServidor(id: String, forcarSrv: Boolean): Fluxo {
        // YouTube: o IP do servidor costuma ser barrado → não vale esperar minutos (antes: 120 s). SoundCloud pode demorar mais.
        val espera = if (id.startsWith("sc_")) 40_000 else 12_000
        val j = try { servidor("/musica/preparar?id=" + id + (if (forcarSrv) "&force=1" else "") + "&" + auth(), espera) }
            catch (e: IOException) {
                if (!id.startsWith("sc_") && motivoYt.isNotBlank()) throw IOException("YouTube no celular → " + motivoYt)
                throw e
            }
        val f = MusicaStore.faixa(id)
        val titulo = f?.titulo ?: "Música"
        val artista = f?.artista ?: "YouTube"
        val dur = f?.duracao ?: 0
        val direto = j.optString("url")
        if (direto.startsWith("http") && !forcarSrv) {
            return Fluxo(direto, UA_WEB, "cdn", System.currentTimeMillis() + 8 * 60_000L, titulo, artista, dur)
        }
        return Fluxo(
            url = Net.base() + "/musica/audio?id=" + id + (if (forcarSrv) "&force=1" else "") + "&" + auth(),
            ua = "ZerounAutomed", cliente = "srv",
            expira = System.currentTimeMillis() + 3 * 3600_000L,
            titulo = titulo, artista = artista, duracao = dur
        )
    }

    private class Resp(val fluxo: Fluxo?, val erro: Exception?)

    private fun corridaYoutube(id: String, forcarSrv: Boolean): Fluxo {
        val fila = LinkedBlockingQueue<Resp>()
        var servidorIniciado = false
        var esperando = 1
        fun iniciarServidor() {
            if (servidorIniciado) return
            servidorIniciado = true; esperando += 2
            Thread {
                try { fila.put(Resp(viaProxies(id), null)) } catch (e: Exception) { fila.put(Resp(null, e)) }
            }.apply { isDaemon = true }.start()
            Thread {
                try { fila.put(Resp(viaServidor(id, forcarSrv), null)) } catch (e: Exception) { fila.put(Resp(null, e)) }
            }.apply { isDaemon = true }.start()
        }
        Thread {
            try { fila.put(Resp(resolverYt(id, emptySet()), null)) } catch (e: Exception) { fila.put(Resp(null, e)) }
        }.apply { isDaemon = true }.start()
        val chamarServidorEm = System.currentTimeMillis() + 1_500L
        var ultimoErro: Exception? = null
        while (esperando > 0) {
            val espera = if (servidorIniciado) (if (id.startsWith("sc_")) 42_000L else 14_000L) else (chamarServidorEm - System.currentTimeMillis()).coerceAtLeast(0L)
            val r = fila.poll(espera, TimeUnit.MILLISECONDS)
            if (r == null) { if (!servidorIniciado) iniciarServidor() else break; continue }
            esperando--
            if (r.fluxo != null) return r.fluxo
            if (r.erro != null) ultimoErro = r.erro
            iniciarServidor() // o celular falhou: não espera mais, vai ao servidor já
        }
        throw ultimoErro ?: IOException("Não consegui o áudio dessa música.")
    }

    /** Manda o servidor baixar uma música do YouTube agora (para tocar na hora quando o usuário clicar). */
    fun aquecerServidor(id: String) { try { servidor("/musica/aquecer?id=" + id + "&" + auth(), 10_000) } catch (e: Exception) { } }

    /** Pergunta ao servidor por que a música não toca (para mostrar o motivo real). "" = sem resposta útil. */
    fun motivo(id: String): String = if (!id.startsWith("sc_") && motivoYt.isNotBlank()) "YouTube no celular → " + motivoYt
        else if (!id.startsWith("sc_")) "o YouTube negou o áudio ao tocar (link recusado)" else try { servidor("/musica/preparar?id=" + id + "&force=1&" + auth(), 30_000); "" } catch (e: Exception) { e.message ?: "" }

    @Volatile private var cidSc = ""

    private fun clienteSc(): String {
        if (cidSc.isNotBlank()) return cidSc
        cidSc = servidor("/musica/cid?" + auth(), 10_000).optString("cid")
        return cidSc
    }

    /** Endereço direto do mp3 no CDN do SoundCloud, pedido pelo próprio celular (~0,3 s). null = usa o bot. */
    private fun diretoSc(prog: String, aut: String): String? {
        val cid = clienteSc()
        if (cid.isBlank()) return null
        val url = prog + (if (prog.contains("?")) "&" else "?") + "client_id=" + cid +
            (if (aut.isNotBlank()) "&track_authorization=" + java.net.URLEncoder.encode(aut, "UTF-8") else "")
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 5_000
            c.readTimeout = 6_000
            c.setRequestProperty("User-Agent", UA_WEB)
            if (c.responseCode !in 200..299) { cidSc = ""; return null } // client_id velho: o bot renova
            val u = JSONObject(c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }).optString("url")
            return if (u.startsWith("http")) u else null
        } finally {
            c.disconnect()
        }
    }

    /** Escolhe o melhor áudio: m4a (AAC) de maior qualidade; se não tiver, qualquer áudio; por último o vídeo completo. */
    private fun melhorAudio(sd: JSONObject?): String? {
        if (sd == null) return null
        val ad = sd.optJSONArray("adaptiveFormats")
        var melhor: String? = null
        var nota = -1L
        if (ad != null) {
            for (i in 0 until ad.length()) {
                val f = ad.optJSONObject(i) ?: continue
                val mime = f.optString("mimeType")
                val u = f.optString("url")
                if (!mime.startsWith("audio/") || u.isBlank()) continue
                val n = f.optLong("bitrate", 0L) + (if (mime.contains("mp4")) 1_000_000_000L else 0L)
                if (n > nota) { nota = n; melhor = u }
            }
        }
        if (melhor != null) return melhor
        val fm = sd.optJSONArray("formats")
        if (fm != null) {
            for (i in 0 until fm.length()) {
                val u = fm.optJSONObject(i)?.optString("url").orEmpty()
                if (u.isNotBlank()) return u
            }
        }
        return null
    }
}

// ───────────────────────── JSON no celular ─────────────────────────

/**
 * Tudo num arquivo só: files/musica.json
 *   "faixas"   → músicas que o usuário clicou (não precisa pesquisar de novo)
 *   "streams"  → endereço do áudio já descoberto (toca na hora enquanto não vence)
 *   "buscas"   → resultados de cada pesquisa (repetir a busca não vai ao YouTube)
 *   "usuarios" → por usuário: quantas vezes ouviu e quando (Mais ouvidas / Recentes)
 * Fica no celular: continua aí quando a key acaba e quando se compra outra.
 */
object MusicaStore {
    private const val MAX_BUSCAS = 200
    private const val MAX_FAIXAS = 2000
    private val lock = Any()
    private val gravador = Executors.newSingleThreadScheduledExecutor()
    private val salvarPendente = AtomicBoolean(false)
    private var arquivo: File? = null
    private var iniciado = false

    private val faixas = LinkedHashMap<String, Som>()
    private val streams = HashMap<String, Fluxo>()
    private val buscas = LinkedHashMap<String, Pair<Long, List<Som>>>()
    private val usuarios = HashMap<String, HashMap<String, Uso>>()
    private val playlists = LinkedHashMap<String, Playlist>()
    private val dicas = HashMap<String, Pair<String, String>>()

    /** Sobe a cada mudança: as telas usam isso pra se atualizar. */
    var versao by mutableIntStateOf(0)
        private set

    fun init(c: Context) {
        if (iniciado) return
        iniciado = true
        val app = c.applicationContext
        Capas.init(app)
        Baixados.init(app)
        Pre.init(app)
        Tocador.init(app)
        arquivo = File(app.filesDir, "musica.json")
        carregar()
        synchronized(lock) { garantirFavoritas() }
        versao = versao + 1
    }

    private fun usuario(): String = Prefs.deviceId

    private fun faixaJson(f: Som): JSONObject = JSONObject()
        .put("id", f.id).put("titulo", f.titulo).put("artista", f.artista).put("duracao", f.duracao)

    private fun faixaDe(o: JSONObject): Som = Som(
        o.optString("id"), o.optString("titulo"), o.optString("artista"), o.optInt("duracao", 0)
    )

    private fun carregar() {
        try {
            val f = arquivo ?: return
            if (!f.exists()) return
            val raiz = JSONObject(f.readText(Charsets.UTF_8))
            synchronized(lock) {
                val fa = raiz.optJSONObject("faixas")
                if (fa != null) {
                    val ks = fa.keys()
                    while (ks.hasNext()) {
                        val k = ks.next()
                        val x = faixaDe(fa.getJSONObject(k))
                        if (x.id.isNotBlank()) faixas[k] = x
                    }
                }
                val st = raiz.optJSONObject("streams")
                if (st != null) {
                    val ks = st.keys()
                    while (ks.hasNext()) {
                        val k = ks.next()
                        val o = st.getJSONObject(k)
                        streams[k] = Fluxo(
                            o.optString("url"), o.optString("ua"), o.optString("cliente"), o.optLong("expira"),
                            o.optString("titulo"), o.optString("artista"), o.optInt("duracao")
                        )
                    }
                }
                val bu = raiz.optJSONObject("buscas")
                if (bu != null) {
                    val ks = bu.keys()
                    while (ks.hasNext()) {
                        val k = ks.next()
                        val o = bu.getJSONObject(k)
                        val arr = o.optJSONArray("itens") ?: JSONArray()
                        val lista = ArrayList<Som>()
                        for (i in 0 until arr.length()) lista.add(faixaDe(arr.getJSONObject(i)))
                        buscas[k] = Pair(o.optLong("ts"), lista)
                    }
                }
                val us = raiz.optJSONObject("usuarios")
                if (us != null) {
                    val ks = us.keys()
                    while (ks.hasNext()) {
                        val u = ks.next()
                        val m = HashMap<String, Uso>()
                        val o = us.getJSONObject(u)
                        val ids = o.keys()
                        while (ids.hasNext()) {
                            val id = ids.next()
                            val x = o.getJSONObject(id)
                            m[id] = Uso(x.optInt("plays"), x.optLong("ultimo"))
                        }
                        usuarios[u] = m
                    }
                }
                val di = raiz.optJSONObject("dicas")
                if (di != null) {
                    val ks = di.keys()
                    while (ks.hasNext()) {
                        val k = ks.next()
                        val o = di.optJSONObject(k) ?: continue
                        dicas[k] = Pair(o.optString("p"), o.optString("a"))
                    }
                }
                val pls = raiz.optJSONArray("playlists")
                if (pls != null) {
                    for (i in 0 until pls.length()) {
                        val o = pls.optJSONObject(i) ?: continue
                        val id = o.optString("id")
                        if (id.isBlank()) continue
                        val ids = ArrayList<String>()
                        val arr = o.optJSONArray("faixas") ?: JSONArray()
                        for (k in 0 until arr.length()) ids.add(arr.optString(k))
                        playlists[id] = Playlist(id, o.optString("nome", "Playlist"), ids, o.optLong("criada"))
                    }
                }
            }
            versao = versao + 1
        } catch (e: Exception) {
            // arquivo estragado: começa do zero (o antigo é sobrescrito no próximo salvar)
        }
    }

    /**
     * Antes: cada clique/play montava o JSON inteiro NA TELA (travava um pouco e atrasava o play).
     * Agora: junta várias mudanças e grava 0,7 s depois em segundo plano. [urgente] (playlists) grava já.
     */
    private fun salvar(urgente: Boolean = false) {
        if (arquivo == null) return
        if (urgente) { gravador.execute { salvarPendente.set(false); gravarAgora() }; return }
        if (!salvarPendente.compareAndSet(false, true)) return
        gravador.schedule({ salvarPendente.set(false); gravarAgora() }, 700L, TimeUnit.MILLISECONDS)
    }

    private fun gravarAgora() {
        val alvo = arquivo ?: return
        val txt: String
        synchronized(lock) {
            val raiz = JSONObject()
            val fa = JSONObject(); faixas.forEach { (k, v) -> fa.put(k, faixaJson(v)) }
            val st = JSONObject()
            streams.forEach { (k, v) ->
                st.put(k, JSONObject().put("url", v.url).put("ua", v.ua).put("cliente", v.cliente)
                    .put("expira", v.expira).put("titulo", v.titulo).put("artista", v.artista).put("duracao", v.duracao))
            }
            val bu = JSONObject()
            buscas.forEach { (k, v) ->
                val arr = JSONArray(); v.second.forEach { arr.put(faixaJson(it)) }
                bu.put(k, JSONObject().put("ts", v.first).put("itens", arr))
            }
            val us = JSONObject()
            usuarios.forEach { (u, m) ->
                val o = JSONObject()
                m.forEach { (id, x) -> o.put(id, JSONObject().put("plays", x.plays).put("ultimo", x.ultimo)) }
                us.put(u, o)
            }
            val pl = JSONArray()
            playlists.values.forEach { p ->
                val ids = JSONArray(); p.faixas.forEach { ids.put(it) }
                pl.put(JSONObject().put("id", p.id).put("nome", p.nome).put("criada", p.criada).put("faixas", ids))
            }
            raiz.put("playlists", pl)
            val di = JSONObject()
            dicas.forEach { (k, v) -> di.put(k, JSONObject().put("p", v.first).put("a", v.second)) }
            raiz.put("dicas", di)
            raiz.put("versao", 1).put("faixas", fa).put("streams", st).put("buscas", bu).put("usuarios", us)
            txt = raiz.toString()
        }
        try {
            val tmp = File(alvo.parentFile, "musica.json.tmp")
            tmp.writeText(txt, Charsets.UTF_8)
            if (!tmp.renameTo(alvo)) { alvo.writeText(txt, Charsets.UTF_8); tmp.delete() }
        } catch (e: Exception) { }
    }

    fun mudou() { Estado.ui { versao = versao + 1 } }

    // ── buscas ──

    private fun chave(q: String) = q.trim().lowercase().replace(Regex("\\s+"), " ")

    fun buscaCache(q: String): List<Som>? = synchronized(lock) { buscas[chave(q)]?.second }

    /** Últimas pesquisas (a mais nova primeiro), sem links. */
    fun buscasRecentes(n: Int): List<String> = synchronized(lock) {
        buscas.keys.toList().asReversed().filter { !it.startsWith("http") }.take(n)
    }

    fun apagarBusca(q: String) {
        synchronized(lock) { buscas.remove(chave(q)) }
        salvar(); mudou()
    }

    fun guardarBusca(q: String, lista: List<Som>) {
        synchronized(lock) {
            val k = chave(q)
            buscas.remove(k)
            buscas[k] = Pair(System.currentTimeMillis(), lista)
            while (buscas.size > MAX_BUSCAS) buscas.remove(buscas.keys.first())
        }
        salvar(); mudou()
    }

    // ── músicas clicadas ──

    fun guardarFaixa(f: Som) {
        synchronized(lock) {
            faixas.remove(f.id)
            faixas[f.id] = f
            while (faixas.size > MAX_FAIXAS) {
                val emUso = playlists.values.flatMap { it.faixas }.toSet()
                val velho = faixas.keys.firstOrNull { it !in emUso } ?: break
                faixas.remove(velho); streams.remove(velho)
            }
        }
        salvar()
    }

    fun faixa(id: String): Som? = synchronized(lock) { faixas[id] }

    /** Todas as músicas que o app conhece (tocadas, favoritas e de playlists). */
    fun todasFaixas(): List<Som> = synchronized(lock) { faixas.values.toList() }

    // ── playlists (igual ao Spotify) ──

    private fun garantirFavoritas() {
        if (playlists.containsKey(ID_FAV)) return
        val resto = LinkedHashMap(playlists)
        playlists.clear()
        playlists[ID_FAV] = Playlist(ID_FAV, "Músicas Favoritas", emptyList(), System.currentTimeMillis())
        playlists.putAll(resto)
    }

    fun listaPlaylists(): List<Playlist> = synchronized(lock) { playlists.values.toList() }

    fun playlist(id: String): Playlist? = synchronized(lock) { playlists[id] }

    /** Músicas da playlist. Nas Favoritas a mais nova aparece primeiro (como o "Curtidas" do Spotify). */
    fun faixasDaPlaylist(id: String): List<Som> = synchronized(lock) {
        val ids = playlists[id]?.faixas ?: return emptyList()
        val lista = ids.mapNotNull { faixas[it] }
        if (id == ID_FAV) lista.reversed() else lista
    }

    fun criarPlaylist(nome: String): String {
        val n = nome.trim().ifBlank { "Minha playlist" }.take(60)
        val id = "pl_" + System.currentTimeMillis().toString(36) + (100..999).random()
        synchronized(lock) { playlists[id] = Playlist(id, n, emptyList(), System.currentTimeMillis()) }
        salvar(true); mudou()
        return id
    }

    /** Playlist vinda de um link: cria uma playlist NOVA (nunca mexe nas suas) e guarda as músicas. */
    fun importarPlaylist(nome: String, lista: List<Som>): String {
        val n = nome.trim().ifBlank { "Playlist importada" }.take(60)
        val id = "pl_" + System.currentTimeMillis().toString(36) + (100..999).random()
        synchronized(lock) {
            lista.forEach { if (!faixas.containsKey(it.id)) faixas[it.id] = it }
            playlists[id] = Playlist(id, n, lista.map { it.id }.distinct(), System.currentTimeMillis())
        }
        salvar(true); mudou()
        return id
    }

    fun renomearPlaylist(id: String, nome: String) {
        if (id == ID_FAV) return
        synchronized(lock) {
            val p = playlists[id] ?: return
            playlists[id] = p.copy(nome = nome.trim().ifBlank { p.nome }.take(60))
        }
        salvar(true); mudou()
    }

    fun excluirPlaylist(id: String) {
        if (id == ID_FAV) return
        synchronized(lock) { playlists.remove(id) }
        salvar(true); mudou()
    }

    fun naPlaylist(plId: String, faixaId: String): Boolean = synchronized(lock) { playlists[plId]?.faixas?.contains(faixaId) == true }

    fun guardarDica(id: String, prog: String, aut: String) {
        synchronized(lock) {
            dicas[id] = Pair(prog, aut)
            if (dicas.size > 3000) dicas.remove(dicas.keys.first())
        }
        salvar()
    }

    fun dica(id: String): Pair<String, String>? = synchronized(lock) { dicas[id] }

    fun emAlgumaPlaylist(id: String): Boolean = synchronized(lock) { playlists.values.any { it.faixas.contains(id) } }

    fun ehFavorita(faixaId: String): Boolean = naPlaylist(ID_FAV, faixaId)

    /** Adiciona se não está / tira se já está. Devolve true se a música ficou DENTRO da playlist. */
    fun alternarNaPlaylist(plId: String, f: Som): Boolean {
        var dentro = false
        synchronized(lock) {
            val p = playlists[plId] ?: return false
            if (!faixas.containsKey(f.id)) faixas[f.id] = f
            if (p.faixas.contains(f.id)) {
                playlists[plId] = p.copy(faixas = p.faixas.filter { it != f.id })
            } else {
                playlists[plId] = p.copy(faixas = p.faixas + f.id)
                dentro = true
            }
        }
        salvar(true); mudou()
        if (dentro) Baixados.agendar(f) // entrou numa playlist → baixa para ouvir sem internet
        return dentro
    }

    fun alternarFavorita(f: Som): Boolean = alternarNaPlaylist(ID_FAV, f)

    fun removerDaPlaylist(plId: String, faixaId: String) {
        synchronized(lock) {
            val p = playlists[plId] ?: return
            playlists[plId] = p.copy(faixas = p.faixas.filter { it != faixaId })
        }
        salvar(true); mudou()
    }

    // ── endereço do áudio ──

    /** Só devolve se ainda vale por mais de 1 minuto. */
    fun stream(id: String): Fluxo? = synchronized(lock) {
        val s = streams[id]
        if (s != null && s.url.isNotBlank() && s.expira - System.currentTimeMillis() > 60_000L) s else null
    }

    fun guardarStream(id: String, fl: Fluxo) {
        synchronized(lock) { streams[id] = fl }
        salvar()
    }

    // ── histórico do usuário ──

    fun registrarPlay(f: Som) {
        synchronized(lock) {
            val m = usuarios.getOrPut(usuario()) { HashMap() }
            val antes = m[f.id]
            m[f.id] = Uso((antes?.plays ?: 0) + 1, System.currentTimeMillis())
        }
        salvar(); mudou()
    }

    fun recentes(n: Int): List<ItemUso> = synchronized(lock) {
        val m = usuarios[usuario()] ?: return emptyList()
        m.entries.sortedByDescending { it.value.ultimo }
            .mapNotNull { e -> faixas[e.key]?.let { ItemUso(it, e.value) } }
            .take(n)
    }

    fun maisOuvidas(n: Int): List<ItemUso> = synchronized(lock) {
        val m = usuarios[usuario()] ?: return emptyList()
        m.entries.filter { it.value.plays > 0 }
            .sortedWith(compareByDescending<Map.Entry<String, Uso>> { it.value.plays }.thenByDescending { it.value.ultimo })
            .mapNotNull { e -> faixas[e.key]?.let { ItemUso(it, e.value) } }
            .take(n)
    }

    fun limparHistorico() {
        synchronized(lock) { usuarios.remove(usuario()) }
        salvar(); mudou()
    }

    fun totalFaixas(): Int = synchronized(lock) { faixas.size }
    fun totalBuscas(): Int = synchronized(lock) { buscas.size }
}

// ───────────────────────── músicas baixadas (tocam SEM internet) ─────────────────────────

/**
 * Guarda o áudio no celular (files/audio). Música que está em alguma playlist é baixada sozinha;
 * na tela da playlist o botão ⬇ baixa todas. Tocar uma música baixada não usa internet nem servidor.
 */
object Baixados {
    private var dir: File? = null
    private val andando = java.util.Collections.synchronizedSet(HashSet<String>())
    private val fila = Executors.newFixedThreadPool(3)

    private var app: Context? = null
    private val pend = java.util.Collections.synchronizedSet(HashSet<String>())
    private val falhas = java.util.concurrent.ConcurrentHashMap<String, Long>()
    private const val MIN_LIVRE = 1_000_000_000L // para de baixar se sobrar menos de ~1 GB no celular

    fun init(c: Context) {
        app = c.applicationContext
        dir = File(c.filesDir, "audio").apply { mkdirs() }
        // assim que o app abre (e a cada 5 min): baixa TUDO que o app conhece, quando estiver no Wi-Fi
        val t = Thread {
            try { Thread.sleep(8_000L) } catch (e: Exception) { }
            while (true) {
                try { automatico() } catch (e: Exception) { }
                try { Thread.sleep(5 * 60_000L) } catch (e: Exception) { }
            }
        }
        t.isDaemon = true
        t.start()
    }

    /** Wi-Fi (rede sem cobrança por dado). Evita gastar o plano de dados do celular. */
    private fun redeLivre(): Boolean {
        val cm = app?.getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager ?: return false
        val n = cm.activeNetwork ?: return false
        val cap = cm.getNetworkCapabilities(n) ?: return false
        return cap.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            cap.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
    }

    private fun automatico() {
        if (Prefs.key.isBlank() || !redeLivre()) return
        val d = dir ?: return
        if (d.usableSpace < MIN_LIVRE) return
        MusicaStore.todasFaixas().forEach { agendar(it) }
    }

    fun faltam(): Int = MusicaStore.todasFaixas().count { !tem(it.id) }

    fun arquivo(id: String): File? {
        val d = dir ?: return null
        val f = File(d, "$id.audio")
        return if (f.exists() && f.length() > 20_000L) f else null
    }

    fun tem(id: String): Boolean = arquivo(id) != null

    fun baixando(id: String): Boolean = andando.contains(id)

    fun emAndamento(): Int = andando.size

    fun total(): Int = dir?.listFiles()?.count { it.name.endsWith(".audio") } ?: 0

    fun apagar(id: String) {
        try { File(dir ?: return, "$id.audio").delete() } catch (e: Exception) { }
        MusicaStore.mudou()
    }

    fun agendar(f: Som) {
        if (tem(f.id) || andando.contains(f.id)) return
        val ultima = falhas[f.id]
        if (ultima != null && System.currentTimeMillis() - ultima < 3600_000L) return // falhou há pouco: espera 1 h
        if (!pend.add(f.id)) return
        fila.execute {
            try { garantir(f) } finally { pend.remove(f.id) }
        }
    }

    fun baixarLista(lista: List<Som>) { lista.forEach { agendar(it) } }

    private fun garantir(f: Som) {
        if (tem(f.id) || !andando.add(f.id)) return
        MusicaStore.mudou()
        try {
            val fl = MusicaStore.stream(f.id) ?: YT.resolver(f.id, emptySet(), true).also { MusicaStore.guardarStream(f.id, it) }
            baixar(f.id, fl)
        } catch (e: Exception) {
            falhas[f.id] = System.currentTimeMillis() // sem internet / servidor fora: tenta de novo depois
        } finally {
            andando.remove(f.id)
            MusicaStore.mudou()
        }
    }

    private fun baixar(id: String, fl: Fluxo) {
        val d = dir ?: return
        val tmp = File(d, "$id.tmp")
        val c = URL(fl.url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = 30_000
            c.setRequestProperty("User-Agent", fl.ua)
            if (c.responseCode !in 200..299) throw IOException("HTTP " + c.responseCode)
            c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o, 64 * 1024) } }
        } finally {
            c.disconnect()
        }
        if (tmp.length() < 20_000L || !tmp.renameTo(File(d, "$id.audio"))) {
            tmp.delete()
            throw IOException("download incompleto")
        }
        try { Capas.carregar(id) } catch (e: Exception) { }
    }
}

// ───────────────────────── pré-carga (faz tocar / avançar ser instantâneo) ─────────────────────────

/**
 * Baixa o áudio ANTES de o usuário pedir: os primeiros resultados da busca e as próximas/anterior da fila.
 * Quando ele toca (ou aperta avançar), o arquivo já está no celular e abre na hora, sem rede.
 * Fica em cache/pre (o Android pode limpar) e é limitado a [MAX_MB]. Não conta como "baixada" das playlists.
 */
object Pre {
    private var dir: File? = null
    private val andando = java.util.Collections.synchronizedSet(HashSet<String>())
    private val pool = Executors.newFixedThreadPool(5)
    private const val MAX_MB = 400L

    fun init(c: Context) {
        dir = File(c.cacheDir, "pre").apply { mkdirs() }
        pool.execute { limpar() }
    }

    fun arquivo(id: String): File? {
        val d = dir ?: return null
        val f = File(d, "$id.audio")
        return if (f.exists() && f.length() > 20_000L) { f.setLastModified(System.currentTimeMillis()); f } else null
    }

    fun apagar(id: String) { try { File(dir ?: return, "$id.audio").delete() } catch (e: Exception) { } }

    /** Baixa o áudio inteiro de cada música da [lista] (se ainda não estiver no celular). */
    fun pedir(lista: List<Som>) { lista.forEach { pedir(it) } }

    private val avisados = java.util.Collections.synchronizedSet(HashSet<String>())

    fun pedir(f: Som) {
        if (dir == null || Baixados.tem(f.id) || arquivo(f.id) != null || !andando.add(f.id)) return
        pool.execute {
            try {
                var fl = MusicaStore.stream(f.id)
                try {
                    if (fl == null) fl = YT.resolver(f.id, emptySet(), true).also { MusicaStore.guardarStream(f.id, it) }
                    baixar(f.id, fl)
                } catch (e: Exception) {
                    // endereço salvo vencido: pede um novo uma vez
                    val novo = YT.resolver(f.id, emptySet(), true).also { MusicaStore.guardarStream(f.id, it) }
                    baixar(f.id, novo)
                }
            } catch (e: Exception) {
            } finally { andando.remove(f.id) }
        }
    }

    fun emAndamento(id: String): Boolean = andando.contains(id)

    /** Só descobre e guarda o endereço de cada música (leve): tocar uma delas pula essa etapa. */
    fun aquecerEnderecos(lista: List<Som>) {
        lista.forEach { f ->
            if (MusicaStore.stream(f.id) != null || Baixados.tem(f.id) || arquivo(f.id) != null) return@forEach
            pool.execute {
                try { MusicaStore.guardarStream(f.id, YT.resolver(f.id, emptySet(), true)) } catch (e: Exception) { }
            }
        }
    }

    /** Resultados de uma busca: as 3 primeiras já vêm inteiras, as outras só com o endereço pronto. */
    fun aquecerBusca(lista: List<Som>) {
        pedir(lista.take(5))
        aquecerEnderecos(lista.drop(5).take(5))
    }

    /** Logo que o primeiro resultado aparece: só o 1º (leve), para não disputar o servidor com a busca ainda em andamento. */
    fun aquecerPrimeira(lista: List<Som>) { pedir(lista.take(1)) }

    /** Baixa em pedaços de 2 MB (o YouTube limita pedidos sem Range); se o servidor não aceitar Range, lê tudo de uma vez. */
    private fun baixar(id: String, fl: Fluxo) {
        val d = dir ?: return
        val tmp = File(d, "$id.tmp")
        val o = java.io.FileOutputStream(tmp)
        try {
            var pos = 0L
            var feito = false
            while (!feito) {
                val c = URL(fl.url).openConnection() as HttpURLConnection
                try {
                    c.connectTimeout = 8_000
                    c.readTimeout = 15_000
                    c.setRequestProperty("User-Agent", fl.ua)
                    c.setRequestProperty("Range", "bytes=" + pos + "-" + (pos + 2_000_000L - 1))
                    val code = c.responseCode
                    if (code == 200) {
                        c.inputStream.copyTo(o, 64 * 1024)
                        feito = true
                    } else if (code == 206) {
                        val total = c.getHeaderField("Content-Range")?.substringAfter('/')?.trim()?.toLongOrNull() ?: -1L
                        val n = c.inputStream.copyTo(o, 64 * 1024)
                        pos += n
                        feito = n <= 0L || (total > 0L && pos >= total) || (total <= 0L && n < 2_000_000L)
                    } else throw IOException("HTTP " + code)
                } finally {
                    c.disconnect()
                }
            }
        } catch (e: Exception) {
            try { o.close() } catch (x: Exception) { }
            tmp.delete(); throw e
        }
        try { o.close() } catch (x: Exception) { }
        if (tmp.length() < 20_000L || !tmp.renameTo(File(d, "$id.audio"))) { tmp.delete(); return }
        limpar()
    }

    /** Mantém a pasta abaixo de [MAX_MB]: apaga as menos usadas primeiro. */
    private fun limpar() {
        try {
            val arqs = (dir?.listFiles() ?: return).filter { it.isFile }
            var total = arqs.sumOf { it.length() }
            for (a in arqs.sortedBy { it.lastModified() }) {
                if (total <= MAX_MB * 1048576L) break
                if (andando.contains(a.name.substringBefore('.'))) continue
                total -= a.length(); a.delete()
            }
        } catch (e: Exception) { }
    }
}

// ───────────────────────── capas (miniaturas) ─────────────────────────

/** Baixa a capa uma vez e guarda no celular (files/capas) — da próxima vez abre na hora, até sem internet. */
object Capas {
    private var dir: File? = null
    private val mem = object : android.util.LruCache<String, ImageBitmap>(80) {}

    fun init(c: Context) { dir = File(c.filesDir, "capas").apply { mkdirs() } }

    fun memoria(id: String): ImageBitmap? = mem.get(id)

    fun carregar(id: String): ImageBitmap? {
        val cacheado = mem.get(id)
        if (cacheado != null) return cacheado
        val d = dir ?: return null
        val f = File(d, "$id.jpg")
        if (!f.exists() || f.length() < 100L) {
            try {
                val c = URL(Net.base() + "/musica/capa?id=" + id + "&" + YT.auth()).openConnection() as HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 10000
                if (c.responseCode == 200) {
                    val tmp = File(d, "$id.tmp")
                    c.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                    tmp.renameTo(f)
                }
                c.disconnect()
            } catch (e: Exception) { }
        }
        val bmp = try { BitmapFactory.decodeFile(f.absolutePath) } catch (e: Exception) { null }
        if (bmp == null) return null
        val img = bmp.asImageBitmap()
        mem.put(id, img)
        return img
    }
}

// ───────────────────────── busca (estado da tela) ─────────────────────────

object MusicaBusca {
    var texto by mutableStateOf("")
    var resultados by mutableStateOf<List<Som>?>(null)
    var doCache by mutableStateOf(false)
    var buscando by mutableStateOf(false)
    var erro by mutableStateOf("")
    private var geracao = 0

    fun limpar() { geracao++; texto = ""; resultados = null; erro = ""; doCache = false; buscando = false }

    /** [forcar] = ignora o que está salvo e pesquisa de novo. Os resultados aparecem assim que a 1ª fonte responde. */
    fun pesquisar(forcar: Boolean = false) {
        val q = texto.trim()
        if (q.isEmpty()) return
        val g = ++geracao
        erro = ""
        if (!forcar) {
            val salvo = MusicaStore.buscaCache(q)
            if (salvo != null) { resultados = salvo; doCache = true; buscando = false; Pre.aquecerBusca(salvo); return }
        }
        buscando = true
        Thread {
            var primeira = true
            try {
                val lista = YT.buscarProgressivo(q) { parcial, fim ->
                    if (primeira) { primeira = false; Pre.aquecerPrimeira(parcial) }
                    if (fim) { MusicaStore.guardarBusca(q, parcial); Pre.aquecerBusca(parcial) }
                    Estado.ui { if (g == geracao) { resultados = parcial; doCache = false; buscando = false } }
                }
                if (lista.isEmpty()) Estado.ui { if (g == geracao) buscando = false }
            } catch (e: Exception) {
                val msg = if (YT.semRede(e)) "Sem internet. Você ainda pode tocar as músicas baixadas (aba Playlists)."
                    else (e.message ?: YT.detalhe(e))
                Estado.ui { if (g == geracao) { buscando = false; erro = msg } }
            }
        }.start()
    }
}

// ───────────────────────── link de playlist (compartilhar / importar) ─────────────────────────

/**
 * O link carrega a playlist INTEIRA dentro dele (nome + músicas, comprimido) — não precisa de servidor.
 * Formato: zeroun://playlist/<texto>. Quem recebe cola em Playlists → "Colar link" e a playlist vira dele (cópia nova).
 */
object LinkPlaylist {
    private const val PREFIXO = "zeroun://playlist/"
    private val re = Regex("zeroun://playlist/([A-Za-z0-9_\\-]+)")
    private val reId = Regex("^[A-Za-z0-9_\\-]{1,40}$")
    const val MAX = 300
    private const val FLAGS = android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING

    class Lida(val nome: String, val faixas: List<Som>)

    fun ehLink(texto: String): Boolean = re.containsMatchIn(texto)

    fun gerar(nome: String, lista: List<Som>): String {
        val arr = JSONArray()
        lista.take(MAX).forEach { arr.put(JSONArray().put(it.id).put(it.titulo).put(it.artista).put(it.duracao)) }
        val j = JSONObject().put("v", 1).put("n", nome).put("f", arr)
        val saida = java.io.ByteArrayOutputStream()
        java.util.zip.GZIPOutputStream(saida).use { it.write(j.toString().toByteArray(Charsets.UTF_8)) }
        return PREFIXO + android.util.Base64.encodeToString(saida.toByteArray(), FLAGS)
    }

    fun ler(texto: String): Lida {
        val token = re.find(texto)?.groupValues?.get(1) ?: throw Exception("Isso não parece um link de playlist da ZEROUN.")
        val txt = try {
            val bruto = android.util.Base64.decode(token, FLAGS)
            java.util.zip.GZIPInputStream(bruto.inputStream()).use { gz ->
                val buf = ByteArray(8192)
                val out = java.io.ByteArrayOutputStream()
                while (true) {
                    val n = gz.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    if (out.size() > 2_000_000) throw Exception("grande demais")
                }
                out.toString("UTF-8")
            }
        } catch (e: Exception) { throw Exception("Link incompleto ou estragado. Copie o link inteiro de novo.") }
        val j = try { JSONObject(txt) } catch (e: Exception) { throw Exception("Link incompleto ou estragado. Copie o link inteiro de novo.") }
        val arr = j.optJSONArray("f") ?: throw Exception("Esse link não tem músicas.")
        val lista = ArrayList<Som>()
        for (i in 0 until minOf(arr.length(), 500)) {
            val o = arr.optJSONArray(i) ?: continue
            val id = o.optString(0)
            if (!reId.matches(id) || lista.any { it.id == id }) continue
            val titulo = o.optString(1).trim().take(200)
            if (titulo.isBlank()) continue
            lista.add(Som(id, titulo, o.optString(2).trim().take(120).ifBlank { "YouTube" }, o.optInt(3).coerceIn(0, 86_400)))
        }
        if (lista.isEmpty()) throw Exception("Esse link não tem músicas.")
        return Lida(j.optString("n").trim().take(60).ifBlank { "Playlist importada" }, lista)
    }

    /** Texto pronto para mandar no WhatsApp/Discord/etc. */
    fun mensagem(nome: String, qtd: Int, link: String): String =
        "🎵 Playlist \"" + nome + "\" · " + qtd + (if (qtd == 1) " música" else " músicas") +
            "\nZEROUN MÚSICA → aba Playlists → \"Colar link\" e cole isto:\n" + link
}
