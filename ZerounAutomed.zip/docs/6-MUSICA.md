# 🎵 Aba Música — "Mediação com música"

Botão **Música** na barra de baixo (entre *Salas* e *Controle*).

## O que tem na tela
| Parte | O que faz |
|---|---|
| 🔎 Barra de pesquisa | Digite o nome da música ou cole um link do YouTube (igual ao `!play` do `index.js`) |
| Resultados | Toque numa música para tocar. Ficam salvos: repetir a mesma busca **não vai ao YouTube** (botão *Atualizar* força uma busca nova) |
| 🔥 Mais ouvidas | As músicas que **o usuário** mais tocou (conta como ouvida quando o áudio realmente começa) |
| 🕘 Recentes | As últimas músicas **do usuário** (cada usuário só vê as suas) |
| ▶ Player (embaixo) | Play/pausa, anterior, próxima, barra de tempo e fechar. Continua tocando com a tela apagada (notificação com botões) |

## Como procura e toca (igual ao index.js)
| index.js (bot de call) | App (no celular) |
|---|---|
| `yt-dlp ytsearch1:<busca>` → título + link | `YT.buscar()` → busca no YouTube, devolve título, canal, duração e capa |
| `yt-dlp -f bestaudio` | `YT.resolver()` → pega o melhor áudio (m4a) |
| `cache` (busca → resultado) | `MusicaStore` → `files/musica.json` |
| `ffmpeg` → Discord | `MediaPlayer` toca no próprio celular |

## O que fica salvo no celular (`files/musica.json` + `files/capas/`)
- `faixas`: músicas em que o usuário clicou · `buscas`: resultado de cada pesquisa · `streams`: endereço do áudio (reaproveitado enquanto vale, ~6 h) · `usuarios`: plays e última vez de cada usuário.
- **Não usa a key nem o servidor.** Se a key acabar, tudo continua salvo; ao comprar outra, as músicas e buscas já estão lá (Sair/trocar de key não apaga nada).
- Entra no backup do Google (`allowBackup`), então reinstalar o app restaura.

## Se a música parar de tocar um dia
O YouTube muda de vez em quando (o mesmo acontece com o yt-dlp). A lista de "clientes" fica no topo de `Musica.kt` (`YT.clientes`): atualize as versões lá e lance o app de novo. A busca e o histórico não são afetados.

## Arquivos
`Musica.kt` (YouTube + JSON + capas + estado da busca) · `Tocador.kt` (player e serviço da notificação) · `MusicaUI.kt` (tela).
